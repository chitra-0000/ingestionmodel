package com.poc.ingest;

import com.poc.ingest.model.LoadStatus;
import com.poc.ingest.model.LoadView;
import com.poc.ingest.repo.LoadLogRepository;
import com.poc.ingest.service.LoadService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Full pipeline against a file-based H2 (not Oracle!) with a small heap, to prove memory stays flat.
 * Run: mvn test -Dtest=PipelineBench -Dbench=true -Dbench.records=1000000 -DargLine=-Xmx512m
 */
@EnabledIfSystemProperty(named = "bench", matches = "true")
@SpringBootTest(properties = {
        "spring.datasource.url=jdbc:h2:file:${java.io.tmpdir}/ingest-bench/db;MODE=Oracle;DB_CLOSE_DELAY=-1",
        "ingest.batch-size=5000", "ingest.writer-threads=4", "ingest.sample-records=20000"})
class PipelineBench {

    @Autowired
    LoadService loadService;
    @Autowired
    LoadLogRepository loads;

    @Test
    void xml() throws Exception {
        int n = Integer.getInteger("bench.records", 1_000_000);
        Path dir = Paths.get(System.getProperty("java.io.tmpdir"), "ingest-bench");
        Files.createDirectories(dir);
        Path xml = dir.resolve("dj-bench.xml");
        TestFiles.XmlSpec spec = new TestFiles.XmlSpec();
        spec.persons = n;
        TestFiles.djXml(xml, spec);
        LoadView v;
        try (InputStream in = Files.newInputStream(xml)) {
            v = loadService.submit("Bench", "dj-bench.xml", in);
        }
        long maxUsed = 0;
        while (true) {
            LoadView now = loads.find(v.getLoadId());
            Runtime rt = Runtime.getRuntime();
            maxUsed = Math.max(maxUsed, rt.totalMemory() - rt.freeMemory());
            if (now.getStatus() != LoadStatus.QUEUED && now.getStatus() != LoadStatus.LOADING) {
                System.out.printf("PIPELINE: %s %,d rows in %,d ms (%,.0f rows/s), peak heap used %,d MB of max %,d MB%n",
                        now.getStatus(), now.getRowsInserted(), now.getDurationMs(),
                        now.getRowsInserted() * 1000.0 / now.getDurationMs(), maxUsed >> 20, rt.maxMemory() >> 20);
                assertThat(now.getStatus()).isIn(LoadStatus.SUCCESS, LoadStatus.NEW_FIELDS);
                break;
            }
            Thread.sleep(200);
        }
    }
}
