package com.poc.ingest;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

/** Minimal JSON_VALUE for H2: supports the '$.unmapped."key"' paths the backfill uses. */
public final class H2Functions {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private H2Functions() {
    }

    public static String jsonValue(String json, String path) throws IOException {
        if (json == null) {
            return null;
        }
        JsonNode n = MAPPER.readTree(json);
        String p = path.substring(2); // after "$."
        int dot = p.indexOf('.');
        n = n.get(p.substring(0, dot));
        String key = p.substring(dot + 1);
        if (key.startsWith("\"")) {
            key = key.substring(1, key.length() - 1);
        }
        if (n == null || n.get(key) == null || !n.get(key).isValueNode() || n.get(key).isNull()) {
            return null;
        }
        return n.get(key).asText();
    }
}
