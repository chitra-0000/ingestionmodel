package com.poc.ingest;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Generates Dow Jones-like XML and wide CSV test files.
 * Also runnable for the benchmark: {@code java -cp target/test-classes com.poc.ingest.TestFiles csv 5000000 out.csv}
 * or {@code ... TestFiles xml 5000000 out.xml}.
 */
public final class TestFiles {

    private TestFiles() {
    }

    /** Options for the XML generator. */
    public static final class XmlSpec {
        int persons = 3000;
        int entityEvery = 50;
        int associations = 40;
        String extraTag;           // e.g. "RiskScore": added to every person
        int longNotesAtPerson = -1; // person number that gets a 6000-character ProfileNotes
    }

    public static void djXml(Path out, XmlSpec s) throws IOException {
        try (Writer w = new BufferedWriter(Files.newBufferedWriter(out, StandardCharsets.UTF_8), 1 << 20)) {
            w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<PFA date=\"2026-11-01\" type=\"full\">\n");
            w.write("  <CountryList>\n");
            String[][] countries = {{"IN", "India"}, {"US", "United States"}, {"GB", "United Kingdom"},
                    {"CH", "Switzerland"}, {"SG", "Singapore"}};
            for (String[] c : countries) {
                w.write("    <CountryName code=\"" + c[0] + "\" name=\"" + c[1] + "\" IsTerritory=\"False\"/>\n");
            }
            w.write("  </CountryList>\n  <OccupationList>\n");
            for (int i = 1; i <= 4; i++) {
                w.write("    <Occupation code=\"" + i + "\" name=\"Occupation " + i + "\"/>\n");
            }
            w.write("  </OccupationList>\n  <Records>\n");
            for (int p = 1; p <= s.persons; p++) {
                person(w, p, s);
                if (s.entityEvery > 0 && p % s.entityEvery == 0) {
                    w.write("    <Entity id=\"E" + p + "\" action=\"add\"><ActiveStatus>Active</ActiveStatus>"
                            + "<NameDetails><Name NameType=\"Primary Name\"><NameValue><EntityName>Company & Co "
                            .replace("&", "&amp;") + p + "</EntityName></NameValue></Name></NameDetails></Entity>\n");
                }
            }
            w.write("  </Records>\n  <Associations>\n");
            for (int a = 1; a <= s.associations; a++) {
                w.write("    <PublicFigure id=\"" + a + "\"><Associate id=\"" + (a + 1) + "\" code=\"11\" ex=\"false\"/>"
                        + "</PublicFigure>\n");
            }
            w.write("  </Associations>\n</PFA>\n");
        }
    }

    private static void person(Writer w, int p, XmlSpec s) throws IOException {
        w.write("    <Person id=\"" + p + "\" action=\"add\" date=\"01-Nov-2026\">");
        w.write("<Gender>" + (p % 2 == 0 ? "Male" : "Female") + "</Gender>");
        w.write("<ActiveStatus>Active</ActiveStatus><Deceased/>");
        w.write("<NameDetails><Name NameType=\"Primary Name\"><NameValue><FirstName>First" + p
                + "</FirstName><Surname>Last" + p + "</Surname></NameValue></Name>");
        if (p % 2 == 0) {
            w.write("<Name NameType=\"Also Known As\"><NameValue><FirstName>Alias" + p + "</FirstName></NameValue></Name>");
        }
        w.write("</NameDetails>");
        w.write("<Descriptions><Description Description1=\"1\" Description2=\"3\"/></Descriptions>");
        w.write("<CountryDetails><Country CountryType=\"Citizenship\"><CountryValue Code=\"IN\"/></Country>");
        if (p % 3 == 0) {
            w.write("<Country CountryType=\"Resident of\"><CountryValue Code=\"GB\"/></Country>");
        }
        w.write("</CountryDetails>");
        if (s.extraTag != null) {
            w.write("<" + s.extraTag + ">" + (p % 100) + "</" + s.extraTag + ">");
        }
        String notes = p == s.longNotesAtPerson ? repeat("Long profile note. ", 320) : "Note " + p;
        w.write("<ProfileNotes>" + notes + "</ProfileNotes>");
        w.write("</Person>\n");
    }

    public static void csv(Path out, int rows, String[] header, int seed) throws IOException {
        try (Writer w = new BufferedWriter(Files.newBufferedWriter(out, StandardCharsets.UTF_8), 1 << 20)) {
            w.write(String.join(",", header));
            w.write("\r\n");
            StringBuilder sb = new StringBuilder(256);
            for (int r = 1; r <= rows; r++) {
                sb.setLength(0);
                for (int c = 0; c < header.length; c++) {
                    if (c > 0) {
                        sb.append(',');
                    }
                    if (c == 2 && r % 10 == 0) {
                        sb.append("\"Smith, \"\"Jr\"\"\nline2\"");
                    } else if (c == 3 && r % 7 == 0) {
                        sb.append("");
                    } else {
                        sb.append(header[c]).append('_').append(r + seed);
                    }
                }
                sb.append("\r\n");
                w.write(sb.toString());
            }
        }
    }

    static String repeat(String s, int n) {
        StringBuilder sb = new StringBuilder(s.length() * n);
        for (int i = 0; i < n; i++) {
            sb.append(s);
        }
        return sb.toString();
    }

    /** Benchmark file generator. */
    public static void main(String[] args) throws IOException {
        if (args.length != 3) {
            throw new IllegalArgumentException("usage: TestFiles csv|xml <records> <output file>");
        }
        int n = Integer.parseInt(args[1]);
        Path out = Paths.get(args[2]);
        if ("xml".equals(args[0])) {
            XmlSpec s = new XmlSpec();
            s.persons = n;
            s.entityEvery = 50;
            s.associations = 1000;
            djXml(out, s);
        } else {
            String[] header = new String[20];
            for (int i = 0; i < header.length; i++) {
                header[i] = "FIELD_" + (i + 1);
            }
            csv(out, n, header, 0);
        }
    }
}
