package com.poc.ingest;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.poc.ingest.model.ChangeStatus;
import com.poc.ingest.model.LoadStatus;
import com.poc.ingest.model.LoadView;
import com.poc.ingest.model.StructureChangeView;
import com.poc.ingest.repo.LoadLogRepository;
import com.poc.ingest.repo.StructureChangeRepository;
import com.poc.ingest.service.LoadService;
import com.poc.ingest.service.StructureChangeService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class IngestEndToEndTest {

    @Autowired
    LoadService loadService;
    @Autowired
    LoadLogRepository loads;
    @Autowired
    StructureChangeRepository changes;
    @Autowired
    StructureChangeService changeService;
    @Autowired
    JdbcTemplate jdbc;
    @Autowired
    MockMvc mvc;

    private final ObjectMapper json = new ObjectMapper();

    @TempDir
    Path tmp;

    private LoadView load(String provider, Path file) throws Exception {
        LoadView v;
        try (InputStream in = Files.newInputStream(file)) {
            v = loadService.submit(provider, file.getFileName().toString(), in);
        }
        long deadline = System.currentTimeMillis() + 120_000;
        while (System.currentTimeMillis() < deadline) {
            LoadView now = loads.find(v.getLoadId());
            if (now.getStatus() != LoadStatus.QUEUED && now.getStatus() != LoadStatus.LOADING
                    && now.getArchiveStatus() != com.poc.ingest.model.ArchiveStatus.PENDING) {
                return now;
            }
            Thread.sleep(50);
        }
        throw new AssertionError("load did not finish");
    }

    private Map<String, String> columnsByPath(long layoutId) throws IOException {
        String d = jdbc.queryForObject("SELECT DESCRIPTOR_JSON FROM INGEST_FORMAT_REGISTRY WHERE LAYOUT_ID = ?",
                String.class, layoutId);
        Map<String, String> m = new java.util.HashMap<>();
        for (JsonNode c : json.readTree(d).get("columns")) {
            m.put(c.get("path").asText(), c.get("name").asText());
        }
        return m;
    }

    @Test
    void xmlProviderLifecycle_lossless_newField_approval_backfill() throws Exception {
        // ---- 1st file: new provider -> new table; sampling sees only the head (1000 records) ----
        TestFiles.XmlSpec spec = new TestFiles.XmlSpec();
        spec.longNotesAtPerson = 2500; // beyond sampling: must survive in EXTRA_JSON.oversize
        Path f1 = tmp.resolve("dj1.xml");
        TestFiles.djXml(f1, spec);
        LoadView v1 = load("Dow Jones", f1);

        assertThat(v1.getStatus()).as(v1.getMessage()).isEqualTo(LoadStatus.SUCCESS);
        assertThat(v1.getTableName()).isEqualTo("RAW_DOW_JONES_XML_1");
        // 3000 persons + 60 entities + 40 associations; 5 countries + 4 occupations
        assertThat(v1.getRecordsParsed()).isEqualTo(3100L);
        assertThat(v1.getRowsInserted()).isEqualTo(3100L);
        assertThat(v1.getRefRows()).isEqualTo(9L);
        // associations were met after sampling: added automatically because the table is new
        assertThat(v1.getMessage()).contains("added as columns automatically");

        String table = v1.getTableName();
        Map<String, String> cols = columnsByPath(v1.getLayoutId());
        assertThat(cols).containsKeys("@id", "Gender", "NameDetails/Name", "CountryDetails/Country", "ProfileNotes",
                "Associate/@code");

        Map<String, Object> p2 = jdbc.queryForMap("SELECT * FROM " + table + " WHERE LOAD_ID = ? AND "
                + cols.get("@id") + " = '2' AND RECORD_TYPE = 'Records/Person'", v1.getLoadId());
        assertThat(p2.get(cols.get("Gender"))).isEqualTo("Male");
        JsonNode names = json.readTree((String) p2.get(cols.get("NameDetails/Name")));
        assertThat(names).hasSize(2);
        assertThat(names.get(1).get("@NameType").asText()).isEqualTo("Also Known As");
        assertThat(names.get(1).get("NameValue").get("FirstName").asText()).isEqualTo("Alias2");
        JsonNode extra2 = json.readTree((String) p2.get("EXTRA_JSON"));
        assertThat(extra2.get("empty").toString()).contains("Deceased"); // <Deceased/> kept as "present but empty"

        Map<String, Object> longOne = jdbc.queryForMap("SELECT EXTRA_JSON, " + cols.get("ProfileNotes")
                + " AS NOTES FROM " + table + " WHERE LOAD_ID = ? AND " + cols.get("@id") + " = '2500'", v1.getLoadId());
        assertThat(longOne.get("NOTES")).isNull();
        assertThat(json.readTree((String) longOne.get("EXTRA_JSON")).get("oversize").get("ProfileNotes").asText())
                .hasSize(6080);

        assertThat(jdbc.queryForObject("SELECT REF_VALUE FROM INGEST_REF_DATA WHERE LOAD_ID = ? AND LIST_NAME = "
                + "'CountryList' AND REF_CODE = 'CH'", String.class, v1.getLoadId())).isEqualTo("Switzerland");
        assertThat(loads.envelope(v1.getLoadId())).contains("\"@date\":\"2026-11-01\"");

        // ---- 2nd file: same layout + a new tag -> same table, approval needed ----
        spec.extraTag = "RiskScore";
        spec.longNotesAtPerson = -1;
        Path f2 = tmp.resolve("dj2.xml");
        TestFiles.djXml(f2, spec);
        LoadView v2 = load("Dow Jones", f2);
        assertThat(v2.getStatus()).isEqualTo(LoadStatus.NEW_FIELDS);
        assertThat(v2.getTableName()).isEqualTo(table);
        List<StructureChangeView> pending = changes.forLoad(v2.getLayoutId(), v2.getLoadId());
        StructureChangeView risk = pending.stream().filter(c -> c.getFieldPath().equals("RiskScore"))
                .findFirst().orElseThrow(AssertionError::new);
        assertThat(risk.getOccurrences()).isEqualTo(3000L);
        assertThat(risk.getStatus()).isEqualTo(ChangeStatus.PENDING);
        String riskInExtra = jdbc.queryForObject("SELECT EXTRA_JSON FROM " + table + " WHERE LOAD_ID = ? AND "
                + cols.get("@id") + " = '42'", String.class, v2.getLoadId());
        assertThat(json.readTree(riskInExtra).get("unmapped").get("RiskScore").asText()).isEqualTo("42");

        // ---- approve via REST with backfill ----
        String body = "{\"changeIds\":[" + risk.getChangeId() + "],\"decidedBy\":\"Chitra\",\"comment\":\"ok\","
                + "\"backfill\":true}";
        MvcResult res = mvc.perform(post("/api/structure-changes/approve")
                .contentType("application/json").content(body)).andExpect(status().isOk()).andReturn();
        assertThat(res.getResponse().getContentAsString()).contains("copied into");
        String riskCol = columnsByPath(v2.getLayoutId()).get("RiskScore");
        assertThat(riskCol).isEqualTo("C" + riskCol.substring(1));
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM " + table + " WHERE " + riskCol + " IS NOT NULL",
                Integer.class)).isEqualTo(3000);

        // second approval of the same field is refused
        mvc.perform(post("/api/structure-changes/approve").contentType("application/json").content(body))
                .andExpect(status().isConflict());

        // ---- 3rd file: lands directly in the new column ----
        Path f3 = tmp.resolve("dj3.xml");
        TestFiles.djXml(f3, spec);
        LoadView v3 = load("Dow Jones", f3);
        assertThat(v3.getStatus()).isEqualTo(LoadStatus.SUCCESS);
        assertThat(jdbc.queryForObject("SELECT " + riskCol + " FROM " + table + " WHERE LOAD_ID = ? AND "
                + cols.get("@id") + " = '42'", String.class, v3.getLoadId())).isEqualTo("42");

        // ---- downloads ----
        MvcResult orig = mvc.perform(get("/api/loads/" + v3.getLoadId() + "/download/original"))
                .andExpect(request().asyncStarted()).andReturn();
        byte[] downloaded = mvc.perform(asyncDispatch(orig)).andExpect(status().isOk()).andReturn()
                .getResponse().getContentAsByteArray();
        assertThat(downloaded).isEqualTo(Files.readAllBytes(f3));

        MvcResult rep = mvc.perform(get("/api/loads/" + v2.getLoadId() + "/download/report"))
                .andExpect(request().asyncStarted()).andReturn();
        String report = mvc.perform(asyncDispatch(rep)).andExpect(status().isOk()).andReturn()
                .getResponse().getContentAsString(StandardCharsets.UTF_8);
        assertThat(report).contains("MATCH").contains("RiskScore").contains("APPROVED").contains("Chitra");
    }

    @Test
    void csv_sameTableForReorderedHeader_newTableForDifferentLayout() throws Exception {
        String[] h1 = {"ID", "NAME", "ALIAS", "COUNTRY", "DOB"};
        Path c1 = tmp.resolve("a.csv");
        TestFiles.csv(c1, 2500, h1, 0);
        LoadView v1 = load("Acme", c1);
        assertThat(v1.getStatus()).as(v1.getMessage()).isEqualTo(LoadStatus.SUCCESS);
        assertThat(v1.getRowsInserted()).isEqualTo(2500L);
        String table = v1.getTableName();
        Map<String, String> cols = columnsByPath(v1.getLayoutId());
        assertThat(jdbc.queryForObject("SELECT " + cols.get("ALIAS") + " FROM " + table + " WHERE "
                + cols.get("ID") + " = 'ID_10'", String.class)).isEqualTo("Smith, \"Jr\"\nline2");

        // reordered columns + one new column: same table, field waits for approval
        String[] h2 = {"NAME", "ID", "DOB", "COUNTRY", "ALIAS", "PEP_FLAG"};
        Path c2 = tmp.resolve("b.csv");
        TestFiles.csv(c2, 1200, h2, 0);
        LoadView v2 = load("Acme", c2);
        assertThat(v2.getTableName()).isEqualTo(table);
        assertThat(v2.getStatus()).isEqualTo(LoadStatus.NEW_FIELDS);
        assertThat(jdbc.queryForObject("SELECT " + cols.get("NAME") + " FROM " + table + " WHERE LOAD_ID = ? AND "
                + cols.get("ID") + " = 'ID_5'", String.class, v2.getLoadId())).isEqualTo("NAME_5");

        // reject: stays in EXTRA_JSON and is not raised again
        StructureChangeView pep = changes.forLoad(v2.getLayoutId(), v2.getLoadId()).get(0);
        changeService.reject(Collections.singletonList(pep.getChangeId()), "Chitra", "not needed");
        LoadView v2b = load("Acme", c2);
        assertThat(v2b.getStatus()).isEqualTo(LoadStatus.SUCCESS);

        // a completely different CSV from the same provider -> its own table
        Path c3 = tmp.resolve("c.csv");
        TestFiles.csv(c3, 100, new String[]{"ACCOUNT", "BALANCE", "CCY"}, 0);
        LoadView v3 = load("Acme", c3);
        assertThat(v3.getTableName()).isEqualTo("RAW_ACME_CSV_2");
    }

    @Test
    void json_groupsNullsAndEnvelope() throws Exception {
        StringBuilder sb = new StringBuilder("{\"meta\":{\"source\":\"vendorX\",\"count\":1500},\"records\":[");
        for (int i = 1; i <= 1500; i++) {
            if (i > 1) {
                sb.append(',');
            }
            sb.append("{\"id\":").append(i).append(",\"score\":1.50,\"name\":{\"first\":\"F").append(i)
                    .append("\"},\"aliases\":[\"a").append(i).append("\"],\"note\":null,\"tags\":[]}");
        }
        sb.append("]}");
        Path f = tmp.resolve("v.json");
        Files.write(f, sb.toString().getBytes(StandardCharsets.UTF_8));
        LoadView v = load("VendorX", f);
        assertThat(v.getStatus()).as(v.getMessage()).isEqualTo(LoadStatus.SUCCESS);
        assertThat(v.getRowsInserted()).isEqualTo(1500L);
        Map<String, String> cols = columnsByPath(v.getLayoutId());
        Map<String, Object> row = jdbc.queryForMap("SELECT * FROM " + v.getTableName() + " WHERE "
                + cols.get("id") + " = '7'");
        assertThat(row.get(cols.get("score"))).isEqualTo("1.50");
        assertThat(row.get(cols.get("name/first"))).isEqualTo("F7");
        assertThat(row.get(cols.get("aliases"))).isEqualTo("[\"a7\"]");
        assertThat(row.get(cols.get("tags"))).isEqualTo("[]");
        assertThat(json.readTree((String) row.get("EXTRA_JSON")).get("null").get(0).asText()).isEqualTo("note");
        assertThat(loads.envelope(v.getLoadId())).contains("vendorX");
    }

    @Test
    void xxeIsRejected_andNothingIsLeftBehind() throws Exception {
        Path secret = tmp.resolve("secret.txt");
        Files.write(secret, "TOP-SECRET".getBytes(StandardCharsets.UTF_8));
        String xml = "<?xml version=\"1.0\"?><!DOCTYPE r [<!ENTITY x SYSTEM \"" + secret.toUri() + "\">]>"
                + "<r><a>&x;</a><a>2</a></r>";
        Path f = tmp.resolve("evil.xml");
        Files.write(f, xml.getBytes(StandardCharsets.UTF_8));
        LoadView v = load("Evil", f);
        assertThat(v.getStatus()).isEqualTo(LoadStatus.FAILED);
        assertThat(v.getMessage()).doesNotContain("TOP-SECRET");
        Set<String> leaked = new java.util.HashSet<>();
        for (Map<String, Object> m : jdbc.queryForList("SELECT ENVELOPE_JSON FROM INGEST_LOAD_LOG")) {
            leaked.add(String.valueOf(m.get("ENVELOPE_JSON")));
        }
        assertThat(String.join("", leaked)).doesNotContain("TOP-SECRET");
    }

    @Test
    void uploadValidation() throws Exception {
        mvc.perform(multipart("/api/uploads").file(new MockMultipartFile("file", "a.csv", "text/csv",
                        "A,B\n1,2\n".getBytes(StandardCharsets.UTF_8))).param("provider", "bad;name"))
                .andExpect(status().isBadRequest());
        mvc.perform(multipart("/api/uploads").file(new MockMultipartFile("file", "../../etc/a.csv", "text/csv",
                        "A,B\n1,2\n".getBytes(StandardCharsets.UTF_8))).param("provider", "Tiny"))
                .andExpect(status().isAccepted());
        List<String> names = new ArrayList<>(jdbc.queryForList(
                "SELECT ORIGINAL_FILENAME FROM INGEST_LOAD_LOG WHERE PROVIDER = 'Tiny'", String.class));
        assertThat(names).containsExactly("a.csv");
    }
}
