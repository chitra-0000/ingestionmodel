package com.poc.ingest;

import com.poc.ingest.config.IngestProperties;
import com.poc.ingest.flatten.DiscoveryCollector;
import com.poc.ingest.flatten.RecordFlattener;
import com.poc.ingest.model.FormatType;
import com.poc.ingest.model.LayoutDescriptor;
import com.poc.ingest.parse.Node;
import com.poc.ingest.parse.RecordSink;
import com.poc.ingest.parse.StreamingEngine;
import com.poc.ingest.parse.XmlContainerScanner;
import com.poc.ingest.service.LayoutService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.api.io.TempDir;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.Set;

/**
 * CPU side only (parse + flatten, no database): shows the parser is not the bottleneck.
 * Run: mvn test -Dtest=ParseThroughputBench -Dbench=true -Dbench.records=1000000
 */
@EnabledIfSystemProperty(named = "bench", matches = "true")
class ParseThroughputBench {

    @TempDir
    Path tmp;

    @Test
    void xmlAndCsv() throws Exception {
        int n = Integer.getInteger("bench.records", 1_000_000);
        IngestProperties props = new IngestProperties();
        LayoutService ls = new LayoutService(props, null, null, null);

        TestFiles.XmlSpec spec = new TestFiles.XmlSpec();
        spec.persons = n;
        Path xml = tmp.resolve("bench.xml");
        TestFiles.djXml(xml, spec);
        run("XML", xml, FormatType.XML, ls, props);

        String[] header = new String[20];
        for (int i = 0; i < header.length; i++) {
            header[i] = "FIELD_" + (i + 1);
        }
        Path csv = tmp.resolve("bench.csv");
        TestFiles.csv(csv, n, header, 0);
        run("CSV", csv, FormatType.CSV, ls, props);
    }

    private static void run(String label, Path file, FormatType f, LayoutService ls, IngestProperties props)
            throws Exception {
        long t0 = System.nanoTime();
        LayoutService.Sample sample = ls.sample(file, f);
        long t1 = System.nanoTime();
        LayoutDescriptor d = sample.getDescriptor();
        Set<String> known = f == FormatType.XML
                ? XmlContainerScanner.scan(Files.newInputStream(file), 2_000_000) : Collections.<String>emptySet();
        RecordFlattener fl = new RecordFlattener(d, 4000, f != FormatType.CSV);
        long[] count = {0};
        StreamingEngine e = ls.engineFor(f);
        long t2 = System.nanoTime();
        try (InputStream in = new BufferedInputStream(Files.newInputStream(file), 256 * 1024)) {
            e.parse(in, known, new RecordSink() {
                @Override
                public void onRecord(String c, Node r) {
                    if (!r.isFlat() || f == FormatType.CSV) {
                        fl.toRow(++count[0], c, r);
                    }
                }

                @Override
                public boolean isDone() {
                    return false;
                }
            });
        }
        long t3 = System.nanoTime();
        double secs = (t3 - t2) / 1e9;
        System.out.printf("%s: %,d MB, sampling %.1fs, parse+flatten %,d records in %.1fs = %,.0f records/s%n",
                label, Files.size(file) >> 20, (t1 - t0) / 1e9, count[0], secs, count[0] / secs);
    }
}
