package com.poc.ingest.parse;

import com.poc.ingest.flatten.DiscoveryCollector;
import com.poc.ingest.flatten.RecordFlattener;
import com.poc.ingest.flatten.RowData;
import com.poc.ingest.config.IngestProperties;
import com.poc.ingest.model.LayoutDescriptor;
import com.poc.ingest.model.FormatType;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class EnginesTest {

    static final class Collect implements RecordSink {
        final List<String> containers = new ArrayList<>();
        final List<Node> records = new ArrayList<>();

        @Override
        public void onRecord(String containerPath, Node record) {
            containers.add(containerPath);
            records.add(record);
        }

        @Override
        public boolean isDone() {
            return false;
        }
    }

    private static ByteArrayInputStream in(String s) {
        return new ByteArrayInputStream(s.getBytes(StandardCharsets.UTF_8));
    }

    @Test
    void unknownBigWrapperIsPromotedAndEnvelopeStaysSmall() throws Exception {
        StringBuilder sb = new StringBuilder("<root v=\"1\"><header><by>me</by></header><late>");
        for (int i = 0; i < 20; i++) {
            sb.append("<item n=\"").append(i).append("\"><x>").append(i).append("</x></item>");
        }
        sb.append("</late></root>");
        Collect c = new Collect();
        Node env = new XmlStreamingEngine(5).parse(in(sb.toString()), Collections.<String>emptySet(), c);
        assertThat(c.records).hasSize(20);
        assertThat(c.containers).containsOnly("/root/late");
        assertThat(c.records.get(0).attrs().get("n")).isEqualTo("0"); // earlier siblings are emitted in order
        String envJson = NodeJson.toJson(env);
        assertThat(envJson).contains("\"by\":\"me\"").doesNotContain("item");
    }

    @Test
    void containerScannerFindsShallowestRepeatingParents() {
        String xml = "<PFA><CountryList><C code=\"a\"/><C code=\"b\"/></CountryList><Records>"
                + "<Person id=\"1\"><Names><N>x</N><N>y</N></Names></Person>"
                + "<Person id=\"2\"><Names><N>z</N></Names></Person></Records><One><Only/></One></PFA>";
        assertThat(XmlContainerScanner.scan(in(xml), 1000))
                .containsExactlyInAnyOrder("/PFA/CountryList", "/PFA/Records");
    }

    @Test
    void namespacesAndMixedContentAreKept() throws Exception {
        String xml = "<r xmlns:p=\"urn:p\"><rec p:id=\"1\">hello<b>x</b></rec><rec p:id=\"2\"/></r>";
        Collect c = new Collect();
        new XmlStreamingEngine(1000).parse(in(xml), Collections.singleton("/r"), c);
        assertThat(NodeJson.toJson(c.records.get(0))).isEqualTo("{\"@p:id\":\"1\",\"#text\":\"hello\",\"b\":\"x\"}");
    }

    @Test
    void csvReaderHandlesQuotesNewlinesAndEmptyFields() throws Exception {
        CsvReader r = new CsvReader(new StringReader("a;\"b;\"\"c\"\"\nd\";;e\r\nx;y;z;w\n"), ';');
        assertThat(r.next()).containsExactly("a", "b;\"c\"\nd", "", "e");
        assertThat(r.next()).containsExactly("x", "y", "z", "w");
        assertThat(r.next()).isNull();
        assertThat(CsvReader.detectDelimiter("a|b|\"c,d\"|e")).isEqualTo('|');
    }

    @Test
    void flattenerNeverDropsAField() throws Exception {
        String head = "[{\"id\":1,\"a\":\"x\"},{\"id\":2,\"a\":\"y\"}]";
        DiscoveryCollector dc = new DiscoveryCollector(100);
        new JsonStreamingEngine().parse(in(head), Collections.<String>emptySet(), dc);
        LayoutDescriptor d = dc.build(FormatType.JSON, new IngestProperties());
        RecordFlattener f = new RecordFlattener(d, 4000, true);
        Collect c = new Collect();
        new JsonStreamingEngine().parse(in("[{\"id\":3,\"a\":\"z\",\"new\":{\"k\":[1,2]},\"b\":\"\"}]"),
                Collections.<String>emptySet(), c);
        RowData row = f.toRow(1, c.containers.get(0), c.records.get(0));
        assertThat(row.getValues()).containsExactly("3", "z");
        assertThat(row.getExtraJson()).isEqualTo("{\"unmapped\":{\"new/k\":[1,2],\"b\":\"\"}}");
        assertThat(f.changes()).extracting("path").containsExactly("new/k", "b");
    }
}
