-- Oracle JSON_VALUE stand-in for H2 tests (backfill uses it)
CREATE ALIAS JSON_VALUE FOR "com.poc.ingest.H2Functions.jsonValue";
