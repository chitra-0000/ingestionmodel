-- =====================================================================
-- Raw ingestion: fixed tables, created ONCE at install by the DBA.
-- The only DDL the application runs at runtime is:
--   CREATE TABLE RAW_<PROVIDER>_<FORMAT>_<n>   (new provider / layout)
--   ALTER TABLE  RAW_...  ADD (Cnnn ...)        (approved new field)
-- The application schema therefore needs CREATE TABLE and ALTER on its own tables.
-- =====================================================================

CREATE SEQUENCE INGEST_SEQ START WITH 1 INCREMENT BY 1 CACHE 50;

-- One row per provider + format + layout. DESCRIPTOR_JSON maps source paths to generated columns.
CREATE TABLE INGEST_FORMAT_REGISTRY (
    LAYOUT_ID        NUMBER(19)     NOT NULL,
    PROVIDER         VARCHAR2(64)   NOT NULL,
    FORMAT_TYPE      VARCHAR2(8)    NOT NULL,
    TABLE_NAME       VARCHAR2(128)  NOT NULL,
    FINGERPRINT      VARCHAR2(64)   NOT NULL,
    DESCRIPTOR_JSON  CLOB           NOT NULL,
    LAYOUT_VERSION   NUMBER(10)     NOT NULL,
    CREATED_AT       TIMESTAMP      NOT NULL,
    UPDATED_AT       TIMESTAMP      NOT NULL,
    CONSTRAINT PK_INGEST_FORMAT_REGISTRY PRIMARY KEY (LAYOUT_ID),
    CONSTRAINT UQ_INGEST_FORMAT_TABLE UNIQUE (TABLE_NAME)
);

-- One row per uploaded file.
CREATE TABLE INGEST_LOAD_LOG (
    LOAD_ID            NUMBER(19)     NOT NULL,
    PROVIDER           VARCHAR2(64)   NOT NULL,
    FORMAT_TYPE        VARCHAR2(8),
    LAYOUT_ID          NUMBER(19),
    TABLE_NAME         VARCHAR2(128),
    ORIGINAL_FILENAME  VARCHAR2(255)  NOT NULL,
    FILE_SIZE          NUMBER(19)     NOT NULL,
    FILE_SHA256        VARCHAR2(64)   NOT NULL,
    STATUS             VARCHAR2(16)   NOT NULL,
    ARCHIVE_STATUS     VARCHAR2(16)   NOT NULL,
    RECORDS_PARSED     NUMBER(19),
    ROWS_INSERTED      NUMBER(19),
    REF_ROWS           NUMBER(19),
    NEW_FIELD_COUNT    NUMBER(10),
    UPLOADED_AT        TIMESTAMP      NOT NULL,
    STARTED_AT         TIMESTAMP,
    FINISHED_AT        TIMESTAMP,
    DURATION_MS        NUMBER(19),
    MESSAGE            VARCHAR2(2000),
    ENVELOPE_JSON      CLOB,
    CONSTRAINT PK_INGEST_LOAD_LOG PRIMARY KEY (LOAD_ID)
);
CREATE INDEX IX_INGEST_LOAD_LOG_STATUS ON INGEST_LOAD_LOG (STATUS);

-- Original file, gzip-compressed. Purged after the retention period (default 160 days).
CREATE TABLE INGEST_FILE_ARCHIVE (
    LOAD_ID            NUMBER(19)     NOT NULL,
    ORIGINAL_FILENAME  VARCHAR2(255)  NOT NULL,
    ORIGINAL_SIZE      NUMBER(19)     NOT NULL,
    COMPRESSED_SIZE    NUMBER(19)     NOT NULL,
    FILE_SHA256        VARCHAR2(64)   NOT NULL,
    ARCHIVED_AT        TIMESTAMP      NOT NULL,
    FILE_GZ            BLOB           NOT NULL,
    CONSTRAINT PK_INGEST_FILE_ARCHIVE PRIMARY KEY (LOAD_ID)
);
CREATE INDEX IX_INGEST_FILE_ARCHIVE_AT ON INGEST_FILE_ARCHIVE (ARCHIVED_AT);

-- All reference lists of all providers. Codes in data tables are resolved against this at read time.
-- RECORD_JSON holds the complete reference element, so nothing is lost even if REF_CODE / REF_VALUE guessing is wrong.
CREATE TABLE INGEST_REF_DATA (
    LOAD_ID      NUMBER(19)     NOT NULL,
    ROW_NO       NUMBER(19)     NOT NULL,
    PROVIDER     VARCHAR2(64)   NOT NULL,
    LIST_NAME    VARCHAR2(256)  NOT NULL,
    RECORD_TYPE  VARCHAR2(256),
    REF_CODE     VARCHAR2(4000),
    REF_VALUE    VARCHAR2(4000),
    RECORD_JSON  CLOB
);
CREATE INDEX IX_INGEST_REF_DATA_LOOKUP ON INGEST_REF_DATA (PROVIDER, LIST_NAME, REF_CODE);
CREATE INDEX IX_INGEST_REF_DATA_LOAD ON INGEST_REF_DATA (LOAD_ID);

-- New fields seen in a file, waiting for approval. Decisions here are the audit trail.
CREATE TABLE INGEST_STRUCTURE_CHANGE (
    CHANGE_ID         NUMBER(19)     NOT NULL,
    LAYOUT_ID         NUMBER(19)     NOT NULL,
    FIRST_LOAD_ID     NUMBER(19)     NOT NULL,
    LAST_LOAD_ID      NUMBER(19)     NOT NULL,
    FIELD_PATH        VARCHAR2(1024) NOT NULL,
    FIELD_KIND        VARCHAR2(8)    NOT NULL,
    OCCURRENCES       NUMBER(19)     NOT NULL,
    MAX_LENGTH        NUMBER(10)     NOT NULL,
    SAMPLE_VALUE      VARCHAR2(400),
    STATUS            VARCHAR2(12)   NOT NULL,
    COLUMN_NAME       VARCHAR2(30),
    BACKFILLED_ROWS   NUMBER(19),
    DECIDED_BY        VARCHAR2(100),
    DECIDED_AT        TIMESTAMP,
    DECISION_COMMENT  VARCHAR2(1000),
    DETECTED_AT       TIMESTAMP      NOT NULL,
    CONSTRAINT PK_INGEST_STRUCTURE_CHANGE PRIMARY KEY (CHANGE_ID)
);
CREATE INDEX IX_INGEST_STRUCT_LAYOUT ON INGEST_STRUCTURE_CHANGE (LAYOUT_ID, STATUS);
