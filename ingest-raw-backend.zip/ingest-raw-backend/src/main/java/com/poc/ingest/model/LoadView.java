package com.poc.ingest.model;

import java.time.Instant;

/** A row of INGEST_LOAD_LOG as shown in the UI. */
public class LoadView {

    private long loadId;
    private String provider;
    private FormatType format;
    private Long layoutId;
    private String tableName;
    private String fileName;
    private long fileSize;
    private String fileSha256;
    private LoadStatus status;
    private ArchiveStatus archiveStatus;
    private Long recordsParsed;
    private Long rowsInserted;
    private Long refRows;
    private Integer newFieldCount;
    private Instant uploadedAt;
    private Instant startedAt;
    private Instant finishedAt;
    private Long durationMs;
    private String message;

    public long getLoadId() { return loadId; }
    public void setLoadId(long loadId) { this.loadId = loadId; }
    public String getProvider() { return provider; }
    public void setProvider(String provider) { this.provider = provider; }
    public FormatType getFormat() { return format; }
    public void setFormat(FormatType format) { this.format = format; }
    public Long getLayoutId() { return layoutId; }
    public void setLayoutId(Long layoutId) { this.layoutId = layoutId; }
    public String getTableName() { return tableName; }
    public void setTableName(String tableName) { this.tableName = tableName; }
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
    public long getFileSize() { return fileSize; }
    public void setFileSize(long fileSize) { this.fileSize = fileSize; }
    public String getFileSha256() { return fileSha256; }
    public void setFileSha256(String fileSha256) { this.fileSha256 = fileSha256; }
    public LoadStatus getStatus() { return status; }
    public void setStatus(LoadStatus status) { this.status = status; }
    public ArchiveStatus getArchiveStatus() { return archiveStatus; }
    public void setArchiveStatus(ArchiveStatus archiveStatus) { this.archiveStatus = archiveStatus; }
    public Long getRecordsParsed() { return recordsParsed; }
    public void setRecordsParsed(Long recordsParsed) { this.recordsParsed = recordsParsed; }
    public Long getRowsInserted() { return rowsInserted; }
    public void setRowsInserted(Long rowsInserted) { this.rowsInserted = rowsInserted; }
    public Long getRefRows() { return refRows; }
    public void setRefRows(Long refRows) { this.refRows = refRows; }
    public Integer getNewFieldCount() { return newFieldCount; }
    public void setNewFieldCount(Integer newFieldCount) { this.newFieldCount = newFieldCount; }
    public Instant getUploadedAt() { return uploadedAt; }
    public void setUploadedAt(Instant uploadedAt) { this.uploadedAt = uploadedAt; }
    public Instant getStartedAt() { return startedAt; }
    public void setStartedAt(Instant startedAt) { this.startedAt = startedAt; }
    public Instant getFinishedAt() { return finishedAt; }
    public void setFinishedAt(Instant finishedAt) { this.finishedAt = finishedAt; }
    public Long getDurationMs() { return durationMs; }
    public void setDurationMs(Long durationMs) { this.durationMs = durationMs; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}
