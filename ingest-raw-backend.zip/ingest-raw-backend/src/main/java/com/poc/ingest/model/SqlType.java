package com.poc.ingest.model;

public enum SqlType {
    VARCHAR, CLOB
}
