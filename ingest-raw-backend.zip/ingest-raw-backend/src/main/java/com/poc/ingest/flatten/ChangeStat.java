package com.poc.ingest.flatten;

import com.poc.ingest.model.FieldKind;

/** A field seen in the file that the layout has no column for. Becomes a pending INGEST_STRUCTURE_CHANGE. */
public final class ChangeStat {

    private final String path;
    private FieldKind kind;
    private long occurrences;
    private int maxBytes;
    private String sample;

    ChangeStat(String path, FieldKind kind) {
        this.path = path;
        this.kind = kind;
    }

    void record(FieldKind seenAs, String value, int bytes) {
        occurrences++;
        if (seenAs == FieldKind.GROUP) {
            kind = FieldKind.GROUP;
        }
        if (bytes > maxBytes) {
            maxBytes = bytes;
        }
        if (sample == null && value != null && !value.isEmpty()) {
            sample = value.length() > 200 ? value.substring(0, 200) : value;
        }
    }

    public String getPath() { return path; }
    public FieldKind getKind() { return kind; }
    public long getOccurrences() { return occurrences; }
    public int getMaxBytes() { return maxBytes; }
    public String getSample() { return sample; }
}
