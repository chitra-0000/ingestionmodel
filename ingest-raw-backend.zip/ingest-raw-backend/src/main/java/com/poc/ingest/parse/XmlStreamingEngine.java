package com.poc.ingest.parse;

import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * StAX engine. Children of a container are streamed as records; everything else is kept in a small envelope tree.
 * A wrapper not known as a container is promoted once it has {@code autoContainerThreshold} same-name children,
 * so an unexpected big list later in the file never accumulates in memory.
 */
public final class XmlStreamingEngine implements StreamingEngine {

    private final int autoContainerThreshold;

    public XmlStreamingEngine(int autoContainerThreshold) {
        this.autoContainerThreshold = Math.max(2, autoContainerThreshold);
    }

    private static final class Ctx {
        final Node node;
        final String path;
        boolean container;
        boolean inRecord;
        boolean recordRoot;
        String containerPath;
        Map<String, Integer> childCounts;

        Ctx(Node node, String path) {
            this.node = node;
            this.path = path;
        }
    }

    @Override
    public Node parse(InputStream in, Set<String> knownContainers, RecordSink sink) {
        Deque<Ctx> stack = new ArrayDeque<>();
        Node envelope = null;
        XMLStreamReader r = null;
        try {
            r = XmlSupport.secureFactory().createXMLStreamReader(in);
            while (r.hasNext()) {
                int ev = r.next();
                switch (ev) {
                    case XMLStreamConstants.START_ELEMENT:
                        Ctx c = start(r, stack.peek(), knownContainers, sink);
                        if (stack.isEmpty()) {
                            envelope = c.node;
                        }
                        stack.push(c);
                        break;
                    case XMLStreamConstants.CHARACTERS:
                    case XMLStreamConstants.CDATA:
                    case XMLStreamConstants.SPACE:
                        text(r, stack.peek());
                        break;
                    case XMLStreamConstants.END_ELEMENT:
                        Ctx done = stack.pop();
                        if (done.recordRoot) {
                            sink.onRecord(done.containerPath, done.node);
                            if (sink.isDone()) {
                                return envelope;
                            }
                        }
                        break;
                    default:
                        // comments and processing instructions are not data; the original file is archived
                        break;
                }
            }
        } catch (XMLStreamException e) {
            throw new ParseException("XML is not well-formed: " + e.getMessage(), e);
        } finally {
            XmlContainerScanner.close(r);
        }
        return envelope;
    }

    private Ctx start(XMLStreamReader r, Ctx parent, Set<String> known, RecordSink sink) {
        String name = XmlSupport.elementName(r);
        Node node = new Node(name);
        XmlSupport.copyAttributes(r, node);
        if (parent == null) {
            Ctx root = new Ctx(node, "/" + name);
            root.container = known.contains(root.path);
            root.childCounts = new HashMap<>();
            return root;
        }
        String path = parent.path + "/" + name;
        Ctx c = new Ctx(node, path);
        if (parent.inRecord) {
            parent.node.addChild(node);
            c.inRecord = true;
            return c;
        }
        if (!parent.container) {
            int count = parent.childCounts.merge(name, 1, Integer::sum);
            if (count < autoContainerThreshold) {
                parent.node.addChild(node);
                c.container = known.contains(path);
                c.childCounts = new HashMap<>();
                return c;
            }
            promote(parent, name, sink);
        }
        c.inRecord = true;
        c.recordRoot = true;
        c.containerPath = parent.path;
        return c;
    }

    /** Earlier same-name siblings were kept in the envelope; they become records now. */
    private static void promote(Ctx parent, String name, RecordSink sink) {
        parent.container = true;
        List<Node> earlier = parent.node.removeChildrenNamed(name);
        for (Node n : earlier) {
            sink.onRecord(parent.path, n);
        }
    }

    private static void text(XMLStreamReader r, Ctx top) {
        if (top == null) {
            return;
        }
        if (top.inRecord) {
            top.node.appendText(r.getTextCharacters(), r.getTextStart(), r.getTextLength());
        } else if (!r.isWhiteSpace()) {
            // envelope: keep real text, drop indentation (would otherwise grow with every record)
            top.node.appendText(r.getTextCharacters(), r.getTextStart(), r.getTextLength());
        }
    }
}
