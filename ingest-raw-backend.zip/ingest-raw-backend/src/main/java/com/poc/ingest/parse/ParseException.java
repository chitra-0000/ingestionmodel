package com.poc.ingest.parse;

/** The file is not well-formed for its detected format. The load fails; nothing is half-kept. */
public class ParseException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ParseException(String message) {
        super(message);
    }

    public ParseException(String message, Throwable cause) {
        super(message, cause);
    }
}
