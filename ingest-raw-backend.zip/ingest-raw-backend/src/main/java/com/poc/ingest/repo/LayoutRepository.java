package com.poc.ingest.repo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.poc.ingest.model.FormatType;
import com.poc.ingest.model.Layout;
import com.poc.ingest.model.LayoutDescriptor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

/** INGEST_FORMAT_REGISTRY. */
@Repository
public class LayoutRepository {

    private static final String SELECT = "SELECT LAYOUT_ID, PROVIDER, FORMAT_TYPE, TABLE_NAME, FINGERPRINT, "
            + "DESCRIPTOR_JSON, LAYOUT_VERSION FROM INGEST_FORMAT_REGISTRY ";

    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;
    private final RowMapper<Layout> rowMapper;

    public LayoutRepository(JdbcTemplate jdbc, ObjectMapper mapper) {
        this.jdbc = jdbc;
        this.mapper = mapper;
        this.rowMapper = (rs, i) -> {
            Layout l = new Layout();
            l.setLayoutId(rs.getLong("LAYOUT_ID"));
            l.setProvider(rs.getString("PROVIDER"));
            l.setFormat(FormatType.valueOf(rs.getString("FORMAT_TYPE")));
            l.setTableName(rs.getString("TABLE_NAME"));
            l.setFingerprint(rs.getString("FINGERPRINT"));
            l.setDescriptor(readDescriptor(rs.getString("DESCRIPTOR_JSON")));
            l.setVersion(rs.getInt("LAYOUT_VERSION"));
            return l;
        };
    }

    public long nextId() {
        Long id = jdbc.queryForObject("SELECT INGEST_SEQ.NEXTVAL FROM DUAL", Long.class);
        if (id == null) {
            throw new IllegalStateException("INGEST_SEQ returned no value");
        }
        return id;
    }

    public List<Layout> findByProviderAndFormat(String provider, FormatType format) {
        return jdbc.query(SELECT + "WHERE PROVIDER = ? AND FORMAT_TYPE = ? ORDER BY LAYOUT_ID",
                rowMapper, provider, format.name());
    }

    public Layout findById(long layoutId) {
        List<Layout> l = jdbc.query(SELECT + "WHERE LAYOUT_ID = ?", rowMapper, layoutId);
        return l.isEmpty() ? null : l.get(0);
    }

    public List<Layout> findAll() {
        return jdbc.query(SELECT + "ORDER BY PROVIDER, FORMAT_TYPE, LAYOUT_ID", rowMapper);
    }

    public boolean tableNameExists(String tableName) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM INGEST_FORMAT_REGISTRY WHERE TABLE_NAME = ?",
                Integer.class, tableName);
        return n != null && n > 0;
    }

    public void insert(Layout l) {
        Timestamp now = Timestamp.from(Instant.now());
        jdbc.update("INSERT INTO INGEST_FORMAT_REGISTRY (LAYOUT_ID, PROVIDER, FORMAT_TYPE, TABLE_NAME, FINGERPRINT, "
                        + "DESCRIPTOR_JSON, LAYOUT_VERSION, CREATED_AT, UPDATED_AT) VALUES (?,?,?,?,?,?,?,?,?)",
                l.getLayoutId(), l.getProvider(), l.getFormat().name(), l.getTableName(), l.getFingerprint(),
                writeDescriptor(l.getDescriptor()), l.getVersion(), now, now);
    }

    public void updateDescriptor(long layoutId, LayoutDescriptor d, int version) {
        jdbc.update("UPDATE INGEST_FORMAT_REGISTRY SET DESCRIPTOR_JSON = ?, LAYOUT_VERSION = ?, UPDATED_AT = ? "
                + "WHERE LAYOUT_ID = ?", writeDescriptor(d), version, Timestamp.from(Instant.now()), layoutId);
    }

    public List<String> providers() {
        return jdbc.queryForList("SELECT DISTINCT PROVIDER FROM INGEST_FORMAT_REGISTRY ORDER BY PROVIDER",
                String.class);
    }

    private LayoutDescriptor readDescriptor(String json) {
        try {
            return mapper.readValue(json, LayoutDescriptor.class);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Corrupt layout descriptor in registry", e);
        }
    }

    private String writeDescriptor(LayoutDescriptor d) {
        try {
            return mapper.writeValueAsString(d);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Cannot serialise layout descriptor", e);
        }
    }
}
