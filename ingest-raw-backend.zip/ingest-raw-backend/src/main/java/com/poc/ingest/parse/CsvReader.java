package com.poc.ingest.parse;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

/**
 * RFC 4180 streaming reader: quoted fields, "" escapes, embedded delimiters and line breaks, CRLF/LF/CR.
 * No third-party dependency (nothing extra for Nexus to scan).
 */
public final class CsvReader {

    private static final int BUF = 64 * 1024;

    private final Reader in;
    private final char delimiter;
    private final char[] buf = new char[BUF];
    private int pos;
    private int len;
    private long line = 1;
    private final StringBuilder field = new StringBuilder(64);

    public CsvReader(Reader in, char delimiter) {
        this.in = in;
        this.delimiter = delimiter;
    }

    private int read() throws IOException {
        if (pos >= len) {
            len = in.read(buf, 0, BUF);
            pos = 0;
            if (len <= 0) {
                return -1;
            }
        }
        return buf[pos++];
    }

    private int peek() throws IOException {
        if (pos >= len) {
            len = in.read(buf, 0, BUF);
            pos = 0;
            if (len <= 0) {
                return -1;
            }
        }
        return buf[pos];
    }

    /** @return the next record, or null at end of input. A blank line yields a single empty field. */
    public List<String> next() throws IOException {
        int c = read();
        if (c == -1) {
            return null;
        }
        List<String> fields = new ArrayList<>();
        field.setLength(0);
        boolean quoted = false;
        boolean wasQuoted = false;
        long startLine = line;
        while (true) {
            if (c == -1) {
                if (quoted) {
                    throw new ParseException("CSV: unclosed quote starting at line " + startLine);
                }
                fields.add(field.toString());
                return fields;
            }
            char ch = (char) c;
            if (quoted) {
                if (ch == '"') {
                    if (peek() == '"') {
                        read();
                        field.append('"');
                    } else {
                        quoted = false;
                    }
                } else {
                    if (ch == '\n') {
                        line++;
                    }
                    field.append(ch);
                }
            } else if (ch == '"' && field.length() == 0 && !wasQuoted) {
                quoted = true;
                wasQuoted = true;
            } else if (ch == delimiter) {
                fields.add(field.toString());
                field.setLength(0);
                wasQuoted = false;
            } else if (ch == '\n' || ch == '\r') {
                if (ch == '\r' && peek() == '\n') {
                    read();
                }
                line++;
                fields.add(field.toString());
                return fields;
            } else {
                field.append(ch);
            }
            c = read();
        }
    }

    /** Picks the delimiter that occurs most often (outside quotes) in the header line. */
    public static char detectDelimiter(String headerLine) {
        char[] candidates = {',', ';', '|', '\t'};
        int[] counts = new int[candidates.length];
        boolean quoted = false;
        for (int i = 0; i < headerLine.length(); i++) {
            char ch = headerLine.charAt(i);
            if (ch == '"') {
                quoted = !quoted;
            } else if (!quoted) {
                for (int k = 0; k < candidates.length; k++) {
                    if (ch == candidates[k]) {
                        counts[k]++;
                    }
                }
            }
        }
        int best = 0;
        for (int k = 1; k < candidates.length; k++) {
            if (counts[k] > counts[best]) {
                best = k;
            }
        }
        return candidates[best];
    }
}
