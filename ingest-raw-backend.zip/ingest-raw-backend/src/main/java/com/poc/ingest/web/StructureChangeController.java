package com.poc.ingest.web;

import com.poc.ingest.model.StructureChangeView;
import com.poc.ingest.repo.StructureChangeRepository;
import com.poc.ingest.service.StructureChangeService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/structure-changes")
public class StructureChangeController {

    private final StructureChangeService service;
    private final StructureChangeRepository changes;

    public StructureChangeController(StructureChangeService service, StructureChangeRepository changes) {
        this.service = service;
        this.changes = changes;
    }

    @GetMapping("/pending")
    public List<StructureChangeView> pending() {
        return changes.pending();
    }

    @PostMapping("/approve")
    public StructureChangeService.Outcome approve(@Valid @RequestBody Requests.Decision d) {
        return service.approve(d.getChangeIds(), d.getDecidedBy().trim(), d.getComment(), d.isBackfill());
    }

    @PostMapping("/reject")
    public List<StructureChangeView> reject(@Valid @RequestBody Requests.Decision d) {
        return service.reject(d.getChangeIds(), d.getDecidedBy().trim(), d.getComment());
    }
}
