package com.poc.ingest.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/** Bounded thread pools: one runs whole loads, one runs inserts, one archives originals. */
@Configuration
public class ExecutorConfig {

    @Bean(destroyMethod = "shutdownNow")
    public ExecutorService loadExecutor(IngestProperties props) {
        return new ThreadPoolExecutor(props.getMaxConcurrentLoads(), props.getMaxConcurrentLoads(),
                0L, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<Runnable>(props.getMaxQueuedLoads()),
                named("ingest-load"), new ThreadPoolExecutor.AbortPolicy());
    }

    @Bean(destroyMethod = "shutdownNow")
    public ExecutorService writerExecutor(IngestProperties props) {
        int threads = props.getMaxConcurrentLoads() * props.getWriterThreads();
        return new ThreadPoolExecutor(threads, threads, 0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<Runnable>(), named("ingest-writer"));
    }

    @Bean(destroyMethod = "shutdownNow")
    public ExecutorService archiveExecutor(IngestProperties props) {
        int threads = props.getMaxConcurrentLoads();
        return new ThreadPoolExecutor(threads, threads, 0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<Runnable>(), named("ingest-archive"));
    }

    private static ThreadFactory named(final String prefix) {
        final AtomicInteger seq = new AtomicInteger();
        return r -> {
            Thread t = new Thread(r, prefix + "-" + seq.incrementAndGet());
            t.setDaemon(true);
            return t;
        };
    }
}
