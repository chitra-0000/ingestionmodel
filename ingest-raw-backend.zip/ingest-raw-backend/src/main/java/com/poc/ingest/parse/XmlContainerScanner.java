package com.poc.ingest.parse;

import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * Pass 1 on the head of an XML file: finds record containers with constant memory (path statistics only).
 * A container is the shallowest element whose children repeat by name and carry attributes or child elements,
 * e.g. /PFA/Records (Person, Entity) or /PFA/CountryList (CountryName). Repeats nested inside a container
 * (Person/NameDetails/Name) are part of the record, not containers.
 */
public final class XmlContainerScanner {

    private static final int MAX_DISTINCT_PATHS = 50_000;

    private XmlContainerScanner() {
    }

    private static final class Frame {
        final String path;
        final Map<String, Integer> childCounts = new HashMap<>();

        Frame(String path) {
            this.path = path;
        }
    }

    public static Set<String> scan(InputStream in, int maxElements) {
        Set<String> structural = new HashSet<>();
        Set<String> repeatingParents = new LinkedHashSet<>();
        Deque<Frame> stack = new ArrayDeque<>();
        XMLStreamReader r = null;
        try {
            r = XmlSupport.secureFactory().createXMLStreamReader(in);
            int seen = 0;
            while (r.hasNext() && seen < maxElements) {
                int ev = r.next();
                if (ev == XMLStreamConstants.START_ELEMENT) {
                    seen++;
                    String name = XmlSupport.elementName(r);
                    Frame parent = stack.peek();
                    String path = parent == null ? "/" + name : parent.path + "/" + name;
                    if (parent != null) {
                        parent.childCounts.merge(name, 1, Integer::sum);
                        markStructural(structural, parent.path);
                    }
                    if (r.getAttributeCount() > 0) {
                        markStructural(structural, path);
                    }
                    stack.push(new Frame(path));
                } else if (ev == XMLStreamConstants.END_ELEMENT) {
                    evaluate(stack.pop(), structural, repeatingParents);
                }
            }
            // records still open when the budget ran out (the big container usually is)
            while (!stack.isEmpty()) {
                evaluate(stack.pop(), structural, repeatingParents);
            }
        } catch (XMLStreamException e) {
            throw new ParseException("XML is not well-formed: " + e.getMessage(), e);
        } finally {
            close(r);
        }
        return shallowest(repeatingParents);
    }

    private static void markStructural(Set<String> structural, String path) {
        if (structural.size() < MAX_DISTINCT_PATHS) {
            structural.add(path);
        }
    }

    private static void evaluate(Frame f, Set<String> structural, Set<String> repeatingParents) {
        for (Map.Entry<String, Integer> e : f.childCounts.entrySet()) {
            if (e.getValue() >= 2 && structural.contains(f.path + "/" + e.getKey())) {
                repeatingParents.add(f.path);
                return;
            }
        }
    }

    static Set<String> shallowest(Set<String> candidates) {
        Set<String> result = new LinkedHashSet<>();
        for (String c : candidates) {
            boolean nested = false;
            for (String other : candidates) {
                if (!other.equals(c) && c.startsWith(other + "/")) {
                    nested = true;
                    break;
                }
            }
            if (!nested) {
                result.add(c);
            }
        }
        return result;
    }

    static void close(XMLStreamReader r) {
        if (r != null) {
            try {
                r.close();
            } catch (XMLStreamException e) {
                // closing a reader cannot lose data; nothing to do
            }
        }
    }
}
