package com.poc.ingest.parse;

import javax.xml.XMLConstants;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;

/** Hardened StAX factory: no DTDs, no external entities (XXE safe, Fortify "XML External Entity Injection"). */
final class XmlSupport {

    private XmlSupport() {
    }

    static XMLInputFactory secureFactory() {
        XMLInputFactory f = XMLInputFactory.newInstance();
        f.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
        f.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
        f.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, Boolean.TRUE);
        f.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
        f.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE, Boolean.TRUE);
        trySet(f, XMLConstants.ACCESS_EXTERNAL_DTD, "");
        trySet(f, XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        return f;
    }

    private static void trySet(XMLInputFactory f, String prop, Object value) {
        try {
            f.setProperty(prop, value);
        } catch (IllegalArgumentException e) {
            // property not supported by this StAX implementation; DTD support is already disabled above
        }
    }

    /** prefix:local, or local when there is no prefix. */
    static String elementName(XMLStreamReader r) {
        String prefix = r.getPrefix();
        String local = r.getLocalName();
        return prefix == null || prefix.isEmpty() ? local : prefix + ":" + local;
    }

    static String attrName(XMLStreamReader r, int i) {
        String prefix = r.getAttributePrefix(i);
        String local = r.getAttributeLocalName(i);
        return prefix == null || prefix.isEmpty() ? local : prefix + ":" + local;
    }

    /** Attributes plus namespace declarations (kept so nothing in the start tag is lost). */
    static void copyAttributes(XMLStreamReader r, Node n) {
        for (int i = 0; i < r.getNamespaceCount(); i++) {
            String p = r.getNamespacePrefix(i);
            n.putAttr(p == null || p.isEmpty() ? "xmlns" : "xmlns:" + p, r.getNamespaceURI(i));
        }
        for (int i = 0; i < r.getAttributeCount(); i++) {
            n.putAttr(attrName(r, i), r.getAttributeValue(i));
        }
    }
}
