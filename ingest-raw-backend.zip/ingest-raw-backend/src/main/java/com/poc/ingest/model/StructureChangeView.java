package com.poc.ingest.model;

import java.time.Instant;

/** A row of INGEST_STRUCTURE_CHANGE. */
public class StructureChangeView {

    private long changeId;
    private long layoutId;
    private String tableName;
    private long firstLoadId;
    private long lastLoadId;
    private String fieldPath;
    private FieldKind fieldKind;
    private long occurrences;
    private int maxLength;
    private String sampleValue;
    private ChangeStatus status;
    private String columnName;
    private Long backfilledRows;
    private String decidedBy;
    private Instant decidedAt;
    private String decisionComment;
    private Instant detectedAt;

    public long getChangeId() { return changeId; }
    public void setChangeId(long changeId) { this.changeId = changeId; }
    public long getLayoutId() { return layoutId; }
    public void setLayoutId(long layoutId) { this.layoutId = layoutId; }
    public String getTableName() { return tableName; }
    public void setTableName(String tableName) { this.tableName = tableName; }
    public long getFirstLoadId() { return firstLoadId; }
    public void setFirstLoadId(long firstLoadId) { this.firstLoadId = firstLoadId; }
    public long getLastLoadId() { return lastLoadId; }
    public void setLastLoadId(long lastLoadId) { this.lastLoadId = lastLoadId; }
    public String getFieldPath() { return fieldPath; }
    public void setFieldPath(String fieldPath) { this.fieldPath = fieldPath; }
    public FieldKind getFieldKind() { return fieldKind; }
    public void setFieldKind(FieldKind fieldKind) { this.fieldKind = fieldKind; }
    public long getOccurrences() { return occurrences; }
    public void setOccurrences(long occurrences) { this.occurrences = occurrences; }
    public int getMaxLength() { return maxLength; }
    public void setMaxLength(int maxLength) { this.maxLength = maxLength; }
    public String getSampleValue() { return sampleValue; }
    public void setSampleValue(String sampleValue) { this.sampleValue = sampleValue; }
    public ChangeStatus getStatus() { return status; }
    public void setStatus(ChangeStatus status) { this.status = status; }
    public String getColumnName() { return columnName; }
    public void setColumnName(String columnName) { this.columnName = columnName; }
    public Long getBackfilledRows() { return backfilledRows; }
    public void setBackfilledRows(Long backfilledRows) { this.backfilledRows = backfilledRows; }
    public String getDecidedBy() { return decidedBy; }
    public void setDecidedBy(String decidedBy) { this.decidedBy = decidedBy; }
    public Instant getDecidedAt() { return decidedAt; }
    public void setDecidedAt(Instant decidedAt) { this.decidedAt = decidedAt; }
    public String getDecisionComment() { return decisionComment; }
    public void setDecisionComment(String decisionComment) { this.decisionComment = decisionComment; }
    public Instant getDetectedAt() { return detectedAt; }
    public void setDetectedAt(Instant detectedAt) { this.detectedAt = detectedAt; }
}
