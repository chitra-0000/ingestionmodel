package com.poc.ingest.parse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Lightweight tree for ONE record (or the small envelope around the records). Never holds a whole file.
 * Same model for XML (attributes, text, children), JSON (keys as children) and CSV (one level).
 */
public final class Node {

    private final String name;
    private Map<String, String> attrs;
    private StringBuilder text;
    private List<Node> children;
    /** JSON: element came from an array, so it is a repeating field even if only one item exists. */
    private boolean arrayItem;
    /** JSON: explicit null (kept distinct from an empty string). */
    private boolean jsonNull;
    /** JSON: an empty array (kept distinct from an absent key). */
    private boolean emptyArray;
    /** JSON: number or boolean; written back unquoted so the type survives. */
    private boolean literal;

    public Node(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void putAttr(String key, String value) {
        if (attrs == null) {
            attrs = new LinkedHashMap<>(8);
        }
        attrs.put(key, value);
    }

    public Map<String, String> attrs() {
        return attrs == null ? Collections.<String, String>emptyMap() : attrs;
    }

    public boolean hasAttrs() {
        return attrs != null && !attrs.isEmpty();
    }

    public void appendText(char[] buf, int start, int len) {
        if (text == null) {
            text = new StringBuilder(Math.max(16, len));
        }
        text.append(buf, start, len);
    }

    public void appendText(String s) {
        if (text == null) {
            text = new StringBuilder(Math.max(16, s.length()));
        }
        text.append(s);
    }

    /** Raw text, or "" when the element had none. */
    public String text() {
        return text == null ? "" : text.toString();
    }

    public boolean hasNonBlankText() {
        if (text == null) {
            return false;
        }
        for (int i = 0; i < text.length(); i++) {
            if (!Character.isWhitespace(text.charAt(i))) {
                return true;
            }
        }
        return false;
    }

    public void addChild(Node child) {
        if (children == null) {
            children = new ArrayList<>(4);
        }
        children.add(child);
    }

    public List<Node> children() {
        return children == null ? Collections.<Node>emptyList() : children;
    }

    public boolean hasChildren() {
        return children != null && !children.isEmpty();
    }

    /** Removes and returns all children with the given name (used when a wrapper is promoted to a container). */
    public List<Node> removeChildrenNamed(String childName) {
        List<Node> removed = new ArrayList<>();
        if (children == null) {
            return removed;
        }
        for (int i = 0; i < children.size(); ) {
            if (children.get(i).name.equals(childName)) {
                removed.add(children.remove(i));
            } else {
                i++;
            }
        }
        return removed;
    }

    public boolean isArrayItem() {
        return arrayItem;
    }

    public void setArrayItem(boolean arrayItem) {
        this.arrayItem = arrayItem;
    }

    public boolean isJsonNull() {
        return jsonNull;
    }

    public void setJsonNull(boolean jsonNull) {
        this.jsonNull = jsonNull;
    }

    public boolean isEmptyArray() {
        return emptyArray;
    }

    public void setEmptyArray(boolean emptyArray) {
        this.emptyArray = emptyArray;
    }

    public boolean isLiteral() {
        return literal;
    }

    public void setLiteral(boolean literal) {
        this.literal = literal;
    }

    /** A record whose element carries only attributes / text, i.e. a code-list entry. */
    public boolean isFlat() {
        return children == null || children.isEmpty();
    }

    /** Children grouped by name, in document order of first appearance. */
    public Map<String, List<Node>> childrenByName() {
        if (children == null || children.isEmpty()) {
            return Collections.emptyMap();
        }
        Map<String, List<Node>> m = new LinkedHashMap<>();
        for (Node c : children) {
            List<Node> l = m.get(c.name);
            if (l == null) {
                l = new ArrayList<>(2);
                m.put(c.name, l);
            }
            l.add(c);
        }
        return m;
    }
}
