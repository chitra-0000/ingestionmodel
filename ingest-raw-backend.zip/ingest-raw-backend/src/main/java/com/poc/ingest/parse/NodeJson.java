package com.poc.ingest.parse;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;

import java.io.IOException;
import java.io.StringWriter;
import java.io.UncheckedIOException;
import java.util.List;
import java.util.Map;

/**
 * Lossless Node -> JSON. Convention:
 * attributes as "@name"; children by name (array when repeated or from a JSON array);
 * a leaf without attributes becomes its text ("" if empty, null for JSON null);
 * text of an element that also has attributes or children goes to "#text".
 */
public final class NodeJson {

    private static final JsonFactory FACTORY = new JsonFactory();

    private NodeJson() {
    }

    public static String toJson(Node node) {
        StringWriter w = new StringWriter(256);
        try (JsonGenerator g = FACTORY.createGenerator(w)) {
            writeValue(g, node);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        return w.toString();
    }

    /** The given same-name siblings as one JSON array. */
    public static String toJsonArray(List<Node> nodes) {
        if (nodes.size() == 1 && nodes.get(0).isEmptyArray()) {
            return "[]";
        }
        StringWriter w = new StringWriter(256 * nodes.size());
        try (JsonGenerator g = FACTORY.createGenerator(w)) {
            g.writeStartArray();
            for (Node n : nodes) {
                writeValue(g, n);
            }
            g.writeEndArray();
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        return w.toString();
    }

    static void writeValue(JsonGenerator g, Node n) throws IOException {
        if (n.isJsonNull()) {
            g.writeNull();
            return;
        }
        if (!n.hasAttrs() && !n.hasChildren()) {
            if (n.isLiteral()) {
                g.writeRawValue(n.text()); // a number/boolean token exactly as the parser read it
            } else {
                g.writeString(n.text());
            }
            return;
        }
        g.writeStartObject();
        for (Map.Entry<String, String> a : n.attrs().entrySet()) {
            g.writeStringField("@" + a.getKey(), a.getValue());
        }
        if (n.hasNonBlankText() || (!n.hasChildren() && !n.text().isEmpty())) {
            g.writeStringField("#text", n.text());
        }
        for (Map.Entry<String, List<Node>> e : n.childrenByName().entrySet()) {
            List<Node> list = e.getValue();
            g.writeFieldName(e.getKey());
            if (list.size() == 1 && list.get(0).isEmptyArray()) {
                g.writeStartArray();
                g.writeEndArray();
            } else if (list.size() > 1 || list.get(0).isArrayItem()) {
                g.writeStartArray();
                for (Node c : list) {
                    writeValue(g, c);
                }
                g.writeEndArray();
            } else {
                writeValue(g, list.get(0));
            }
        }
        g.writeEndObject();
    }
}
