package com.poc.ingest.model;

/** DATA containers go to the provider's RAW_ table; REF containers (code lists) go to INGEST_REF_DATA. */
public enum ContainerKind {
    DATA, REF
}
