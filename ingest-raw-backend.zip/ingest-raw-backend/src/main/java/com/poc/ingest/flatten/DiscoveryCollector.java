package com.poc.ingest.flatten;

import com.poc.ingest.config.IngestProperties;
import com.poc.ingest.model.ColumnDef;
import com.poc.ingest.model.ContainerKind;
import com.poc.ingest.model.FieldKind;
import com.poc.ingest.model.FormatType;
import com.poc.ingest.model.LayoutDescriptor;
import com.poc.ingest.model.SqlType;
import com.poc.ingest.parse.Node;
import com.poc.ingest.parse.RecordSink;
import com.poc.ingest.util.Safe;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Sampling sink: learns containers, scalar fields, repeating groups and value sizes from the head of the file,
 * then builds a {@link LayoutDescriptor}. Holds statistics only, never records.
 */
public final class DiscoveryCollector implements RecordSink {

    private static final int MAX_PATHS_PER_CONTAINER = 20_000;

    private static final class PathStat {
        boolean scalar;
        boolean repeating;
        int maxBytes;
    }

    private static final class ContainerStat {
        long records;
        boolean allFlat = true;
        final Map<String, PathStat> paths = new LinkedHashMap<>();
    }

    private final int sampleRecords;
    private final Map<String, ContainerStat> containers = new LinkedHashMap<>();
    private long total;
    private long nonFlat;

    public DiscoveryCollector(int sampleRecords) {
        this.sampleRecords = Math.max(1, sampleRecords);
    }

    @Override
    public void onRecord(String containerPath, Node record) {
        ContainerStat cs = containers.get(containerPath);
        if (cs == null) {
            cs = new ContainerStat();
            containers.put(containerPath, cs);
        }
        cs.records++;
        total++;
        if (!record.isFlat()) {
            cs.allFlat = false;
            nonFlat++;
        }
        walk(cs.paths, record, "");
    }

    @Override
    public boolean isDone() {
        return nonFlat >= sampleRecords || total >= 10L * sampleRecords;
    }

    public long getTotal() {
        return total;
    }

    private static PathStat stat(Map<String, PathStat> paths, String p) {
        PathStat s = paths.get(p);
        if (s == null) {
            if (paths.size() >= MAX_PATHS_PER_CONTAINER) {
                return new PathStat(); // over budget: field will simply land in EXTRA_JSON
            }
            s = new PathStat();
            paths.put(p, s);
        }
        return s;
    }

    private static void scalar(Map<String, PathStat> paths, String p, String value) {
        PathStat s = stat(paths, p);
        s.scalar = true;
        int b = Safe.utf8Length(value);
        if (b > s.maxBytes) {
            s.maxBytes = b;
        }
    }

    private static void walk(Map<String, PathStat> paths, Node n, String rel) {
        for (Map.Entry<String, String> a : n.attrs().entrySet()) {
            scalar(paths, Paths.attr(rel, a.getKey()), a.getValue());
        }
        if (!n.hasChildren()) {
            if (!n.hasAttrs() || !n.text().isEmpty()) {
                scalar(paths, Paths.text(rel), n.text());
            }
        } else if (n.hasNonBlankText()) {
            scalar(paths, Paths.text(rel), n.text());
        }
        for (Map.Entry<String, List<Node>> e : n.childrenByName().entrySet()) {
            List<Node> list = e.getValue();
            String cp = Paths.child(rel, e.getKey());
            if (list.size() > 1 || list.get(0).isArrayItem() || list.get(0).isEmptyArray()) {
                stat(paths, cp).repeating = true;
            }
            for (Node c : list) {
                if (!c.isEmptyArray()) {
                    walk(paths, c, cp);
                }
            }
        }
    }

    /** Builds the layout descriptor from what was sampled. */
    public LayoutDescriptor build(FormatType format, IngestProperties props) {
        LayoutDescriptor d = new LayoutDescriptor();
        d.setFormat(format);
        String main = null;
        long max = -1;
        for (Map.Entry<String, ContainerStat> e : containers.entrySet()) {
            if (e.getValue().records > max) {
                max = e.getValue().records;
                main = e.getKey();
            }
        }
        Map<String, PathStat> merged = new LinkedHashMap<>();
        for (Map.Entry<String, ContainerStat> e : containers.entrySet()) {
            ContainerStat cs = e.getValue();
            boolean data = e.getKey().equals(main) || !cs.allFlat;
            d.getContainers().put(e.getKey(), data ? ContainerKind.DATA : ContainerKind.REF);
            if (data) {
                merge(merged, cs.paths);
            }
        }
        List<String> groups = new ArrayList<>();
        for (Map.Entry<String, PathStat> e : merged.entrySet()) {
            if (e.getValue().repeating && !underAny(e.getKey(), groups)) {
                groups.add(e.getKey());
            }
        }
        // a group discovered later may cover a group added earlier
        List<String> topGroups = new ArrayList<>();
        for (String g : groups) {
            if (!underAny(g, groups)) {
                topGroups.add(g);
            }
        }
        int scalarSeq = 0;
        int groupSeq = 0;
        int cap = props.getMaxDataColumns();
        for (Map.Entry<String, PathStat> e : merged.entrySet()) {
            if (d.getColumns().size() >= cap) {
                break;
            }
            String p = e.getKey();
            PathStat s = e.getValue();
            if (topGroups.contains(p)) {
                d.getColumns().add(new ColumnDef(String.format("G%04d", ++groupSeq), p, FieldKind.GROUP, SqlType.CLOB));
            } else if (s.scalar && !s.repeating && !underAny(p, topGroups)) {
                SqlType t = s.maxBytes > props.getClobThresholdBytes() ? SqlType.CLOB : SqlType.VARCHAR;
                d.getColumns().add(new ColumnDef(String.format("C%04d", ++scalarSeq), p, FieldKind.SCALAR, t));
            }
        }
        return d;
    }

    private static boolean underAny(String path, List<String> ancestors) {
        for (String a : ancestors) {
            if (Paths.isBelow(path, a)) {
                return true;
            }
        }
        return false;
    }

    private static void merge(Map<String, PathStat> into, Map<String, PathStat> from) {
        for (Map.Entry<String, PathStat> e : from.entrySet()) {
            PathStat t = into.get(e.getKey());
            if (t == null) {
                t = new PathStat();
                into.put(e.getKey(), t);
            }
            PathStat f = e.getValue();
            t.scalar |= f.scalar;
            t.repeating |= f.repeating;
            t.maxBytes = Math.max(t.maxBytes, f.maxBytes);
        }
    }
}
