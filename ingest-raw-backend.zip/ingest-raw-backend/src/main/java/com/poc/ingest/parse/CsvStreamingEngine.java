package com.poc.ingest.parse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * CSV engine: the header row names the fields, every following row is a record of type "row" in container "/".
 * Duplicate header names get "#2", "#3"; blank names and values beyond the header become "_col_N".
 */
public final class CsvStreamingEngine implements StreamingEngine {

    public static final String CONTAINER = "/";
    public static final String RECORD_NAME = "row";
    private static final int HEADER_PEEK = 1024 * 1024;

    private final Charset charset;

    public CsvStreamingEngine(Charset charset) {
        this.charset = charset;
    }

    @Override
    public Node parse(InputStream in, Set<String> knownContainers, RecordSink sink) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in, charset), 256 * 1024);
        skipBom(reader);
        reader.mark(HEADER_PEEK);
        String firstLine = reader.readLine();
        Node envelope = new Node("csv");
        if (firstLine == null) {
            return envelope;
        }
        reader.reset();
        char delimiter = CsvReader.detectDelimiter(firstLine);
        envelope.putAttr("delimiter", String.valueOf(delimiter));
        CsvReader csv = new CsvReader(reader, delimiter);
        List<String> header = names(csv.next());
        for (String h : header) {
            Node hn = new Node("header");
            hn.setArrayItem(true);
            hn.appendText(h);
            envelope.addChild(hn);
        }
        List<String> row;
        while ((row = csv.next()) != null) {
            if (row.size() == 1 && row.get(0).isEmpty()) {
                continue; // blank line carries no data
            }
            Node rec = new Node(RECORD_NAME);
            for (int i = 0; i < row.size(); i++) {
                String name = i < header.size() ? header.get(i) : "_col_" + (i + 1);
                Node f = new Node(name);
                f.appendText(row.get(i));
                rec.addChild(f);
            }
            sink.onRecord(CONTAINER, rec);
            if (sink.isDone()) {
                break;
            }
        }
        return envelope;
    }

    private static void skipBom(BufferedReader r) throws IOException {
        r.mark(1);
        if (r.read() != '﻿') {
            r.reset();
        }
    }

    static List<String> names(List<String> raw) {
        List<String> out = new ArrayList<>(raw.size());
        Map<String, Integer> seen = new HashMap<>();
        for (int i = 0; i < raw.size(); i++) {
            String n = raw.get(i).trim();
            if (n.isEmpty()) {
                n = "_col_" + (i + 1);
            }
            int count = seen.merge(n, 1, Integer::sum);
            out.add(count == 1 ? n : n + "#" + count);
        }
        return out;
    }
}
