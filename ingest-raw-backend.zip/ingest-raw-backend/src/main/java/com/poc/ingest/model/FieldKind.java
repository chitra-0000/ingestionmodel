package com.poc.ingest.model;

/** SCALAR: one value per record (element text or attribute). GROUP: repeating element, stored as a JSON array. */
public enum FieldKind {
    SCALAR, GROUP
}
