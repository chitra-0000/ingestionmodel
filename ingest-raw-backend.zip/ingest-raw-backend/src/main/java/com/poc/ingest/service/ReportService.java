package com.poc.ingest.service;

import com.poc.ingest.model.LoadView;
import com.poc.ingest.model.StructureChangeView;
import com.poc.ingest.repo.StructureChangeRepository;
import com.poc.ingest.util.Safe;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;

/** The "Download report" CSV: load summary, reconciliation, and the field changes of the load. */
@Service
public class ReportService {

    private final StructureChangeRepository changes;

    public ReportService(StructureChangeRepository changes) {
        this.changes = changes;
    }

    public void write(LoadView v, OutputStream out) throws IOException {
        Writer w = new OutputStreamWriter(out, StandardCharsets.UTF_8);
        w.write('﻿'); // lets Excel open UTF-8 correctly
        line(w, "Section", "Item", "Value");
        line(w, "Load", "Load ID", v.getLoadId());
        line(w, "Load", "Provider", v.getProvider());
        line(w, "Load", "File", v.getFileName());
        line(w, "Load", "File size (bytes)", v.getFileSize());
        line(w, "Load", "SHA-256", v.getFileSha256());
        line(w, "Load", "Format", v.getFormat());
        line(w, "Load", "Table", v.getTableName());
        line(w, "Load", "Status", v.getStatus());
        line(w, "Load", "Message", v.getMessage());
        line(w, "Load", "Uploaded at", v.getUploadedAt());
        line(w, "Load", "Started at", v.getStartedAt());
        line(w, "Load", "Finished at", v.getFinishedAt());
        line(w, "Load", "Duration (ms)", v.getDurationMs());
        line(w, "Reconciliation", "Records in file", v.getRecordsParsed());
        line(w, "Reconciliation", "Rows inserted", v.getRowsInserted());
        line(w, "Reconciliation", "Reference rows inserted", v.getRefRows());
        line(w, "Reconciliation", "Result", reconciliation(v));
        line(w, "Archive", "Original file", v.getArchiveStatus());
        w.write("\r\n");
        line(w, "New field", "Path", "Kind", "Occurrences", "Max length", "Sample", "Status", "Column",
                "Decided by", "Decided at", "Comment");
        List<StructureChangeView> list = v.getLayoutId() == null
                ? Collections.<StructureChangeView>emptyList()
                : changes.forLoad(v.getLayoutId(), v.getLoadId());
        for (StructureChangeView c : list) {
            line(w, "New field", c.getFieldPath(), c.getFieldKind(), c.getOccurrences(), c.getMaxLength(),
                    c.getSampleValue(), c.getStatus(), c.getColumnName(), c.getDecidedBy(), c.getDecidedAt(),
                    c.getDecisionComment());
        }
        w.flush();
    }

    private static String reconciliation(LoadView v) {
        if (v.getRecordsParsed() == null) {
            return "n/a";
        }
        return v.getRecordsParsed().equals(v.getRowsInserted()) ? "MATCH" : "MISMATCH";
    }

    private static void line(Writer w, Object... cells) throws IOException {
        for (int i = 0; i < cells.length; i++) {
            if (i > 0) {
                w.write(',');
            }
            w.write(Safe.csvCell(cells[i]));
        }
        w.write("\r\n");
    }
}
