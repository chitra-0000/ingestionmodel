package com.poc.ingest.model;

public enum FormatType {
    XML, JSON, CSV
}
