package com.poc.ingest.model;

/** A row of INGEST_FORMAT_REGISTRY. */
public class Layout {

    private long layoutId;
    private String provider;
    private FormatType format;
    private String tableName;
    private String fingerprint;
    private LayoutDescriptor descriptor;
    private int version;

    public long getLayoutId() { return layoutId; }
    public void setLayoutId(long layoutId) { this.layoutId = layoutId; }
    public String getProvider() { return provider; }
    public void setProvider(String provider) { this.provider = provider; }
    public FormatType getFormat() { return format; }
    public void setFormat(FormatType format) { this.format = format; }
    public String getTableName() { return tableName; }
    public void setTableName(String tableName) { this.tableName = tableName; }
    public String getFingerprint() { return fingerprint; }
    public void setFingerprint(String fingerprint) { this.fingerprint = fingerprint; }
    public LayoutDescriptor getDescriptor() { return descriptor; }
    public void setDescriptor(LayoutDescriptor descriptor) { this.descriptor = descriptor; }
    public int getVersion() { return version; }
    public void setVersion(int version) { this.version = version; }
}
