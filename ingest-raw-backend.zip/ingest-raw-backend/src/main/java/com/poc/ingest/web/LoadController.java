package com.poc.ingest.web;

import com.poc.ingest.model.ArchiveStatus;
import com.poc.ingest.model.LoadView;
import com.poc.ingest.model.StructureChangeView;
import com.poc.ingest.repo.LayoutRepository;
import com.poc.ingest.repo.LoadLogRepository;
import com.poc.ingest.repo.StructureChangeRepository;
import com.poc.ingest.service.ArchiveService;
import com.poc.ingest.service.ReportService;
import com.poc.ingest.util.Safe;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/api")
public class LoadController {

    private final LoadLogRepository loads;
    private final StructureChangeRepository changes;
    private final LayoutRepository layouts;
    private final ArchiveService archive;
    private final ReportService report;

    public LoadController(LoadLogRepository loads, StructureChangeRepository changes, LayoutRepository layouts,
                          ArchiveService archive, ReportService report) {
        this.loads = loads;
        this.changes = changes;
        this.layouts = layouts;
        this.archive = archive;
        this.report = report;
    }

    @GetMapping("/loads")
    public List<LoadView> recent(@RequestParam(value = "limit", defaultValue = "100") int limit) {
        return loads.recent(Math.max(1, Math.min(limit, 500)));
    }

    @GetMapping("/loads/{id}")
    public LoadView one(@PathVariable("id") long id) {
        return require(id);
    }

    @GetMapping("/loads/{id}/structure-changes")
    public List<StructureChangeView> structureChanges(@PathVariable("id") long id) {
        LoadView v = require(id);
        return v.getLayoutId() == null ? Collections.<StructureChangeView>emptyList()
                : changes.forLoad(v.getLayoutId(), id);
    }

    @GetMapping("/providers")
    public List<String> providers() {
        return layouts.providers();
    }

    @GetMapping("/loads/{id}/download/original")
    public ResponseEntity<StreamingResponseBody> original(@PathVariable("id") long id) {
        LoadView v = require(id);
        if (v.getArchiveStatus() != ArchiveStatus.ARCHIVED || !archive.hasOriginal(id)) {
            throw new ApiException(HttpStatus.NOT_FOUND, "The original file is not available (archive status "
                    + v.getArchiveStatus() + ")");
        }
        StreamingResponseBody body = out -> archive.streamOriginal(id, out);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, attachment(Safe.fileName(v.getFileName())))
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(body);
    }

    @GetMapping("/loads/{id}/download/report")
    public ResponseEntity<StreamingResponseBody> report(@PathVariable("id") long id) {
        LoadView v = require(id);
        StreamingResponseBody body = out -> report.write(v, out);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, attachment("load-" + id + "-report.csv"))
                .contentType(new MediaType("text", "csv", StandardCharsets.UTF_8))
                .body(body);
    }

    private static String attachment(String fileName) {
        return ContentDisposition.attachment().filename(fileName, StandardCharsets.UTF_8).build().toString();
    }

    private LoadView require(long id) {
        LoadView v = loads.find(id);
        if (v == null) {
            throw new ApiException(HttpStatus.NOT_FOUND, "Load " + id + " not found");
        }
        return v;
    }
}
