package com.poc.ingest.service;

import org.springframework.stereotype.Component;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Loads into a table hold its read lock (several loads may run together);
 * ALTER TABLE on approval needs the write lock, so a column is never added while rows are being inserted.
 * Also serialises "find or create layout" per provider + format so two uploads cannot create two tables.
 */
@Component
public class LayoutLocks {

    private final ConcurrentMap<Long, ReentrantReadWriteLock> tableLocks = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, Object> resolveLocks = new ConcurrentHashMap<>();

    public ReentrantReadWriteLock forLayout(long layoutId) {
        return tableLocks.computeIfAbsent(layoutId, k -> new ReentrantReadWriteLock());
    }

    public Object forResolve(String provider, String format) {
        return resolveLocks.computeIfAbsent(provider + '\u0000' + format, k -> new Object());
    }
}
