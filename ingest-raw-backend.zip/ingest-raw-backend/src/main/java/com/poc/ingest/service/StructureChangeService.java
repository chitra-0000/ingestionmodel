package com.poc.ingest.service;

import com.poc.ingest.config.IngestProperties;
import com.poc.ingest.model.ChangeStatus;
import com.poc.ingest.model.ColumnDef;
import com.poc.ingest.model.FieldKind;
import com.poc.ingest.model.Layout;
import com.poc.ingest.model.SqlType;
import com.poc.ingest.model.StructureChangeView;
import com.poc.ingest.repo.LayoutRepository;
import com.poc.ingest.repo.LoadLogRepository;
import com.poc.ingest.repo.StructureChangeRepository;
import com.poc.ingest.util.Safe;
import com.poc.ingest.web.ApiException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.Lock;

/**
 * Approve = ALTER TABLE ADD (new column) + registry update (+ optional backfill from EXTRA_JSON).
 * Reject = field keeps landing in EXTRA_JSON and is not raised again. Every decision is audited.
 */
@Service
public class StructureChangeService {

    private static final Logger LOG = LoggerFactory.getLogger(StructureChangeService.class);
    public static final String SYSTEM_USER = "SYSTEM";

    private final StructureChangeRepository changes;
    private final LayoutRepository layouts;
    private final LoadLogRepository loads;
    private final DdlService ddl;
    private final LayoutLocks locks;
    private final IngestProperties props;

    public StructureChangeService(StructureChangeRepository changes, LayoutRepository layouts,
                                  LoadLogRepository loads, DdlService ddl, LayoutLocks locks,
                                  IngestProperties props) {
        this.changes = changes;
        this.layouts = layouts;
        this.loads = loads;
        this.ddl = ddl;
        this.locks = locks;
        this.props = props;
    }

    /** Outcome shown to the approver. */
    public static final class Outcome {
        private final List<StructureChangeView> changes;
        private final List<String> notes;

        Outcome(List<StructureChangeView> changes, List<String> notes) {
            this.changes = changes;
            this.notes = notes;
        }

        public List<StructureChangeView> getChanges() { return changes; }
        public List<String> getNotes() { return notes; }
    }

    public Outcome approve(Collection<Long> ids, String approver, String comment, boolean backfill) {
        return approve(ids, approver, comment, backfill, -1L);
    }

    private Outcome approve(Collection<Long> ids, String approver, String comment, boolean backfill,
                            long ownLoadId) {
        List<StructureChangeView> selected = pendingSelection(ids);
        List<String> notes = new ArrayList<>();
        for (Map.Entry<Long, List<StructureChangeView>> e : byLayout(selected).entrySet()) {
            approveForLayout(e.getKey(), e.getValue(), new Decision(approver, comment, backfill, ownLoadId), notes);
            closeReviewIfDone(e.getKey());
        }
        return new Outcome(changes.byIds(ids), notes);
    }

    /** Who decided, why, and whether to backfill. ownLoadId: the load asking (ignored by the busy check). */
    private static final class Decision {
        final String approver;
        final String comment;
        final boolean backfill;
        final long ownLoadId;

        Decision(String approver, String comment, boolean backfill, long ownLoadId) {
            this.approver = approver;
            this.comment = comment;
            this.backfill = backfill;
            this.ownLoadId = ownLoadId;
        }
    }

    private void approveForLayout(long layoutId, List<StructureChangeView> items, Decision d, List<String> notes) {
        Lock w = locks.forLayout(layoutId).writeLock();
        if (!w.tryLock()) {
            throw busy(items.get(0).getTableName());
        }
        try {
            if (loads.isLoadRunning(layoutId, d.ownLoadId)) {
                throw busy(items.get(0).getTableName());
            }
            Layout layout = layouts.findById(layoutId);
            String table = layout.getTableName();
            Set<String> existing = ddl.existingColumns(table);
            for (StructureChangeView c : items) {
                ColumnDef col = findByPath(layout, c.getFieldPath(), c.getFieldKind());
                if (col == null) {
                    if (layout.getDescriptor().dataColumnCount() >= props.getMaxDataColumns()) {
                        throw new ApiException(HttpStatus.CONFLICT, "Table " + table + " already has the maximum of "
                                + props.getMaxDataColumns() + " data columns; the field stays in EXTRA_JSON");
                    }
                    col = newColumn(layout, existing, c);
                    ddl.addColumn(table, col);
                    existing.add(col.getName());
                    layout.getDescriptor().getColumns().add(col);
                    layout.setVersion(layout.getVersion() + 1);
                    layouts.updateDescriptor(layoutId, layout.getDescriptor(), layout.getVersion());
                }
                Long filled = null;
                if (d.backfill) {
                    filled = backfill(table, col, c, notes);
                }
                changes.markApproved(c.getChangeId(), col.getName(), filled, d.approver, d.comment);
                LOG.info("Approved field {} as {}.{} by {}", Safe.log(c.getFieldPath()), table, col.getName(),
                        Safe.log(d.approver));
            }
        } finally {
            w.unlock();
        }
    }

    private Long backfill(String table, ColumnDef col, StructureChangeView c, List<String> notes) {
        if (col.getKind() != FieldKind.SCALAR || col.getSqlType() != SqlType.VARCHAR) {
            notes.add(c.getFieldPath() + ": earlier rows keep this value in EXTRA_JSON (backfill is for short "
                    + "single values only)");
            return null;
        }
        if (!Safe.isSafeJsonKey(c.getFieldPath())) {
            notes.add(c.getFieldPath() + ": name has special characters, earlier rows keep it in EXTRA_JSON");
            return null;
        }
        long n = ddl.backfill(table, col.getName(), c.getFieldPath());
        notes.add(c.getFieldPath() + ": copied into " + col.getName() + " for " + n + " earlier rows");
        return n;
    }

    /** First load into a table it created: approve what it found, if nothing else is loading into the table. */
    public int autoApproveNewLayout(long layoutId, long loadId) {
        List<Long> ids = new ArrayList<>();
        for (StructureChangeView c : changes.pending()) {
            if (c.getLayoutId() == layoutId) {
                ids.add(c.getChangeId());
            }
        }
        if (ids.isEmpty()) {
            return 0;
        }
        try {
            approve(ids, SYSTEM_USER, "Auto-approved: first load of a new table", true, loadId);
            return ids.size();
        } catch (ApiException e) {
            LOG.warn("Auto-approval for new layout {} skipped: {}", layoutId, Safe.log(e.getMessage()));
            return 0;
        }
    }

    public List<StructureChangeView> reject(Collection<Long> ids, String approver, String comment) {
        List<StructureChangeView> selected = pendingSelection(ids);
        for (StructureChangeView c : selected) {
            changes.markRejected(c.getChangeId(), approver, comment);
            LOG.info("Rejected field {} of {} by {}", Safe.log(c.getFieldPath()), c.getTableName(),
                    Safe.log(approver));
        }
        for (Long layoutId : byLayout(selected).keySet()) {
            closeReviewIfDone(layoutId);
        }
        return changes.byIds(ids);
    }

    private void closeReviewIfDone(long layoutId) {
        if (changes.countPending(layoutId) == 0) {
            loads.markReviewed(layoutId);
        }
    }

    private List<StructureChangeView> pendingSelection(Collection<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Select at least one field");
        }
        List<StructureChangeView> found = changes.byIds(ids);
        if (found.size() != ids.size()) {
            throw new ApiException(HttpStatus.NOT_FOUND, "One or more selected fields do not exist");
        }
        for (StructureChangeView c : found) {
            if (c.getStatus() != ChangeStatus.PENDING) {
                throw new ApiException(HttpStatus.CONFLICT,
                        "Field " + c.getFieldPath() + " was already " + c.getStatus().name().toLowerCase(java.util.Locale.ROOT));
            }
        }
        return found;
    }

    private static Map<Long, List<StructureChangeView>> byLayout(List<StructureChangeView> list) {
        Map<Long, List<StructureChangeView>> m = new LinkedHashMap<>();
        for (StructureChangeView c : list) {
            m.computeIfAbsent(c.getLayoutId(), k -> new ArrayList<>()).add(c);
        }
        return m;
    }

    private static ColumnDef findByPath(Layout layout, String path, FieldKind kind) {
        for (ColumnDef c : layout.getDescriptor().getColumns()) {
            if (c.getPath().equals(path) && c.getKind() == kind) {
                return c;
            }
        }
        return null;
    }

    private ColumnDef newColumn(Layout layout, Set<String> existing, StructureChangeView c) {
        boolean group = c.getFieldKind() == FieldKind.GROUP;
        String prefix = group ? "G" : "C";
        int max = 0;
        for (ColumnDef d : layout.getDescriptor().getColumns()) {
            max = Math.max(max, suffix(d.getName(), prefix));
        }
        for (String e : existing) {
            max = Math.max(max, suffix(e, prefix));
        }
        String name = String.format("%s%04d", prefix, max + 1);
        SqlType type = group || c.getMaxLength() > props.getClobThresholdBytes() ? SqlType.CLOB : SqlType.VARCHAR;
        return new ColumnDef(name, c.getFieldPath(), group ? FieldKind.GROUP : FieldKind.SCALAR, type);
    }

    private static int suffix(String column, String prefix) {
        if (column.length() == 5 && column.startsWith(prefix)) {
            try {
                return Integer.parseInt(column.substring(1));
            } catch (NumberFormatException e) {
                return 0;
            }
        }
        return 0;
    }

    private static ApiException busy(String table) {
        return new ApiException(HttpStatus.CONFLICT,
                "A file is loading into " + table + " right now. Approve after it finishes.");
    }
}
