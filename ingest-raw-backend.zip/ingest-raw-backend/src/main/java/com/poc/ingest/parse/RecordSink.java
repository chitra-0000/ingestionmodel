package com.poc.ingest.parse;

/** Receives records one at a time from a streaming engine. */
public interface RecordSink {

    /**
     * @param containerPath path of the element/array that holds the records, e.g. /PFA/Records
     * @param record        the complete record subtree; it is not referenced after this call
     */
    void onRecord(String containerPath, Node record);

    /** Return true to stop reading (used by sampling). */
    boolean isDone();
}
