package com.poc.ingest.flatten;

/** Record-relative path naming: "NameDetails/Name", "@id", "CountryValue/@Code", "#text" for the record's own text. */
public final class Paths {

    public static final String ROOT_TEXT = "#text";

    private Paths() {
    }

    public static String child(String rel, String name) {
        return rel.isEmpty() ? name : rel + "/" + name;
    }

    public static String attr(String rel, String name) {
        return rel.isEmpty() ? "@" + name : rel + "/@" + name;
    }

    public static String text(String rel) {
        return rel.isEmpty() ? ROOT_TEXT : rel;
    }

    /** True when {@code path} lies strictly below {@code ancestor}. */
    public static boolean isBelow(String path, String ancestor) {
        return path.length() > ancestor.length() && path.startsWith(ancestor) && path.charAt(ancestor.length()) == '/';
    }

    /** RECORD_TYPE value: container name + "/" + record element, e.g. "Records/Person"; CSV rows are "row". */
    public static String recordType(String containerPath, String elementName) {
        int slash = containerPath.lastIndexOf('/');
        String container = slash >= 0 ? containerPath.substring(slash + 1) : containerPath;
        return container.isEmpty() ? elementName : container + "/" + elementName;
    }

    public static String lastSegment(String path) {
        int slash = path.lastIndexOf('/');
        String s = slash >= 0 ? path.substring(slash + 1) : path;
        return s.isEmpty() ? path : s;
    }
}
