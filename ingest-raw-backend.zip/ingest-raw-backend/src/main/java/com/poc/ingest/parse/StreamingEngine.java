package com.poc.ingest.parse;

import java.io.IOException;
import java.io.InputStream;
import java.util.Set;

/** One-pass, constant-memory reader. Memory holds one record at a time plus the small envelope. */
public interface StreamingEngine {

    /**
     * Streams records to the sink.
     *
     * @param knownContainers container paths learned from sampling or the registry (XML); others may be ignored
     * @return the envelope: everything in the file that is not inside a record (root attributes, headers, small lists)
     */
    Node parse(InputStream in, Set<String> knownContainers, RecordSink sink) throws IOException;
}
