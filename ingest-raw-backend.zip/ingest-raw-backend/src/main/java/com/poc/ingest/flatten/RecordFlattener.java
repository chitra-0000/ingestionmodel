package com.poc.ingest.flatten;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.poc.ingest.model.ColumnDef;
import com.poc.ingest.model.FieldKind;
import com.poc.ingest.model.LayoutDescriptor;
import com.poc.ingest.model.SqlType;
import com.poc.ingest.parse.Node;
import com.poc.ingest.parse.NodeJson;
import com.poc.ingest.util.Safe;

import java.io.IOException;
import java.io.StringWriter;
import java.io.UncheckedIOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Turns one record into one row WITHOUT losing anything:
 * mapped scalars -> C columns, mapped repeating groups -> G columns (JSON array),
 * everything else -> EXTRA_JSON {"unmapped":{...},"oversize":{...},"empty":[...],"null":[...]}.
 * Not thread-safe: one instance per load, used by the single parser thread.
 */
public final class RecordFlattener {

    private static final JsonFactory JSON = new JsonFactory();
    private static final int MAX_TRACKED_CHANGES = 5_000;

    private final Map<String, Integer> scalarIdx = new HashMap<>();
    private final Map<String, Integer> groupIdx = new HashMap<>();
    private final SqlType[] types;
    private final int width;
    private final int varcharMaxBytes;
    private final boolean trackEmpty;
    private final Map<String, ChangeStat> changes = new LinkedHashMap<>();

    /** Per-record scratch (reused). */
    private String[] values;
    private Extra extra;

    public RecordFlattener(LayoutDescriptor d, int varcharMaxBytes, boolean trackEmpty) {
        List<ColumnDef> cols = d.getColumns();
        this.width = cols.size();
        this.types = new SqlType[width];
        for (int i = 0; i < width; i++) {
            ColumnDef c = cols.get(i);
            types[i] = c.getSqlType();
            if (c.getKind() == FieldKind.GROUP) {
                groupIdx.put(c.getPath(), i);
            } else {
                scalarIdx.put(c.getPath(), i);
            }
        }
        this.varcharMaxBytes = varcharMaxBytes;
        this.trackEmpty = trackEmpty;
    }

    public Collection<ChangeStat> changes() {
        return changes.values();
    }

    public RowData toRow(long rowNo, String containerPath, Node record) {
        values = new String[width];
        extra = null;
        walk(record, "");
        return new RowData(rowNo, Paths.recordType(containerPath, record.getName()), values,
                extra == null ? null : extra.toJson());
    }

    public static RefRow toRef(long rowNo, String containerPath, Node record) {
        String code = null;
        String value = record.hasNonBlankText() ? record.text() : null;
        Map<String, String> fields = new LinkedHashMap<>(record.attrs());
        for (Node c : record.children()) {
            if (!c.hasChildren() && !c.hasAttrs() && !fields.containsKey(c.getName())) {
                fields.put(c.getName(), c.text());
            }
        }
        for (Map.Entry<String, String> f : fields.entrySet()) {
            String k = f.getKey().toLowerCase(java.util.Locale.ROOT);
            if (code == null && (k.equals("code") || k.equals("id") || k.endsWith("code") || k.endsWith("id"))) {
                code = f.getValue();
            } else if (value == null && (k.equals("name") || k.equals("value") || k.endsWith("name")
                    || k.equals("description"))) {
                value = f.getValue();
            }
        }
        if (code == null && !fields.isEmpty()) {
            code = fields.values().iterator().next();
        }
        return new RefRow(rowNo, Paths.lastSegment(containerPath), Paths.recordType(containerPath, record.getName()),
                Safe.truncateBytes(code, 4000), Safe.truncateBytes(value, 4000), NodeJson.toJson(record));
    }

    private void walk(Node n, String rel) {
        for (Map.Entry<String, String> a : n.attrs().entrySet()) {
            scalar(Paths.attr(rel, a.getKey()), a.getValue(), false);
        }
        if (!n.hasChildren()) {
            if (n.isJsonNull()) {
                scalar(Paths.text(rel), null, true);
            } else if (!n.hasAttrs() || !n.text().isEmpty()) {
                scalar(Paths.text(rel), n.text(), false);
            }
        } else if (n.hasNonBlankText()) {
            scalar(Paths.text(rel), n.text(), false);
        }
        for (Map.Entry<String, List<Node>> e : n.childrenByName().entrySet()) {
            List<Node> list = e.getValue();
            String cp = Paths.child(rel, e.getKey());
            Integer g = groupIdx.get(cp);
            Node first = list.get(0);
            if (g != null) {
                values[g] = NodeJson.toJsonArray(list);
            } else if (list.size() > 1 || first.isArrayItem() || first.isEmptyArray()) {
                String json = NodeJson.toJsonArray(list);
                extra().unmapped.put(cp, new RawJson(json));
                track(cp, FieldKind.GROUP, json);
            } else {
                walk(first, cp);
            }
        }
    }

    private void scalar(String path, String value, boolean isNull) {
        Integer i = scalarIdx.get(path);
        if (i == null) {
            Extra x = extra();
            if (isNull) {
                x.nulls.add(path);
            } else {
                x.unmapped.put(x.unmapped.containsKey(path) ? path + "#dup" + x.unmapped.size() : path, value);
                track(path, FieldKind.SCALAR, value);
            }
            return;
        }
        if (isNull) {
            extra().nulls.add(path);
        } else if (value.isEmpty()) {
            if (trackEmpty) {
                extra().empty.add(path);
            }
        } else if (values[i] != null) {
            extra().unmapped.put(path + "#dup" + extra().unmapped.size(), value);
        } else if (types[i] == SqlType.VARCHAR && value.length() * 3 > varcharMaxBytes
                && Safe.utf8Length(value) > varcharMaxBytes) {
            extra().oversize.put(path, value);
        } else {
            values[i] = value;
        }
    }

    private void track(String path, FieldKind kind, String value) {
        ChangeStat s = changes.get(path);
        if (s == null) {
            if (changes.size() >= MAX_TRACKED_CHANGES) {
                return;
            }
            s = new ChangeStat(path, kind);
            changes.put(path, s);
        }
        s.record(kind, value, value == null ? 0 : Safe.utf8Length(value));
    }

    private Extra extra() {
        if (extra == null) {
            extra = new Extra();
        }
        return extra;
    }

    /** Marks a value that is already JSON text. */
    private static final class RawJson {
        final String json;

        RawJson(String json) {
            this.json = json;
        }
    }

    private static final class Extra {
        final Map<String, Object> unmapped = new LinkedHashMap<>();
        final Map<String, String> oversize = new LinkedHashMap<>();
        final List<String> empty = new ArrayList<>();
        final List<String> nulls = new ArrayList<>();

        boolean isEmpty() {
            return unmapped.isEmpty() && oversize.isEmpty() && empty.isEmpty() && nulls.isEmpty();
        }

        String toJson() {
            if (isEmpty()) {
                return null;
            }
            StringWriter w = new StringWriter(128);
            try (JsonGenerator g = JSON.createGenerator(w)) {
                g.writeStartObject();
                if (!unmapped.isEmpty()) {
                    g.writeObjectFieldStart("unmapped");
                    for (Map.Entry<String, Object> e : unmapped.entrySet()) {
                        g.writeFieldName(e.getKey());
                        if (e.getValue() instanceof RawJson) {
                            g.writeRawValue(((RawJson) e.getValue()).json);
                        } else {
                            g.writeString((String) e.getValue());
                        }
                    }
                    g.writeEndObject();
                }
                if (!oversize.isEmpty()) {
                    g.writeObjectFieldStart("oversize");
                    for (Map.Entry<String, String> e : oversize.entrySet()) {
                        g.writeStringField(e.getKey(), e.getValue());
                    }
                    g.writeEndObject();
                }
                writeList(g, "empty", empty);
                writeList(g, "null", nulls);
                g.writeEndObject();
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
            return w.toString();
        }

        private static void writeList(JsonGenerator g, String name, List<String> list) throws IOException {
            if (list.isEmpty()) {
                return;
            }
            g.writeArrayFieldStart(name);
            for (String s : list) {
                g.writeString(s);
            }
            g.writeEndArray();
        }
    }
}
