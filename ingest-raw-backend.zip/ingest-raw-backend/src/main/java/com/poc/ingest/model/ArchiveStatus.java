package com.poc.ingest.model;

public enum ArchiveStatus {
    PENDING, ARCHIVED, FAILED, PURGED
}
