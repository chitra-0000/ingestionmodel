package com.poc.ingest.repo;

import com.poc.ingest.flatten.ChangeStat;
import com.poc.ingest.model.ChangeStatus;
import com.poc.ingest.model.FieldKind;
import com.poc.ingest.model.StructureChangeView;
import com.poc.ingest.util.Safe;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Collection;
import java.util.List;

/** INGEST_STRUCTURE_CHANGE: new fields awaiting approval, and the decision audit trail. */
@Repository
public class StructureChangeRepository {

    public static final int MAX_PATH_LENGTH = 1000;

    private static final String SELECT = "SELECT c.CHANGE_ID, c.LAYOUT_ID, r.TABLE_NAME, c.FIRST_LOAD_ID, "
            + "c.LAST_LOAD_ID, c.FIELD_PATH, c.FIELD_KIND, c.OCCURRENCES, c.MAX_LENGTH, c.SAMPLE_VALUE, c.STATUS, "
            + "c.COLUMN_NAME, c.BACKFILLED_ROWS, c.DECIDED_BY, c.DECIDED_AT, c.DECISION_COMMENT, c.DETECTED_AT "
            + "FROM INGEST_STRUCTURE_CHANGE c JOIN INGEST_FORMAT_REGISTRY r ON r.LAYOUT_ID = c.LAYOUT_ID ";

    private static final RowMapper<StructureChangeView> MAPPER = (rs, i) -> {
        StructureChangeView v = new StructureChangeView();
        v.setChangeId(rs.getLong("CHANGE_ID"));
        v.setLayoutId(rs.getLong("LAYOUT_ID"));
        v.setTableName(rs.getString("TABLE_NAME"));
        v.setFirstLoadId(rs.getLong("FIRST_LOAD_ID"));
        v.setLastLoadId(rs.getLong("LAST_LOAD_ID"));
        v.setFieldPath(rs.getString("FIELD_PATH"));
        v.setFieldKind(FieldKind.valueOf(rs.getString("FIELD_KIND")));
        v.setOccurrences(rs.getLong("OCCURRENCES"));
        v.setMaxLength(rs.getInt("MAX_LENGTH"));
        v.setSampleValue(rs.getString("SAMPLE_VALUE"));
        v.setStatus(ChangeStatus.valueOf(rs.getString("STATUS")));
        v.setColumnName(rs.getString("COLUMN_NAME"));
        long b = rs.getLong("BACKFILLED_ROWS");
        v.setBackfilledRows(rs.wasNull() ? null : b);
        v.setDecidedBy(rs.getString("DECIDED_BY"));
        Timestamp d = rs.getTimestamp("DECIDED_AT");
        v.setDecidedAt(d == null ? null : d.toInstant());
        v.setDecisionComment(rs.getString("DECISION_COMMENT"));
        v.setDetectedAt(rs.getTimestamp("DETECTED_AT").toInstant());
        return v;
    };

    private final JdbcTemplate jdbc;
    private final NamedParameterJdbcTemplate named;
    private final LayoutRepository layouts;

    public StructureChangeRepository(JdbcTemplate jdbc, NamedParameterJdbcTemplate named, LayoutRepository layouts) {
        this.jdbc = jdbc;
        this.named = named;
        this.layouts = layouts;
    }

    /**
     * Records a new field seen by a load.
     *
     * @return true if the field is (still) pending approval; false if it was rejected before
     */
    public boolean upsert(long layoutId, long loadId, ChangeStat s) {
        List<StructureChangeView> existing = jdbc.query(SELECT + "WHERE c.LAYOUT_ID = ? AND c.FIELD_PATH = ?",
                MAPPER, layoutId, s.getPath());
        String sample = Safe.truncateBytes(s.getSample(), 400);
        if (existing.isEmpty()) {
            jdbc.update("INSERT INTO INGEST_STRUCTURE_CHANGE (CHANGE_ID, LAYOUT_ID, FIRST_LOAD_ID, LAST_LOAD_ID, "
                            + "FIELD_PATH, FIELD_KIND, OCCURRENCES, MAX_LENGTH, SAMPLE_VALUE, STATUS, DETECTED_AT) "
                            + "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    layouts.nextId(), layoutId, loadId, loadId, s.getPath(), s.getKind().name(), s.getOccurrences(),
                    s.getMaxBytes(), sample, ChangeStatus.PENDING.name(), Timestamp.from(Instant.now()));
            return true;
        }
        StructureChangeView e = existing.get(0);
        if (e.getStatus() != ChangeStatus.PENDING) {
            return false;
        }
        String kind = s.getKind() == FieldKind.GROUP ? FieldKind.GROUP.name() : e.getFieldKind().name();
        jdbc.update("UPDATE INGEST_STRUCTURE_CHANGE SET LAST_LOAD_ID = ?, OCCURRENCES = OCCURRENCES + ?, "
                        + "MAX_LENGTH = ?, FIELD_KIND = ? WHERE CHANGE_ID = ?",
                loadId, s.getOccurrences(), Math.max(e.getMaxLength(), s.getMaxBytes()), kind, e.getChangeId());
        return true;
    }

    /** Pending changes of the load's layout plus every decision on fields this load raised. */
    public List<StructureChangeView> forLoad(long layoutId, long loadId) {
        return jdbc.query(SELECT + "WHERE c.LAYOUT_ID = ? AND (c.STATUS = ? OR c.FIRST_LOAD_ID = ? "
                + "OR c.LAST_LOAD_ID = ?) ORDER BY c.CHANGE_ID", MAPPER, layoutId, ChangeStatus.PENDING.name(),
                loadId, loadId);
    }

    public List<StructureChangeView> byIds(Collection<Long> ids) {
        if (ids.isEmpty()) {
            return java.util.Collections.emptyList();
        }
        return named.query(SELECT + "WHERE c.CHANGE_ID IN (:ids) ORDER BY c.CHANGE_ID",
                new MapSqlParameterSource("ids", ids), MAPPER);
    }

    public List<StructureChangeView> pending() {
        return jdbc.query(SELECT + "WHERE c.STATUS = ? ORDER BY c.CHANGE_ID", MAPPER, ChangeStatus.PENDING.name());
    }

    public int countPending(long layoutId) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM INGEST_STRUCTURE_CHANGE WHERE LAYOUT_ID = ? AND STATUS = ?",
                Integer.class, layoutId, ChangeStatus.PENDING.name());
        return n == null ? 0 : n;
    }

    public void markApproved(long changeId, String column, Long backfilled, String by, String comment) {
        jdbc.update("UPDATE INGEST_STRUCTURE_CHANGE SET STATUS = ?, COLUMN_NAME = ?, BACKFILLED_ROWS = ?, "
                        + "DECIDED_BY = ?, DECIDED_AT = ?, DECISION_COMMENT = ? WHERE CHANGE_ID = ? AND STATUS = ?",
                ChangeStatus.APPROVED.name(), column, backfilled, by, Timestamp.from(Instant.now()), comment,
                changeId, ChangeStatus.PENDING.name());
    }

    public void markRejected(long changeId, String by, String comment) {
        jdbc.update("UPDATE INGEST_STRUCTURE_CHANGE SET STATUS = ?, DECIDED_BY = ?, DECIDED_AT = ?, "
                        + "DECISION_COMMENT = ? WHERE CHANGE_ID = ? AND STATUS = ?",
                ChangeStatus.REJECTED.name(), by, Timestamp.from(Instant.now()), comment, changeId,
                ChangeStatus.PENDING.name());
    }
}
