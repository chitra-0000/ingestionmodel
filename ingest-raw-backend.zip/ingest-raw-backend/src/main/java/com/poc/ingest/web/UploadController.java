package com.poc.ingest.web;

import com.poc.ingest.model.LoadView;
import com.poc.ingest.service.LoadService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;

@RestController
@RequestMapping("/api/uploads")
public class UploadController {

    private final LoadService loadService;

    public UploadController(LoadService loadService) {
        this.loadService = loadService;
    }

    /** Accepts the file and returns at once (202); the load runs in the background. */
    @PostMapping
    public ResponseEntity<LoadView> upload(@RequestParam("provider") String provider,
                                           @RequestPart("file") MultipartFile file) throws IOException {
        if (file.isEmpty()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "The file is empty");
        }
        try (InputStream in = file.getInputStream()) {
            return ResponseEntity.status(HttpStatus.ACCEPTED)
                    .body(loadService.submit(provider, file.getOriginalFilename(), in));
        }
    }
}
