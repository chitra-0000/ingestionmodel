package com.poc.ingest.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The "runtime extractor": how one provider/format layout maps onto its table.
 * Stored as JSON in INGEST_FORMAT_REGISTRY.DESCRIPTOR_JSON.
 */
public class LayoutDescriptor {

    private FormatType format;
    /** Container path -> DATA or REF. Children of a container are records. */
    private Map<String, ContainerKind> containers = new LinkedHashMap<>();
    private List<ColumnDef> columns = new ArrayList<>();

    public FormatType getFormat() { return format; }
    public void setFormat(FormatType format) { this.format = format; }
    public Map<String, ContainerKind> getContainers() { return containers; }
    public void setContainers(Map<String, ContainerKind> containers) { this.containers = containers; }
    public List<ColumnDef> getColumns() { return columns; }
    public void setColumns(List<ColumnDef> columns) { this.columns = columns; }

    /** Field paths plus container paths: what layout matching compares. */
    @JsonIgnore
    public Set<String> signature() {
        Set<String> s = new HashSet<>();
        for (String c : containers.keySet()) {
            s.add("container:" + c);
        }
        for (ColumnDef c : columns) {
            s.add(c.getKind() + ":" + c.getPath());
        }
        return s;
    }

    @JsonIgnore
    public int dataColumnCount() {
        return columns.size();
    }
}
