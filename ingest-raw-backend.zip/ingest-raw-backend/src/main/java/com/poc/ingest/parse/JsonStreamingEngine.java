package com.poc.ingest.parse;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.StreamReadConstraints;

import java.io.IOException;
import java.io.InputStream;
import java.util.Set;

/**
 * Jackson streaming engine. Every array of objects outside a record is a container; its objects are records.
 * Paths: root is "$", object keys append "/key". Scalars keep their exact source text (1.50 stays "1.50").
 */
public final class JsonStreamingEngine implements StreamingEngine {

    private static final String ROOT = "$";
    private static final int MAX_DEPTH = 200;

    private final JsonFactory factory;

    public JsonStreamingEngine() {
        this.factory = JsonFactory.builder()
                .streamReadConstraints(StreamReadConstraints.builder()
                        .maxNestingDepth(MAX_DEPTH)
                        .build())
                .build();
    }

    /** Thrown internally to stop sampling early. */
    private static final class StopParsing extends RuntimeException {
        private static final long serialVersionUID = 1L;

        StopParsing() {
            super(null, null, false, false);
        }
    }

    @Override
    public Node parse(InputStream in, Set<String> knownContainers, RecordSink sink) throws IOException {
        Node envelope = new Node(ROOT);
        try (JsonParser p = factory.createParser(in)) {
            JsonToken t = p.nextToken();
            if (t == null) {
                return envelope;
            }
            if (t == JsonToken.START_ARRAY) {
                envelopeArray(p, envelope, "record", ROOT, sink);
            } else if (t == JsonToken.START_OBJECT) {
                envelopeObjectFields(p, envelope, ROOT, sink);
            } else {
                envelope.appendText(p.getText());
            }
        } catch (StopParsing stop) {
            return envelope;
        } catch (com.fasterxml.jackson.core.JsonProcessingException e) {
            throw new ParseException("JSON is not well-formed: " + e.getOriginalMessage(), e);
        }
        return envelope;
    }

    private void envelopeObjectFields(JsonParser p, Node parent, String path, RecordSink sink) throws IOException {
        while (p.nextToken() == JsonToken.FIELD_NAME) {
            String key = p.getCurrentName();
            JsonToken v = p.nextToken();
            String childPath = path + "/" + key;
            if (v == JsonToken.START_OBJECT) {
                Node child = new Node(key);
                parent.addChild(child);
                envelopeObjectFields(p, child, childPath, sink);
            } else if (v == JsonToken.START_ARRAY) {
                envelopeArray(p, parent, key, childPath, sink);
            } else {
                parent.addChild(scalar(p, key, v));
            }
        }
    }

    /** An array outside records: objects make it a container, anything else stays in the envelope. */
    private void envelopeArray(JsonParser p, Node parent, String key, String path, RecordSink sink) throws IOException {
        JsonToken first = p.nextToken();
        if (first == JsonToken.END_ARRAY) {
            Node empty = new Node(key);
            empty.setEmptyArray(true);
            parent.addChild(empty);
            return;
        }
        if (first == JsonToken.START_OBJECT) {
            JsonToken t = first;
            while (t != JsonToken.END_ARRAY) {
                Node record = value(p, key, t);
                sink.onRecord(path, record);
                if (sink.isDone()) {
                    throw new StopParsing();
                }
                t = p.nextToken();
            }
            return;
        }
        JsonToken t = first;
        while (t != JsonToken.END_ARRAY) {
            Node item = value(p, key, t);
            item.setArrayItem(true);
            parent.addChild(item);
            t = p.nextToken();
        }
    }

    /** Reads one complete value (current token t) into a Node; recursion depth is bounded by the parser's nesting limit. */
    private Node value(JsonParser p, String name, JsonToken t) throws IOException {
        if (t == JsonToken.START_OBJECT) {
            Node n = new Node(name);
            while (p.nextToken() == JsonToken.FIELD_NAME) {
                String key = p.getCurrentName();
                JsonToken v = p.nextToken();
                if (v == JsonToken.START_ARRAY) {
                    readArrayInto(p, n, key);
                } else {
                    n.addChild(value(p, key, v));
                }
            }
            return n;
        }
        if (t == JsonToken.START_ARRAY) {
            // array directly inside an array: wrap it so the nesting survives
            Node n = new Node(name);
            readArrayInto(p, n, name);
            return n;
        }
        return scalar(p, name, t);
    }

    private void readArrayInto(JsonParser p, Node parent, String key) throws IOException {
        JsonToken t = p.nextToken();
        if (t == JsonToken.END_ARRAY) {
            Node empty = new Node(key);
            empty.setEmptyArray(true);
            parent.addChild(empty);
            return;
        }
        while (t != JsonToken.END_ARRAY) {
            Node item = value(p, key, t);
            item.setArrayItem(true);
            parent.addChild(item);
            t = p.nextToken();
        }
    }

    private static Node scalar(JsonParser p, String name, JsonToken t) throws IOException {
        Node n = new Node(name);
        if (t == JsonToken.VALUE_NULL) {
            n.setJsonNull(true);
        } else {
            n.appendText(p.getText());
            n.setLiteral(t != JsonToken.VALUE_STRING);
        }
        return n;
    }
}
