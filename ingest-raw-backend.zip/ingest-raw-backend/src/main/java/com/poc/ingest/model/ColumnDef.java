package com.poc.ingest.model;

/** One generated column: C0001.. for scalars, G0001.. for repeating groups. The source path is kept here, never in SQL. */
public class ColumnDef {

    private String name;
    private String path;
    private FieldKind kind;
    private SqlType sqlType;

    public ColumnDef() {
        // for Jackson
    }

    public ColumnDef(String name, String path, FieldKind kind, SqlType sqlType) {
        this.name = name;
        this.path = path;
        this.kind = kind;
        this.sqlType = sqlType;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPath() { return path; }
    public void setPath(String path) { this.path = path; }
    public FieldKind getKind() { return kind; }
    public void setKind(FieldKind kind) { this.kind = kind; }
    public SqlType getSqlType() { return sqlType; }
    public void setSqlType(SqlType sqlType) { this.sqlType = sqlType; }
}
