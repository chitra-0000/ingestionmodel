package com.poc.ingest.flatten;

/** One INGEST_REF_DATA row. recordJson is the complete element, so code/value guessing can never lose data. */
public final class RefRow {

    private final long rowNo;
    private final String listName;
    private final String recordType;
    private final String code;
    private final String value;
    private final String recordJson;

    public RefRow(long rowNo, String listName, String recordType, String code, String value, String recordJson) {
        this.rowNo = rowNo;
        this.listName = listName;
        this.recordType = recordType;
        this.code = code;
        this.value = value;
        this.recordJson = recordJson;
    }

    public long getRowNo() { return rowNo; }
    public String getListName() { return listName; }
    public String getRecordType() { return recordType; }
    public String getCode() { return code; }
    public String getValue() { return value; }
    public String getRecordJson() { return recordJson; }
}
