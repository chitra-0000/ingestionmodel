package com.poc.ingest.service;

import com.poc.ingest.config.IngestProperties;
import com.poc.ingest.flatten.DiscoveryCollector;
import com.poc.ingest.model.ContainerKind;
import com.poc.ingest.model.FormatType;
import com.poc.ingest.model.Layout;
import com.poc.ingest.model.LayoutDescriptor;
import com.poc.ingest.parse.CsvStreamingEngine;
import com.poc.ingest.parse.JsonStreamingEngine;
import com.poc.ingest.parse.StreamingEngine;
import com.poc.ingest.parse.XmlContainerScanner;
import com.poc.ingest.parse.XmlStreamingEngine;
import com.poc.ingest.repo.LayoutRepository;
import com.poc.ingest.util.Safe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Sampling of the file head, matching against the registry, and runtime CREATE TABLE for new layouts. */
@Service
public class LayoutService {

    private static final Logger LOG = LoggerFactory.getLogger(LayoutService.class);

    private final IngestProperties props;
    private final LayoutRepository layouts;
    private final DdlService ddl;
    private final LayoutLocks locks;

    public LayoutService(IngestProperties props, LayoutRepository layouts, DdlService ddl, LayoutLocks locks) {
        this.props = props;
        this.layouts = layouts;
        this.ddl = ddl;
        this.locks = locks;
    }

    /** What sampling learned about one file. */
    public static final class Sample {
        private final LayoutDescriptor descriptor;
        private final Set<String> scannedContainers;
        private final long records;

        Sample(LayoutDescriptor descriptor, Set<String> scannedContainers, long records) {
            this.descriptor = descriptor;
            this.scannedContainers = scannedContainers;
            this.records = records;
        }

        public LayoutDescriptor getDescriptor() { return descriptor; }
        public Set<String> getScannedContainers() { return scannedContainers; }
        public long getRecords() { return records; }
    }

    /** The layout to load into, and whether this load created it. */
    public static final class Resolution {
        private final Layout layout;
        private final boolean created;

        Resolution(Layout layout, boolean created) {
            this.layout = layout;
            this.created = created;
        }

        public Layout getLayout() { return layout; }
        public boolean isCreated() { return created; }
    }

    public StreamingEngine engineFor(FormatType format) {
        switch (format) {
            case XML:
                return new XmlStreamingEngine(props.getAutoContainerThreshold());
            case JSON:
                return new JsonStreamingEngine();
            default:
                return new CsvStreamingEngine(StandardCharsets.UTF_8);
        }
    }

    public Sample sample(Path file, FormatType format) throws IOException {
        Set<String> scanned = Collections.emptySet();
        if (format == FormatType.XML) {
            try (InputStream in = open(file)) {
                scanned = XmlContainerScanner.scan(in, props.getContainerScanElements());
            }
        }
        DiscoveryCollector collector = new DiscoveryCollector(props.getSampleRecords());
        try (InputStream in = open(file)) {
            engineFor(format).parse(in, scanned, collector);
        }
        return new Sample(collector.build(format, props), scanned, collector.getTotal());
    }

    static InputStream open(Path file) throws IOException {
        return new BufferedInputStream(Files.newInputStream(file), 256 * 1024);
    }

    /** Finds the provider's table for this layout, or creates one. Serialised per provider + format. */
    public Resolution resolve(String provider, FormatType format, Sample sample) {
        synchronized (locks.forResolve(provider, format.name())) {
            List<Layout> candidates = layouts.findByProviderAndFormat(provider, format);
            Set<String> sig = sample.getDescriptor().signature();
            Layout best = null;
            double bestScore = -1;
            for (Layout l : candidates) {
                double score = overlap(sig, l.getDescriptor().signature());
                if (score > bestScore) {
                    bestScore = score;
                    best = l;
                }
            }
            boolean nothingSampled = sample.getRecords() == 0;
            if (best != null && (bestScore >= props.getLayoutMatchThreshold() || nothingSampled)) {
                mergeContainers(best, sample.getDescriptor());
                return new Resolution(best, false);
            }
            return new Resolution(create(provider, format, sample.getDescriptor(), candidates.size()), true);
        }
    }

    /**
     * Containers are not columns: newly seen ones are recorded in the registry without approval.
     * Skipped (not needed for this load) if an approval currently holds the table lock.
     */
    private void mergeContainers(Layout layout, LayoutDescriptor sampled) {
        java.util.concurrent.locks.Lock w = locks.forLayout(layout.getLayoutId()).writeLock();
        if (!w.tryLock()) {
            return;
        }
        try {
            Layout fresh = layouts.findById(layout.getLayoutId());
            boolean changed = false;
            for (Map.Entry<String, ContainerKind> e : sampled.getContainers().entrySet()) {
                if (!fresh.getDescriptor().getContainers().containsKey(e.getKey())) {
                    fresh.getDescriptor().getContainers().put(e.getKey(), e.getValue());
                    changed = true;
                }
            }
            if (changed) {
                layouts.updateDescriptor(fresh.getLayoutId(), fresh.getDescriptor(), fresh.getVersion());
            }
        } finally {
            w.unlock();
        }
    }

    private Layout create(String provider, FormatType format, LayoutDescriptor d, int existing) {
        String base = "RAW_" + Safe.identifierFragment(provider, 40) + "_" + format.name() + "_";
        int n = existing + 1;
        while (layouts.tableNameExists(base + n)) {
            n++;
        }
        String table = Safe.sqlIdentifier(base + n);
        ddl.createDataTable(table, d);
        Layout l = new Layout();
        l.setLayoutId(layouts.nextId());
        l.setProvider(provider);
        l.setFormat(format);
        l.setTableName(table);
        l.setFingerprint(fingerprint(d.signature()));
        l.setDescriptor(d);
        l.setVersion(1);
        layouts.insert(l);
        LOG.info("Created table {} for provider {} format {} with {} data columns", table, Safe.log(provider),
                format, d.dataColumnCount());
        return l;
    }

    /**
     * Share of the smaller field set found in the other. A file that only ADDS fields to a known layout scores 1.0
     * (same table, new fields go to approval); a file with a different structure scores low (new table).
     */
    static double overlap(Set<String> sample, Set<String> layout) {
        if (sample.isEmpty() || layout.isEmpty()) {
            return sample.isEmpty() && layout.isEmpty() ? 1.0 : 0.0;
        }
        int hit = 0;
        for (String s : sample) {
            if (layout.contains(s)) {
                hit++;
            }
        }
        return (double) hit / Math.min(sample.size(), layout.size());
    }

    static String fingerprint(Set<String> signature) {
        List<String> sorted = new ArrayList<>(signature);
        Collections.sort(sorted);
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            for (String s : sorted) {
                md.update(s.getBytes(StandardCharsets.UTF_8));
                md.update((byte) '\n');
            }
            return hex(md.digest());
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    public static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) {
            sb.append(Character.forDigit((x >> 4) & 0xF, 16)).append(Character.forDigit(x & 0xF, 16));
        }
        return sb.toString();
    }

    /** Container kinds for this load: registry first, then what sampling found. */
    public static Map<String, ContainerKind> containerKinds(Layout layout, Sample sample) {
        Map<String, ContainerKind> m = new java.util.LinkedHashMap<>(sample.getDescriptor().getContainers());
        m.putAll(layout.getDescriptor().getContainers());
        return m;
    }

    /** Containers the engine must treat as record containers for this load. */
    public static Set<String> knownContainers(Layout layout, Sample sample) {
        Set<String> s = new LinkedHashSet<>(layout.getDescriptor().getContainers().keySet());
        s.addAll(sample.getScannedContainers());
        s.addAll(sample.getDescriptor().getContainers().keySet());
        return s;
    }
}
