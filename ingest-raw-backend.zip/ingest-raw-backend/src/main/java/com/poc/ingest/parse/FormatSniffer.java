package com.poc.ingest.parse;

import com.poc.ingest.model.FormatType;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/** Detects the format from content, not from the file extension. */
public final class FormatSniffer {

    private FormatSniffer() {
    }

    public static FormatType detect(Path file) throws IOException {
        byte[] head = new byte[4096];
        int n;
        try (InputStream in = Files.newInputStream(file)) {
            n = in.read(head);
        }
        int i = 0;
        if (n >= 3 && (head[0] & 0xFF) == 0xEF && (head[1] & 0xFF) == 0xBB && (head[2] & 0xFF) == 0xBF) {
            i = 3;
        }
        for (; i < n; i++) {
            char c = (char) (head[i] & 0xFF);
            if (c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == 0) {
                continue;
            }
            if (c == '<') {
                return FormatType.XML;
            }
            if (c == '{' || c == '[') {
                return FormatType.JSON;
            }
            return FormatType.CSV;
        }
        return FormatType.CSV;
    }
}
