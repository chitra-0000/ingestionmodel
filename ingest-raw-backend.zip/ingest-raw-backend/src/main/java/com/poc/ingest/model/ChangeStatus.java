package com.poc.ingest.model;

public enum ChangeStatus {
    PENDING, APPROVED, REJECTED
}
