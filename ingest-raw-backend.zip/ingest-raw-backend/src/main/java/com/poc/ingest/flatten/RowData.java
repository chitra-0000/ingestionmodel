package com.poc.ingest.flatten;

/** One data-table row ready to bind. values[] is aligned with LayoutDescriptor.columns. */
public final class RowData {

    final long rowNo;
    final String recordType;
    final String[] values;
    final String extraJson;

    public RowData(long rowNo, String recordType, String[] values, String extraJson) {
        this.rowNo = rowNo;
        this.recordType = recordType;
        this.values = values;
        this.extraJson = extraJson;
    }

    public long getRowNo() { return rowNo; }
    public String getRecordType() { return recordType; }
    public String[] getValues() { return values; }
    public String getExtraJson() { return extraJson; }
}
