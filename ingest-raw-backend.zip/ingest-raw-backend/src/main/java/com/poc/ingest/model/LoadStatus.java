package com.poc.ingest.model;

public enum LoadStatus {
    QUEUED, LOADING, SUCCESS, NEW_FIELDS, FAILED
}
