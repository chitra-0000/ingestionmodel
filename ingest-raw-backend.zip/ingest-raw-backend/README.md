# Raw Ingestion – backend

Loads provider files (XML, CSV, JSON) into Oracle **as received**, with no business processing in front of the
insert. One table per provider and file layout, created at runtime. Nothing in the file is lost.

Stack: Java 8, Spring Boot 2.7.18, Maven 3.8+, Oracle 19 (ojdbc8). No other third-party libraries.

## How a file is loaded

```
upload ──► disk (SHA-256 while copying) ──► queue (max 2 loads at a time, 50 waiting)
                 │
                 ├──► archive: gzip ──► INGEST_FILE_ARCHIVE (BLOB, 160 days)          [in parallel]
                 │
                 ▼
  1. detect format from content          (<  → XML,  { [ → JSON,  else CSV)
  2. sample the head of the file          containers, fields, repeating groups, value sizes
  3. find the provider's table            reuse if ≥ 50 % of fields match, else CREATE TABLE RAW_<PROVIDER>_<FMT>_<n>
  4. stream the whole file once           1 parser thread ─► bounded queue ─► 4 writer threads
                                          JDBC batch 5,000 rows + commit per batch, own connection each
  5. reconcile                            records parsed = rows written = SELECT COUNT(*) for the load
  6. record new fields                    INGEST_STRUCTURE_CHANGE (PENDING) ─► Approve / Reject in the UI
```

Any error stops the load (fail-fast, no automatic retry), deletes the load's rows by `LOAD_ID`, and marks it
`FAILED`. The operator re-uploads. A restart marks unfinished loads `FAILED` the same way.

## Tables

Created once by the DBA with `src/main/resources/db/install-oracle.sql`:

| Table | Purpose |
|---|---|
| `INGEST_FORMAT_REGISTRY` | Provider + format + layout → table name and the column map (`DESCRIPTOR_JSON`) |
| `INGEST_LOAD_LOG` | One row per file: counts, timings, status, reconciliation, file envelope |
| `INGEST_FILE_ARCHIVE` | Original file, gzip BLOB, purged after 160 days (daily job 02:30) |
| `INGEST_REF_DATA` | All code lists of all providers (country, occupation, sanction lists…) |
| `INGEST_STRUCTURE_CHANGE` | New fields waiting for approval, and the decision audit trail |

Created at runtime, one per provider and layout:

```
RAW_DOW_JONES_XML_1
  LOAD_ID, ROW_NO, RECORD_TYPE       system columns (RECORD_TYPE e.g. "Records/Person", "Records/Entity")
  C0001 … Cnnnn                      single values: element text or attribute     VARCHAR2(4000 BYTE) or CLOB
  G0001 … Gnnnn                      repeating groups as a JSON array              CLOB
  EXTRA_JSON                         everything the column map does not cover      CLOB
```

The readable name of every column (`@id`, `Gender`, `NameDetails/Name` …) is in `DESCRIPTOR_JSON`. Source field
names are never used in SQL, so the DDL cannot be injected through a file.

## Why nothing is lost

| Situation | Where it goes |
|---|---|
| Known single value | Its `C` column |
| Repeating element (several names, countries…) | Its `G` column, the whole group as JSON |
| Field not in the column map (new tag, typo, test field) | `EXTRA_JSON.unmapped`, plus a pending structure change |
| Value longer than the VARCHAR2 column | `EXTRA_JSON.oversize` (column left NULL, never truncated) |
| `<Deceased/>` (present but empty) | `EXTRA_JSON.empty` (Oracle stores `''` as NULL, so presence is recorded here) |
| JSON `null` | `EXTRA_JSON.null` |
| Code lists | `INGEST_REF_DATA`, with the complete element in `RECORD_JSON` |
| File header / root attributes (e.g. `<PFA date=…>`) | `INGEST_LOAD_LOG.ENVELOPE_JSON` |
| Anything else (comments, formatting) | The archived original file |

Reference codes are stored as received and resolved at read time, for example:

```sql
-- column names come from DESCRIPTOR_JSON: here C0001 = @id, G0004 = CountryDetails/Country
SELECT p.C0001 AS person_id, c.REF_VALUE AS country
FROM   RAW_DOW_JONES_XML_1 p,
       JSON_TABLE(p.G0004, '$[*]' COLUMNS (code VARCHAR2(10) PATH '$.CountryValue."@Code"')) j
JOIN   INGEST_REF_DATA c ON c.PROVIDER = 'Dow Jones' AND c.LIST_NAME = 'CountryList' AND c.REF_CODE = j.code;
```

## New fields: approval

* **Existing table:** a new field lands in `EXTRA_JSON` and the load ends as `NEW_FIELDS`. In the UI an authorised
  user approves (→ `ALTER TABLE … ADD (Cnnnn …)`, registry version +1, optional backfill of earlier rows from
  `EXTRA_JSON`) or rejects (field stays in `EXTRA_JSON` and is not raised again). Name, time and comment are stored.
* **Brand-new table:** fields met after sampling are added automatically after the first load (decided by
  `SYSTEM`), because there is no existing structure to protect yet.
* Approval waits for loads into that table to finish (the API answers 409 while one is running).
* Backfill covers short single values. Repeating groups and CLOB fields keep their earlier values in `EXTRA_JSON`.

## Run it on the office laptop

1. DBA runs `db/install-oracle.sql` in the application schema and grants `CREATE TABLE` (runtime tables) and quota.
2. Point Maven at your Artifactory (`~/.m2/settings.xml` mirror) and build:
   ```
   mvn clean package
   ```
3. Start (credentials from environment variables, never from the properties file):
   ```
   set DB_URL=jdbc:oracle:thin:@//dbhost:1521/SERVICE
   set DB_USER=INGEST
   set DB_PASSWORD=********
   set INGEST_STORAGE_DIR=D:\ingest-work
   java -Xmx1g -jar target\ingest-raw-backend-1.0.0-SNAPSHOT.jar
   ```
   `INGEST_STORAGE_DIR` needs free space of about 1.5 × the largest file (file + its gzip while archiving).

Tests run on H2 in Oracle mode: `mvn test` (end-to-end XML/CSV/JSON loads, approval with backfill, downloads, XXE).

## Benchmark (please run on your Oracle before the demo)

Generate 5M-record files with the test generator:

```
mvn test-compile dependency:build-classpath -Dmdep.outputFile=cp.txt -Dmdep.includeScope=test
java -cp "target/test-classes;target/classes;<contents of cp.txt>" com.poc.ingest.TestFiles csv 5000000 bench.csv
java -cp "…same…" com.poc.ingest.TestFiles xml 5000000 bench.xml
```

Upload them through the UI and read the duration in the load list. Tune in this order:

| Setting | Try |
|---|---|
| `ingest.writer-threads` | 4 → 6 → 8 (stop when time stops improving) |
| `ingest.batch-size` | 5000 → 10000 |
| `ingest.insert-hint` | `APPEND_VALUES` with `writer-threads=1`: direct path, compare against the parallel run |
| `spring.datasource.hikari.maximum-pool-size` | ≥ max-concurrent-loads × writer-threads + 4 |

Measured here (CPU side, no Oracle): parsing + flattening runs at about **85,000 XML records/s** (Dow Jones-like,
550 MB per million records) and **240,000 CSV rows/s**, so 5M records cost about 60 s / 20 s of parser time. A full
1M-record XML load into an embedded H2 database took 27 s with a 512 MB heap. The 5-minute target therefore depends
on Oracle insert speed (redo, network, storage), which only your benchmark can confirm.

## Configuration (`application.properties`, prefix `ingest.`)

| Key | Default | Meaning |
|---|---|---|
| `batch-size` | 5000 | Rows per JDBC batch and commit |
| `writer-threads` | 4 | Insert threads per load |
| `queue-capacity` | 16 | Batches buffered between parser and writers (bounds heap) |
| `max-concurrent-loads` / `max-queued-loads` | 2 / 50 | Files loading together / waiting |
| `container-scan-elements` | 2,000,000 | XML elements read to find record containers |
| `sample-records` | 20,000 | Records read to learn fields |
| `auto-container-threshold` | 1000 | XML wrapper treated as a container after this many same-name children |
| `layout-match-threshold` | 0.5 | Field overlap needed to reuse a table |
| `varchar-max-bytes` | 4000 | Use 32767 if the DB has `MAX_STRING_SIZE=EXTENDED` |
| `clob-threshold-bytes` | 2000 | Longer sampled values make the column a CLOB |
| `max-data-columns` | 900 | Oracle allows 1000 columns per table |
| `table-options` | NOLOGGING | Runtime tables. Only reduces redo for direct-path inserts; ignored under FORCE LOGGING |
| `insert-hint` | (empty) | e.g. `APPEND_VALUES` |
| `reconcile-with-count` | true | Extra `COUNT(*)` check after each load |
| `archive-retention-days` | 160 | Original file retention |

## REST API

| Method | Path | |
|---|---|---|
| POST | `/api/uploads` (multipart `provider`, `file`) | 202, load queued |
| GET | `/api/loads?limit=100` | Load history |
| GET | `/api/loads/{id}` | One load |
| GET | `/api/loads/{id}/download/original` | Original file from the archive |
| GET | `/api/loads/{id}/download/report` | CSV: summary, reconciliation, field decisions |
| GET | `/api/loads/{id}/structure-changes` | Pending fields of the table + decisions on this load's fields |
| POST | `/api/structure-changes/approve` | `{changeIds, decidedBy, comment, backfill}` |
| POST | `/api/structure-changes/reject` | `{changeIds, decidedBy, comment}` |
| GET | `/api/providers` | Known providers |

## Security and quality notes

* **Fortify:** StAX with DTDs and external entities disabled (XXE test included); every dynamic SQL identifier is
  generated and whitelisted (`Safe.sqlIdentifier`, `DdlService`); values are always bound; the backfill JSON key is
  whitelisted; upload file names are reduced to a safe base name (path traversal) and stored under the load id;
  `Content-Disposition` is built with `ContentDisposition`; log lines strip CR/LF; error responses never include
  stack traces; report CSV cells are protected against formula injection.
* **Nexus:** patched versions pinned in `pom.xml` (Spring 5.3.39, Tomcat 9.0.123, Logback 1.2.13, Jackson 2.17.3);
  SnakeYAML excluded. Spring Boot 2.7 is out of open-source support; if Nexus policy flags that, the code moves to
  Boot 3 only together with Java 17.
* **Sonar:** constructor injection, no `System.out`, no generic catches outside the error handler, `-Xlint:all` clean.
* **Not in the POC yet:** login/SSO and roles (the approver name is typed in), CSRF protection, maker-checker rule
  that the approver differs from the uploader.

## Known limits / next steps

* Data tables have no index. As loads accumulate, `COUNT(*)` and cleanup by `LOAD_ID` scan the whole table.
  For production: list/interval partitioning by `LOAD_ID` (Oracle Partitioning licence) or an index on `LOAD_ID`.
* A JSON scalar larger than 20 MB fails the load (Jackson safety limit) instead of being stored.
* CSV is read as UTF-8 (BOM handled). Other encodings need a setting.
* XML comments and processing instructions are not stored in tables (they are in the archived file).
