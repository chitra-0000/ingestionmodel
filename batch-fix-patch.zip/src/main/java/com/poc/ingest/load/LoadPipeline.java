package com.poc.ingest.load;

import com.poc.ingest.flatten.RecordFlattener;
import com.poc.ingest.flatten.RefRow;
import com.poc.ingest.flatten.RowData;
import com.poc.ingest.model.ColumnDef;
import com.poc.ingest.model.ContainerKind;
import com.poc.ingest.parse.Node;
import com.poc.ingest.parse.RecordSink;
import com.poc.ingest.parse.StreamingEngine;
import com.poc.ingest.service.DdlService;
import com.poc.ingest.util.Safe;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * One parser thread (the caller) -> bounded queue -> N writer threads, each with its own connection doing
 * JDBC batch inserts and a commit per batch. Heap use is bounded by queueCapacity x batchSize rows.
 * Fail-fast: the first error stops parsing; the caller deletes the load's rows (no automatic retry).
 */
public final class LoadPipeline {

    /** Everything the pipeline needs for one load. */
    public static final class Job {
        long loadId;
        String provider;
        String tableName;
        String insertSql;
        List<ColumnDef> columns;
        Map<String, ContainerKind> containerKinds;
        Set<String> knownContainers;
        StreamingEngine engine;
        RecordFlattener flattener;
        int batchSize;
        int writerThreads;
        int queueCapacity;

        public Job loadId(long v) { loadId = v; return this; }
        public Job provider(String v) { provider = v; return this; }
        public Job tableName(String v) { tableName = v; return this; }
        public Job insertSql(String v) { insertSql = v; return this; }
        public Job columns(List<ColumnDef> v) { columns = v; return this; }
        public Job containerKinds(Map<String, ContainerKind> v) { containerKinds = new HashMap<>(v); return this; }
        public Job knownContainers(Set<String> v) { knownContainers = v; return this; }
        public Job engine(StreamingEngine v) { engine = v; return this; }
        public Job flattener(RecordFlattener v) { flattener = v; return this; }
        public Job batchSize(int v) { batchSize = v; return this; }
        public Job writerThreads(int v) { writerThreads = v; return this; }
        public Job queueCapacity(int v) { queueCapacity = v; return this; }
    }

    /** Counts used for reconciliation. */
    public static final class Result {
        private final long dataParsed;
        private final long refParsed;
        private final long dataWritten;
        private final long refWritten;
        private final long largeRows;
        private final Node envelope;

        Result(long dataParsed, long refParsed, long dataWritten, long refWritten, long largeRows, Node envelope) {
            this.dataParsed = dataParsed;
            this.refParsed = refParsed;
            this.dataWritten = dataWritten;
            this.refWritten = refWritten;
            this.largeRows = largeRows;
            this.envelope = envelope;
        }

        public long getDataParsed() { return dataParsed; }
        public long getRefParsed() { return refParsed; }
        public long getDataWritten() { return dataWritten; }
        public long getRefWritten() { return refWritten; }
        /** Rows sent one by one because a value exceeded 4000 bytes. */
        public long getLargeRows() { return largeRows; }
        public Node getEnvelope() { return envelope; }
    }

    private static final class Batch {
        static final Batch POISON = new Batch(false, null);
        final boolean ref;
        final List<Object> rows;

        Batch(boolean ref, List<Object> rows) {
            this.ref = ref;
            this.rows = rows;
        }
    }

    /** Raised in the parser thread when a writer has failed, to stop reading the file. */
    static final class Aborted extends RuntimeException {
        private static final long serialVersionUID = 1L;

        Aborted() {
            super("Load aborted because a database write failed", null, false, false);
        }
    }

    private static final int SMALL_BIND_BYTES = 4000;

    private final DataSource dataSource;
    private final ExecutorService writers;

    public LoadPipeline(DataSource dataSource, ExecutorService writers) {
        this.dataSource = dataSource;
        this.writers = writers;
    }

    public Result run(Job job, InputStream in) throws IOException, SQLException {
        BlockingQueue<Batch> queue = new ArrayBlockingQueue<>(Math.max(2, job.queueCapacity));
        AtomicReference<Throwable> failure = new AtomicReference<>();
        AtomicLong dataWritten = new AtomicLong();
        AtomicLong refWritten = new AtomicLong();
        AtomicLong largeRows = new AtomicLong();
        List<Future<?>> futures = new ArrayList<>();
        for (int i = 0; i < Math.max(1, job.writerThreads); i++) {
            futures.add(writers.submit(new Writer(job, queue, failure, dataWritten, refWritten, largeRows)));
        }
        Producer producer = new Producer(job, queue, failure);
        Node envelope = null;
        try {
            envelope = job.engine.parse(in, job.knownContainers, producer);
            producer.flush();
        } catch (Aborted a) {
            // a writer failed; its exception is reported below
        } catch (RuntimeException | IOException e) {
            failure.compareAndSet(null, e);
        } finally {
            for (int i = 0; i < futures.size(); i++) {
                putUninterruptibly(queue, Batch.POISON);
            }
            awaitAll(futures, failure);
        }
        Throwable t = failure.get();
        if (t != null) {
            rethrow(t);
        }
        return new Result(producer.dataSeq, producer.refSeq, dataWritten.get(), refWritten.get(), largeRows.get(),
                envelope);
    }

    /** Over 4000 bytes Oracle binds a string as a LOB, which breaks batching. */
    static boolean isLarge(String v) {
        return v != null && v.length() * 3 > SMALL_BIND_BYTES && Safe.utf8Length(v) > SMALL_BIND_BYTES;
    }

    private static void rethrow(Throwable t) throws IOException, SQLException {
        if (t instanceof SQLException) {
            throw (SQLException) t;
        }
        if (t instanceof IOException) {
            throw (IOException) t;
        }
        if (t instanceof RuntimeException) {
            throw (RuntimeException) t;
        }
        if (t instanceof Error) {
            throw (Error) t;
        }
        throw new IllegalStateException(t);
    }

    private static void putUninterruptibly(BlockingQueue<Batch> q, Batch b) {
        boolean interrupted = false;
        while (true) {
            try {
                q.put(b);
                break;
            } catch (InterruptedException e) {
                interrupted = true;
            }
        }
        if (interrupted) {
            Thread.currentThread().interrupt();
        }
    }

    private static void awaitAll(List<Future<?>> futures, AtomicReference<Throwable> failure) {
        for (Future<?> f : futures) {
            try {
                f.get();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                failure.compareAndSet(null, e);
            } catch (ExecutionException e) {
                failure.compareAndSet(null, e.getCause());
            }
        }
    }

    /** Runs in the parser thread: flattens records into batches. */
    private static final class Producer implements RecordSink {
        private final Job job;
        private final BlockingQueue<Batch> queue;
        private final AtomicReference<Throwable> failure;
        private List<Object> data;
        private List<Object> refs;
        long dataSeq;
        long refSeq;

        Producer(Job job, BlockingQueue<Batch> queue, AtomicReference<Throwable> failure) {
            this.job = job;
            this.queue = queue;
            this.failure = failure;
            this.data = new ArrayList<>(job.batchSize);
            this.refs = new ArrayList<>(job.batchSize);
        }

        @Override
        public void onRecord(String containerPath, Node record) {
            ContainerKind kind = job.containerKinds.get(containerPath);
            if (kind == null) {
                // container not seen in sampling: decide once, from its first record
                kind = record.isFlat() ? ContainerKind.REF : ContainerKind.DATA;
                job.containerKinds.put(containerPath, kind);
            }
            if (kind == ContainerKind.DATA) {
                data.add(job.flattener.toRow(++dataSeq, containerPath, record));
                if (data.size() >= job.batchSize) {
                    send(new Batch(false, data));
                    data = new ArrayList<>(job.batchSize);
                }
            } else {
                refs.add(RecordFlattener.toRef(++refSeq, containerPath, record));
                if (refs.size() >= job.batchSize) {
                    send(new Batch(true, refs));
                    refs = new ArrayList<>(job.batchSize);
                }
            }
        }

        @Override
        public boolean isDone() {
            return false;
        }

        void flush() {
            if (!data.isEmpty()) {
                send(new Batch(false, data));
                data = new ArrayList<>(0);
            }
            if (!refs.isEmpty()) {
                send(new Batch(true, refs));
                refs = new ArrayList<>(0);
            }
        }

        private void send(Batch b) {
            try {
                while (!queue.offer(b, 200, TimeUnit.MILLISECONDS)) {
                    if (failure.get() != null) {
                        throw new Aborted();
                    }
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                failure.compareAndSet(null, e);
                throw new Aborted();
            }
            if (failure.get() != null) {
                throw new Aborted();
            }
        }
    }

    /** Insert thread: own connection, batch insert, commit per batch. After a failure it only drains the queue. */
    private final class Writer implements Runnable {
        private final Job job;
        private final BlockingQueue<Batch> queue;
        private final AtomicReference<Throwable> failure;
        private final AtomicLong dataWritten;
        private final AtomicLong refWritten;
        private final AtomicLong largeRows;
        private boolean poisoned;

        Writer(Job job, BlockingQueue<Batch> queue, AtomicReference<Throwable> failure,
               AtomicLong dataWritten, AtomicLong refWritten, AtomicLong largeRows) {
            this.job = job;
            this.queue = queue;
            this.failure = failure;
            this.dataWritten = dataWritten;
            this.refWritten = refWritten;
            this.largeRows = largeRows;
        }

        @Override
        public void run() {
            try (Connection con = dataSource.getConnection()) {
                boolean auto = con.getAutoCommit();
                con.setAutoCommit(false);
                try (PreparedStatement dataPs = con.prepareStatement(job.insertSql);
                     PreparedStatement refPs = con.prepareStatement(DdlService.refInsertSql())) {
                    loop(con, dataPs, refPs);
                } finally {
                    con.setAutoCommit(auto);
                }
            } catch (SQLException | RuntimeException e) {
                failure.compareAndSet(null, e);
                drain();
            }
        }

        private void loop(Connection con, PreparedStatement dataPs, PreparedStatement refPs)
                throws SQLException {
            while (true) {
                Batch b = take();
                if (b == Batch.POISON) {
                    return;
                }
                if (failure.get() != null) {
                    continue; // drain only
                }
                try {
                    if (b.ref) {
                        writeRefs(refPs, b.rows);
                    } else {
                        writeData(dataPs, b.rows);
                    }
                    con.commit();
                    (b.ref ? refWritten : dataWritten).addAndGet(b.rows.size());
                } catch (SQLException | RuntimeException e) {
                    failure.compareAndSet(null, e);
                    rollbackQuietly(con);
                }
            }
        }

        private void drain() {
            while (!poisoned) {
                take(); // discard: the load already failed
            }
        }

        private Batch take() {
            try {
                Batch b = queue.take();
                if (b == Batch.POISON) {
                    poisoned = true;
                }
                return b;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                failure.compareAndSet(null, e);
                poisoned = true;
                return Batch.POISON;
            }
        }

        /**
         * Oracle flushes a JDBC batch every time a parameter's bind type changes between rows
         * (NULL as CLOB vs string, string up to 4000 bytes vs longer string sent as a LOB). With remote DB latency
         * that turns a 5,000-row batch into ~5,000 round trips. So: every value is bound the same way (string, or
         * NULL typed VARCHAR); rows holding a value over 4000 bytes are taken out of the batch and sent one by one.
         */
        private void writeData(PreparedStatement ps, List<Object> rows) throws SQLException {
            List<RowData> large = new ArrayList<>();
            int batched = 0;
            for (Object o : rows) {
                RowData r = (RowData) o;
                if (hasLargeValue(r)) {
                    large.add(r);
                    continue;
                }
                bindData(ps, r);
                ps.addBatch();
                batched++;
            }
            if (batched > 0) {
                ps.executeBatch();
            }
            for (RowData r : large) {
                bindData(ps, r);
                ps.executeUpdate();
            }
            largeRows.addAndGet(large.size());
        }

        private void bindData(PreparedStatement ps, RowData r) throws SQLException {
            int p = 1;
            ps.setLong(p++, job.loadId);
            ps.setLong(p++, r.getRowNo());
            ps.setString(p++, r.getRecordType());
            for (String v : r.getValues()) {
                bind(ps, p++, v);
            }
            bind(ps, p, r.getExtraJson());
        }

        private void writeRefs(PreparedStatement ps, List<Object> rows) throws SQLException {
            List<RefRow> large = new ArrayList<>();
            int batched = 0;
            for (Object o : rows) {
                RefRow r = (RefRow) o;
                if (isLarge(r.getRecordJson())) {
                    large.add(r);
                    continue;
                }
                bindRef(ps, r);
                ps.addBatch();
                batched++;
            }
            if (batched > 0) {
                ps.executeBatch();
            }
            for (RefRow r : large) {
                bindRef(ps, r);
                ps.executeUpdate();
            }
            largeRows.addAndGet(large.size());
        }

        private void bindRef(PreparedStatement ps, RefRow r) throws SQLException {
            ps.setLong(1, job.loadId);
            ps.setLong(2, r.getRowNo());
            ps.setString(3, job.provider);
            ps.setString(4, r.getListName());
            ps.setString(5, r.getRecordType());
            bind(ps, 6, r.getCode());
            bind(ps, 7, r.getValue());
            bind(ps, 8, r.getRecordJson());
        }

        private boolean hasLargeValue(RowData r) {
            if (isLarge(r.getExtraJson())) {
                return true;
            }
            for (String v : r.getValues()) {
                if (isLarge(v)) {
                    return true;
                }
            }
            return false;
        }

        /** NULL is always bound with the same SQL type so the batch never sees a type change. */
        private void bind(PreparedStatement ps, int idx, String v) throws SQLException {
            if (v == null) {
                ps.setNull(idx, Types.VARCHAR);
            } else {
                ps.setString(idx, v);
            }
        }

        private void rollbackQuietly(Connection con) {
            try {
                con.rollback();
            } catch (SQLException e) {
                failure.compareAndSet(null, e);
            }
        }
    }
}
