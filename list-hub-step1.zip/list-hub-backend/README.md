# Global List Management Hub – backend

Java 21, Spring Boot 3.5, Oracle. Ingestion, golden list, versioning, validation, certification
and publication to downstream systems (DSS).

## Open in IntelliJ IDEA

1. **File > Open** and select this folder's `pom.xml`, then choose **Open as Project**.
2. Set the project SDK to Java 21 (**File > Project Structure > Project**).
3. The shared run configuration **ListHubApplication (local Oracle, demo data)** appears in the
   run toolbar (from `.run/`). Fill in `LISTHUB_DB_PASSWORD` and `LISTHUB_SECURITY_USERS_0_PASSWORDHASH`
   locally under **Run > Edit Configurations**. Never commit those values.

No local Maven needed: IntelliJ and the command line use the wrapper (`./mvnw`).

## Local Oracle

```bash
docker run -d --name listhub-oracle -p 1521:1521 \
  -e ORACLE_PASSWORD=<sys-password> -e APP_USER=listhub -e APP_USER_PASSWORD=<app-password> \
  gvenzl/oracle-free:23-slim-faststart
```

The application creates and upgrades its schema with Liquibase at start-up.
`LISTHUB_LIQUIBASE_CONTEXTS=schema,demo` also loads sample lists for the Lists screen.

## Users (POC, until SSO)

Users come from the environment, never from files. Create a password hash:

```bash
htpasswd -bnBC 10 "" '<password>' | tr -d ':\n' | sed 's/^/{bcrypt}/'
```

| Variable | Example |
| --- | --- |
| `LISTHUB_SECURITY_USERS_0_USERNAME` | `admin` |
| `LISTHUB_SECURITY_USERS_0_PASSWORDHASH` | `{bcrypt}$2y$10$...` |
| `LISTHUB_SECURITY_USERS_0_ROLES` | `ADMIN` |

Roles: `VIEWER`, `LIST_VALIDATOR`, `LIST_CERTIFIER`, `MAPPING_AUTHOR`, `ADMIN`.

## Build and test

```bash
./mvnw verify                 # unit, web and architecture tests, JaCoCo report
./mvnw verify -Poracle-it     # also applies all changelogs to Oracle Free in Docker and tests the view
```

## Layout

| Package | Module |
| --- | --- |
| `lists` | List definitions, applicable and in-progress versions (Lists screen) |
| `intake`, `ingestion`, `mapping` | File intake, streaming parsers, mapping and rules (next steps) |
| `golden`, `delta` | Golden record versions, set-based delta in Oracle (next steps) |
| `publication`, `governance` | Validation, certification, DSS publication, audit (next steps) |
| `config`, `common` | Security, OpenAPI, errors |

Database scripts: `src/main/resources/db/changelog/sql/` (001 to 007 schema, 100 demo data).

## API

`GET /api/v1/lists?label=&ref=&kind=SIMPLE|CONCATENATED&sort=listRef&direction=asc&page=0&size=50`

OpenAPI at `/swagger-ui.html` when `LISTHUB_SWAGGER_ENABLED=true` (ADMIN role).
