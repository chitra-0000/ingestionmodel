--liquibase formatted sql

-- Staging and delta work tables. Interval-partitioned by BATCH_ID: one partition per file,
-- dropped after the version is published (no large DELETEs). No secondary indexes:
-- the delta step reads a whole batch partition with a hash join.
-- NOLOGGING on these tables is a DBA decision (not possible with FORCE LOGGING / Data Guard).

--changeset listhub:005-stg-record context:schema
-- One row per mapped record. CANONICAL_JSON carries the mapped record with its child sections;
-- PKG_LIST_DELTA expands it into RECORD and child tables with JSON_TABLE in one set-based step.
CREATE TABLE stg_record (
    batch_id        NUMBER(19)          NOT NULL,
    list_id         NUMBER(19)          NOT NULL,
    row_no          NUMBER(12)          NOT NULL,
    ext_ref         VARCHAR2(100 CHAR)  NOT NULL,
    record_type     CHAR(1 CHAR)        NOT NULL,
    rec_hash        RAW(32)             NOT NULL,
    source_offset   NUMBER(19),
    source_length   NUMBER(10),
    canonical_json  CLOB                NOT NULL,
    CONSTRAINT ck_stg_record_json CHECK (canonical_json IS JSON)
)
PARTITION BY RANGE (batch_id) INTERVAL (1) (PARTITION p_init VALUES LESS THAN (1));
--rollback DROP TABLE stg_record;

--changeset listhub:005-list-delta context:schema
CREATE TABLE list_delta (
    batch_id   NUMBER(19)          NOT NULL,
    list_id    NUMBER(19)          NOT NULL,
    ext_ref    VARCHAR2(100 CHAR)  NOT NULL,
    action     VARCHAR2(3 CHAR)    NOT NULL,
    CONSTRAINT ck_list_delta_action CHECK (action IN ('ADD', 'CHG', 'DEL'))
)
PARTITION BY RANGE (batch_id) INTERVAL (1) (PARTITION p_init VALUES LESS THAN (1));
--rollback DROP TABLE list_delta;

--changeset listhub:005-rejected-row context:schema
CREATE TABLE rejected_row (
    batch_id       NUMBER(19)           NOT NULL,
    row_no         NUMBER(12)           NOT NULL,
    ext_ref        VARCHAR2(100 CHAR),
    field_name     VARCHAR2(61 CHAR),
    reason_code    VARCHAR2(40 CHAR)    NOT NULL,
    reason_text    VARCHAR2(1000 CHAR),
    source_offset  NUMBER(19)
)
PARTITION BY RANGE (batch_id) INTERVAL (1) (PARTITION p_init VALUES LESS THAN (1));
CREATE INDEX ix_rejected_row_batch ON rejected_row (batch_id, row_no) LOCAL;
--rollback DROP TABLE rejected_row;
