--liquibase formatted sql

--changeset listhub:007-v-list-overview context:schema runOnChange:true
-- One row per active list, as shown on the Lists screen.
-- Applicable version = last version certified and published to the DSS.
-- In-progress version = latest loaded version while it is newer than the applicable one.
CREATE OR REPLACE VIEW v_list_overview AS
SELECT ld.list_id,
       ld.list_ref,
       ld.label,
       ld.list_kind,
       ld.list_type,
       ld.list_category,
       ld.scope_code,
       ld.country_code,
       ld.confidentiality,
       pr.provider_name,
       lp.applicable_version_no,
       av.application_date,
       (SELECT MAX(dp.published_at)
          FROM dss_publication dp
         WHERE dp.list_id = ld.list_id
           AND dp.version_no = lp.applicable_version_no) AS publication_date,
       av.cnt_total AS record_count,
       iv.version_no AS in_progress_version_no,
       CASE WHEN iv.version_no IS NOT NULL THEN iv.publication_status END AS in_progress_status
  FROM list_definition ld
  LEFT JOIN provider pr     ON pr.provider_id = ld.provider_id
  LEFT JOIN list_pointer lp ON lp.list_id = ld.list_id
  LEFT JOIN list_version av ON av.list_id = ld.list_id
                           AND av.version_no = lp.applicable_version_no
  LEFT JOIN list_version iv ON iv.list_id = ld.list_id
                           AND iv.version_no = lp.loaded_version_no
                           AND lp.loaded_version_no > NVL(lp.applicable_version_no, 0)
 WHERE ld.active_flag = 'Y';
--rollback DROP VIEW v_list_overview;
