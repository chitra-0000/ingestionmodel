--liquibase formatted sql

-- Providers, their feeds and reference data.
-- Conventions for every script: VARCHAR2 with CHAR semantics (Unicode names), identity keys with a
-- large cache, timestamps in UTC as TIMESTAMP WITH TIME ZONE, and named constraints.

--changeset listhub:001-provider context:schema
CREATE TABLE provider (
    provider_id    VARCHAR2(10 CHAR)  NOT NULL,
    provider_name  VARCHAR2(200 CHAR) NOT NULL,
    active_flag    CHAR(1 CHAR)       DEFAULT 'Y' NOT NULL,
    created_at     TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT pk_provider PRIMARY KEY (provider_id),
    CONSTRAINT ck_provider_active CHECK (active_flag IN ('Y', 'N'))
);
--rollback DROP TABLE provider;

--changeset listhub:001-provider-feed context:schema
CREATE TABLE provider_feed (
    feed_id            VARCHAR2(40 CHAR)   NOT NULL,
    provider_id        VARCHAR2(10 CHAR)   NOT NULL,
    file_format        VARCHAR2(10 CHAR)   NOT NULL,
    record_root        VARCHAR2(400 CHAR)  NOT NULL,
    external_id_path   VARCHAR2(400 CHAR)  NOT NULL,
    encoding           VARCHAR2(20 CHAR)   DEFAULT 'UTF-8' NOT NULL,
    field_delimiter    VARCHAR2(5 CHAR),
    max_file_bytes     NUMBER(19),
    active_flag        CHAR(1 CHAR)        DEFAULT 'Y' NOT NULL,
    CONSTRAINT pk_provider_feed PRIMARY KEY (feed_id),
    CONSTRAINT fk_feed_provider FOREIGN KEY (provider_id) REFERENCES provider (provider_id),
    CONSTRAINT ck_feed_format CHECK (file_format IN ('XML', 'CSV', 'JSON', 'FIXED')),
    CONSTRAINT ck_feed_active CHECK (active_flag IN ('Y', 'N'))
);
CREATE INDEX ix_feed_provider ON provider_feed (provider_id);
--rollback DROP TABLE provider_feed;

--changeset listhub:001-ref-country context:schema
CREATE TABLE ref_country (
    iso2          CHAR(2 CHAR)        NOT NULL,
    iso3          CHAR(3 CHAR),
    country_name  VARCHAR2(200 CHAR)  NOT NULL,
    CONSTRAINT pk_ref_country PRIMARY KEY (iso2)
);
--rollback DROP TABLE ref_country;

--changeset listhub:001-ref-code context:schema
-- One table for the small code lists: DATE_TYPE, COUNTRY_TYPE, ID_TYPE, NAME_TYPE, RELATION_TYPE,
-- SANCTION_LIST, DESCRIPTION, SOURCE, PROGRAM_GROUP. CATEGORY routes ID types (DOCUMENT, ENTITY_CODE,
-- VESSEL_CODE, PROGRAM); CODE_LEVEL holds the description level (1, 2, 3).
CREATE TABLE ref_code (
    code_type    VARCHAR2(30 CHAR)   NOT NULL,
    code         VARCHAR2(50 CHAR)   NOT NULL,
    label        VARCHAR2(500 CHAR)  NOT NULL,
    category     VARCHAR2(30 CHAR),
    code_level   NUMBER(1),
    provider_id  VARCHAR2(10 CHAR),
    active_flag  CHAR(1 CHAR)        DEFAULT 'Y' NOT NULL,
    CONSTRAINT pk_ref_code PRIMARY KEY (code_type, code),
    CONSTRAINT fk_ref_code_provider FOREIGN KEY (provider_id) REFERENCES provider (provider_id),
    CONSTRAINT ck_ref_code_active CHECK (active_flag IN ('Y', 'N'))
);
CREATE INDEX ix_ref_code_provider ON ref_code (provider_id);
--rollback DROP TABLE ref_code;
