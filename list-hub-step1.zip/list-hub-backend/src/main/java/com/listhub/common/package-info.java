/**
 * Shared API types and error handling.
 */
package com.listhub.common;
