package com.listhub.common;

import java.util.List;

/**
 * One page of results.
 *
 * @param items rows on this page
 * @param total rows matching the filter, across all pages
 * @param page  zero-based page number
 * @param size  page size requested
 */
public record PageResult<T>(List<T> items, long total, int page, int size) {

    public PageResult {
        items = List.copyOf(items);
    }
}
