package com.listhub.common;

import java.util.UUID;

/** Short ids that link an error response to its log entry without exposing details. */
public final class ErrorIds {

    private ErrorIds() {
    }

    public static String next() {
        return UUID.randomUUID().toString().substring(0, 8);
    }
}
