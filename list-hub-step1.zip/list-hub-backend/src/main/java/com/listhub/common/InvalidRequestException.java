package com.listhub.common;

/** A request the client can fix; its message is safe to return to the caller. */
public class InvalidRequestException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public InvalidRequestException(String message) {
        super(message);
    }
}
