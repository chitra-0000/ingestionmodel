/**
 * Golden list store: canonical RECORD model with record versions (FROM_VERSION, TO_VERSION). Next step.
 */
package com.listhub.golden;
