package com.listhub.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** OpenAPI description of the hub's REST API. Swagger UI is off unless enabled per environment. */
@Configuration
public class OpenApiConfig {

    private static final String BASIC = "basicAuth";

    @Bean
    OpenAPI listHubOpenApi() {
        return new OpenAPI()
            .info(new Info()
                .title("Global List Management Hub API")
                .version("v1")
                .description("Lists, versions, records and publication to downstream systems"))
            .components(new Components().addSecuritySchemes(BASIC,
                new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("basic")))
            .addSecurityItem(new SecurityRequirement().addList(BASIC));
    }
}
