/**
 * Security, OpenAPI and runtime configuration.
 */
package com.listhub.config;
