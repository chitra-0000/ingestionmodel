package com.listhub.config;

/**
 * Application roles. Validator and certifier are separate roles; the same person may hold both,
 * but the publication workflow refuses to let one user validate and certify the same version.
 */
public enum Role {
    VIEWER,
    LIST_VALIDATOR,
    LIST_CERTIFIER,
    MAPPING_AUTHOR,
    ADMIN;

    /** Every role, as plain names for {@code hasAnyRole(...)}. */
    public static String[] allNames() {
        Role[] roles = values();
        String[] names = new String[roles.length];
        for (int i = 0; i < roles.length; i++) {
            names[i] = roles[i].name();
        }
        return names;
    }
}
