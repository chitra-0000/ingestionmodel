package com.listhub.config;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

/**
 * POC users until SSO is connected. Passwords are never stored in configuration files:
 * each user's password hash is injected from the environment (see README).
 *
 * @param users local users with an encoded password ({@code {bcrypt}...}) and their roles
 */
@Validated
@ConfigurationProperties(prefix = "listhub.security")
public record ListHubSecurityProperties(@Valid List<LocalUser> users) {

    public ListHubSecurityProperties {
        users = users == null ? List.of() : List.copyOf(users);
    }

    /**
     * @param username        login name
     * @param passwordHash    encoded password with its id prefix, for example {@code {bcrypt}$2a$10$...}
     * @param roles           roles granted to the user
     */
    public record LocalUser(
            @NotBlank String username,
            @NotBlank String passwordHash,
            @NotEmpty List<Role> roles) {

        public LocalUser {
            roles = roles == null ? List.of() : List.copyOf(roles);
        }

        @Override
        public String toString() {
            // Never print the hash.
            return "LocalUser[username=" + username + ", roles=" + roles + "]";
        }
    }
}
