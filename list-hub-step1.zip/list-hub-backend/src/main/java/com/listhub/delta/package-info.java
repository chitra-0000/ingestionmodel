/**
 * Delta engine: set-based add/change/delete in Oracle through PKG_LIST_DELTA. Next step.
 */
package com.listhub.delta;
