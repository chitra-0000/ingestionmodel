package com.listhub.lists;

import com.listhub.common.PageResult;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

/**
 * Reads the Lists screen from {@code V_LIST_OVERVIEW}. Every value from the request is a bind
 * variable; the ORDER BY text is chosen from statements built once at startup from fixed columns.
 */
@Repository
public class ListRepository {

    private static final String SELECT_COLUMNS = """
        SELECT list_id, list_ref, label, list_kind, list_type, list_category, scope_code, country_code,
               confidentiality, provider_name, applicable_version_no, application_date, publication_date,
               record_count, in_progress_version_no, in_progress_status
          FROM v_list_overview
        """;

    private static final String WHERE = """
         WHERE list_kind = :kind
           AND (:labelPattern IS NULL OR UPPER(label) LIKE :labelPattern ESCAPE '\\')
           AND (:refPattern IS NULL OR UPPER(list_ref) LIKE :refPattern ESCAPE '\\')
        """;

    private static final String COUNT_SQL = "SELECT COUNT(*) FROM v_list_overview" + WHERE;

    private static final Map<ListSortField, String> PAGE_SQL_ASC = buildPageSql(true);
    private static final Map<ListSortField, String> PAGE_SQL_DESC = buildPageSql(false);

    private final JdbcClient jdbc;

    public ListRepository(JdbcClient jdbc) {
        this.jdbc = jdbc;
    }

    public PageResult<ListOverview> find(ListQuery query) {
        MapSqlParameterSource params = new MapSqlParameterSource()
            .addValue("kind", query.kind().name(), Types.VARCHAR)
            .addValue("labelPattern", containsPattern(query.label()), Types.VARCHAR)
            .addValue("refPattern", containsPattern(query.listRef()), Types.VARCHAR);

        long total = jdbc.sql(COUNT_SQL).paramSource(params).query(Long.class).single();
        if (total == 0) {
            return new PageResult<>(List.of(), 0, query.page(), query.size());
        }

        params.addValue("offset", query.offset(), Types.BIGINT)
              .addValue("size", query.size(), Types.INTEGER);
        String sql = (query.ascending() ? PAGE_SQL_ASC : PAGE_SQL_DESC).get(query.sort());
        List<ListOverview> rows = jdbc.sql(sql).paramSource(params).query(ListRepository::mapRow).list();
        return new PageResult<>(rows, total, query.page(), query.size());
    }

    /** Escapes LIKE wildcards in the user's text and wraps it for a "contains" search. */
    static String containsPattern(String upperText) {
        if (upperText == null) {
            return null;
        }
        String escaped = upperText.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
        return "%" + escaped + "%";
    }

    private static Map<ListSortField, String> buildPageSql(boolean ascending) {
        Map<ListSortField, String> statements = new EnumMap<>(ListSortField.class);
        String direction = ascending ? "ASC" : "DESC";
        for (ListSortField field : ListSortField.values()) {
            statements.put(field, SELECT_COLUMNS + WHERE
                + " ORDER BY " + field.column() + " " + direction + " NULLS LAST, list_id"
                + " OFFSET :offset ROWS FETCH NEXT :size ROWS ONLY");
        }
        return Map.copyOf(statements);
    }

    private static ListOverview mapRow(ResultSet rs, int rowNum) throws SQLException {
        return new ListOverview(
            rs.getLong("list_id"),
            rs.getString("list_ref"),
            rs.getString("label"),
            rs.getString("list_kind"),
            rs.getString("list_type"),
            rs.getString("list_category"),
            rs.getString("scope_code"),
            rs.getString("country_code"),
            rs.getString("confidentiality"),
            rs.getString("provider_name"),
            rs.getObject("applicable_version_no", Integer.class),
            rs.getObject("application_date", LocalDate.class),
            rs.getObject("publication_date", OffsetDateTime.class),
            rs.getObject("record_count", Long.class),
            rs.getObject("in_progress_version_no", Integer.class),
            rs.getString("in_progress_status"));
    }
}
