package com.listhub.lists;

import java.time.LocalDate;
import java.time.OffsetDateTime;

/**
 * One row of the Lists screen.
 *
 * @param applicableVersion last version certified and published to the downstream systems
 * @param inProgressVersion latest loaded version while newer than the applicable one, else {@code null}
 * @param inProgressStatus  publication status of the in-progress version (PENDING, VALIDATED, CERTIFIED, REJECTED)
 */
public record ListOverview(
        long listId,
        String listRef,
        String label,
        String listKind,
        String listType,
        String listCategory,
        String scope,
        String country,
        String confidentiality,
        String providerName,
        Integer applicableVersion,
        LocalDate applicationDate,
        OffsetDateTime publicationDate,
        Long recordCount,
        Integer inProgressVersion,
        String inProgressStatus) {
}
