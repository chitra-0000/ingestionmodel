package com.listhub.lists;

import com.listhub.common.InvalidRequestException;
import java.util.Locale;

/**
 * Filters, sorting and paging for the Lists screen.
 *
 * @param label     part of the label to search for, case-insensitive; {@code null} for all
 * @param listRef   part of the list reference to search for; {@code null} for all
 * @param kind      simple or concatenated lists
 * @param sort      column to sort by
 * @param ascending sort direction
 * @param page      zero-based page
 * @param size      rows per page, 1 to {@value #MAX_PAGE_SIZE}
 */
public record ListQuery(
        String label,
        String listRef,
        ListKind kind,
        ListSortField sort,
        boolean ascending,
        int page,
        int size) {

    public static final int MAX_PAGE_SIZE = 200;
    public static final int MAX_SEARCH_LENGTH = 100;

    public ListQuery {
        label = normalise(label);
        listRef = normalise(listRef);
        if (kind == null) {
            kind = ListKind.SIMPLE;
        }
        if (sort == null) {
            sort = ListSortField.LIST_REF;
        }
        if (page < 0) {
            throw new InvalidRequestException("Page must be 0 or more.");
        }
        if (size < 1 || size > MAX_PAGE_SIZE) {
            throw new InvalidRequestException("Page size must be between 1 and " + MAX_PAGE_SIZE + ".");
        }
    }

    /** Offset of the first row of the page. */
    public long offset() {
        return (long) page * size;
    }

    private static String normalise(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        String trimmed = value.trim();
        if (trimmed.length() > MAX_SEARCH_LENGTH) {
            throw new InvalidRequestException("Search text must be " + MAX_SEARCH_LENGTH + " characters or fewer.");
        }
        return trimmed.toUpperCase(Locale.ROOT);
    }
}
