package com.listhub.lists;

import com.listhub.common.PageResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Read side of list management. Write operations (add a list, versions, approvals) come next. */
@Service
public class ListService {

    private final ListRepository repository;

    public ListService(ListRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public PageResult<ListOverview> findLists(ListQuery query) {
        return repository.find(query);
    }
}
