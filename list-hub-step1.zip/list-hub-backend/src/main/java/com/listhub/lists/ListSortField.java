package com.listhub.lists;

import com.listhub.common.InvalidRequestException;
import java.util.Arrays;
import java.util.Locale;
import java.util.stream.Collectors;

/**
 * Columns the Lists screen can sort by. Each maps to a fixed column of {@code V_LIST_OVERVIEW};
 * client input only selects one of these constants and never reaches the SQL text.
 */
public enum ListSortField {
    LIST_REF("listRef", "list_ref"),
    LABEL("label", "UPPER(label)"),
    LIST_TYPE("listType", "list_type"),
    LIST_CATEGORY("listCategory", "list_category"),
    SCOPE("scope", "scope_code"),
    COUNTRY("country", "country_code"),
    APPLICABLE_VERSION("applicableVersion", "applicable_version_no"),
    APPLICATION_DATE("applicationDate", "application_date"),
    PUBLICATION_DATE("publicationDate", "publication_date"),
    CONFIDENTIALITY("confidentiality", "confidentiality");

    private final String apiName;
    private final String column;

    ListSortField(String apiName, String column) {
        this.apiName = apiName;
        this.column = column;
    }

    public String apiName() {
        return apiName;
    }

    String column() {
        return column;
    }

    /** Resolves the API name (for example {@code publicationDate}); unknown names are a client error. */
    public static ListSortField fromApiName(String value) {
        String wanted = value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
        return Arrays.stream(values())
            .filter(field -> field.apiName.toLowerCase(Locale.ROOT).equals(wanted))
            .findFirst()
            .orElseThrow(() -> new InvalidRequestException("Unknown sort field. Use one of: "
                + Arrays.stream(values()).map(ListSortField::apiName).collect(Collectors.joining(", "))));
    }
}
