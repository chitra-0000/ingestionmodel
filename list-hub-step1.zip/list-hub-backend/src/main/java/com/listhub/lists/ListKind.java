package com.listhub.lists;

/** A list loaded from a provider file, or a list made by combining other lists. */
public enum ListKind {
    SIMPLE,
    CONCATENATED
}
