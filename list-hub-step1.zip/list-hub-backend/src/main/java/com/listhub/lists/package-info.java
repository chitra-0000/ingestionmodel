/**
 * Lists: list definitions and their applicable and in-progress versions, as shown on the Lists screen.
 */
package com.listhub.lists;
