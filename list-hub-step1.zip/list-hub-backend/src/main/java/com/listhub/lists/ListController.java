package com.listhub.lists;

import com.listhub.common.InvalidRequestException;
import com.listhub.common.PageResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.Locale;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/lists")
@Tag(name = "Lists", description = "List definitions with their applicable and in-progress versions")
public class ListController {

    private final ListService service;

    public ListController(ListService service) {
        this.service = service;
    }

    @GetMapping
    @Operation(summary = "Search lists",
        description = "Filters by label and list reference (contains, case-insensitive), sorted and paged.")
    public PageResult<ListOverview> search(
            @RequestParam(required = false) String label,
            @RequestParam(name = "ref", required = false) String listRef,
            @RequestParam(defaultValue = "SIMPLE") ListKind kind,
            @RequestParam(defaultValue = "listRef") String sort,
            @RequestParam(defaultValue = "asc") String direction,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size) {
        ListQuery query = new ListQuery(label, listRef, kind, ListSortField.fromApiName(sort),
            isAscending(direction), page, size);
        return service.findLists(query);
    }

    private static boolean isAscending(String direction) {
        String value = direction.trim().toLowerCase(Locale.ROOT);
        if ("asc".equals(value)) {
            return true;
        }
        if ("desc".equals(value)) {
            return false;
        }
        throw new InvalidRequestException("Direction must be asc or desc.");
    }
}
