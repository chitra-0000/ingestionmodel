/**
 * Ingestion engine: streaming readers (StAX, Jackson streaming, Commons CSV) with a bounded queue into staging. Next step.
 */
package com.listhub.ingestion;
