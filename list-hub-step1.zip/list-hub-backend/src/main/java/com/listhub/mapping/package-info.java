/**
 * Mapping and rules: metadata-driven source paths, value maps and the rule library. Next step.
 */
package com.listhub.mapping;
