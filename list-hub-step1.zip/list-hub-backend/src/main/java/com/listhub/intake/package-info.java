/**
 * Intake: receives provider files (CFT, SFTP, REST, MQ), checks for duplicates by SHA-256 and registers deliveries. Next step.
 */
package com.listhub.intake;
