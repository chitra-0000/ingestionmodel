package com.listhub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * Global List Management Hub.
 *
 * <p>One codebase, two runtime roles selected by Spring profile:
 * {@code api} (GUI and REST API) and {@code batch} (ingestion workers). They are deployed
 * separately so that a large load can never starve interactive users.
 */
@SpringBootApplication
@ConfigurationPropertiesScan
public class ListHubApplication {

    public static void main(String[] args) {
        SpringApplication.run(ListHubApplication.class, args);
    }
}
