package com.listhub.lists;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.listhub.common.ApiExceptionHandler;
import com.listhub.common.PageResult;
import com.listhub.config.SecurityConfig;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(ListController.class)
@Import({SecurityConfig.class, ApiExceptionHandler.class})
class ListControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockitoBean
    private ListService service;

    private static final ListOverview EU = new ListOverview(1L, "001", "EU Consolidated Financial Sanctions",
        "SIMPLE", "REGULATORY", "SANCTIONS", "GROUP", "GROUP", "PUBLIC", "European Union",
        412, LocalDate.of(2026, 10, 30), OffsetDateTime.of(2026, 10, 30, 8, 7, 0, 0, ZoneOffset.UTC),
        5210L, 413, "PENDING");

    @Test
    void refusesAnonymousCallers() throws Exception {
        mvc.perform(get("/api/v1/lists")).andExpect(status().isUnauthorized());
        verify(service, never()).findLists(any());
    }

    @Test
    @WithMockUser(roles = "VIEWER")
    void returnsListsWithApplicableAndInProgressVersions() throws Exception {
        when(service.findLists(any())).thenReturn(new PageResult<>(List.of(EU), 1, 0, 50));

        mvc.perform(get("/api/v1/lists"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.total").value(1))
            .andExpect(jsonPath("$.items[0].listRef").value("001"))
            .andExpect(jsonPath("$.items[0].applicableVersion").value(412))
            .andExpect(jsonPath("$.items[0].inProgressVersion").value(413))
            .andExpect(jsonPath("$.items[0].inProgressStatus").value("PENDING"))
            .andExpect(jsonPath("$.items[0].applicationDate").value("2026-10-30"));
    }

    @Test
    @WithMockUser(roles = "VIEWER")
    void passesFiltersSortAndPagingToTheService() throws Exception {
        when(service.findLists(any())).thenReturn(new PageResult<>(List.of(), 0, 2, 20));

        mvc.perform(get("/api/v1/lists")
                .param("label", " ofac ")
                .param("ref", "00")
                .param("kind", "CONCATENATED")
                .param("sort", "publicationDate")
                .param("direction", "desc")
                .param("page", "2")
                .param("size", "20"))
            .andExpect(status().isOk());

        ArgumentCaptor<ListQuery> captor = ArgumentCaptor.forClass(ListQuery.class);
        verify(service).findLists(captor.capture());
        ListQuery query = captor.getValue();
        assertThat(query.label()).isEqualTo("OFAC");
        assertThat(query.listRef()).isEqualTo("00");
        assertThat(query.kind()).isEqualTo(ListKind.CONCATENATED);
        assertThat(query.sort()).isEqualTo(ListSortField.PUBLICATION_DATE);
        assertThat(query.ascending()).isFalse();
        assertThat(query.offset()).isEqualTo(40);
    }

    @Test
    @WithMockUser(roles = "VIEWER")
    void rejectsUnknownSortFieldWithAProblemResponse() throws Exception {
        mvc.perform(get("/api/v1/lists").param("sort", "label; DROP TABLE record"))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.detail").value(org.hamcrest.Matchers.startsWith("Unknown sort field")));
        verify(service, never()).findLists(any());
    }

    @Test
    @WithMockUser(roles = "VIEWER")
    void rejectsPageSizeAboveTheLimit() throws Exception {
        mvc.perform(get("/api/v1/lists").param("size", "500"))
            .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(roles = "VIEWER")
    void rejectsUnknownListKind() throws Exception {
        mvc.perform(get("/api/v1/lists").param("kind", "OTHER"))
            .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(roles = "VIEWER")
    void hidesDatabaseDetailsWhenTheDatabaseFails() throws Exception {
        when(service.findLists(any())).thenThrow(new DataAccessResourceFailureException("ORA-12541: no listener"));

        mvc.perform(get("/api/v1/lists"))
            .andExpect(status().isServiceUnavailable())
            .andExpect(jsonPath("$.detail").value("The list database is not available right now. Try again later."))
            .andExpect(jsonPath("$.errorId").exists());
    }
}
