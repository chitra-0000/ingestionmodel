package com.listhub.lists;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.listhub.common.InvalidRequestException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

class ListRepositoryTest {

    @Test
    void escapesLikeWildcardsInUserText() {
        assertThat(ListRepository.containsPattern("100%_A\\B")).isEqualTo("%100\\%\\_A\\\\B%");
        assertThat(ListRepository.containsPattern(null)).isNull();
    }

    @ParameterizedTest
    @EnumSource(ListSortField.class)
    void everySortFieldResolvesFromItsApiNameInAnyCase(ListSortField field) {
        assertThat(ListSortField.fromApiName(field.apiName().toUpperCase())).isEqualTo(field);
    }

    @Test
    void sortColumnsAreFixedIdentifiers() {
        for (ListSortField field : ListSortField.values()) {
            assertThat(field.column()).matches("[A-Za-z_()]+");
        }
    }

    @Test
    void unknownSortFieldIsAClientError() {
        assertThatThrownBy(() -> ListSortField.fromApiName("1=1"))
            .isInstanceOf(InvalidRequestException.class)
            .hasMessageStartingWith("Unknown sort field");
    }
}
