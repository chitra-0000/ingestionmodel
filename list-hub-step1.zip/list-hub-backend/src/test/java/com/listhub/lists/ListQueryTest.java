package com.listhub.lists;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.listhub.common.InvalidRequestException;
import org.junit.jupiter.api.Test;

class ListQueryTest {

    @Test
    void appliesDefaultsAndNormalisesSearchText() {
        ListQuery query = new ListQuery("  eu consolidated ", "   ", null, null, true, 0, 50);

        assertThat(query.label()).isEqualTo("EU CONSOLIDATED");
        assertThat(query.listRef()).isNull();
        assertThat(query.kind()).isEqualTo(ListKind.SIMPLE);
        assertThat(query.sort()).isEqualTo(ListSortField.LIST_REF);
        assertThat(query.offset()).isZero();
    }

    @Test
    void computesOffsetWithoutIntOverflow() {
        ListQuery query = new ListQuery(null, null, null, null, true, Integer.MAX_VALUE, 200);
        assertThat(query.offset()).isEqualTo(Integer.MAX_VALUE * 200L);
    }

    @Test
    void rejectsInvalidPaging() {
        assertThatThrownBy(() -> new ListQuery(null, null, null, null, true, -1, 50))
            .isInstanceOf(InvalidRequestException.class);
        assertThatThrownBy(() -> new ListQuery(null, null, null, null, true, 0, 0))
            .isInstanceOf(InvalidRequestException.class);
        assertThatThrownBy(() -> new ListQuery(null, null, null, null, true, 0, ListQuery.MAX_PAGE_SIZE + 1))
            .isInstanceOf(InvalidRequestException.class);
    }

    @Test
    void rejectsOverlongSearchText() {
        String tooLong = "x".repeat(ListQuery.MAX_SEARCH_LENGTH + 1);
        assertThatThrownBy(() -> new ListQuery(tooLong, null, null, null, true, 0, 50))
            .isInstanceOf(InvalidRequestException.class);
    }
}
