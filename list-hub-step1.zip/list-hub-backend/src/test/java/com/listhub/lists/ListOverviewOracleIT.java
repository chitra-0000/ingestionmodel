package com.listhub.lists;

import static org.assertj.core.api.Assertions.assertThat;

import com.listhub.common.PageResult;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.test.context.TestPropertySource;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.oracle.OracleContainer;

/**
 * Applies every Liquibase changelog to a real Oracle database (Oracle Free in Docker), then reads
 * the Lists screen from the view. Run with: {@code mvn verify -Poracle-it}.
 */
@SpringBootTest
@Testcontainers
@TestPropertySource(properties = "spring.liquibase.contexts=schema,demo")
class ListOverviewOracleIT {

    @Container
    @ServiceConnection
    static final OracleContainer ORACLE = new OracleContainer("gvenzl/oracle-free:23-slim-faststart");

    @Autowired
    private ListService service;

    @Test
    void schemaAndDemoDataLoadAndTheListsScreenReadsThem() {
        PageResult<ListOverview> page = service.findLists(
            new ListQuery(null, null, ListKind.SIMPLE, ListSortField.LIST_REF, true, 0, 50));

        assertThat(page.total()).isEqualTo(7);
        ListOverview eu = page.items().get(0);
        assertThat(eu.listRef()).isEqualTo("001");
        assertThat(eu.applicableVersion()).isEqualTo(412);
        assertThat(eu.inProgressVersion()).isEqualTo(413);
        assertThat(eu.inProgressStatus()).isEqualTo("PENDING");
        assertThat(eu.publicationDate()).isNotNull();

        ListOverview ofac = page.items().get(1);
        assertThat(ofac.inProgressVersion()).isNull();
    }

    @Test
    void filtersByLabelAndKind() {
        PageResult<ListOverview> ofac = service.findLists(
            new ListQuery("ofac", null, ListKind.SIMPLE, ListSortField.LABEL, true, 0, 50));
        assertThat(ofac.items()).extracting(ListOverview::listRef).containsExactly("002");

        PageResult<ListOverview> concatenated = service.findLists(
            new ListQuery(null, null, ListKind.CONCATENATED, ListSortField.LIST_REF, true, 0, 50));
        assertThat(concatenated.items()).extracting(ListOverview::listRef).containsExactly("008");
    }
}
