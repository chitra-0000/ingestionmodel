# Global List Management Hub – POC

| Folder | Project | Open with |
| --- | --- | --- |
| `list-hub-backend` | Java 21, Spring Boot 3.5, Maven, Oracle (Liquibase) | IntelliJ IDEA: open `pom.xml` as project |
| `list-hub-frontend` | Angular 22, Vitest | Visual Studio Code: open the folder |

Start the backend first (port 8080), then the frontend (`npm start`, port 4200).
See each project's README for setup, users and tests.

## Step 1 (this version)

- Both projects scaffolded with quality gates (JaCoCo, ArchUnit, Maven enforcer, Sonar properties; strict TypeScript).
- Oracle data model as Liquibase changelogs (44 tables): providers, mapping metadata, lists,
  deliveries, files, list versions with applicable and loaded pointers, golden record and child
  tables (list-partitioned), staging and delta, validation, certification and DSS publication; demo data.
- Lists screen end to end: `GET /api/v1/lists` and the Angular Lists page.

## Next steps

DJ XML streaming ingestion into staging, set-based delta package in Oracle, version review with
validation and certification, publication to the DSS.
