# Global List Management Hub – frontend

Angular 22 (standalone components, signals, zoneless), Vitest unit tests.

## Open in Visual Studio Code

1. **File > Open Folder** and select this folder.
2. Install the recommended extensions when VS Code offers them (Angular Language Service,
   Prettier, EditorConfig, Vitest, SonarQube for IDE).
3. Run `npm ci` once in the terminal.
4. Press **F5** (`ng serve (Chrome)` or `ng serve (Edge)`): it starts the dev server and opens the app.

The dev server forwards `/api` to the backend on `http://localhost:8080` (`proxy.conf.json`),
so the browser sees one origin and the CSRF cookie works without CORS.

## Commands

| Command | What it does |
| --- | --- |
| `npm start` | Dev server on http://localhost:4200 with the API proxy |
| `npm test` | Unit tests (Vitest) |
| `npm run build` | Production build into `dist/` |

## Layout

| Folder | Holds |
| --- | --- |
| `src/app/core/lists` | API client and types for lists |
| `src/app/features/lists` | Lists screen: tabs, search, sort, paging, version and status columns |
| `src/app/features/planned` | Placeholder for Records, Deliveries, Administration, Users (next steps) |
| `src/app/shared` | Display helpers (code labels, status chips, versions) |
