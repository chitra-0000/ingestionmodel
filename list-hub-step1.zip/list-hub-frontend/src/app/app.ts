import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './app.html',
  styleUrl: './app.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class App {
  protected readonly nav = [
    { path: '/lists', label: 'Lists' },
    { path: '/records', label: 'Records' },
    { path: '/deliveries', label: 'Deliveries' },
    { path: '/administration', label: 'Administration' },
    { path: '/users', label: 'Users' },
  ] as const;
}
