import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ListOverview, ListQuery, PageResult } from './list-overview';

/** Reads lists from the hub's REST API. */
@Injectable({ providedIn: 'root' })
export class ListApi {
  private readonly http = inject(HttpClient);

  search(query: ListQuery): Observable<PageResult<ListOverview>> {
    let params = new HttpParams()
      .set('kind', query.kind)
      .set('sort', query.sort)
      .set('direction', query.direction)
      .set('page', query.page)
      .set('size', query.size);
    const label = query.label.trim();
    const ref = query.ref.trim();
    if (label) {
      params = params.set('label', label);
    }
    if (ref) {
      params = params.set('ref', ref);
    }
    return this.http.get<PageResult<ListOverview>>('/api/v1/lists', { params });
  }
}
