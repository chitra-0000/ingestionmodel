/** One row of the Lists screen, as returned by GET /api/v1/lists. */
export interface ListOverview {
  listId: number;
  listRef: string;
  label: string;
  listKind: ListKind;
  listType: string;
  listCategory: string;
  scope: string;
  country: string;
  confidentiality: string;
  providerName: string | null;
  /** Last version certified and published to the downstream systems. */
  applicableVersion: number | null;
  applicationDate: string | null;
  publicationDate: string | null;
  recordCount: number | null;
  /** Latest loaded version while it is newer than the applicable one. */
  inProgressVersion: number | null;
  inProgressStatus: InProgressStatus | null;
}

export type ListKind = 'SIMPLE' | 'CONCATENATED';

export type InProgressStatus = 'PENDING' | 'VALIDATED' | 'CERTIFIED' | 'REJECTED' | 'NOT_PUBLISHED';

export type ListSortField =
  | 'listRef'
  | 'label'
  | 'listType'
  | 'listCategory'
  | 'scope'
  | 'country'
  | 'applicableVersion'
  | 'applicationDate'
  | 'publicationDate'
  | 'confidentiality';

export interface ListQuery {
  label: string;
  ref: string;
  kind: ListKind;
  sort: ListSortField;
  direction: 'asc' | 'desc';
  page: number;
  size: number;
}

export interface PageResult<T> {
  items: T[];
  total: number;
  page: number;
  size: number;
}
