import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { ListApi } from './list-api';
import { ListQuery } from './list-overview';

describe('ListApi', () => {
  let api: ListApi;
  let http: HttpTestingController;

  const baseQuery: ListQuery = {
    label: '',
    ref: '',
    kind: 'SIMPLE',
    sort: 'listRef',
    direction: 'asc',
    page: 0,
    size: 50,
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    api = TestBed.inject(ListApi);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('sends kind, sort and paging, and leaves out empty searches', () => {
    api.search(baseQuery).subscribe();

    const req = http.expectOne((r) => r.url === '/api/v1/lists');
    expect(req.request.method).toBe('GET');
    expect(req.request.params.get('kind')).toBe('SIMPLE');
    expect(req.request.params.get('sort')).toBe('listRef');
    expect(req.request.params.get('direction')).toBe('asc');
    expect(req.request.params.get('page')).toBe('0');
    expect(req.request.params.get('size')).toBe('50');
    expect(req.request.params.has('label')).toBe(false);
    expect(req.request.params.has('ref')).toBe(false);
    req.flush({ items: [], total: 0, page: 0, size: 50 });
  });

  it('trims search text before sending it', () => {
    api.search({ ...baseQuery, label: '  ofac ', ref: ' 00 ' }).subscribe();

    const req = http.expectOne((r) => r.url === '/api/v1/lists');
    expect(req.request.params.get('label')).toBe('ofac');
    expect(req.request.params.get('ref')).toBe('00');
    req.flush({ items: [], total: 0, page: 0, size: 50 });
  });
});
