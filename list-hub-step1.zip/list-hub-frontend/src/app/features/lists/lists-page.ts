import { DatePipe, DecimalPipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { catchError, debounceTime, map, of, startWith, switchMap } from 'rxjs';
import { ListApi } from '../../core/lists/list-api';
import { ListKind, ListOverview, ListQuery, ListSortField, PageResult } from '../../core/lists/list-overview';
import { codeLabel, statusDisplay, versionLabel } from '../../shared/display-labels';

interface Column {
  field: ListSortField;
  title: string;
}

type LoadState =
  | { status: 'loading' }
  | { status: 'loaded'; result: PageResult<ListOverview> }
  | { status: 'failed' };

const PAGE_SIZE = 50;

@Component({
  selector: 'app-lists-page',
  imports: [DatePipe, DecimalPipe],
  templateUrl: './lists-page.html',
  styleUrl: './lists-page.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ListsPage {
  private readonly api = inject(ListApi);

  protected readonly columns: readonly Column[] = [
    { field: 'listRef', title: 'List ref' },
    { field: 'label', title: 'Label' },
    { field: 'listType', title: 'List type' },
    { field: 'listCategory', title: 'List category' },
    { field: 'scope', title: 'Scope' },
    { field: 'country', title: 'Country' },
    { field: 'applicableVersion', title: 'Applicable / in progress' },
    { field: 'applicationDate', title: 'Application date' },
    { field: 'publicationDate', title: 'Publication date' },
    { field: 'confidentiality', title: 'Confidentiality' },
  ];

  protected readonly codeLabel = codeLabel;
  protected readonly statusDisplay = statusDisplay;
  protected readonly versionLabel = versionLabel;

  protected readonly kind = signal<ListKind>('SIMPLE');
  protected readonly label = signal('');
  protected readonly ref = signal('');
  protected readonly sort = signal<ListSortField>('listRef');
  protected readonly direction = signal<'asc' | 'desc'>('asc');
  protected readonly page = signal(0);
  private readonly reload = signal(0);

  private readonly query = computed<ListQuery & { reload: number }>(() => ({
    kind: this.kind(),
    label: this.label(),
    ref: this.ref(),
    sort: this.sort(),
    direction: this.direction(),
    page: this.page(),
    size: PAGE_SIZE,
    reload: this.reload(),
  }));

  protected readonly state = toSignal(
    toObservable(this.query).pipe(
      debounceTime(250),
      switchMap((query) =>
        this.api.search(query).pipe(
          map((result): LoadState => ({ status: 'loaded', result })),
          catchError(() => of<LoadState>({ status: 'failed' })),
          startWith<LoadState>({ status: 'loading' }),
        ),
      ),
    ),
    { initialValue: { status: 'loading' } as LoadState },
  );

  protected readonly result = computed(() => {
    const state = this.state();
    return state.status === 'loaded' ? state.result : null;
  });

  protected readonly rangeText = computed(() => {
    const result = this.result();
    if (!result || result.total === 0) {
      return '';
    }
    const first = result.page * result.size + 1;
    const last = Math.min(first + result.items.length - 1, result.total);
    return `${first}–${last} of ${result.total}`;
  });

  protected readonly hasPrevious = computed(() => this.page() > 0);
  protected readonly hasNext = computed(() => {
    const result = this.result();
    return !!result && (result.page + 1) * result.size < result.total;
  });

  protected selectKind(kind: ListKind): void {
    this.kind.set(kind);
    this.page.set(0);
  }

  protected searchLabel(value: string): void {
    this.label.set(value);
    this.page.set(0);
  }

  protected searchRef(value: string): void {
    this.ref.set(value);
    this.page.set(0);
  }

  protected sortBy(field: ListSortField): void {
    if (this.sort() === field) {
      this.direction.update((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      this.sort.set(field);
      this.direction.set('asc');
    }
    this.page.set(0);
  }

  protected ariaSort(field: ListSortField): 'ascending' | 'descending' | 'none' {
    if (this.sort() !== field) {
      return 'none';
    }
    return this.direction() === 'asc' ? 'ascending' : 'descending';
  }

  protected previousPage(): void {
    this.page.update((p) => Math.max(0, p - 1));
  }

  protected nextPage(): void {
    this.page.update((p) => p + 1);
  }

  protected retry(): void {
    this.reload.update((n) => n + 1);
  }
}
