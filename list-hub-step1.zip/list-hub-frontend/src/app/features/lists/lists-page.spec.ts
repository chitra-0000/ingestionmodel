import { TestBed } from '@angular/core/testing';
import { Observable, of, throwError } from 'rxjs';
import { ListApi } from '../../core/lists/list-api';
import { ListOverview, ListQuery, PageResult } from '../../core/lists/list-overview';
import { ListsPage } from './lists-page';

const EU: ListOverview = {
  listId: 1,
  listRef: '001',
  label: 'EU Consolidated Financial Sanctions',
  listKind: 'SIMPLE',
  listType: 'REGULATORY',
  listCategory: 'SANCTIONS',
  scope: 'GROUP',
  country: 'GROUP',
  confidentiality: 'PUBLIC',
  providerName: 'European Union',
  applicableVersion: 412,
  applicationDate: '2026-10-30',
  publicationDate: '2026-10-30T08:07:00Z',
  recordCount: 5210,
  inProgressVersion: 413,
  inProgressStatus: 'PENDING',
};

const OFAC: ListOverview = { ...EU, listId: 2, listRef: '002', label: 'US OFAC SDN', inProgressVersion: null, inProgressStatus: null };

class FakeListApi {
  queries: ListQuery[] = [];
  next: Observable<PageResult<ListOverview>> = of({ items: [EU, OFAC], total: 2, page: 0, size: 50 });

  search(query: ListQuery): Observable<PageResult<ListOverview>> {
    this.queries.push(query);
    return this.next;
  }
}

async function settle(fixture: { whenStable(): Promise<unknown>; detectChanges(): void }): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, 300));
  await fixture.whenStable();
  fixture.detectChanges();
}

describe('ListsPage', () => {
  let api: FakeListApi;

  beforeEach(() => {
    api = new FakeListApi();
    TestBed.configureTestingModule({
      imports: [ListsPage],
      providers: [{ provide: ListApi, useValue: api }],
    });
  });

  it('shows each list with its applicable and in-progress versions', async () => {
    const fixture = TestBed.createComponent(ListsPage);
    await settle(fixture);
    const text: string = fixture.nativeElement.textContent;

    expect(text).toContain('EU Consolidated Financial Sanctions');
    expect(text).toContain('V412');
    expect(text).toContain('V413');
    expect(text).toContain('Awaiting validation');
    expect(text).toContain('5,210 records');
    expect(text).toContain('1–2 of 2');
    expect(fixture.nativeElement.querySelectorAll('tbody tr').length).toBe(2);
  });

  it('sorts by a column, then reverses on a second click', async () => {
    const fixture = TestBed.createComponent(ListsPage);
    await settle(fixture);
    const labelHeader: HTMLButtonElement = fixture.nativeElement.querySelectorAll('th .sort')[1];

    labelHeader.click();
    await settle(fixture);
    expect(api.queries.at(-1)).toMatchObject({ sort: 'label', direction: 'asc', page: 0 });

    labelHeader.click();
    await settle(fixture);
    expect(api.queries.at(-1)).toMatchObject({ sort: 'label', direction: 'desc' });
  });

  it('switches to concatenated lists', async () => {
    const fixture = TestBed.createComponent(ListsPage);
    await settle(fixture);

    (fixture.nativeElement.querySelector('#tab-concatenated') as HTMLButtonElement).click();
    await settle(fixture);
    expect(api.queries.at(-1)?.kind).toBe('CONCATENATED');
  });

  it('explains a failure and offers a retry', async () => {
    api.next = throwError(() => new Error('offline'));
    const fixture = TestBed.createComponent(ListsPage);
    await settle(fixture);

    expect(fixture.nativeElement.textContent).toContain('The lists could not be loaded');
    expect(fixture.nativeElement.querySelector('button.link')).not.toBeNull();
  });
});
