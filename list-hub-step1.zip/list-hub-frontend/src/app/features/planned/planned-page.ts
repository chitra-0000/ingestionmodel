import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ActivatedRoute } from '@angular/router';
import { map } from 'rxjs';

/** Placeholder for screens planned in the next steps. */
@Component({
  selector: 'app-planned-page',
  template: `
    <h1>{{ title() }}</h1>
    <p class="note">This screen comes in a later step of the POC.</p>
  `,
  styles: `
    h1 { margin: 0 0 4px; font-size: 1.5rem; font-weight: 650; }
    .note { color: var(--ink-muted); }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PlannedPage {
  protected readonly title = toSignal(
    inject(ActivatedRoute).data.pipe(map((data) => String(data['title'] ?? ''))),
    { initialValue: '' },
  );
}
