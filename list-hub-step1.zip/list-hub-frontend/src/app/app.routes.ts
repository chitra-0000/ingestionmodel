import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'lists' },
  {
    path: 'lists',
    title: 'Lists · List Hub',
    loadComponent: () => import('./features/lists/lists-page').then((m) => m.ListsPage),
  },
  ...(
    [
      ['records', 'Records'],
      ['deliveries', 'Deliveries'],
      ['administration', 'Administration'],
      ['users', 'Users'],
    ] as const
  ).map(([path, title]) => ({
    path,
    title: `${title} · List Hub`,
    data: { title },
    loadComponent: () => import('./features/planned/planned-page').then((m) => m.PlannedPage),
  })),
  { path: '**', redirectTo: 'lists' },
];
