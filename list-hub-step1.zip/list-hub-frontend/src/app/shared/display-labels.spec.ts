import { codeLabel, statusDisplay, versionLabel } from './display-labels';

describe('display labels', () => {
  it('turns codes into words and keeps unknown codes', () => {
    expect(codeLabel('AML_CTF')).toBe('AML/CTF');
    expect(codeLabel('REGULATORY')).toBe('Regulatory');
    expect(codeLabel('NEW_CODE')).toBe('NEW_CODE');
    expect(codeLabel(null)).toBe('');
  });

  it('describes each in-progress status', () => {
    expect(statusDisplay('PENDING')).toEqual({ text: 'Awaiting validation', tone: 'waiting' });
    expect(statusDisplay('VALIDATED')).toEqual({ text: 'Awaiting certification', tone: 'review' });
    expect(statusDisplay('REJECTED')?.tone).toBe('blocked');
    expect(statusDisplay(null)).toBeNull();
  });

  it('formats versions', () => {
    expect(versionLabel(412)).toBe('V412');
    expect(versionLabel(null)).toBe('–');
  });
});
