import { InProgressStatus } from '../core/lists/list-overview';

const CODE_LABELS: Record<string, string> = {
  REGULATORY: 'Regulatory',
  DERIVATIVE: 'Derivative',
  INTERNAL: 'Internal',
  SANCTIONS: 'Sanctions',
  AML_CTF: 'AML/CTF',
  GROUP: 'Group',
  PUBLIC: 'Public',
  CONFIDENTIAL: 'Confidential',
  SECRET: 'Secret',
};

/** Turns a code from the API into words for the screen; unknown codes are shown as they are. */
export function codeLabel(code: string | null | undefined): string {
  if (!code) {
    return '';
  }
  return CODE_LABELS[code] ?? code;
}

export type StatusTone = 'waiting' | 'review' | 'ready' | 'blocked';

export interface StatusDisplay {
  text: string;
  tone: StatusTone;
}

const STATUS_DISPLAY: Record<InProgressStatus, StatusDisplay> = {
  PENDING: { text: 'Awaiting validation', tone: 'waiting' },
  VALIDATED: { text: 'Awaiting certification', tone: 'review' },
  CERTIFIED: { text: 'Certified, publishing', tone: 'ready' },
  REJECTED: { text: 'Rejected', tone: 'blocked' },
  NOT_PUBLISHED: { text: 'Not published', tone: 'blocked' },
};

/** What the in-progress status chip says and how it is coloured. */
export function statusDisplay(status: InProgressStatus | null): StatusDisplay | null {
  return status ? STATUS_DISPLAY[status] : null;
}

export function versionLabel(version: number | null): string {
  return version === null ? '–' : `V${version}`;
}
