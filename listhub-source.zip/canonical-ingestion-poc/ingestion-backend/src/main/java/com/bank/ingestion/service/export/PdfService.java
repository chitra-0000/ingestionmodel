package com.bank.ingestion.service.export;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/** Record sheet PDF: the record as valid in a version, and what changed in that version. */
@Service
public class PdfService {

    private static final Color NAVY = new Color(0x16, 0x23, 0x3A);
    private static final Color BLUE = new Color(0x1E, 0x4E, 0x8C);
    private static final Color GREY = new Color(0x5B, 0x65, 0x75);
    private static final Color LINE = new Color(0xDC, 0xE0, 0xE5);
    private static final Color HEAD = new Color(0xEE, 0xF1, 0xF5);

    /**
     * @param record  rowView of RecordService (attributes grouped)
     * @param change  changeView of the version's change for this record, may be null
     */
    @SuppressWarnings("unchecked")
    public byte[] recordSheet(Map<String, Object> record, Map<String, Object> change, Integer version) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Document doc = new Document(PageSize.A4, 48, 48, 48, 48);
        try {
            PdfWriter.getInstance(doc, out);
            doc.addTitle("Record " + record.get("rglId"));
            doc.addCreator("ListHub");
            doc.open();
            Font title = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 15, NAVY);
            Font small = FontFactory.getFont(FontFactory.HELVETICA, 9, GREY);
            Font name = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, NAVY);
            Font section = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, BLUE);
            Font label = FontFactory.getFont(FontFactory.HELVETICA, 9, GREY);
            Font value = FontFactory.getFont(FontFactory.HELVETICA, 10, NAVY);
            Font bold = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, NAVY);

            PdfPTable head = new PdfPTable(new float[]{3, 2});
            head.setWidthPercentage(100);
            PdfPCell left = new PdfPCell();
            left.setBorder(PdfPCell.BOTTOM);
            left.setBorderWidthBottom(1.5f);
            left.setBorderColorBottom(NAVY);
            left.addElement(new Paragraph("ListHub record sheet", title));
            left.addElement(new Paragraph(record.get("listCode") + " " + record.get("listName")
                    + (version == null ? "" : " - version " + version), small));
            head.addCell(left);
            PdfPCell right = new PdfPCell();
            right.setBorder(PdfPCell.BOTTOM);
            right.setBorderWidthBottom(1.5f);
            right.setBorderColorBottom(NAVY);
            Paragraph id = new Paragraph(String.valueOf(record.get("rglId")), FontFactory.getFont(FontFactory.COURIER_BOLD, 11, NAVY));
            id.setAlignment(Element.ALIGN_RIGHT);
            right.addElement(id);
            if (change != null) {
                Paragraph t = new Paragraph(String.valueOf(change.get("type")), small);
                t.setAlignment(Element.ALIGN_RIGHT);
                right.addElement(t);
            }
            head.addCell(right);
            doc.add(head);

            Paragraph n = new Paragraph(String.valueOf(record.get("primaryName")), name);
            n.setSpacingBefore(14);
            n.setSpacingAfter(10);
            doc.add(n);

            doc.add(heading("RECORD", section));
            PdfPTable t = new PdfPTable(new float[]{2, 5});
            t.setWidthPercentage(100);
            row(t, "Provider ID", record.get("externalRef"), label, value);
            row(t, "Type", record.get("recordType"), label, value);
            row(t, "Valid from version", record.get("validFrom"), label, value);
            if (record.get("validTo") != null) {
                row(t, "Valid until version", record.get("validTo"), label, value);
            }
            for (Map<String, Object> a : (List<Map<String, Object>>) record.get("attributes")) {
                row(t, (String) a.get("label"), String.join("; ", (List<String>) a.get("values")), label, value);
            }
            doc.add(t);

            if (change != null && change.get("detail") instanceof Map) {
                Map<String, Object> detail = (Map<String, Object>) change.get("detail");
                Object changes = detail.get("changes");
                if (changes instanceof List && !((List<?>) changes).isEmpty()) {
                    Paragraph h = heading("WHAT CHANGED IN THIS VERSION", section);
                    h.setSpacingBefore(14);
                    doc.add(h);
                    PdfPTable c = new PdfPTable(new float[]{2, 3, 3});
                    c.setWidthPercentage(100);
                    headCell(c, "Field", bold);
                    headCell(c, "Before", bold);
                    headCell(c, "After", bold);
                    for (Map<String, Object> i : (List<Map<String, Object>>) changes) {
                        cell(c, String.valueOf(i.get("field")), bold);
                        cell(c, i.get("before") == null ? "-" : String.valueOf(i.get("before")), value);
                        cell(c, i.get("after") == null ? "-" : String.valueOf(i.get("after")), value);
                    }
                    doc.add(c);
                }
            }
            if (record.get("flags") != null) {
                Paragraph f = new Paragraph("Quality flags: " + record.get("flags"), small);
                f.setSpacingBefore(10);
                doc.add(f);
            }
            Paragraph foot = new Paragraph("Batch " + record.get("batchId") + ", raw record " + record.get("rawSeq")
                    + ". Generated " + LocalDateTime.now().withNano(0) + " by ListHub.", small);
            foot.setSpacingBefore(24);
            doc.add(foot);
        } catch (DocumentException e) {
            throw new IllegalStateException("PDF generation failed", e);
        } finally {
            doc.close();
        }
        return out.toByteArray();
    }

    private static Paragraph heading(String text, Font f) {
        Paragraph p = new Paragraph(new Chunk(text, f));
        p.setSpacingAfter(6);
        return p;
    }

    private static void row(PdfPTable t, String k, Object v, Font lf, Font vf) {
        cell(t, k, lf);
        cell(t, v == null ? "-" : String.valueOf(v), vf);
    }

    private static void cell(PdfPTable t, String text, Font f) {
        PdfPCell c = new PdfPCell(new Phrase(text, f));
        c.setBorder(PdfPCell.BOTTOM);
        c.setBorderColor(LINE);
        c.setPadding(5);
        t.addCell(c);
    }

    private static void headCell(PdfPTable t, String text, Font f) {
        PdfPCell c = new PdfPCell(new Phrase(text, f));
        c.setBorder(PdfPCell.NO_BORDER);
        c.setBackgroundColor(HEAD);
        c.setPadding(5);
        t.addCell(c);
    }
}
