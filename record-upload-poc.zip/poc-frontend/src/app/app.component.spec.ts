import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { UploadResult } from './models';
import { RecordsTableComponent } from './records/records-table.component';

describe('AppComponent', () => {
  let fixture: ComponentFixture<AppComponent>;
  let app: AppComponent;
  let http: HttpTestingController;

  const result: UploadResult = {
    upload: {
      uploadId: 7,
      fileName: 'dowjones-sample.xml',
      format: 'XML',
      fileSizeBytes: 5120,
      status: 'COMPLETED',
      recordsRead: 8,
      recordsLoaded: 6,
      recordsRejected: 2,
      message: '6 records loaded, 2 rejected (see the reasons below).',
      startedAt: '2026-11-02T10:00:00Z',
      endedAt: '2026-11-02T10:00:01Z',
      durationMs: 840,
    },
    rejects: [{ rowNo: 7, externalRef: null, reason: 'Missing external id' }],
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule],
      declarations: [AppComponent, RecordsTableComponent],
    }).compileComponents();
    fixture = TestBed.createComponent(AppComponent);
    app = fixture.componentInstance;
    http = TestBed.inject(HttpTestingController);
    fixture.detectChanges();
    http.expectOne((r) => r.url === '/api/uploads' && r.method === 'GET').flush([]);
  });

  it('refuses files that are not XML or CSV', () => {
    app.choose(new File(['x'], 'list.pdf'));
    fixture.detectChanges();
    expect(app.selectedFile).toBeNull();
    expect(fixture.nativeElement.textContent).toContain('is not an .xml or .csv file');
  });

  it('uploads the file and shows the counts and the rejected rows', () => {
    app.choose(new File(['<PFA/>'], 'dowjones-sample.xml'));
    expect(app.selectedFormat).toBe('Dow Jones XML');
    app.upload();

    const post = http.expectOne((r) => r.url === '/api/uploads' && r.method === 'POST');
    expect(post.request.body instanceof FormData).toBeTrue();
    post.flush(result);
    http.expectOne((r) => r.url === '/api/uploads' && r.method === 'GET').flush([result.upload]);
    fixture.detectChanges();
    http.expectOne((r) => r.url === '/api/uploads/7/records').flush({ items: [], total: 0, page: 0, size: 25 });
    fixture.detectChanges();

    const text: string = fixture.nativeElement.textContent;
    expect(text).toContain('Upload #7 saved.');
    expect(text).toContain('Saved to database');
    expect(text).toContain('Missing external id');
    expect(app.phase).toBe('done');
  });

  it('shows the server message when the same file is uploaded twice', () => {
    app.choose(new File(['a,b'], 'list.csv'));
    app.upload();
    http.expectOne((r) => r.method === 'POST').flush(
      { status: 409, message: 'This file was already loaded as upload #3 (list.csv).' },
      { status: 409, statusText: 'Conflict' },
    );
    fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain('already loaded as upload #3');
  });
});
