import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { RecordPage } from '../models';
import { RecordsTableComponent } from './records-table.component';

describe('RecordsTableComponent', () => {
  let fixture: ComponentFixture<RecordsTableComponent>;
  let component: RecordsTableComponent;
  let http: HttpTestingController;

  const page: RecordPage = {
    items: [
      {
        recordId: 1,
        rowNo: 1,
        externalRef: '900101',
        recordType: 'PERSON',
        fullName: 'Viktor Pavel ORLANDO',
        gender: 'Male',
        dateOfBirth: '1965-03-12',
        nationality: 'ZZ',
        sanctionsLists: 'OFAC - SDN',
        aliases: ['Victor ORLANDOV', 'The Captain'],
      },
    ],
    total: 1,
    page: 0,
    size: 25,
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule],
      declarations: [RecordsTableComponent],
    }).compileComponents();
    fixture = TestBed.createComponent(RecordsTableComponent);
    component = fixture.componentInstance;
    http = TestBed.inject(HttpTestingController);
    component.uploadId = 7;
    component.ngOnChanges();
    fixture.detectChanges();
  });

  it('shows the records read back from the database with their aliases', () => {
    http.expectOne((r) => r.url === '/api/uploads/7/records').flush(page);
    fixture.detectChanges();
    const text: string = fixture.nativeElement.textContent;
    expect(text).toContain('Viktor Pavel ORLANDO');
    expect(text).toContain('also: Victor ORLANDOV · The Captain');
    expect(text).toContain('1965-03-12');
    expect(component.rangeText).toBe('1–1 of 1');
  });

  it('searches after the user stops typing', fakeAsync(() => {
    http.expectOne((r) => r.url === '/api/uploads/7/records').flush(page);
    component.onSearch('orlando');
    tick(300);
    const req = http.expectOne((r) => r.url === '/api/uploads/7/records');
    expect(req.request.params.get('search')).toBe('orlando');
    expect(req.request.params.get('page')).toBe('0');
    req.flush(page);
  }));
});
