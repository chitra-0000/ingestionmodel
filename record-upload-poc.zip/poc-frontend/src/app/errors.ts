import { HttpErrorResponse } from '@angular/common/http';
import { ApiError } from './models';

/** The backend's message when there is one, otherwise a plain explanation. */
export function messageOf(err: HttpErrorResponse): string {
  const body = err.error as ApiError | null;
  if (body && typeof body.message === 'string') {
    return body.message;
  }
  if (err.status === 0) {
    return 'The server cannot be reached. Check that the backend is running on port 8080.';
  }
  if (err.status === 413) {
    return 'The file is larger than the upload limit.';
  }
  return `The request failed (HTTP ${err.status}). Try again.`;
}
