/** One uploaded file and the result of loading it. */
export interface UploadSummary {
  uploadId: number;
  fileName: string;
  format: 'XML' | 'CSV';
  fileSizeBytes: number;
  status: 'PROCESSING' | 'COMPLETED' | 'FAILED';
  recordsRead: number;
  recordsLoaded: number;
  recordsRejected: number;
  message: string | null;
  startedAt: string;
  endedAt: string | null;
  durationMs: number | null;
}

export interface RejectRow {
  rowNo: number;
  externalRef: string | null;
  reason: string;
}

export interface UploadResult {
  upload: UploadSummary;
  rejects: RejectRow[];
}

export interface RecordView {
  recordId: number;
  rowNo: number;
  externalRef: string;
  recordType: 'PERSON' | 'ENTITY' | 'VESSEL' | 'UNKNOWN';
  fullName: string;
  gender: string | null;
  dateOfBirth: string | null;
  nationality: string | null;
  sanctionsLists: string | null;
  aliases: string[];
}

export interface RecordPage {
  items: RecordView[];
  total: number;
  page: number;
  size: number;
}

/** Error body returned by the backend. */
export interface ApiError {
  status: number;
  message: string;
  errorId?: string;
}
