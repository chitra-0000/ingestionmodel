import { HttpErrorResponse, HttpEventType } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { messageOf } from './errors';
import { RejectRow, UploadSummary } from './models';
import { UploadApiService } from './upload-api.service';

type Phase = 'idle' | 'uploading' | 'processing' | 'done' | 'error';

const ACCEPTED = ['.xml', '.csv'];

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, OnDestroy {
  selectedFile: File | null = null;
  dragOver = false;
  phase: Phase = 'idle';
  progress = 0;
  errorMessage = '';

  current: UploadSummary | null = null;
  rejects: RejectRow[] = [];
  history: UploadSummary[] = [];
  historyError = '';

  private uploadSub?: Subscription;

  constructor(private readonly api: UploadApiService) {}

  ngOnInit(): void {
    this.loadHistory();
  }

  ngOnDestroy(): void {
    this.uploadSub?.unsubscribe();
  }

  get selectedFormat(): string {
    const name = this.selectedFile?.name.toLowerCase() ?? '';
    if (name.endsWith('.xml')) {
      return 'Dow Jones XML';
    }
    if (name.endsWith('.csv')) {
      return 'CSV';
    }
    return '';
  }

  get busy(): boolean {
    return this.phase === 'uploading' || this.phase === 'processing';
  }

  onFileInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.choose(input.files && input.files.length ? input.files[0] : null);
    input.value = '';
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    this.dragOver = true;
  }

  onDragLeave(): void {
    this.dragOver = false;
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    this.dragOver = false;
    const files = event.dataTransfer?.files;
    this.choose(files && files.length ? files[0] : null);
  }

  choose(file: File | null): void {
    this.errorMessage = '';
    if (!file) {
      return;
    }
    const lower = file.name.toLowerCase();
    if (!ACCEPTED.some((ext) => lower.endsWith(ext))) {
      this.selectedFile = null;
      this.phase = 'error';
      this.errorMessage = `"${file.name}" is not an .xml or .csv file. Choose a Dow Jones XML or a CSV file.`;
      return;
    }
    this.selectedFile = file;
    this.phase = 'idle';
  }

  upload(): void {
    if (!this.selectedFile || this.busy) {
      return;
    }
    this.phase = 'uploading';
    this.progress = 0;
    this.errorMessage = '';
    this.uploadSub = this.api.upload(this.selectedFile).subscribe({
      next: (event) => {
        if (event.type === HttpEventType.UploadProgress) {
          this.progress = event.total ? Math.round((event.loaded / event.total) * 100) : 0;
          if (this.progress >= 100) {
            this.phase = 'processing';
          }
        } else if (event.type === HttpEventType.Response && event.body) {
          this.current = event.body.upload;
          this.rejects = event.body.rejects;
          this.phase = event.body.upload.status === 'FAILED' ? 'error' : 'done';
          this.errorMessage = event.body.upload.status === 'FAILED' ? event.body.upload.message ?? '' : '';
          this.selectedFile = null;
          this.loadHistory();
        }
      },
      error: (err: HttpErrorResponse) => {
        this.phase = 'error';
        this.errorMessage = messageOf(err);
        this.current = null;
        this.rejects = [];
      },
    });
  }

  show(upload: UploadSummary): void {
    this.current = upload;
    this.rejects = [];
    this.phase = upload.status === 'FAILED' ? 'error' : 'done';
    this.errorMessage = upload.status === 'FAILED' ? upload.message ?? '' : '';
    if (upload.recordsRejected > 0) {
      this.api.rejects(upload.uploadId, 50).subscribe({ next: (rows) => (this.rejects = rows) });
    }
  }

  loadHistory(): void {
    this.api.recent(20).subscribe({
      next: (rows) => {
        this.history = rows;
        this.historyError = '';
      },
      error: (err: HttpErrorResponse) => (this.historyError = messageOf(err)),
    });
  }

  fileSize(bytes: number): string {
    if (bytes < 1024) {
      return `${bytes} B`;
    }
    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }

  duration(ms: number | null): string {
    if (ms === null || ms === undefined) {
      return '–';
    }
    return ms < 1000 ? `${ms} ms` : `${(ms / 1000).toFixed(1)} s`;
  }
}
