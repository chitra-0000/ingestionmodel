package com.listhub.poc.parse;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class DowJonesXmlReaderTest {

    private final DowJonesXmlReader reader = new DowJonesXmlReader();

    @Test
    void readsPersonsEntitiesAndVesselsFromTheSample() throws IOException {
        Collected out = read(getClass().getResourceAsStream("/samples/dowjones-sample.xml"));

        assertThat(out.records).hasSize(7);
        assertThat(out.rejects).containsExactly("8|900104|Date of birth: Month 13 is not between 1 and 12");

        ParsedRecord viktor = out.records.get(0);
        assertThat(viktor.getExternalRef()).isEqualTo("900101");
        assertThat(viktor.getRecordType()).isEqualTo(RecordType.PERSON);
        assertThat(viktor.getFullName()).isEqualTo("Viktor Pavel ORLANDO");
        assertThat(viktor.getLastName()).isEqualTo("ORLANDO");
        assertThat(viktor.getGender()).isEqualTo("Male");
        assertThat(viktor.getDobDay()).isEqualTo(12);
        assertThat(viktor.getDobMonth()).isEqualTo(3);
        assertThat(viktor.getDobYear()).isEqualTo(1965);
        assertThat(viktor.getNationality()).isEqualTo("ZZ");
        assertThat(viktor.getSanctionsLists()).containsExactly(
            "OFAC - Specially Designated Nationals (SDN)", "EU - Consolidated Financial Sanctions");
        assertThat(viktor.getAliases()).extracting(ParsedRecord.Alias::getFullName)
            .containsExactly("Victor ORLANDOV", "The Captain");

        ParsedRecord amira = out.records.get(1);
        assertThat(amira.getDobDay()).isNull();
        assertThat(amira.getDobMonth()).isNull();
        assertThat(amira.getDobYear()).isEqualTo(1978);

        ParsedRecord entity = out.records.get(4);
        assertThat(entity.getRecordType()).isEqualTo(RecordType.ENTITY);
        assertThat(entity.getFullName()).isEqualTo("Blue Harbour Investments & Holdings");

        ParsedRecord vessel = out.records.get(5);
        assertThat(vessel.getRecordType()).isEqualTo(RecordType.VESSEL);
        assertThat(vessel.getAliases()).extracting(ParsedRecord.Alias::getType).containsExactly("Formerly Known As");

        ParsedRecord noId = out.records.get(6);
        assertThat(noId.getExternalRef()).isNull();
    }

    @Test
    void matchesElementNamesWithoutRegardToCase() throws IOException {
        String xml = "<PFA><records><PERSON ID=\"7\"><namedetails><name nametype=\"primary name\">"
            + "<namevalue><firstname>Ann</firstname><SurName>LEE</SurName></namevalue></name></namedetails>"
            + "<GenderValue>F</GenderValue></PERSON></records></PFA>";
        Collected out = read(stream(xml));

        assertThat(out.records).hasSize(1);
        assertThat(out.records.get(0).getExternalRef()).isEqualTo("7");
        assertThat(out.records.get(0).getFullName()).isEqualTo("Ann LEE");
        assertThat(out.records.get(0).getGender()).isEqualTo("Female");
    }

    @Test
    void refusesDoctypeSoExternalEntitiesCannotBeUsed() {
        String xxe = "<?xml version=\"1.0\"?><!DOCTYPE r [<!ENTITY x SYSTEM \"file:///etc/passwd\">]>"
            + "<PFA><Records><Person id=\"1\"><NameDetails><Name><NameValue><Surname>&x;</Surname>"
            + "</NameValue></Name></NameDetails></Person></Records></PFA>";

        assertThatThrownBy(() -> read(stream(xxe))).isInstanceOf(FileFormatException.class);
    }

    @Test
    void reportsMalformedXmlWithTheLine() {
        assertThatThrownBy(() -> read(stream("<PFA>\n<Records>\n<Person id=\"1\">\n</Records>")))
            .isInstanceOf(FileFormatException.class)
            .hasMessageContaining("not well-formed")
            .hasMessageContaining("line");
    }

    @Test
    void explainsWhenTheFileHasNoRecords() {
        assertThatThrownBy(() -> read(stream("<catalog><book/></catalog>")))
            .isInstanceOf(FileFormatException.class)
            .hasMessageContaining("No <Person>, <Entity> or <Vessel> records");
    }

    private static InputStream stream(String xml) {
        return new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8));
    }

    private Collected read(InputStream in) throws IOException {
        Collected out = new Collected();
        reader.read(in, out);
        return out;
    }

    static final class Collected implements RecordSink {
        final List<ParsedRecord> records = new ArrayList<>();
        final List<String> rejects = new ArrayList<>();

        @Override
        public void accept(ParsedRecord record) {
            records.add(record);
        }

        @Override
        public void reject(long rowNo, String externalRef, String reason) {
            rejects.add(rowNo + "|" + externalRef + "|" + reason);
        }
    }
}
