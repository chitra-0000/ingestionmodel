package com.listhub.poc.parse;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.listhub.poc.config.CsvColumnsProperties;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.Test;

class CsvRecordReaderTest {

    private final CsvRecordReader reader = new CsvRecordReader(new CsvColumnsProperties());

    @Test
    void readsTheSampleFile() throws IOException {
        DowJonesXmlReaderTest.Collected out = new DowJonesXmlReaderTest.Collected();
        reader.read(getClass().getResourceAsStream("/samples/sanctions-sample.csv"), out);

        assertThat(out.records).hasSize(6);
        assertThat(out.rejects).hasSize(1);
        assertThat(out.rejects.get(0)).startsWith("7|CSV-1007|Date '1985-02-31x' is not in a supported format");

        ParsedRecord elena = out.records.get(0);
        assertThat(elena.getFullName()).isEqualTo("Elena VARGOSA");
        assertThat(elena.getGender()).isEqualTo("Female");
        assertThat(elena.getDobYear()).isEqualTo(1972);
        assertThat(elena.getAliases()).extracting(ParsedRecord.Alias::getFullName)
            .containsExactly("Helena Vargosa", "E. Vargosa");

        ParsedRecord marcus = out.records.get(1);
        assertThat(marcus.getDobMonth()).isNull();
        assertThat(marcus.getSanctionsLists()).containsExactly("OFAC - SDN", "UK - HM Treasury");

        ParsedRecord tomas = out.records.get(4);
        assertThat(tomas.getDobDay()).isEqualTo(3);
        assertThat(tomas.getDobMonth()).isEqualTo(11);
        assertThat(tomas.getRecordType()).isEqualTo(RecordType.PERSON);
    }

    @Test
    void detectsSemicolonsAndIgnoresHeaderCase() throws IOException {
        String csv = "EXTERNAL_ID;Full_Name;RECORD_TYPE\nA-1;Acme Corp;E\n";
        DowJonesXmlReaderTest.Collected out = new DowJonesXmlReaderTest.Collected();
        reader.read(stream(csv), out);

        assertThat(out.records).hasSize(1);
        assertThat(out.records.get(0).getFullName()).isEqualTo("Acme Corp");
        assertThat(out.records.get(0).getRecordType()).isEqualTo(RecordType.ENTITY);
    }

    @Test
    void namesTheMissingRequiredColumns() {
        assertThatThrownBy(() -> reader.read(stream("id,name\n1,Ann\n"), new DowJonesXmlReaderTest.Collected()))
            .isInstanceOf(FileFormatException.class)
            .hasMessageContaining("external_id")
            .hasMessageContaining("full_name");
    }

    @Test
    void usesConfiguredColumnNames() throws IOException {
        CsvColumnsProperties columns = new CsvColumnsProperties();
        columns.setExternalRef("REF_ID");
        columns.setFullName("NAME");
        DowJonesXmlReaderTest.Collected out = new DowJonesXmlReaderTest.Collected();
        new CsvRecordReader(columns).read(stream("REF_ID,NAME\nX9,Some Name\n"), out);

        assertThat(out.records.get(0).getExternalRef()).isEqualTo("X9");
    }

    private static InputStream stream(String csv) {
        return new ByteArrayInputStream(csv.getBytes(StandardCharsets.UTF_8));
    }
}
