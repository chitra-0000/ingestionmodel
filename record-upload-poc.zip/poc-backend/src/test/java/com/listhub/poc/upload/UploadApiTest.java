package com.listhub.poc.upload;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.util.StreamUtils;

/** Whole flow on H2 in Oracle mode: Liquibase schema, upload, records, rejects, duplicates. */
@SpringBootTest(properties = {
    "spring.datasource.url=jdbc:h2:mem:poc;MODE=Oracle;DEFAULT_NULL_ORDERING=HIGH;DB_CLOSE_DELAY=-1",
    "spring.datasource.username=sa",
    "spring.datasource.password=",
    "poc.upload.batch-size=2"})
@AutoConfigureMockMvc
@DirtiesContext
class UploadApiTest {

    @Autowired
    private MockMvc mvc;

    @Test
    void loadsTheDowJonesSampleAndRefusesItTheSecondTime() throws Exception {
        MockMultipartFile file = sample("dowjones-sample.xml", "application/xml");

        String body = mvc.perform(multipart("/api/uploads").file(file))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.upload.status").value("COMPLETED"))
            .andExpect(jsonPath("$.upload.format").value("XML"))
            .andExpect(jsonPath("$.upload.recordsRead").value(8))
            .andExpect(jsonPath("$.upload.recordsLoaded").value(6))
            .andExpect(jsonPath("$.upload.recordsRejected").value(2))
            .andExpect(jsonPath("$.rejects[0].reason").value("Missing external id"))
            .andReturn().getResponse().getContentAsString();
        long uploadId = Long.parseLong(body.replaceAll(".*\"uploadId\":(\\d+).*", "$1"));

        mvc.perform(get("/api/uploads/" + uploadId + "/records"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.total").value(6))
            .andExpect(jsonPath("$.items[0].externalRef").value("900101"))
            .andExpect(jsonPath("$.items[0].fullName").value("Viktor Pavel ORLANDO"))
            .andExpect(jsonPath("$.items[0].dateOfBirth").value("1965-03-12"))
            .andExpect(jsonPath("$.items[0].aliases[0]").value("Victor ORLANDOV"))
            .andExpect(jsonPath("$.items[1].dateOfBirth").value("1978"))
            .andExpect(jsonPath("$.items[2].dateOfBirth").value("1981-07"));

        mvc.perform(get("/api/uploads/" + uploadId + "/records").param("search", "harbour"))
            .andExpect(jsonPath("$.total").value(1))
            .andExpect(jsonPath("$.items[0].recordType").value("ENTITY"));

        mvc.perform(multipart("/api/uploads").file(sample("dowjones-sample.xml", "application/xml")))
            .andExpect(status().isConflict())
            .andExpect(jsonPath("$.message", containsString("already loaded as upload #" + uploadId)));
    }

    @Test
    void loadsTheCsvSample() throws Exception {
        mvc.perform(multipart("/api/uploads").file(sample("sanctions-sample.csv", "text/csv")))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.upload.format").value("CSV"))
            .andExpect(jsonPath("$.upload.recordsLoaded").value(5))
            .andExpect(jsonPath("$.upload.recordsRejected").value(2));

        mvc.perform(get("/api/uploads"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].fileName").value("sanctions-sample.csv"));
    }

    @Test
    void failedFileLeavesNoRecordsAndSaysWhy() throws Exception {
        MockMultipartFile broken = new MockMultipartFile("file", "broken.xml", "application/xml",
            "<PFA><Records><Person id=\"1\"><NameDetails><Name><NameValue><Surname>A</Surname></NameValue></Name></NameDetails></Person><Person id=\"2\">"
                .getBytes(StandardCharsets.UTF_8));

        mvc.perform(multipart("/api/uploads").file(broken))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.upload.status").value("FAILED"))
            .andExpect(jsonPath("$.upload.recordsLoaded").value(0))
            .andExpect(jsonPath("$.upload.message", containsString("not well-formed")));
    }

    @Test
    void refusesOtherFileTypes() throws Exception {
        MockMultipartFile pdf = new MockMultipartFile("file", "list.pdf", "application/pdf", new byte[] {1, 2, 3});
        mvc.perform(multipart("/api/uploads").file(pdf))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.message").value("Only .xml (Dow Jones) and .csv files can be uploaded."));
    }

    @Test
    void unknownUploadIsNotFound() throws Exception {
        mvc.perform(get("/api/uploads/987654/records")).andExpect(status().isNotFound());
    }

    private MockMultipartFile sample(String name, String type) throws IOException {
        try (InputStream in = getClass().getResourceAsStream("/samples/" + name)) {
            return new MockMultipartFile("file", name, type, StreamUtils.copyToByteArray(in));
        }
    }
}
