package com.listhub.poc.parse;

/** The file as a whole cannot be read; the message is safe to show to the user. */
public class FileFormatException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public FileFormatException(String message) {
        super(message);
    }

    public FileFormatException(String message, Throwable cause) {
        super(message, cause);
    }
}
