package com.listhub.poc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/** Record upload POC: upload a Dow Jones XML or CSV file and load its records into Oracle. */
@SpringBootApplication
@ConfigurationPropertiesScan
public class PocApplication {

    public static void main(String[] args) {
        SpringApplication.run(PocApplication.class, args);
    }
}
