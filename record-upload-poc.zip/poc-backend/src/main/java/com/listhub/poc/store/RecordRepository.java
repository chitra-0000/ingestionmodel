package com.listhub.poc.store;

import com.listhub.poc.parse.ParsedRecord;
import com.listhub.poc.parse.Text;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 * Writes records in JDBC batches and reads them back for the page. Every value is a bind variable.
 */
@Repository
public class RecordRepository {

    private static final String INSERT_RECORD =
        "INSERT INTO poc_record (record_id, upload_id, row_no, external_ref, record_type, full_name, first_name,"
            + " middle_name, last_name, gender, dob_day, dob_month, dob_year, nationality, sanctions_lists,"
            + " alias_count, created_at)"
            + " VALUES (poc_record_seq.NEXTVAL, :uploadId, :rowNo, :externalRef, :recordType, :fullName, :firstName,"
            + " :middleName, :lastName, :gender, :dobDay, :dobMonth, :dobYear, :nationality, :sanctionsLists,"
            + " :aliasCount, :createdAt)";

    /** Aliases find their record by upload and row number, so no generated keys are needed. */
    private static final String INSERT_ALIAS =
        "INSERT INTO poc_record_alias (alias_id, record_id, seq_no, alias_type, full_name)"
            + " SELECT poc_alias_seq.NEXTVAL, r.record_id, :seqNo, :aliasType, :fullName"
            + " FROM poc_record r WHERE r.upload_id = :uploadId AND r.row_no = :rowNo";

    private static final String INSERT_REJECT =
        "INSERT INTO poc_reject (upload_id, row_no, external_ref, reason) VALUES (:uploadId, :rowNo, :externalRef, :reason)";

    private static final String RECORD_FILTER =
        " FROM poc_record WHERE upload_id = :uploadId"
            + " AND (:pattern IS NULL OR UPPER(full_name) LIKE :pattern ESCAPE '\\' OR UPPER(external_ref) LIKE :pattern ESCAPE '\\')";

    private static final String SELECT_RECORDS =
        "SELECT record_id, row_no, external_ref, record_type, full_name, gender, dob_day, dob_month, dob_year,"
            + " nationality, sanctions_lists, alias_count" + RECORD_FILTER
            + " ORDER BY row_no OFFSET :offset ROWS FETCH NEXT :size ROWS ONLY";

    private final NamedParameterJdbcTemplate jdbc;

    public RecordRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** Inserts a chunk of records and their aliases in two batch statements. */
    public void insertBatch(long uploadId, List<ParsedRecord> records) {
        if (records.isEmpty()) {
            return;
        }
        Timestamp now = Timestamp.from(Instant.now());
        SqlParameterSource[] recordParams = new SqlParameterSource[records.size()];
        List<SqlParameterSource> aliasParams = new ArrayList<>();
        for (int i = 0; i < records.size(); i++) {
            ParsedRecord r = records.get(i);
            recordParams[i] = new MapSqlParameterSource()
                .addValue("uploadId", uploadId)
                .addValue("rowNo", r.getRowNo())
                .addValue("externalRef", r.getExternalRef(), Types.VARCHAR)
                .addValue("recordType", r.getRecordType().name(), Types.VARCHAR)
                .addValue("fullName", Text.fit(r.getFullName(), 1000), Types.VARCHAR)
                .addValue("firstName", Text.fit(r.getFirstName(), 200), Types.VARCHAR)
                .addValue("middleName", Text.fit(r.getMiddleName(), 200), Types.VARCHAR)
                .addValue("lastName", Text.fit(r.getLastName(), 200), Types.VARCHAR)
                .addValue("gender", r.getGender(), Types.VARCHAR)
                .addValue("dobDay", r.getDobDay(), Types.INTEGER)
                .addValue("dobMonth", r.getDobMonth(), Types.INTEGER)
                .addValue("dobYear", r.getDobYear(), Types.INTEGER)
                .addValue("nationality", Text.fit(r.getNationality(), 100), Types.VARCHAR)
                .addValue("sanctionsLists", Text.fit(String.join(", ", r.getSanctionsLists()), 2000), Types.VARCHAR)
                .addValue("aliasCount", r.getAliases().size())
                .addValue("createdAt", now, Types.TIMESTAMP);
            int seq = 1;
            for (ParsedRecord.Alias alias : r.getAliases()) {
                aliasParams.add(new MapSqlParameterSource()
                    .addValue("uploadId", uploadId)
                    .addValue("rowNo", r.getRowNo())
                    .addValue("seqNo", seq++)
                    .addValue("aliasType", Text.fit(alias.getType(), 50), Types.VARCHAR)
                    .addValue("fullName", Text.fit(alias.getFullName(), 1000), Types.VARCHAR));
            }
        }
        jdbc.batchUpdate(INSERT_RECORD, recordParams);
        if (!aliasParams.isEmpty()) {
            jdbc.batchUpdate(INSERT_ALIAS, aliasParams.toArray(new SqlParameterSource[0]));
        }
    }

    public void insertRejects(long uploadId, List<RejectRow> rejects) {
        if (rejects.isEmpty()) {
            return;
        }
        SqlParameterSource[] params = new SqlParameterSource[rejects.size()];
        for (int i = 0; i < rejects.size(); i++) {
            RejectRow r = rejects.get(i);
            params[i] = new MapSqlParameterSource()
                .addValue("uploadId", uploadId)
                .addValue("rowNo", r.getRowNo())
                .addValue("externalRef", Text.fit(r.getExternalRef(), 100), Types.VARCHAR)
                .addValue("reason", Text.fit(r.getReason(), 500), Types.VARCHAR);
        }
        jdbc.batchUpdate(INSERT_REJECT, params);
    }

    /** Removes everything a failed upload had written, so a failure never leaves half a file. */
    public void deleteUpload(long uploadId) {
        MapSqlParameterSource p = new MapSqlParameterSource("uploadId", uploadId);
        jdbc.update("DELETE FROM poc_record_alias WHERE record_id IN (SELECT record_id FROM poc_record WHERE upload_id = :uploadId)", p);
        jdbc.update("DELETE FROM poc_record WHERE upload_id = :uploadId", p);
    }

    public long countRecords(long uploadId, String search) {
        Long count = jdbc.queryForObject("SELECT COUNT(*)" + RECORD_FILTER, filter(uploadId, search), Long.class);
        return count == null ? 0 : count;
    }

    public List<RecordView> findRecords(long uploadId, String search, int page, int size) {
        MapSqlParameterSource params = filter(uploadId, search)
            .addValue("offset", (long) page * size)
            .addValue("size", size);
        List<RecordView> rows = jdbc.query(SELECT_RECORDS, params, (rs, n) -> {
            RecordView v = new RecordView();
            v.setRecordId(rs.getLong("record_id"));
            v.setRowNo(rs.getLong("row_no"));
            v.setExternalRef(rs.getString("external_ref"));
            v.setRecordType(rs.getString("record_type"));
            v.setFullName(rs.getString("full_name"));
            v.setGender(rs.getString("gender"));
            v.setDateOfBirth(formatDate(intOrNull(rs.getObject("dob_day")), intOrNull(rs.getObject("dob_month")),
                intOrNull(rs.getObject("dob_year"))));
            v.setNationality(rs.getString("nationality"));
            v.setSanctionsLists(rs.getString("sanctions_lists"));
            return v;
        });
        attachAliases(rows);
        return rows;
    }

    public List<RejectRow> findRejects(long uploadId, int limit) {
        MapSqlParameterSource p = new MapSqlParameterSource("uploadId", uploadId).addValue("limit", limit);
        return jdbc.query("SELECT row_no, external_ref, reason FROM poc_reject WHERE upload_id = :uploadId"
                + " ORDER BY row_no FETCH FIRST :limit ROWS ONLY", p,
            (rs, n) -> new RejectRow(rs.getLong("row_no"), rs.getString("external_ref"), rs.getString("reason")));
    }

    private void attachAliases(List<RecordView> rows) {
        if (rows.isEmpty()) {
            return;
        }
        Map<Long, RecordView> byId = new LinkedHashMap<>();
        for (RecordView row : rows) {
            byId.put(row.getRecordId(), row);
        }
        Map<Long, List<String>> aliases = new HashMap<>();
        jdbc.query("SELECT record_id, full_name FROM poc_record_alias WHERE record_id IN (:ids) ORDER BY record_id, seq_no",
            new MapSqlParameterSource("ids", new ArrayList<>(byId.keySet())),
            rs -> {
                aliases.computeIfAbsent(rs.getLong("record_id"), k -> new ArrayList<>()).add(rs.getString("full_name"));
            });
        for (RecordView row : rows) {
            List<String> names = aliases.get(row.getRecordId());
            row.setAliases(names == null ? Collections.<String>emptyList() : names);
        }
    }

    private static MapSqlParameterSource filter(long uploadId, String search) {
        String pattern = null;
        if (search != null && !search.trim().isEmpty()) {
            String upper = search.trim().toUpperCase(java.util.Locale.ROOT);
            pattern = "%" + upper.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%";
        }
        return new MapSqlParameterSource("uploadId", uploadId).addValue("pattern", pattern, Types.VARCHAR);
    }

    private static Integer intOrNull(Object value) {
        return value == null ? null : ((Number) value).intValue();
    }

    /** 1965-03-12, 1965-03 or 1965, depending on which parts the provider gave. */
    static String formatDate(Integer day, Integer month, Integer year) {
        if (year == null) {
            return null;
        }
        if (month == null) {
            return String.valueOf(year);
        }
        if (day == null) {
            return String.format("%04d-%02d", year, month);
        }
        return String.format("%04d-%02d-%02d", year, month, day);
    }
}
