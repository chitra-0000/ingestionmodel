package com.listhub.poc.web;

import com.listhub.poc.upload.UploadException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import javax.validation.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.support.MissingServletRequestPartException;

/**
 * Turns errors into a small JSON body {status, message[, errorId]}. Messages say what to do;
 * internal details are only logged, with an error id the user can quote.
 */
@RestControllerAdvice
public class ApiErrorHandler {

    private static final Logger LOG = LoggerFactory.getLogger(ApiErrorHandler.class);

    @ExceptionHandler(UploadException.class)
    public ResponseEntity<Map<String, Object>> upload(UploadException e) {
        return body(HttpStatus.valueOf(e.getStatus()), e.getMessage(), null);
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<Map<String, Object>> tooLarge(MaxUploadSizeExceededException e) {
        return body(HttpStatus.PAYLOAD_TOO_LARGE, "The file is larger than the upload limit.", null);
    }

    @ExceptionHandler({ConstraintViolationException.class, MethodArgumentTypeMismatchException.class,
        MissingServletRequestParameterException.class, MissingServletRequestPartException.class})
    public ResponseEntity<Map<String, Object>> badRequest(Exception e) {
        return body(HttpStatus.BAD_REQUEST, "The request is not valid. Choose a file and try again.", null);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> unexpected(Exception e) {
        String errorId = UUID.randomUUID().toString().substring(0, 8);
        LOG.error("Unexpected error, errorId={}", errorId, e);
        return body(HttpStatus.INTERNAL_SERVER_ERROR,
            "Something went wrong on the server. Quote error id " + errorId + " when reporting it.", errorId);
    }

    private static ResponseEntity<Map<String, Object>> body(HttpStatus status, String message, String errorId) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("status", status.value());
        body.put("message", message);
        if (errorId != null) {
            body.put("errorId", errorId);
        }
        return ResponseEntity.status(status).body(body);
    }
}
