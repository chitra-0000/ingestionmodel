package com.listhub.poc.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * CSV header names for each record field, set in application.yml (poc.csv.columns.*).
 * Changing a provider's column names is a configuration change, not a code change.
 */
@ConfigurationProperties(prefix = "poc.csv.columns")
public class CsvColumnsProperties {

    private String externalRef = "external_id";
    private String recordType = "record_type";
    private String fullName = "full_name";
    private String firstName = "first_name";
    private String middleName = "middle_name";
    private String lastName = "last_name";
    private String gender = "gender";
    private String dateOfBirth = "date_of_birth";
    private String nationality = "nationality";
    private String sanctionsLists = "sanctions_lists";
    private String aliases = "aliases";
    /** Separator between several values inside one cell (aliases, sanctions lists). */
    private String multiValueSeparator = "|";

    public String getExternalRef() {
        return externalRef;
    }

    public void setExternalRef(String externalRef) {
        this.externalRef = externalRef;
    }

    public String getRecordType() {
        return recordType;
    }

    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getSanctionsLists() {
        return sanctionsLists;
    }

    public void setSanctionsLists(String sanctionsLists) {
        this.sanctionsLists = sanctionsLists;
    }

    public String getAliases() {
        return aliases;
    }

    public void setAliases(String aliases) {
        this.aliases = aliases;
    }

    public String getMultiValueSeparator() {
        return multiValueSeparator;
    }

    public void setMultiValueSeparator(String multiValueSeparator) {
        this.multiValueSeparator = multiValueSeparator;
    }
}
