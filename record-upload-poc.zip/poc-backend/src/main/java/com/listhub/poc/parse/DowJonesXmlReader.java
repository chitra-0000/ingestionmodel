package com.listhub.poc.parse;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.xml.stream.Location;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.springframework.stereotype.Component;

/**
 * Streams a Dow Jones sanctions XML file (PFA-style structure) record by record with StAX.
 *
 * <p>Read per {@code <Person>}, {@code <Entity>} or {@code <Vessel>}: the {@code id} attribute,
 * gender, the primary name and aliases from {@code NameDetails/Name/NameValue}, date of birth from
 * {@code DateDetails/Date[DateType=Date of Birth]/DateValue}, nationality from
 * {@code CountryDetails/Country[CountryType=Citizenship]/CountryValue@Code}, and sanctions list codes
 * from {@code SanctionsReferences/Reference}, translated with the file's {@code ReferenceName} list.
 * Element and attribute names are matched without regard to case.
 *
 * <p>Only one record is held in memory at a time. DTDs and external entities are refused (XXE).
 */
@Component
public class DowJonesXmlReader implements RecordReader {

    private final XMLInputFactory factory;

    public DowJonesXmlReader() {
        factory = XMLInputFactory.newInstance();
        factory.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
        factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
        factory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
    }

    @Override
    public void read(InputStream input, RecordSink sink) throws IOException {
        XMLStreamReader xml = null;
        try {
            xml = factory.createXMLStreamReader(input);
            new Parse(xml, sink).run();
        } catch (XMLStreamException e) {
            throw new FileFormatException("The XML file is not well-formed" + where(e.getLocation())
                + ". Check that it is a complete Dow Jones XML file.", e);
        } finally {
            closeQuietly(xml);
        }
    }

    private static String where(Location location) {
        return location == null || location.getLineNumber() < 0 ? "" : " (line " + location.getLineNumber() + ")";
    }

    private static void closeQuietly(XMLStreamReader xml) {
        if (xml != null) {
            try {
                xml.close();
            } catch (XMLStreamException ignored) {
                // nothing more to release
            }
        }
    }

    /** State of one pass over the file. */
    private static final class Parse {
        private final XMLStreamReader xml;
        private final RecordSink sink;
        private final Map<String, String> referenceNames = new HashMap<>();

        private long rowNo;
        private boolean sawRecordsRoot;
        private ParsedRecord record;
        private String recordError;
        private String nameType;
        private String dateType;
        private String countryType;
        private boolean inSanctionsReferences;
        private final Map<String, String> nameParts = new HashMap<>();

        Parse(XMLStreamReader xml, RecordSink sink) {
            this.xml = xml;
            this.sink = sink;
        }

        void run() throws XMLStreamException {
            while (xml.hasNext()) {
                int event = xml.next();
                if (event == XMLStreamConstants.DTD) {
                    throw new FileFormatException("DOCTYPE declarations are not allowed in uploaded XML files.");
                }
                if (event == XMLStreamConstants.START_ELEMENT) {
                    start(local());
                } else if (event == XMLStreamConstants.END_ELEMENT) {
                    end(local());
                }
            }
            if (!sawRecordsRoot) {
                throw new FileFormatException("No <Person>, <Entity> or <Vessel> records were found. "
                    + "Check that this is a Dow Jones sanctions XML file.");
            }
        }

        private String local() {
            return xml.getLocalName().toLowerCase(Locale.ROOT);
        }

        private String attr(String name) {
            for (int i = 0; i < xml.getAttributeCount(); i++) {
                if (xml.getAttributeLocalName(i).equalsIgnoreCase(name)) {
                    return Text.clean(xml.getAttributeValue(i));
                }
            }
            return null;
        }

        private void start(String name) throws XMLStreamException {
            if (record == null) {
                startOutsideRecord(name);
                return;
            }
            switch (name) {
                case "name":
                    nameType = attr("NameType");
                    break;
                case "namevalue":
                    nameParts.clear();
                    break;
                case "firstname":
                case "middlename":
                case "surname":
                case "entityname":
                case "singlestringname":
                case "titlehonorific":
                case "maidenname":
                case "suffix":
                    nameParts.put(name, xml.getElementText());
                    break;
                case "gender":
                case "gendervalue":
                    record.setGender(xml.getElementText());
                    break;
                case "date":
                    dateType = attr("DateType");
                    break;
                case "datevalue":
                    readDate();
                    break;
                case "country":
                    countryType = attr("CountryType");
                    break;
                case "countryvalue":
                    readCountry();
                    break;
                case "sanctionsreferences":
                    inSanctionsReferences = true;
                    break;
                case "reference":
                    if (inSanctionsReferences) {
                        String code = Text.clean(xml.getElementText());
                        if (code != null) {
                            String label = referenceNames.get(code);
                            record.addSanctionsList(label != null ? label : code);
                        }
                    }
                    break;
                default:
                    break;
            }
        }

        private void startOutsideRecord(String name) {
            if ("referencename".equals(name)) {
                String code = attr("code");
                String label = attr("name");
                if (code != null && label != null) {
                    referenceNames.put(code, label);
                }
                return;
            }
            RecordType type = recordTypeOf(name);
            if (type != null) {
                sawRecordsRoot = true;
                rowNo++;
                record = new ParsedRecord(rowNo);
                record.setRecordType(type);
                record.setExternalRef(attr("id"));
                recordError = null;
            }
        }

        private void end(String name) {
            if (record == null) {
                return;
            }
            switch (name) {
                case "namevalue":
                    applyName();
                    break;
                case "name":
                    nameType = null;
                    break;
                case "date":
                    dateType = null;
                    break;
                case "country":
                    countryType = null;
                    break;
                case "sanctionsreferences":
                    inSanctionsReferences = false;
                    break;
                default:
                    if (recordTypeOf(name) != null) {
                        finishRecord();
                    }
                    break;
            }
        }

        private void readDate() {
            if (dateType == null || !dateType.toLowerCase(Locale.ROOT).contains("birth") || record.getDobYear() != null) {
                return;
            }
            try {
                PartialDates.Parts parts = PartialDates.fromParts(attr("Day"), attr("Month"), attr("Year"));
                record.setDateOfBirth(parts.day, parts.month, parts.year);
            } catch (IllegalArgumentException e) {
                recordError = "Date of birth: " + e.getMessage();
            }
        }

        private void readCountry() {
            if (record.getNationality() != null || countryType == null) {
                return;
            }
            String type = countryType.toLowerCase(Locale.ROOT);
            if (type.contains("citizen") || type.contains("nationality")) {
                record.setNationality(attr("Code"));
            }
        }

        private void applyName() {
            String entity = Text.clean(nameParts.get("entityname"));
            String single = Text.clean(nameParts.get("singlestringname"));
            String first = nameParts.get("firstname");
            String middle = nameParts.get("middlename");
            String last = nameParts.get("surname");
            String full = entity != null ? entity
                : single != null ? single
                : Text.join(" ", first, middle, last, nameParts.get("suffix"));
            boolean primary = nameType == null || nameType.toLowerCase(Locale.ROOT).contains("primary");
            if (primary && record.getFullName() == null) {
                record.setFullName(full);
                record.setFirstName(first);
                record.setMiddleName(middle);
                record.setLastName(last);
            } else {
                record.addAlias(nameType, full);
            }
            nameParts.clear();
        }

        private void finishRecord() {
            if (recordError != null) {
                sink.reject(record.getRowNo(), record.getExternalRef(), recordError);
            } else {
                record.completeFullName();
                sink.accept(record);
            }
            record = null;
            nameType = null;
            dateType = null;
            countryType = null;
            inSanctionsReferences = false;
        }

        private static RecordType recordTypeOf(String elementName) {
            switch (elementName) {
                case "person":
                    return RecordType.PERSON;
                case "entity":
                    return RecordType.ENTITY;
                case "vessel":
                    return RecordType.VESSEL;
                default:
                    return null;
            }
        }
    }
}
