package com.listhub.poc.parse;

import java.util.StringJoiner;

/** Small text helpers shared by the readers. */
public final class Text {

    private Text() {
    }

    /** Trims, collapses inner spaces and turns empty text into {@code null}. */
    public static String clean(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.replaceAll("\\s+", " ").trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    /** Joins the non-empty parts with the separator; {@code null} when every part is empty. */
    public static String join(String separator, String... parts) {
        StringJoiner joiner = new StringJoiner(separator);
        for (String part : parts) {
            String p = clean(part);
            if (p != null) {
                joiner.add(p);
            }
        }
        return clean(joiner.toString());
    }

    /** Cuts text to the column size so a long provider value never breaks the load. */
    public static String fit(String value, int maxLength) {
        if (value == null || value.length() <= maxLength) {
            return value;
        }
        return value.substring(0, maxLength);
    }
}
