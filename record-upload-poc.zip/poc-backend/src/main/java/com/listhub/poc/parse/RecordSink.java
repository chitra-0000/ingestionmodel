package com.listhub.poc.parse;

/** Receives records one by one as a file is streamed, so a file is never held in memory. */
public interface RecordSink {

    /** A record that was read; it may still be rejected by validation. */
    void accept(ParsedRecord record);

    /** A row that could not be read at all (for example a bad date). */
    void reject(long rowNo, String externalRef, String reason);
}
