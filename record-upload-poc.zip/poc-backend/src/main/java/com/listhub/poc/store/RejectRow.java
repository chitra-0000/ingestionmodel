package com.listhub.poc.store;

/** A row of the file that was not loaded, and why. */
public class RejectRow {

    private final long rowNo;
    private final String externalRef;
    private final String reason;

    public RejectRow(long rowNo, String externalRef, String reason) {
        this.rowNo = rowNo;
        this.externalRef = externalRef;
        this.reason = reason;
    }

    public long getRowNo() {
        return rowNo;
    }

    public String getExternalRef() {
        return externalRef;
    }

    public String getReason() {
        return reason;
    }
}
