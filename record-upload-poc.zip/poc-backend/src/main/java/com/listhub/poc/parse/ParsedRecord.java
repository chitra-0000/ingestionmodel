package com.listhub.poc.parse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * One record read from a provider file, in the common shape used for every format.
 * Built by a reader, checked by {@link RecordValidator}, then written to the database.
 */
public final class ParsedRecord {

    private final long rowNo;
    private String externalRef;
    private RecordType recordType = RecordType.UNKNOWN;
    private String fullName;
    private String firstName;
    private String middleName;
    private String lastName;
    private String gender;
    private Integer dobDay;
    private Integer dobMonth;
    private Integer dobYear;
    private String nationality;
    private final List<String> sanctionsLists = new ArrayList<>();
    private final List<Alias> aliases = new ArrayList<>();

    public ParsedRecord(long rowNo) {
        this.rowNo = rowNo;
    }

    public long getRowNo() {
        return rowNo;
    }

    public String getExternalRef() {
        return externalRef;
    }

    public void setExternalRef(String externalRef) {
        this.externalRef = Text.clean(externalRef);
    }

    public RecordType getRecordType() {
        return recordType;
    }

    public void setRecordType(RecordType recordType) {
        this.recordType = recordType == null ? RecordType.UNKNOWN : recordType;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = Text.clean(fullName);
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = Text.clean(firstName);
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = Text.clean(middleName);
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = Text.clean(lastName);
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = Gender.normalise(gender);
    }

    public Integer getDobDay() {
        return dobDay;
    }

    public Integer getDobMonth() {
        return dobMonth;
    }

    public Integer getDobYear() {
        return dobYear;
    }

    public void setDateOfBirth(Integer day, Integer month, Integer year) {
        this.dobDay = day;
        this.dobMonth = month;
        this.dobYear = year;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = Text.clean(nationality);
    }

    public List<String> getSanctionsLists() {
        return Collections.unmodifiableList(sanctionsLists);
    }

    public void addSanctionsList(String list) {
        String value = Text.clean(list);
        if (value != null && !sanctionsLists.contains(value)) {
            sanctionsLists.add(value);
        }
    }

    public List<Alias> getAliases() {
        return Collections.unmodifiableList(aliases);
    }

    public void addAlias(String type, String name) {
        String value = Text.clean(name);
        if (value != null) {
            aliases.add(new Alias(Text.clean(type), value));
        }
    }

    /** Builds the full name from its parts when the file gave only parts. */
    public void completeFullName() {
        if (fullName == null) {
            setFullName(Text.join(" ", firstName, middleName, lastName));
        }
    }

    /** An alternative name of the record. */
    public static final class Alias {
        private final String type;
        private final String fullName;

        public Alias(String type, String fullName) {
            this.type = type;
            this.fullName = fullName;
        }

        public String getType() {
            return type;
        }

        public String getFullName() {
            return fullName;
        }
    }
}
