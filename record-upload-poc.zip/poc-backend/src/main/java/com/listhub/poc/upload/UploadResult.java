package com.listhub.poc.upload;

import com.listhub.poc.store.RejectRow;
import com.listhub.poc.store.UploadSummary;
import java.util.ArrayList;
import java.util.List;

/** What the page shows right after an upload: the summary and the first rejected rows. */
public class UploadResult {

    private final UploadSummary upload;
    private final List<RejectRow> rejects;

    public UploadResult(UploadSummary upload, List<RejectRow> rejects) {
        this.upload = upload;
        this.rejects = new ArrayList<>(rejects);
    }

    public UploadSummary getUpload() {
        return upload;
    }

    public List<RejectRow> getRejects() {
        return rejects;
    }
}
