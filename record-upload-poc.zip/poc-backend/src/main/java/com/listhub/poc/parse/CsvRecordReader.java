package com.listhub.poc.parse;

import com.listhub.poc.config.CsvColumnsProperties;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Pattern;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Component;

/**
 * Streams a CSV file with a header row. Column names come from configuration
 * ({@link CsvColumnsProperties}) and are matched without regard to case. The delimiter
 * (comma or semicolon) is detected from the header line. Only one row is in memory at a time.
 */
@Component
public class CsvRecordReader implements RecordReader {

    private static final int MAX_HEADER_LENGTH = 10_000;

    private final CsvColumnsProperties columns;

    public CsvRecordReader(CsvColumnsProperties columns) {
        this.columns = columns;
    }

    @Override
    public void read(InputStream input, RecordSink sink) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8));
        reader.mark(MAX_HEADER_LENGTH);
        String headerLine = reader.readLine();
        if (headerLine == null || headerLine.trim().isEmpty()) {
            throw new FileFormatException("The CSV file is empty. The first line must hold the column names.");
        }
        reader.reset();
        char delimiter = countOf(headerLine, ';') > countOf(headerLine, ',') ? ';' : ',';

        CSVFormat format = CSVFormat.DEFAULT.builder()
            .setDelimiter(delimiter)
            .setHeader()
            .setSkipHeaderRecord(true)
            .setIgnoreEmptyLines(true)
            .setTrim(true)
            .build();
        try (CSVParser parser = new CSVParser(reader, format)) {
            Map<String, String> headerByLowerName = headerIndex(parser.getHeaderNames());
            checkRequiredColumns(headerByLowerName);
            for (CSVRecord row : parser) {
                readRow(row, headerByLowerName, sink);
            }
        } catch (UncheckedIOException e) {
            throw new FileFormatException("The CSV file could not be read near line "
                + "(check quotes and line endings): " + Text.fit(e.getMessage(), 200), e);
        }
    }

    private void readRow(CSVRecord row, Map<String, String> header, RecordSink sink) {
        long rowNo = row.getRecordNumber();
        ParsedRecord record = new ParsedRecord(rowNo);
        try {
            record.setExternalRef(cell(row, header, columns.getExternalRef()));
            record.setRecordType(RecordType.fromText(cell(row, header, columns.getRecordType())));
            record.setFullName(cell(row, header, columns.getFullName()));
            record.setFirstName(cell(row, header, columns.getFirstName()));
            record.setMiddleName(cell(row, header, columns.getMiddleName()));
            record.setLastName(cell(row, header, columns.getLastName()));
            record.setGender(cell(row, header, columns.getGender()));
            record.setNationality(cell(row, header, columns.getNationality()));
            PartialDates.Parts dob = PartialDates.fromText(cell(row, header, columns.getDateOfBirth()));
            record.setDateOfBirth(dob.day, dob.month, dob.year);
            for (String list : split(cell(row, header, columns.getSanctionsLists()))) {
                record.addSanctionsList(list);
            }
            for (String alias : split(cell(row, header, columns.getAliases()))) {
                record.addAlias("Alias", alias);
            }
            record.completeFullName();
            sink.accept(record);
        } catch (IllegalArgumentException e) {
            sink.reject(rowNo, record.getExternalRef(), e.getMessage());
        }
    }

    private void checkRequiredColumns(Map<String, String> header) {
        List<String> missing = new ArrayList<>();
        if (!header.containsKey(lower(columns.getExternalRef()))) {
            missing.add(columns.getExternalRef());
        }
        boolean hasName = header.containsKey(lower(columns.getFullName()))
            || header.containsKey(lower(columns.getLastName()));
        if (!hasName) {
            missing.add(columns.getFullName() + " (or " + columns.getLastName() + ")");
        }
        if (!missing.isEmpty()) {
            throw new FileFormatException("The CSV file is missing required column(s): " + String.join(", ", missing)
                + ". Expected columns include: " + columns.getExternalRef() + ", " + columns.getFullName() + ", "
                + columns.getRecordType() + ", " + columns.getDateOfBirth() + ", " + columns.getNationality() + ".");
        }
    }

    private static Map<String, String> headerIndex(List<String> names) {
        Map<String, String> index = new TreeMap<>();
        for (String name : names) {
            if (name != null) {
                index.put(lower(name), name);
            }
        }
        return index;
    }

    private static String cell(CSVRecord row, Map<String, String> header, String column) {
        String actual = header.get(lower(column));
        if (actual == null || !row.isSet(actual)) {
            return null;
        }
        return row.get(actual);
    }

    private List<String> split(String value) {
        List<String> parts = new ArrayList<>();
        String v = Text.clean(value);
        if (v == null) {
            return parts;
        }
        for (String part : v.split(Pattern.quote(columns.getMultiValueSeparator()))) {
            String p = Text.clean(part);
            if (p != null) {
                parts.add(p);
            }
        }
        return parts;
    }

    private static String lower(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
    }

    private static int countOf(String text, char c) {
        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == c) {
                count++;
            }
        }
        return count;
    }
}
