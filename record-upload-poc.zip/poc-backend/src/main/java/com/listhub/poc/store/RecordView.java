package com.listhub.poc.store;

import java.util.ArrayList;
import java.util.List;

/** A loaded record as shown on the page. */
public class RecordView {

    private long recordId;
    private long rowNo;
    private String externalRef;
    private String recordType;
    private String fullName;
    private String gender;
    private String dateOfBirth;
    private String nationality;
    private String sanctionsLists;
    private List<String> aliases = new ArrayList<>();

    public long getRecordId() {
        return recordId;
    }

    public void setRecordId(long recordId) {
        this.recordId = recordId;
    }

    public long getRowNo() {
        return rowNo;
    }

    public void setRowNo(long rowNo) {
        this.rowNo = rowNo;
    }

    public String getExternalRef() {
        return externalRef;
    }

    public void setExternalRef(String externalRef) {
        this.externalRef = externalRef;
    }

    public String getRecordType() {
        return recordType;
    }

    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getSanctionsLists() {
        return sanctionsLists;
    }

    public void setSanctionsLists(String sanctionsLists) {
        this.sanctionsLists = sanctionsLists;
    }

    public List<String> getAliases() {
        return aliases;
    }

    public void setAliases(List<String> aliases) {
        this.aliases = new ArrayList<>(aliases);
    }
}
