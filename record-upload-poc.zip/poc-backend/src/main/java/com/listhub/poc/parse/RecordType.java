package com.listhub.poc.parse;

import java.util.Locale;

/** Kind of listed party. */
public enum RecordType {
    PERSON,
    ENTITY,
    VESSEL,
    UNKNOWN;

    /** Accepts P, PERSON, INDIVIDUAL, E, ENTITY, ORGANISATION, V, VESSEL (any case). */
    public static RecordType fromText(String value) {
        String v = Text.clean(value);
        if (v == null) {
            return UNKNOWN;
        }
        switch (v.toUpperCase(Locale.ROOT)) {
            case "P":
            case "PERSON":
            case "INDIVIDUAL":
                return PERSON;
            case "E":
            case "ENTITY":
            case "ORGANISATION":
            case "ORGANIZATION":
            case "COMPANY":
                return ENTITY;
            case "V":
            case "VESSEL":
                return VESSEL;
            default:
                return UNKNOWN;
        }
    }
}
