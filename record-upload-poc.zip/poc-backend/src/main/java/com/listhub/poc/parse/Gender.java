package com.listhub.poc.parse;

import java.util.Locale;

/** Normalises provider gender values to Male, Female or the provider's own word. */
final class Gender {

    private Gender() {
    }

    static String normalise(String value) {
        String v = Text.clean(value);
        if (v == null) {
            return null;
        }
        String upper = v.toUpperCase(Locale.ROOT);
        if ("M".equals(upper) || "MALE".equals(upper)) {
            return "Male";
        }
        if ("F".equals(upper) || "FEMALE".equals(upper)) {
            return "Female";
        }
        return Text.fit(v, 10);
    }
}
