package com.listhub.poc.upload;

import java.util.Locale;

/** Supported upload formats, recognised by file extension. */
public enum FileFormat {
    XML,
    CSV;

    /** @return the format for the file name, or {@code null} when the extension is not supported */
    public static FileFormat fromFileName(String fileName) {
        if (fileName == null) {
            return null;
        }
        String lower = fileName.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".xml")) {
            return XML;
        }
        if (lower.endsWith(".csv")) {
            return CSV;
        }
        return null;
    }
}
