package com.listhub.poc.upload;

import com.listhub.poc.store.RecordRepository;
import com.listhub.poc.store.RecordView;
import com.listhub.poc.store.RejectRow;
import com.listhub.poc.store.UploadRepository;
import com.listhub.poc.store.UploadSummary;
import java.util.List;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@Validated
@RequestMapping("/api/uploads")
public class UploadController {

    private final UploadService service;
    private final UploadRepository uploads;
    private final RecordRepository records;

    public UploadController(UploadService service, UploadRepository uploads, RecordRepository records) {
        this.service = service;
        this.uploads = uploads;
        this.records = records;
    }

    /** Uploads one Dow Jones XML or CSV file and loads its records. */
    @PostMapping(consumes = "multipart/form-data")
    @ResponseStatus(HttpStatus.CREATED)
    public UploadResult upload(@RequestPart("file") MultipartFile file) {
        return service.upload(file);
    }

    /** Most recent uploads first. */
    @GetMapping
    public List<UploadSummary> recent(@RequestParam(defaultValue = "20") @Min(1) @Max(100) int limit) {
        return uploads.findRecent(limit);
    }

    @GetMapping("/{uploadId}")
    public UploadSummary one(@PathVariable long uploadId) {
        return existing(uploadId);
    }

    /** Records loaded from one upload, in file order, with an optional name or id search. */
    @GetMapping("/{uploadId}/records")
    public RecordPage records(@PathVariable long uploadId,
                              @RequestParam(required = false) @Size(max = 100) String search,
                              @RequestParam(defaultValue = "0") @Min(0) int page,
                              @RequestParam(defaultValue = "25") @Min(1) @Max(200) int size) {
        existing(uploadId);
        long total = records.countRecords(uploadId, search);
        List<RecordView> items = total == 0 ? java.util.Collections.<RecordView>emptyList()
            : records.findRecords(uploadId, search, page, size);
        return new RecordPage(items, total, page, size);
    }

    @GetMapping("/{uploadId}/rejects")
    public List<RejectRow> rejects(@PathVariable long uploadId,
                                   @RequestParam(defaultValue = "200") @Min(1) @Max(1000) int limit) {
        existing(uploadId);
        return records.findRejects(uploadId, limit);
    }

    private UploadSummary existing(long uploadId) {
        UploadSummary summary = uploads.findById(uploadId);
        if (summary == null) {
            throw new UploadException(404, "Upload #" + uploadId + " does not exist.");
        }
        return summary;
    }
}
