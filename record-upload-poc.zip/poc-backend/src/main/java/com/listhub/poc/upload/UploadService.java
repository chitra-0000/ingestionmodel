package com.listhub.poc.upload;

import com.listhub.poc.parse.CsvRecordReader;
import com.listhub.poc.parse.DowJonesXmlReader;
import com.listhub.poc.parse.FileFormatException;
import com.listhub.poc.parse.ParsedRecord;
import com.listhub.poc.parse.RecordReader;
import com.listhub.poc.parse.RecordSink;
import com.listhub.poc.parse.RecordValidator;
import com.listhub.poc.store.RecordRepository;
import com.listhub.poc.store.RejectRow;
import com.listhub.poc.store.UploadRepository;
import com.listhub.poc.store.UploadSummary;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.multipart.MultipartFile;

/**
 * Loads one uploaded file: checks it, refuses a file already loaded, streams it through the
 * reader for its format, and writes records in batches. Memory use stays at one batch of records
 * whatever the file size. A file that fails part-way leaves no records behind.
 */
@Service
public class UploadService {

    private static final Logger LOG = LoggerFactory.getLogger(UploadService.class);
    private static final int MAX_REJECTS_STORED = 10_000;
    private static final int REJECTS_RETURNED = 50;

    private final DowJonesXmlReader xmlReader;
    private final CsvRecordReader csvReader;
    private final RecordValidator validator;
    private final UploadRepository uploads;
    private final RecordRepository records;
    private final TransactionTemplate transactions;
    private final int batchSize;

    public UploadService(DowJonesXmlReader xmlReader, CsvRecordReader csvReader, RecordValidator validator,
                         UploadRepository uploads, RecordRepository records, TransactionTemplate transactions,
                         @Value("${poc.upload.batch-size:500}") int batchSize) {
        this.xmlReader = xmlReader;
        this.csvReader = csvReader;
        this.validator = validator;
        this.uploads = uploads;
        this.records = records;
        this.transactions = transactions;
        this.batchSize = batchSize;
    }

    public UploadResult upload(MultipartFile file) {
        String fileName = safeFileName(file.getOriginalFilename());
        FileFormat format = FileFormat.fromFileName(fileName);
        if (format == null) {
            throw new UploadException(400, "Only .xml (Dow Jones) and .csv files can be uploaded.");
        }
        if (file.isEmpty()) {
            throw new UploadException(400, "The file is empty.");
        }
        String sha256 = sha256Of(file);
        UploadSummary earlier = uploads.findCompletedBySha256(sha256);
        if (earlier != null) {
            throw new UploadException(409, "This file was already loaded as upload #" + earlier.getUploadId()
                + " (" + earlier.getFileName() + "). The same content is never loaded twice.");
        }

        long uploadId = uploads.nextId();
        uploads.insertProcessing(uploadId, fileName, format.name(), sha256, file.getSize());
        LoadingSink sink = new LoadingSink(uploadId);
        RecordReader reader = format == FileFormat.XML ? xmlReader : csvReader;
        try (InputStream in = new BufferedInputStream(file.getInputStream())) {
            reader.read(in, sink);
            sink.flush();
            uploads.finish(uploadId, "COMPLETED", sink.read, sink.loaded, sink.rejected, completedMessage(sink));
        } catch (FileFormatException e) {
            fail(uploadId, sink, e.getMessage());
        } catch (IOException | IllegalStateException e) {
            LOG.warn("Upload {} could not be read: {}", uploadId, e.getClass().getSimpleName());
            fail(uploadId, sink, "The file could not be read. Check that it is a complete " + format.name() + " file.");
        } catch (DataAccessException e) {
            LOG.error("Upload {} failed while writing to the database", uploadId, e);
            fail(uploadId, sink, "The records could not be saved to the database. Try again later.");
        }
        return new UploadResult(uploads.findById(uploadId), records.findRejects(uploadId, REJECTS_RETURNED));
    }

    private void fail(long uploadId, LoadingSink sink, String message) {
        transactions.execute(status -> {
            records.deleteUpload(uploadId);
            return null;
        });
        uploads.finish(uploadId, "FAILED", sink.read, 0, sink.rejected, message);
    }

    private static String completedMessage(LoadingSink sink) {
        if (sink.rejected == 0) {
            return "All " + sink.loaded + " records were loaded.";
        }
        return sink.loaded + " records loaded, " + sink.rejected + " rejected (see the reasons below).";
    }

    /** Keeps the file's own name only: no folders, no control characters, at most 255 characters. */
    static String safeFileName(String original) {
        if (original == null) {
            return "upload";
        }
        String name = original.replace('\\', '/');
        name = name.substring(name.lastIndexOf('/') + 1);
        name = name.replaceAll("[\\p{Cntrl}]", "").trim();
        if (name.isEmpty()) {
            return "upload";
        }
        return name.length() > 255 ? name.substring(name.length() - 255) : name;
    }

    private static String sha256Of(MultipartFile file) {
        try (InputStream in = new DigestInputStream(new BufferedInputStream(file.getInputStream()), sha256())) {
            byte[] buffer = new byte[64 * 1024];
            while (in.read(buffer) != -1) {
                // reading feeds the digest
            }
            byte[] hash = ((DigestInputStream) in).getMessageDigest().digest();
            StringBuilder hex = new StringBuilder(hash.length * 2);
            for (byte b : hash) {
                hex.append(String.format(Locale.ROOT, "%02x", b));
            }
            return hex.toString();
        } catch (IOException e) {
            throw new UploadException(400, "The uploaded file could not be read.");
        }
    }

    private static MessageDigest sha256() {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is not available", e);
        }
    }

    /** Collects records into batches and writes each batch in its own transaction. */
    private final class LoadingSink implements RecordSink {
        private final long uploadId;
        private final List<ParsedRecord> batch = new ArrayList<>(batchSize);
        private final List<RejectRow> rejectBatch = new ArrayList<>();
        private long read;
        private long loaded;
        private long rejected;

        LoadingSink(long uploadId) {
            this.uploadId = uploadId;
        }

        @Override
        public void accept(ParsedRecord record) {
            read++;
            String problem = validator.problemWith(record);
            if (problem != null) {
                addReject(record.getRowNo(), record.getExternalRef(), problem);
                return;
            }
            batch.add(record);
            if (batch.size() >= batchSize) {
                flush();
            }
        }

        @Override
        public void reject(long rowNo, String externalRef, String reason) {
            read++;
            addReject(rowNo, externalRef, reason);
        }

        private void addReject(long rowNo, String externalRef, String reason) {
            rejected++;
            if (rejected <= MAX_REJECTS_STORED) {
                rejectBatch.add(new RejectRow(rowNo, externalRef, reason));
            }
            if (rejectBatch.size() >= batchSize) {
                flush();
            }
        }

        void flush() {
            if (batch.isEmpty() && rejectBatch.isEmpty()) {
                return;
            }
            final List<ParsedRecord> toWrite = new ArrayList<>(batch);
            final List<RejectRow> rejectsToWrite = new ArrayList<>(rejectBatch);
            transactions.execute(status -> {
                records.insertBatch(uploadId, toWrite);
                records.insertRejects(uploadId, rejectsToWrite);
                return null;
            });
            loaded += toWrite.size();
            batch.clear();
            rejectBatch.clear();
        }
    }
}
