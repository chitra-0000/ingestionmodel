package com.listhub.poc.store;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.Instant;
import java.util.List;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

/** Upload history: one row per file. */
@Repository
public class UploadRepository {

    private static final String COLUMNS = "upload_id, file_name, file_format, file_size_bytes, status, records_read,"
        + " records_loaded, records_rejected, message, started_at, ended_at";

    private final NamedParameterJdbcTemplate jdbc;

    public UploadRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public long nextId() {
        Long id = jdbc.getJdbcTemplate().queryForObject("SELECT poc_upload_seq.NEXTVAL FROM dual", Long.class);
        if (id == null) {
            throw new IllegalStateException("Sequence poc_upload_seq returned no value");
        }
        return id;
    }

    public void insertProcessing(long uploadId, String fileName, String format, String sha256, long size) {
        jdbc.update("INSERT INTO poc_upload (upload_id, file_name, file_format, file_sha256, file_size_bytes, status, started_at)"
                + " VALUES (:id, :fileName, :format, :sha256, :size, 'PROCESSING', :startedAt)",
            new MapSqlParameterSource("id", uploadId)
                .addValue("fileName", fileName, Types.VARCHAR)
                .addValue("format", format, Types.VARCHAR)
                .addValue("sha256", sha256, Types.VARCHAR)
                .addValue("size", size)
                .addValue("startedAt", Timestamp.from(Instant.now()), Types.TIMESTAMP));
    }

    public void finish(long uploadId, String status, long read, long loaded, long rejected, String message) {
        jdbc.update("UPDATE poc_upload SET status = :status, records_read = :read, records_loaded = :loaded,"
                + " records_rejected = :rejected, message = :message, ended_at = :endedAt WHERE upload_id = :id",
            new MapSqlParameterSource("id", uploadId)
                .addValue("status", status, Types.VARCHAR)
                .addValue("read", read)
                .addValue("loaded", loaded)
                .addValue("rejected", rejected)
                .addValue("message", message, Types.VARCHAR)
                .addValue("endedAt", Timestamp.from(Instant.now()), Types.TIMESTAMP));
    }

    /** The earlier successful upload of the same file content, if any. */
    public UploadSummary findCompletedBySha256(String sha256) {
        List<UploadSummary> found = jdbc.query("SELECT " + COLUMNS + " FROM poc_upload"
                + " WHERE file_sha256 = :sha256 AND status = 'COMPLETED' ORDER BY upload_id FETCH FIRST 1 ROWS ONLY",
            new MapSqlParameterSource("sha256", sha256), UploadRepository::map);
        return found.isEmpty() ? null : found.get(0);
    }

    public UploadSummary findById(long uploadId) {
        List<UploadSummary> found = jdbc.query("SELECT " + COLUMNS + " FROM poc_upload WHERE upload_id = :id",
            new MapSqlParameterSource("id", uploadId), UploadRepository::map);
        return found.isEmpty() ? null : found.get(0);
    }

    public List<UploadSummary> findRecent(int limit) {
        return jdbc.query("SELECT " + COLUMNS + " FROM poc_upload ORDER BY upload_id DESC FETCH FIRST :limit ROWS ONLY",
            new MapSqlParameterSource("limit", limit), UploadRepository::map);
    }

    private static UploadSummary map(ResultSet rs, int rowNum) throws SQLException {
        UploadSummary s = new UploadSummary();
        s.setUploadId(rs.getLong("upload_id"));
        s.setFileName(rs.getString("file_name"));
        s.setFormat(rs.getString("file_format"));
        s.setFileSizeBytes(rs.getLong("file_size_bytes"));
        s.setStatus(rs.getString("status"));
        s.setRecordsRead(rs.getLong("records_read"));
        s.setRecordsLoaded(rs.getLong("records_loaded"));
        s.setRecordsRejected(rs.getLong("records_rejected"));
        s.setMessage(rs.getString("message"));
        Timestamp started = rs.getTimestamp("started_at");
        Timestamp ended = rs.getTimestamp("ended_at");
        s.setStartedAt(started == null ? null : started.toInstant());
        s.setEndedAt(ended == null ? null : ended.toInstant());
        if (started != null && ended != null) {
            s.setDurationMs(ended.getTime() - started.getTime());
        }
        return s;
    }
}
