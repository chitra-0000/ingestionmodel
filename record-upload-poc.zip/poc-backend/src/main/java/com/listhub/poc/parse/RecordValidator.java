package com.listhub.poc.parse;

import org.springframework.stereotype.Component;

/** Checks that a record has what the database needs; returns the reason when it does not. */
@Component
public class RecordValidator {

    /** @return {@code null} when the record is valid, otherwise a reason the user can act on */
    public String problemWith(ParsedRecord record) {
        if (record.getExternalRef() == null) {
            return "Missing external id";
        }
        if (record.getExternalRef().length() > 100) {
            return "External id is longer than 100 characters";
        }
        if (record.getFullName() == null) {
            return "Missing name";
        }
        return null;
    }
}
