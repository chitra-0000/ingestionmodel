package com.listhub.poc.parse;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads dates that may be partial (year only, or month and year), as sanctions providers send them.
 * Missing parts stay {@code null}; nothing is invented.
 */
public final class PartialDates {

    private static final String[] MONTHS = {
        "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};

    private static final Pattern ISO = Pattern.compile("^(\\d{4})(?:-(\\d{1,2})(?:-(\\d{1,2}))?)?$");
    private static final Pattern DAY_FIRST = Pattern.compile("^(\\d{1,2})[/.](\\d{1,2})[/.](\\d{4})$");

    private PartialDates() {
    }

    /** Day, month, year; each may be {@code null}. */
    public static final class Parts {
        public final Integer day;
        public final Integer month;
        public final Integer year;

        Parts(Integer day, Integer month, Integer year) {
            this.day = day;
            this.month = month;
            this.year = year;
        }

        public boolean isEmpty() {
            return day == null && month == null && year == null;
        }
    }

    /** From separate attributes (Dow Jones: Day, Month as number or name, Year). */
    public static Parts fromParts(String day, String month, String year) {
        return check(toInt(day), monthNumber(month), toInt(year));
    }

    /** From one text: 1965, 1965-03, 1965-03-12, 12/03/1965 or 12.03.1965. */
    public static Parts fromText(String value) {
        String v = Text.clean(value);
        if (v == null) {
            return new Parts(null, null, null);
        }
        Matcher iso = ISO.matcher(v);
        if (iso.matches()) {
            return check(toInt(iso.group(3)), toInt(iso.group(2)), toInt(iso.group(1)));
        }
        Matcher dayFirst = DAY_FIRST.matcher(v);
        if (dayFirst.matches()) {
            return check(toInt(dayFirst.group(1)), toInt(dayFirst.group(2)), toInt(dayFirst.group(3)));
        }
        throw new IllegalArgumentException("Date '" + Text.fit(v, 20) + "' is not in a supported format (yyyy, yyyy-MM, yyyy-MM-dd, dd/MM/yyyy)");
    }

    private static Parts check(Integer day, Integer month, Integer year) {
        if (day != null && (day < 1 || day > 31)) {
            throw new IllegalArgumentException("Day " + day + " is not between 1 and 31");
        }
        if (month != null && (month < 1 || month > 12)) {
            throw new IllegalArgumentException("Month " + month + " is not between 1 and 12");
        }
        if (year != null && (year < 1800 || year > 2100)) {
            throw new IllegalArgumentException("Year " + year + " is not between 1800 and 2100");
        }
        return new Parts(day, month, year);
    }

    private static Integer monthNumber(String month) {
        String m = Text.clean(month);
        if (m == null) {
            return null;
        }
        if (m.chars().allMatch(Character::isDigit)) {
            return toInt(m);
        }
        String prefix = m.length() >= 3 ? m.substring(0, 3).toUpperCase(Locale.ROOT) : m.toUpperCase(Locale.ROOT);
        for (int i = 0; i < MONTHS.length; i++) {
            if (MONTHS[i].equals(prefix)) {
                return i + 1;
            }
        }
        throw new IllegalArgumentException("Month '" + Text.fit(m, 12) + "' is not recognised");
    }

    private static Integer toInt(String value) {
        String v = Text.clean(value);
        if (v == null) {
            return null;
        }
        try {
            return Integer.valueOf(v);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("'" + Text.fit(v, 12) + "' is not a number", e);
        }
    }
}
