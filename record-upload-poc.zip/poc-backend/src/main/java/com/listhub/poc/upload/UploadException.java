package com.listhub.poc.upload;

/** An upload the user can fix (wrong type, empty, duplicate). The message is safe to show. */
public class UploadException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final int status;

    public UploadException(int status, String message) {
        super(message);
        this.status = status;
    }

    public int getStatus() {
        return status;
    }
}
