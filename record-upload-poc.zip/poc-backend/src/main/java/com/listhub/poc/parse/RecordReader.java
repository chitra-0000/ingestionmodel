package com.listhub.poc.parse;

import java.io.IOException;
import java.io.InputStream;

/** Streams one file format into common records. One implementation per format. */
public interface RecordReader {

    /**
     * Reads the whole stream, handing each record or rejected row to the sink.
     *
     * @throws FileFormatException when the file as a whole cannot be read (for example malformed XML)
     */
    void read(InputStream input, RecordSink sink) throws IOException;
}
