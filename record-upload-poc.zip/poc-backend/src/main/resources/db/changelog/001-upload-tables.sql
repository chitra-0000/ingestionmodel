--liquibase formatted sql

-- Tables for the record upload POC. Written for Oracle 19; the same script also runs on
-- H2 in Oracle mode (demo profile and tests). Sequences instead of identity columns.

--changeset poc:001-sequences
CREATE SEQUENCE poc_upload_seq START WITH 1 INCREMENT BY 1 CACHE 20;
CREATE SEQUENCE poc_record_seq START WITH 1 INCREMENT BY 1 CACHE 1000;
CREATE SEQUENCE poc_alias_seq START WITH 1 INCREMENT BY 1 CACHE 1000;
--rollback DROP SEQUENCE poc_alias_seq; DROP SEQUENCE poc_record_seq; DROP SEQUENCE poc_upload_seq;

--changeset poc:001-upload
-- One row per uploaded file.
CREATE TABLE poc_upload (
    upload_id         NUMBER(19)           NOT NULL,
    file_name         VARCHAR2(255 CHAR)   NOT NULL,
    file_format       VARCHAR2(10 CHAR)    NOT NULL,
    file_sha256       VARCHAR2(64 CHAR)    NOT NULL,
    file_size_bytes   NUMBER(19)           NOT NULL,
    status            VARCHAR2(12 CHAR)    NOT NULL,
    records_read      NUMBER(12)           DEFAULT 0 NOT NULL,
    records_loaded    NUMBER(12)           DEFAULT 0 NOT NULL,
    records_rejected  NUMBER(12)           DEFAULT 0 NOT NULL,
    message           VARCHAR2(1000 CHAR),
    started_at        TIMESTAMP            NOT NULL,
    ended_at          TIMESTAMP,
    CONSTRAINT pk_poc_upload PRIMARY KEY (upload_id),
    CONSTRAINT ck_poc_upload_status CHECK (status IN ('PROCESSING', 'COMPLETED', 'FAILED')),
    CONSTRAINT ck_poc_upload_format CHECK (file_format IN ('XML', 'CSV'))
);
CREATE INDEX ix_poc_upload_sha256 ON poc_upload (file_sha256, status);
--rollback DROP TABLE poc_upload;

--changeset poc:001-record
-- One row per record loaded from a file; partial dates of birth kept as day, month, year.
CREATE TABLE poc_record (
    record_id        NUMBER(19)           NOT NULL,
    upload_id        NUMBER(19)           NOT NULL,
    row_no           NUMBER(12)           NOT NULL,
    external_ref     VARCHAR2(100 CHAR)   NOT NULL,
    record_type      VARCHAR2(10 CHAR)    NOT NULL,
    full_name        VARCHAR2(1000 CHAR)  NOT NULL,
    first_name       VARCHAR2(200 CHAR),
    middle_name      VARCHAR2(200 CHAR),
    last_name        VARCHAR2(200 CHAR),
    gender           VARCHAR2(10 CHAR),
    dob_day          NUMBER(2),
    dob_month        NUMBER(2),
    dob_year         NUMBER(4),
    nationality      VARCHAR2(100 CHAR),
    sanctions_lists  VARCHAR2(2000 CHAR),
    alias_count      NUMBER(5)            DEFAULT 0 NOT NULL,
    created_at       TIMESTAMP            NOT NULL,
    CONSTRAINT pk_poc_record PRIMARY KEY (record_id),
    CONSTRAINT fk_poc_record_upload FOREIGN KEY (upload_id) REFERENCES poc_upload (upload_id),
    CONSTRAINT ck_poc_record_type CHECK (record_type IN ('PERSON', 'ENTITY', 'VESSEL', 'UNKNOWN'))
);
CREATE UNIQUE INDEX ux_poc_record_upload_row ON poc_record (upload_id, row_no);
CREATE INDEX ix_poc_record_ext_ref ON poc_record (external_ref);
--rollback DROP TABLE poc_record;

--changeset poc:001-record-alias
CREATE TABLE poc_record_alias (
    alias_id    NUMBER(19)           NOT NULL,
    record_id   NUMBER(19)           NOT NULL,
    seq_no      NUMBER(5)            NOT NULL,
    alias_type  VARCHAR2(50 CHAR),
    full_name   VARCHAR2(1000 CHAR)  NOT NULL,
    CONSTRAINT pk_poc_record_alias PRIMARY KEY (alias_id),
    CONSTRAINT fk_poc_alias_record FOREIGN KEY (record_id) REFERENCES poc_record (record_id)
);
CREATE INDEX ix_poc_alias_record ON poc_record_alias (record_id, seq_no);
--rollback DROP TABLE poc_record_alias;

--changeset poc:001-reject
-- Rows that could not be loaded, with the reason.
CREATE TABLE poc_reject (
    upload_id     NUMBER(19)          NOT NULL,
    row_no        NUMBER(12)          NOT NULL,
    external_ref  VARCHAR2(100 CHAR),
    reason        VARCHAR2(500 CHAR)  NOT NULL,
    CONSTRAINT fk_poc_reject_upload FOREIGN KEY (upload_id) REFERENCES poc_upload (upload_id)
);
CREATE INDEX ix_poc_reject_upload ON poc_reject (upload_id, row_no);
--rollback DROP TABLE poc_reject;
