-- Run once as a DBA on the Oracle 19 database (adapt the tablespace and password policy).
-- The application creates its own tables with Liquibase at first start.
CREATE USER listhub_poc IDENTIFIED BY "<choose-a-password>"
  DEFAULT TABLESPACE users QUOTA 2G ON users;
GRANT CREATE SESSION, CREATE TABLE, CREATE SEQUENCE, CREATE VIEW TO listhub_poc;

-- To remove everything after the POC:
-- DROP USER listhub_poc CASCADE;
