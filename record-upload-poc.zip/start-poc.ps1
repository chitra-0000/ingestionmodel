<#
.SYNOPSIS
  Starts the record upload POC (backend + frontend) and opens the page in the browser.

.EXAMPLE
  # Demo without Oracle (H2 database in Oracle mode, stored in poc-backend\data):
  powershell -ExecutionPolicy Bypass -File .\start-poc.ps1 -Demo

  # Against Oracle 19 (asks for the password; nothing is saved):
  powershell -ExecutionPolicy Bypass -File .\start-poc.ps1 -DbUrl "jdbc:oracle:thin:@//host:1521/SERVICE" -DbUser LISTHUB_POC
#>
[CmdletBinding(DefaultParameterSetName = 'Oracle')]
param(
    [Parameter(ParameterSetName = 'Demo')] [switch] $Demo,
    [Parameter(ParameterSetName = 'Oracle', Mandatory = $true)] [string] $DbUrl,
    [Parameter(ParameterSetName = 'Oracle', Mandatory = $true)] [string] $DbUser
)

$ErrorActionPreference = 'Stop'
$Backend = Join-Path $PSScriptRoot 'poc-backend'
$Frontend = Join-Path $PSScriptRoot 'poc-frontend'

function Fail([string] $text) { Write-Host "`nSTOPPED: $text" -ForegroundColor Red; exit 1 }

foreach ($tool in 'java', 'node', 'npm') {
    if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) { Fail "$tool was not found. Install it and open a new PowerShell window." }
}

if ($Demo) {
    $env:SPRING_PROFILES_ACTIVE = 'h2'
    Write-Host 'Mode: demo database (H2, Oracle mode). Data is kept in poc-backend\data.' -ForegroundColor Cyan
} else {
    $secure = Read-Host -AsSecureString "Oracle password for $DbUser"
    $env:POC_DB_URL = $DbUrl
    $env:POC_DB_USER = $DbUser
    $env:POC_DB_PASSWORD = [System.Net.NetworkCredential]::new('', $secure).Password
    Write-Host "Mode: Oracle 19 at $DbUrl" -ForegroundColor Cyan
}

Write-Host 'Starting the backend in its own window (first run downloads Maven packages)...'
Start-Process powershell -WorkingDirectory $Backend -ArgumentList @(
    '-NoExit', '-Command', "`$Host.UI.RawUI.WindowTitle = 'POC backend'; .\mvnw.cmd -q spring-boot:run")
Remove-Item Env:POC_DB_PASSWORD -ErrorAction SilentlyContinue

Write-Host -NoNewline 'Waiting for the backend'
$up = $false
for ($i = 0; $i -lt 120; $i++) {
    try {
        if ((Invoke-RestMethod -Uri 'http://localhost:8080/actuator/health' -TimeoutSec 2).status -eq 'UP') { $up = $true; break }
    } catch { }
    Write-Host -NoNewline '.'; Start-Sleep -Seconds 3
}
Write-Host ''
if (-not $up) { Fail "The backend did not start. Check the 'POC backend' window." }

if (-not (Test-Path (Join-Path $Frontend 'node_modules'))) {
    Write-Host 'Installing frontend packages (first run only)...'
    Push-Location $Frontend; & npm install; $code = $LASTEXITCODE; Pop-Location
    if ($code -ne 0) { Fail 'npm install failed. On the bank network, point npm to your Nexus registry (.npmrc).' }
}
Write-Host 'Starting the frontend in its own window...'
Start-Process powershell -WorkingDirectory $Frontend -ArgumentList @(
    '-NoExit', '-Command', "`$Host.UI.RawUI.WindowTitle = 'POC frontend'; npm start")

Write-Host -NoNewline 'Waiting for the page'
for ($i = 0; $i -lt 90; $i++) {
    try { Invoke-WebRequest -Uri 'http://localhost:4200/' -UseBasicParsing -TimeoutSec 2 | Out-Null; break } catch { }
    Write-Host -NoNewline '.'; Start-Sleep -Seconds 2
}
Write-Host ''
Start-Process 'http://localhost:4200/'
Write-Host 'Ready: http://localhost:4200  (close the two windows to stop)' -ForegroundColor Green
