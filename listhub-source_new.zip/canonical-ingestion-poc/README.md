# ListHub

Provider list files in (XML, CSV, JSON), canonical versioned records out. Standalone: one WAR, H2 on a developer
machine, Oracle 19c in the environment. The full guide (code explanation, setup, deployment, how to use each screen)
is the "ListHub - code and user guide" document.

```
ingestion-backend/    Java 8, Spring Boot 2.7.18, Maven   -> listhub.war (screens included)
ingestion-frontend/   Angular 11.2.4, Node 14.17.6
.run/                 IntelliJ run configurations (H2, Oracle)
```

## Build

```
cd ingestion-frontend && npm install && npx ng build --prod      # Node 14.17.6 -> dist/listhub
cd ../ingestion-backend && mvn clean package                     # copies dist/listhub into the WAR, runs the tests
```

## Run locally (H2, nothing to install)

```
set LISTHUB_ADMIN_PASSWORD=ChangeMe12345          (Linux: export ...)
java -jar target/listhub.war --spring.profiles.active=h2
```

Open http://localhost:8080, sign in as `admin`. Drop provider files into `listhub-data/inbound`.

## Run in the environment (Oracle)

The DBA runs `ingestion-backend/src/main/resources/db/schema.sql` once. Then:

```
export ORACLE_URL=jdbc:oracle:thin:@//dbhost:1521/SERVICE ORACLE_USER=LISTHUB ORACLE_PASSWORD=...
export LISTHUB_ADMIN_PASSWORD=...
java -Xms4g -Xmx8g -XX:+UseG1GC -jar listhub.war --spring.profiles.active=oracle --listhub.base-dir=/data/listhub
```

## Sample files

```
java -cp ingestion-backend/target/classes com.bank.ingestion.tools.SampleFiles ./samples 20000 3
```

Writes three versions of a Dow Jones S_XML-like sanctions file, a delta file, a CSV and a JSON file (generated, not real data).
