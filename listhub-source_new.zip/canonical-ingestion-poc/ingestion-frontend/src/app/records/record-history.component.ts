import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../core/api.service';
import { errorText } from '../core/http.interceptor';
import { ChangeRow, HistoryView, RawView } from '../core/models';
import { statusClass } from '../shared/format';

@Component({
  selector: 'app-record-history',
  template: `
    <div class="page" *ngIf="h as hv">
      <div class="crumb"><a routerLink="/records">Records</a> / {{ hv.current.rglId }}</div>
      <div class="head">
        <div>
          <div class="row" style="gap: 10px"><h1>{{ hv.current.primaryName }}</h1>
            <span [class]="hv.active ? 'pill p-ok' : 'pill p-bad'">{{ hv.active ? 'Active' : 'Deleted' }}</span></div>
          <p class="mono">{{ hv.current.rglId }} · provider id {{ hv.current.externalRef || '–' }} · {{ hv.current.recordType }} ·
            <a [routerLink]="['/lists', hv.current.listId, 'versions']">{{ hv.current.listCode }} {{ hv.current.listName }}</a></p>
        </div>
        <div class="row"><button class="btn primary" type="button" (click)="pdf = api.pdfUrl(hv.current.rglId)">View PDF (latest)</button></div>
      </div>
      <div class="msg err" *ngIf="error">{{ error }}</div>

      <div class="cols">
        <section class="narrow panel" style="max-width: 460px">
          <h2>History across versions</h2>
          <ol class="tl">
            <li *ngFor="let e of hv.events" style="cursor: pointer" (click)="sel = e; raw = null" [style.font-weight]="sel === e ? 600 : 400">
              <span class="dot" [style.background]="color(e.type)"></span>
              <div class="row" style="gap: 8px"><b>Version {{ e.version }}</b><span [class]="cls(e.type)">{{ e.type | status }}</span></div>
              <div class="small muted">{{ e.summary }}</div>
            </li>
          </ol>
        </section>
        <section class="wide" style="display: flex; flex-direction: column; gap: 16px">
          <div class="panel" *ngIf="sel as e">
            <div class="panel-head"><h2>Version {{ e.version }}: {{ e.type | status }}</h2>
              <div class="row" style="gap: 8px">
                <a class="btn small" [routerLink]="['/lists', hv.current.listId, 'versions', e.version]">Open version {{ e.version }}</a>
                <button class="btn small" type="button" *ngIf="e.rawSeq" (click)="showRaw(e)">{{ raw ? 'Hide raw record' : 'Raw record' }}</button>
                <button class="btn small" type="button" (click)="pdf = api.pdfUrl(hv.current.rglId, e.type === 'DELETED' ? e.version - 1 : e.version)">PDF of this version</button>
              </div></div>
            <div class="chg" *ngIf="e.detail?.changes?.length">
              <span class="h">Field</span><span class="h">Before</span><span class="h">After</span>
              <ng-container *ngFor="let c of e.detail.changes"><span style="font-weight: 600">{{ c.field }}</span>
                <span class="b">{{ c.before || '–' }}</span><span class="a">{{ c.after || '–' }}</span></ng-container>
            </div>
            <div *ngIf="e.detail?.issues?.length" class="row"><span class="pill p-warn" *ngFor="let i of e.detail.issues">{{ i.message }}</span></div>
            <p class="muted" *ngIf="!e.detail?.changes?.length && !e.detail?.issues?.length">{{ e.summary }}</p>
            <pre class="raw" *ngIf="raw" style="margin-top: 12px">{{ raw.text }}</pre>
          </div>
          <div class="panel" *ngFor="let p of periodsDesc()">
            <div class="panel-head"><h2>Valid from version {{ p.validFrom }} {{ p.validTo ? 'to ' + p.validTo : '(current)' }}</h2></div>
            <dl class="dl"><ng-container *ngFor="let a of p.attributes"><dt>{{ a.label }}</dt><dd>{{ a.values.join('; ') }}</dd></ng-container></dl>
          </div>
        </section>
      </div>
    </div>
    <app-pdf-viewer *ngIf="pdf" [src]="pdf" [title]="h?.current?.rglId || ''" (close)="pdf = ''"></app-pdf-viewer>
  `
})
export class RecordHistoryComponent implements OnInit {
  h: HistoryView | null = null;
  sel: ChangeRow | null = null;
  raw: RawView | null = null;
  pdf = '';
  error = '';
  cls = statusClass;

  constructor(private route: ActivatedRoute, public api: ApiService) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(p => {
      this.api.history(p.get('rglId') || '').subscribe(h => {
        this.h = h;
        this.sel = h.events.filter(e => e.type !== 'FLAGGED').slice(-1)[0] || h.events[0] || null;
      }, e => this.error = errorText(e));
    });
  }

  periodsDesc(): HistoryView['periods'] {
    return this.h ? this.h.periods.slice().reverse() : [];
  }

  color(t: string): string {
    return t === 'CREATED' ? '#2F6B4F' : t === 'DELETED' ? '#A3352B' : t === 'MODIFIED' ? '#1E4E8C' : t === 'FLAGGED' ? '#C98A1B' : '#8A94A3';
  }

  showRaw(e: ChangeRow): void {
    if (this.raw) { this.raw = null; return; }
    if (e.rawSeq) {
      this.api.raw(e.batchId, e.rawSeq).subscribe(r => this.raw = r, err => this.error = errorText(err));
    }
  }
}
