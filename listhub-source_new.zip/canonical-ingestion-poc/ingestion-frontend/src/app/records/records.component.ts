import { Component, OnInit } from '@angular/core';
import { ApiService } from '../core/api.service';
import { errorText } from '../core/http.interceptor';
import { ListRow, SearchRow } from '../core/models';

@Component({
  selector: 'app-records',
  template: `
    <div class="page">
      <div class="head"><div><h1>Records</h1><p>Search every list by name (any spelling of the name or an alias), internal id or
        provider id. Each person or entity keeps one internal id for its whole life in a list.</p></div></div>
      <form class="panel row" (ngSubmit)="search()">
        <input class="in grow" name="q" [(ngModel)]="q" placeholder="Name, RGL-… id or provider id" aria-label="Search text">
        <select class="in" name="list" [(ngModel)]="listId" aria-label="List"><option [ngValue]="undefined">All lists</option>
          <option *ngFor="let l of lists" [ngValue]="l.list.listId">{{ l.list.listCode }} {{ l.list.name }}</option></select>
        <select class="in" name="type" [(ngModel)]="type" aria-label="Type"><option value="">All types</option>
          <option>PERSON</option><option>ENTITY</option><option>VESSEL</option><option>AIRCRAFT</option></select>
        <label class="check"><input type="checkbox" name="deleted" [(ngModel)]="deleted"> Include deleted</label>
        <button class="btn primary" type="submit">Search</button>
      </form>
      <div class="msg err" *ngIf="error">{{ error }}</div>
      <div class="panel flush scroll" *ngIf="rows">
        <table>
          <thead><tr><th>Internal id</th><th>Name</th><th>Type</th><th>Date of birth</th><th>Countries</th><th>List</th><th>Sanctions lists</th><th>Status</th></tr></thead>
          <tbody>
            <tr *ngFor="let r of rows" class="click" [routerLink]="['/records', r.rglId]">
              <td class="mono"><a [routerLink]="['/records', r.rglId]">{{ r.rglId }}</a><div class="small muted">{{ r.externalRef }}</div></td>
              <td style="font-weight: 600">{{ r.primaryName }}</td>
              <td>{{ r.recordType }}</td>
              <td class="small">{{ r.dob || '–' }}</td>
              <td class="small">{{ r.countries || '–' }}</td>
              <td class="small">{{ r.listCode }} {{ r.listName }}</td>
              <td class="small">{{ r.listRefs || '–' }}</td>
              <td><span [class]="r.active ? 'pill p-ok' : 'pill p-bad'">{{ r.active ? 'Active since V' + r.validFrom : 'Deleted after V' + r.validTo }}</span></td>
            </tr>
            <tr *ngIf="!rows.length"><td colspan="8" class="empty">No record found.</td></tr>
          </tbody>
        </table>
        <p class="small muted" style="padding: 8px 14px; margin: 0" *ngIf="rows.length === 200">First 200 results: refine the search.</p>
      </div>
    </div>
  `
})
export class RecordsComponent implements OnInit {
  q = '';
  listId?: number;
  type = '';
  deleted = false;
  rows: SearchRow[] | null = null;
  lists: ListRow[] = [];
  error = '';

  constructor(private api: ApiService) { }

  ngOnInit(): void {
    this.api.lists().subscribe(l => this.lists = l);
  }

  search(): void {
    this.error = '';
    this.api.search(this.q, this.listId, this.type, this.deleted).subscribe(r => this.rows = r, e => this.error = errorText(e));
  }
}
