import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HTTP_INTERCEPTORS, HttpClientModule, HttpClientXsrfModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { AuthGuard } from './core/auth.guard';
import { SessionInterceptor } from './core/http.interceptor';
import { BytesPipe, DurationPipe, NumberPipe, StatusPipe, StepPipe, WhenPipe } from './shared/format';
import { PdfViewerComponent } from './shared/pdf-viewer.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { ListsComponent } from './lists/lists.component';
import { ListShellComponent } from './list/list-shell.component';
import { ListFormComponent } from './list/list-form.component';
import { ListImportComponent } from './list/list-import.component';
import { MappingComponent } from './list/mapping.component';
import { VersionsComponent } from './list/versions.component';
import { VersionDetailComponent } from './version/version-detail.component';
import { RecordsComponent } from './records/records.component';
import { RecordHistoryComponent } from './records/record-history.component';
import { AdminShellComponent } from './admin/admin-shell.component';
import { AutoImportComponent } from './admin/auto-import.component';
import { BatchesComponent } from './admin/batches.component';
import { UsersComponent } from './admin/users.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: '', canActivate: [AuthGuard], children: [
      { path: '', component: HomeComponent },
      { path: 'lists', component: ListsComponent },
      { path: 'lists/new', component: ListShellComponent, children: [{ path: '', component: ListFormComponent }] },
      {
        path: 'lists/:id', component: ListShellComponent, children: [
          { path: '', redirectTo: 'characteristics', pathMatch: 'full' },
          { path: 'characteristics', component: ListFormComponent },
          { path: 'import', component: ListImportComponent },
          { path: 'mapping', component: MappingComponent },
          { path: 'versions', component: VersionsComponent },
          { path: 'versions/:v', component: VersionDetailComponent }
        ]
      },
      { path: 'records', component: RecordsComponent },
      { path: 'records/:rglId', component: RecordHistoryComponent },
      {
        path: 'admin', component: AdminShellComponent, children: [
          { path: '', redirectTo: 'import', pathMatch: 'full' },
          { path: 'import', component: AutoImportComponent },
          { path: 'batches', component: BatchesComponent },
          { path: 'users', component: UsersComponent }
        ]
      }
    ]
  },
  { path: '**', redirectTo: '' }
];

@NgModule({
  declarations: [
    AppComponent, LoginComponent, HomeComponent, ListsComponent, ListShellComponent, ListFormComponent, ListImportComponent,
    MappingComponent, VersionsComponent, VersionDetailComponent, RecordsComponent, RecordHistoryComponent,
    AdminShellComponent, AutoImportComponent, BatchesComponent, UsersComponent, PdfViewerComponent,
    NumberPipe, BytesPipe, DurationPipe, WhenPipe, StatusPipe, StepPipe
  ],
  imports: [
    BrowserModule, FormsModule, HttpClientModule,
    HttpClientXsrfModule.withOptions({ cookieName: 'XSRF-TOKEN', headerName: 'X-XSRF-TOKEN' }),
    RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled' })
  ],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: SessionInterceptor, multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule { }
