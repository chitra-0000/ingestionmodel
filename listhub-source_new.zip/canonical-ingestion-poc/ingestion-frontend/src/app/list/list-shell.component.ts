import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../core/api.service';
import { ListDef } from '../core/models';

@Component({
  selector: 'app-list-shell',
  template: `
    <div class="frame">
      <aside class="side">
        <div class="who-list" *ngIf="list; else newList">
          <div class="mono muted">{{ list.listCode }}</div>
          <div style="font-size: 17px; font-weight: 600">{{ list.name }}</div>
          <div class="small muted">{{ list.providerCode }}</div>
        </div>
        <ng-template #newList><div class="who-list"><div style="font-size: 17px; font-weight: 600">New list</div></div></ng-template>
        <nav aria-label="List" *ngIf="list">
          <a [routerLink]="['/lists', list.listId, 'characteristics']" routerLinkActive="on">Characteristics</a>
          <a [routerLink]="['/lists', list.listId, 'import']" routerLinkActive="on">Import and files</a>
          <a [routerLink]="['/lists', list.listId, 'mapping']" routerLinkActive="on">Mapping</a>
          <a [routerLink]="['/lists', list.listId, 'versions']" routerLinkActive="on">Versions</a>
        </nav>
      </aside>
      <main class="main"><router-outlet></router-outlet></main>
    </div>
  `
})
export class ListShellComponent implements OnInit {
  list: ListDef | null = null;

  constructor(private route: ActivatedRoute, private api: ApiService) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(p => {
      const id = p.get('id');
      if (id) {
        this.api.list(+id).subscribe(l => this.list = l);
      } else {
        this.list = null;
      }
    });
  }
}
