import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpEventType } from '@angular/common/http';
import { interval, Subscription } from 'rxjs';
import { startWith, switchMap } from 'rxjs/operators';
import { ApiService } from '../core/api.service';
import { AuthService } from '../core/auth.service';
import { errorText } from '../core/http.interceptor';
import { BatchView, ListDef } from '../core/models';
import { statusClass } from '../shared/format';

@Component({
  selector: 'app-list-import',
  template: `
    <div class="crumb"><a routerLink="/lists">Lists</a> / {{ list?.listCode }} {{ list?.name }} / Import and files</div>
    <div class="head"><div><h1>Import and files</h1>
      <p>Files arrive by themselves in the inbound folder when their name matches <span class="mono">{{ list?.filePattern || '(no pattern)' }}</span>.
        You can also upload a file here. Stage 1 stores every record as received; stage 2 builds the new version.</p></div></div>

    <section class="panel" *ngIf="auth.has('OPERATOR')">
      <h2>Upload a file</h2>
      <div class="row">
        <input type="file" (change)="pick($event)" aria-label="File to upload" accept=".xml,.csv,.json,.txt">
        <button class="btn primary" type="button" (click)="upload()" [disabled]="!file || uploading">Upload and load</button>
        <span class="muted small" *ngIf="file">{{ file.name }} · {{ file.size | bytes }}</span>
      </div>
      <div class="progress" *ngIf="uploading" style="margin-top: 10px"><span [style.width.%]="uploadPct"></span></div>
      <div class="msg err" *ngIf="error" style="margin-top: 10px">{{ error }}</div>
    </section>

    <section>
      <div class="panel-head"><h2>Files of this list</h2><span class="muted small">Refreshes every 5 s</span></div>
      <div class="panel flush scroll">
        <table>
          <thead><tr><th>File</th><th>Received</th><th>Status</th><th class="num">Records</th><th>Steps</th><th class="num">Time</th><th></th></tr></thead>
          <tbody>
            <tr *ngFor="let b of batches">
              <td><span class="mono small">{{ b.batch.fileName }}</span>
                <div class="small muted">{{ b.batch.fileSize | bytes }} · {{ b.batch.delivery || '' }} {{ b.batch.fileFormat || '' }} · batch {{ b.batch.batchId }}</div></td>
              <td class="nowrap">{{ b.batch.receivedAt | when }}</td>
              <td><span [class]="cls(b.batch.status)">{{ b.batch.status | status }}</span>
                <div class="small muted" style="max-width: 320px">{{ b.batch.message }}</div>
                <div *ngIf="b.progress" style="margin-top: 4px"><div class="progress"><span [style.width.%]="b.progress.percent || 0"></span></div>
                  <span class="small muted">{{ b.progress.phase }} {{ b.progress.percent }}%</span></div></td>
              <td class="num">{{ b.batch.recordCount | n }}</td>
              <td class="small"><div *ngFor="let s of b.steps">{{ s.code | step }}: <b>{{ s.durationMs | dur }}</b></div></td>
              <td class="num nowrap">{{ b.processingMs | dur }}</td>
              <td class="nowrap">
                <a class="btn small" *ngIf="b.batch.versionNo" [routerLink]="['/lists', listId, 'versions', b.batch.versionNo]">Version {{ b.batch.versionNo }}</a>
                <a class="btn small" *ngIf="b.batch.status === 'MAPPING_REVIEW'" [routerLink]="['/lists', listId, 'mapping']">Review mapping</a>
                <button class="btn small" type="button" *ngIf="b.batch.status === 'FAILED' && auth.has('OPERATOR')" (click)="retry(b.batch.batchId)">Load again</button>
              </td>
            </tr>
            <tr *ngIf="!batches.length"><td colspan="7" class="empty">No file yet.</td></tr>
          </tbody>
        </table>
      </div>
    </section>
  `
})
export class ListImportComponent implements OnInit, OnDestroy {
  listId = 0;
  list: ListDef | null = null;
  batches: BatchView[] = [];
  file: File | null = null;
  uploading = false;
  uploadPct = 0;
  error = '';
  cls = statusClass;
  private sub?: Subscription;

  constructor(private route: ActivatedRoute, private api: ApiService, public auth: AuthService) { }

  ngOnInit(): void {
    this.listId = +(this.route.parent!.snapshot.paramMap.get('id') || 0);
    this.api.list(this.listId).subscribe(l => this.list = l);
    this.sub = interval(5000).pipe(startWith(0), switchMap(() => this.api.batches(90, this.listId))).subscribe(b => this.batches = b);
  }

  ngOnDestroy(): void { this.sub?.unsubscribe(); }

  pick(e: Event): void {
    const input = e.target as HTMLInputElement;
    this.file = input.files && input.files.length ? input.files[0] : null;
  }

  upload(): void {
    if (!this.file) { return; }
    this.uploading = true;
    this.error = '';
    this.api.upload(this.file, this.listId).subscribe(ev => {
      if (ev.type === HttpEventType.UploadProgress && ev.total) {
        this.uploadPct = Math.round(ev.loaded * 100 / ev.total);
      } else if (ev.type === HttpEventType.Response) {
        this.uploading = false;
        this.file = null;
        this.refresh();
      }
    }, e => { this.uploading = false; this.error = errorText(e); });
  }

  retry(id: number): void {
    this.api.retry(id).subscribe(() => this.refresh(), e => this.error = errorText(e));
  }

  private refresh(): void {
    this.api.batches(90, this.listId).subscribe(b => this.batches = b);
  }
}
