import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../core/api.service';
import { ListDef, ListVersion } from '../core/models';
import { statusClass } from '../shared/format';

@Component({
  selector: 'app-versions',
  template: `
    <div class="crumb"><a routerLink="/lists">Lists</a> / {{ list?.listCode }} {{ list?.name }} / Versions</div>
    <div class="head"><div><h1>Versions</h1><p>One version per file. A version is visible to subscribers once it is published
      (validated by one user, certified by another).</p></div></div>
    <div class="panel flush scroll">
      <table>
        <thead><tr><th>Version</th><th>Status</th><th>Delivery</th><th class="num">Records</th><th class="num">Created</th>
          <th class="num">Modified</th><th class="num">Deleted</th><th class="num">Rejected</th><th>Loaded</th><th>Validated</th><th>Certified</th></tr></thead>
        <tbody>
          <tr *ngFor="let v of versions" class="click" [routerLink]="['/lists', listId, 'versions', v.versionNo]">
            <td><a [routerLink]="['/lists', listId, 'versions', v.versionNo]">V{{ v.versionNo }}</a></td>
            <td><span [class]="cls(v.status)">{{ v.status | status }}</span></td>
            <td>{{ v.delivery }}</td>
            <td class="num">{{ v.totalRecords | n }}</td>
            <td class="num" style="color: var(--ok)">+{{ v.createdCount | n }}</td>
            <td class="num" style="color: var(--blue)">{{ v.modifiedCount | n }}</td>
            <td class="num" style="color: var(--bad)">−{{ v.deletedCount | n }}</td>
            <td class="num">{{ v.rejectedCount | n }}</td>
            <td class="nowrap">{{ v.createdAt | when }}</td>
            <td class="small">{{ v.validatedBy || '–' }}</td>
            <td class="small">{{ v.certifiedBy || v.rejectedBy || '–' }}</td>
          </tr>
          <tr *ngIf="loaded && !versions.length"><td colspan="11" class="empty">No version yet: load a file of this list.</td></tr>
        </tbody>
      </table>
    </div>
  `
})
export class VersionsComponent implements OnInit {
  listId = 0;
  list: ListDef | null = null;
  versions: ListVersion[] = [];
  loaded = false;
  cls = statusClass;

  constructor(private route: ActivatedRoute, private api: ApiService) { }

  ngOnInit(): void {
    this.listId = +(this.route.parent!.snapshot.paramMap.get('id') || 0);
    this.api.list(this.listId).subscribe(l => this.list = l);
    this.api.versions(this.listId).subscribe(v => { this.versions = v; this.loaded = true; });
  }
}
