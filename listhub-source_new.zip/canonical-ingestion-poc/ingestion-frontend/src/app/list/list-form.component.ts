import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../core/api.service';
import { AuthService } from '../core/auth.service';
import { errorText } from '../core/http.interceptor';
import { ListDef } from '../core/models';

@Component({
  selector: 'app-list-form',
  template: `
    <div class="crumb"><a routerLink="/lists">Lists</a> / {{ isNew ? 'New list' : l.listCode + ' ' + l.name }}</div>
    <div class="head"><h1>{{ isNew ? 'New list' : 'List characteristics' }}</h1></div>
    <form class="panel" (ngSubmit)="save()">
      <div class="form">
        <label class="field">List code *<input name="code" [(ngModel)]="l.listCode" [disabled]="!isNew" required maxlength="20">
          <span class="hint">Part of every internal id; cannot change later</span></label>
        <label class="field span2">Name *<input name="name" [(ngModel)]="l.name" required maxlength="200"></label>
        <label class="field">Provider *<input name="provider" [(ngModel)]="l.providerCode" required maxlength="30">
          <span class="hint">e.g. DOWJONES, SIX</span></label>
        <label class="field span2">File name pattern<input name="pattern" class="mono" [(ngModel)]="l.filePattern" maxlength="200">
          <span class="hint">* for the part that changes: s_xml_1158_158_*. Files matching it are loaded into this list.</span></label>
        <label class="field">Delta file pattern<input name="delta" class="mono" [(ngModel)]="l.deltaPattern" maxlength="200">
          <span class="hint">e.g. *_d.xml; other files are full</span></label>
        <label class="field">File format
          <select name="format" [(ngModel)]="l.fileFormat"><option>AUTO</option><option>XML</option><option>CSV</option><option>JSON</option></select></label>
        <label class="field span2">Record elements (XML)<input name="elements" [(ngModel)]="l.recordElements" placeholder="found in the file">
          <span class="hint">Leave empty: found from the file (e.g. Person, Entity)</span></label>
        <label class="field">Internal id prefix<input name="prefix" [(ngModel)]="l.idPrefix" [disabled]="!isNew" maxlength="10">
          <span class="hint">{{ (l.idPrefix || 'RGL') + '-' + (l.listCode || 'code') }}-0000000001</span></label>
        <label class="field">Category<input name="category" [(ngModel)]="l.category" maxlength="40"></label>
        <label class="field span2">Match key (providers without their own id)<input name="match" [(ngModel)]="l.matchKeyAttrs"
            placeholder="PRIMARY_NAME,DOB,NATIONALITY">
          <span class="hint">Used only when the mapping has no provider id</span></label>
        <label class="field">Approval
          <select name="workflow" [(ngModel)]="l.workflow"><option value="MANUAL">Validate + certify</option>
            <option value="AUTO">Automatic when quality is met</option></select></label>
        <label class="field">Max rejected (%)<input name="maxr" type="number" min="0" max="100" step="0.1" [(ngModel)]="l.maxRejectPercent"></label>
        <fieldset class="field span2" style="border: 0; padding: 0; margin: 0">
          <legend style="margin-bottom: 6px">Export files at publication</legend>
          <label class="check"><input type="checkbox" name="csv" [(ngModel)]="csv"> CSV (full and delta)</label>
          <label class="check"><input type="checkbox" name="xml" [(ngModel)]="xml"> XML (full)</label>
        </fieldset>
        <label class="field span2"><span><input type="checkbox" name="active" [(ngModel)]="l.active"> Active (files are loaded)</span></label>
        <label class="field span4">Description<textarea name="descr" [(ngModel)]="l.description" maxlength="1000"></textarea></label>
      </div>
      <div class="msg err" *ngIf="error" style="margin-top: 14px">{{ error }}</div>
      <div class="msg ok" *ngIf="saved" style="margin-top: 14px">Saved.</div>
      <div class="row" style="margin-top: 16px; justify-content: flex-end" *ngIf="auth.has('ADMIN')">
        <a class="btn" routerLink="/lists">Cancel</a>
        <button class="btn primary" type="submit" [disabled]="busy">{{ isNew ? 'Create the list' : 'Save' }}</button>
      </div>
    </form>
  `
})
export class ListFormComponent implements OnInit {
  l: ListDef = {
    listId: 0, listCode: '', name: '', providerCode: '', fileFormat: 'AUTO', idPrefix: 'RGL', workflow: 'MANUAL',
    exportFormats: 'CSV,XML', maxRejectPercent: 5, active: true
  };
  isNew = true;
  csv = true;
  xml = true;
  error = '';
  saved = false;
  busy = false;

  constructor(private route: ActivatedRoute, private router: Router, private api: ApiService, public auth: AuthService) { }

  ngOnInit(): void {
    const id = this.route.parent ? this.route.parent.snapshot.paramMap.get('id') : null;
    if (id) {
      this.isNew = false;
      this.api.list(+id).subscribe(l => {
        this.l = l;
        this.csv = (l.exportFormats || '').indexOf('CSV') >= 0;
        this.xml = (l.exportFormats || '').indexOf('XML') >= 0;
      });
    }
  }

  save(): void {
    this.error = '';
    this.saved = false;
    this.busy = true;
    this.l.exportFormats = [this.csv ? 'CSV' : '', this.xml ? 'XML' : ''].filter(x => x).join(',');
    const call = this.isNew ? this.api.createList(this.l) : this.api.updateList(this.l.listId, this.l);
    call.subscribe(l => {
      this.busy = false;
      if (this.isNew) {
        this.router.navigate(['/lists', l.listId, 'import']);
      } else {
        this.l = l;
        this.saved = true;
      }
    }, e => { this.busy = false; this.error = errorText(e); });
  }
}
