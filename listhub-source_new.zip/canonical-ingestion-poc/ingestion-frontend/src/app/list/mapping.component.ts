import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../core/api.service';
import { AuthService } from '../core/auth.service';
import { errorText } from '../core/http.interceptor';
import { FieldRule, MappingRules, MappingView, PreviewResult, ProfileRow } from '../core/models';

@Component({
  selector: 'app-mapping',
  templateUrl: './mapping.component.html'
})
export class MappingComponent implements OnInit {
  listId = 0;
  view: MappingView | null = null;
  rules: MappingRules = { fields: [] };
  preview: PreviewResult | null = null;
  error = '';
  info = '';
  busy = false;
  profileFilter = '';

  constructor(private route: ActivatedRoute, private api: ApiService, public auth: AuthService) { }

  ngOnInit(): void {
    this.listId = +(this.route.parent!.snapshot.paramMap.get('id') || 0);
    this.load();
  }

  load(): void {
    this.api.mapping(this.listId).subscribe(v => {
      this.view = v;
      const src = v.draft || v.approved;
      this.rules = src ? JSON.parse(JSON.stringify(src.rules)) : { fields: [] };
      if (!this.rules.fields) { this.rules.fields = []; }
    }, e => this.error = errorText(e));
  }

  get refLists(): string[] {
    return this.view && this.view.file ? Object.keys(this.view.file.refLists || {}) : [];
  }

  get paths(): string[] {
    return this.view && this.view.file ? this.view.file.profile.map(p => p.path) : [];
  }

  profile(): ProfileRow[] {
    if (!this.view || !this.view.file) { return []; }
    const f = this.profileFilter.trim().toLowerCase();
    const used = new Set(this.rules.fields.map(r => r.path));
    return this.view.file.profile
      .filter(p => !f || p.path.toLowerCase().indexOf(f) >= 0 || (p.samples || '').toLowerCase().indexOf(f) >= 0)
      .map(p => ({ ...p, used: used.has(p.path) } as ProfileRow & { used: boolean }));
  }

  share(p: ProfileRow): number {
    const n = this.view && this.view.file ? Math.min(this.view.file.records, 5000) : 0;
    return n ? Math.round(p.recordsWith * 100 / n) : 0;
  }

  label(code: string): string {
    const a = this.view ? this.view.attributes.find(x => x.code === code) : null;
    return a ? a.label : code;
  }

  use(p: ProfileRow): void {
    this.rules.fields.push({ attr: '', path: p.path, decode: p.refList || undefined });
    this.info = 'Rule added at the end of the list: choose its attribute.';
  }

  add(): void { this.rules.fields.push({ attr: '', path: '' }); }

  remove(r: FieldRule): void { this.rules.fields = this.rules.fields.filter(x => x !== r); }

  propose(): void {
    this.run(this.api.propose(this.listId), () => { this.info = 'A proposal was made from the fields of the last file. Check it, preview, then approve.'; this.load(); });
  }

  save(): void {
    this.run(this.api.saveDraft(this.listId, this.clean()), v => { this.view = v; this.info = 'Draft saved.'; });
  }

  doPreview(): void {
    this.run(this.api.preview(this.listId, this.clean()), p => { this.preview = p; this.info = ''; });
  }

  approve(): void {
    this.run(this.api.saveDraft(this.listId, this.clean()), () =>
      this.run(this.api.approve(this.listId), v => {
        this.view = v;
        this.info = 'Mapping approved. Files of this list that were waiting are loaded now.';
      }));
  }

  attrsOf(r: { attrs: { t: string; v: string; q?: string }[] }, t: string): string {
    return r.attrs.filter(a => a.t === t).map(a => a.v + (a.q ? ' (' + a.q + ')' : '')).join('; ');
  }

  filledPct(code: string): number {
    if (!this.preview || !this.preview.checked) { return 0; }
    return Math.round((this.preview.filled[code] || 0) * 100 / this.preview.checked);
  }

  issueCodes(): string[] { return this.preview ? Object.keys(this.preview.issueCounts) : []; }

  private clean(): MappingRules {
    return {
      externalRef: this.rules.externalRef || undefined,
      action: this.rules.action || undefined,
      recordType: this.rules.recordType || undefined,
      deleteValues: this.rules.deleteValues,
      fields: this.rules.fields.filter(r => r.attr && r.path).map(r => ({
        attr: r.attr, path: r.path.trim(), decode: r.decode || undefined, qualifier: r.qualifier || undefined
      }))
    };
  }

  private run<T>(obs: import('rxjs').Observable<T>, ok: (v: T) => void): void {
    this.busy = true;
    this.error = '';
    obs.subscribe(v => { this.busy = false; ok(v); }, e => { this.busy = false; this.error = errorText(e); });
  }
}
