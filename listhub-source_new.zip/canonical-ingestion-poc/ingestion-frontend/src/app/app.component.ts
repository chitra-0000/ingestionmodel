import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/operators';
import { AuthService } from './core/auth.service';

@Component({
  selector: 'app-root',
  template: `
    <header class="top" *ngIf="!onLogin">
      <div class="top-in">
        <a routerLink="/" class="brand">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#8FD1B5" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h10"></path><path d="M17 17l2 2 3-4"></path></svg>
          ListHub
        </a>
        <nav class="nav" aria-label="Main">
          <a routerLink="/" routerLinkActive="on" [routerLinkActiveOptions]="{ exact: true }">Home</a>
          <a routerLink="/lists" routerLinkActive="on">Lists</a>
          <a routerLink="/records" routerLinkActive="on">Records</a>
          <a routerLink="/admin" routerLinkActive="on">Administration</a>
        </nav>
        <div class="who" *ngIf="auth.user">
          <span>{{ auth.name }} · {{ auth.user.roles.join(', ').toLowerCase() }}</span>
          <button type="button" (click)="logout()">Sign out</button>
        </div>
      </div>
    </header>
    <router-outlet></router-outlet>
  `
})
export class AppComponent {
  onLogin = false;

  constructor(public auth: AuthService, private router: Router) {
    router.events.pipe(filter(e => e instanceof NavigationEnd)).subscribe(e => {
      this.onLogin = (e as NavigationEnd).urlAfterRedirects.startsWith('/login');
    });
  }

  logout(): void {
    this.auth.logout().subscribe(() => this.router.navigateByUrl('/login'));
  }
}
