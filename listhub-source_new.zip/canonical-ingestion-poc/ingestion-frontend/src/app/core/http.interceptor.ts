import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthService } from './auth.service';

/** A 401 on any call (session expired) sends the user back to the login page. */
@Injectable()
export class SessionInterceptor implements HttpInterceptor {
  constructor(private router: Router, private auth: AuthService) { }

  intercept(req: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(req.clone({ withCredentials: true })).pipe(catchError((e: HttpErrorResponse) => {
      if (e.status === 401 && !req.url.endsWith('/auth/me') && !req.url.endsWith('/auth/login')) {
        this.auth.user = null;
        this.router.navigateByUrl('/login');
      }
      return throwError(e);
    }));
  }
}

/** Readable message of an API error. */
export function errorText(e: unknown): string {
  const h = e as HttpErrorResponse;
  if (h && h.error && typeof h.error === 'object' && h.error.error) {
    const d = h.error.details ? ': ' + h.error.details.join('; ') : '';
    return h.error.error + d;
  }
  if (h && h.status === 0) {
    return 'The server cannot be reached';
  }
  if (h && h.status === 403) {
    return 'Your role does not allow this action';
  }
  return 'Something went wrong' + (h && h.status ? ' (' + h.status + ')' : '');
}
