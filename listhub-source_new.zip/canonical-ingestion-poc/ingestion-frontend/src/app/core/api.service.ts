import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import {
  Batch, BatchView, ChangePage, ChangeRow, ExportFile, HistoryView, ListDef, ListRow, ListVersion, MappingRules,
  MappingView, PreviewResult, RawView, RecordView, SearchRow, Summary, User, VersionView
} from './models';

/** Every call to the ListHub backend. Cookies (session, XSRF) travel with each call. */
@Injectable({ providedIn: 'root' })
export class ApiService {

  readonly base = environment.apiBase;

  constructor(private http: HttpClient) { }

  // ---- lists
  lists(): Observable<ListRow[]> { return this.http.get<ListRow[]>(`${this.base}/lists`); }
  list(id: number): Observable<ListDef> { return this.http.get<ListDef>(`${this.base}/lists/${id}`); }
  createList(l: Partial<ListDef>): Observable<ListDef> { return this.http.post<ListDef>(`${this.base}/lists`, l); }
  updateList(id: number, l: Partial<ListDef>): Observable<ListDef> { return this.http.put<ListDef>(`${this.base}/lists/${id}`, l); }
  versions(id: number): Observable<ListVersion[]> { return this.http.get<ListVersion[]>(`${this.base}/lists/${id}/versions`); }
  route(fileName: string): Observable<{ fileName: string; list?: ListDef; delivery?: string }> {
    return this.http.get<{ fileName: string; list?: ListDef; delivery?: string }>(`${this.base}/lists/route`,
      { params: new HttpParams().set('fileName', fileName) });
  }

  // ---- mapping
  mapping(id: number): Observable<MappingView> { return this.http.get<MappingView>(`${this.base}/lists/${id}/mapping`); }
  propose(id: number): Observable<MappingRules> { return this.http.post<MappingRules>(`${this.base}/lists/${id}/mapping/propose`, {}); }
  saveDraft(id: number, rules: MappingRules): Observable<MappingView> {
    return this.http.put<MappingView>(`${this.base}/lists/${id}/mapping/draft`, rules);
  }
  preview(id: number, rules?: MappingRules): Observable<PreviewResult> {
    return this.http.post<PreviewResult>(`${this.base}/lists/${id}/mapping/preview`, rules || null);
  }
  approve(id: number): Observable<MappingView> { return this.http.post<MappingView>(`${this.base}/lists/${id}/mapping/approve`, {}); }

  // ---- batches
  upload(file: File, listId?: number): Observable<HttpEvent<Batch>> {
    const form = new FormData();
    form.append('file', file, file.name);
    let params = new HttpParams();
    if (listId) { params = params.set('listId', String(listId)); }
    return this.http.post<Batch>(`${this.base}/batches/upload`, form, { params, reportProgress: true, observe: 'events' });
  }
  batches(days: number, listId?: number): Observable<BatchView[]> {
    let params = new HttpParams().set('days', String(days));
    if (listId) { params = params.set('listId', String(listId)); }
    return this.http.get<BatchView[]>(`${this.base}/batches`, { params });
  }
  batch(id: number): Observable<BatchView> { return this.http.get<BatchView>(`${this.base}/batches/${id}`); }
  assign(id: number, listId: number): Observable<Batch> { return this.http.post<Batch>(`${this.base}/batches/${id}/assign`, { listId }); }
  retry(id: number): Observable<Batch> { return this.http.post<Batch>(`${this.base}/batches/${id}/retry`, {}); }
  summary(): Observable<Summary> { return this.http.get<Summary>(`${this.base}/batches/summary`); }

  // ---- versions
  version(id: number, v: number): Observable<VersionView> { return this.http.get<VersionView>(`${this.base}/lists/${id}/versions/${v}`); }
  changes(id: number, v: number, type: string, q: string, page: number, size: number): Observable<ChangePage> {
    const params = new HttpParams().set('type', type).set('q', q || '').set('page', String(page)).set('size', String(size));
    return this.http.get<ChangePage>(`${this.base}/lists/${id}/versions/${v}/changes`, { params });
  }
  change(id: number, v: number, type: string, seq: number): Observable<ChangeRow> {
    return this.http.get<ChangeRow>(`${this.base}/lists/${id}/versions/${v}/changes/${type}/${seq}`);
  }
  changesCsvUrl(id: number, v: number, type: string): string { return `${this.base}/lists/${id}/versions/${v}/changes.csv?type=${type}`; }
  validate(id: number, v: number, comment: string): Observable<ListVersion> {
    return this.http.post<ListVersion>(`${this.base}/lists/${id}/versions/${v}/validate`, { comment });
  }
  certify(id: number, v: number): Observable<ListVersion> {
    return this.http.post<ListVersion>(`${this.base}/lists/${id}/versions/${v}/certify`, {});
  }
  reject(id: number, v: number, comment: string): Observable<ListVersion> {
    return this.http.post<ListVersion>(`${this.base}/lists/${id}/versions/${v}/reject`, { comment });
  }
  reExport(id: number, v: number): Observable<ExportFile[]> {
    return this.http.post<ExportFile[]>(`${this.base}/lists/${id}/versions/${v}/export`, {});
  }
  exportUrl(exportId: number): string { return `${this.base}/exports/${exportId}/download`; }

  // ---- records
  search(q: string, listId?: number, type?: string, deleted = false): Observable<SearchRow[]> {
    let params = new HttpParams().set('q', q || '').set('deleted', String(deleted));
    if (listId) { params = params.set('listId', String(listId)); }
    if (type) { params = params.set('type', type); }
    return this.http.get<SearchRow[]>(`${this.base}/records/search`, { params });
  }
  record(rglId: string, version?: number): Observable<RecordView> {
    let params = new HttpParams();
    if (version) { params = params.set('version', String(version)); }
    return this.http.get<RecordView>(`${this.base}/records/${encodeURIComponent(rglId)}`, { params });
  }
  history(rglId: string): Observable<HistoryView> {
    return this.http.get<HistoryView>(`${this.base}/records/${encodeURIComponent(rglId)}/history`);
  }
  pdfUrl(rglId: string, version?: number): string {
    return `${this.base}/records/${encodeURIComponent(rglId)}/pdf` + (version ? `?version=${version}` : '');
  }
  raw(batchId: number, seq: number): Observable<RawView> { return this.http.get<RawView>(`${this.base}/raw/${batchId}/${seq}`); }

  // ---- users
  users(): Observable<User[]> { return this.http.get<User[]>(`${this.base}/users`); }
  createUser(u: { username: string; displayName: string; password: string; roles: string[] }): Observable<User> {
    return this.http.post<User>(`${this.base}/users`, u);
  }
  updateUser(username: string, u: { displayName: string; roles: string[]; active: boolean }): Observable<User> {
    return this.http.put<User>(`${this.base}/users/${encodeURIComponent(username)}`, u);
  }
  resetPassword(username: string, password: string): Observable<unknown> {
    return this.http.post(`${this.base}/users/${encodeURIComponent(username)}/password`, { password });
  }
}
