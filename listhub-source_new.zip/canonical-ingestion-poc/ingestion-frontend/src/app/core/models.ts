/** Shapes of the ListHub API (backend: com.bank.ingestion.web). */

export interface ListDef {
  listId: number;
  listCode: string;
  name: string;
  providerCode: string;
  category?: string;
  fileFormat: string;
  filePattern?: string;
  deltaPattern?: string;
  recordElements?: string;
  idPrefix: string;
  matchKeyAttrs?: string;
  workflow: string;
  exportFormats: string;
  maxRejectPercent: number;
  active: boolean;
  description?: string;
  createdBy?: string;
  createdAt?: string;
}

export interface ListVersion {
  listId: number;
  versionNo: number;
  batchId: number;
  status: string;
  delivery: string;
  mappingVersion?: number;
  fileRecords: number;
  totalRecords: number;
  createdCount: number;
  modifiedCount: number;
  minorCount: number;
  deletedCount: number;
  unchangedCount: number;
  rejectedCount: number;
  flaggedCount: number;
  createdAt: string;
  validatedBy?: string;
  validatedAt?: string;
  certifiedBy?: string;
  certifiedAt?: string;
  publishedBy?: string;
  publishedAt?: string;
  rejectedBy?: string;
  rejectedAt?: string;
  commentText?: string;
}

export interface ListRow {
  list: ListDef;
  records: number;
  lastVersion?: ListVersion;
  publishedVersion?: number;
  mappingApproved: boolean;
}

export interface Batch {
  batchId: number;
  listId?: number;
  fileName: string;
  fileSize: number;
  source: string;
  fileFormat?: string;
  delivery?: string;
  sha256?: string;
  status: string;
  message?: string;
  versionNo?: number;
  recordCount: number;
  refCount: number;
  submittedBy?: string;
  receivedAt: string;
  startedAt?: string;
  finishedAt?: string;
}

export interface Step {
  code: string;
  startedAt: string;
  finishedAt?: string;
  durationMs?: number;
  result?: string;
}

export interface BatchView {
  batch: Batch;
  listCode?: string;
  listName?: string;
  steps: Step[];
  progress?: { phase: string; done: number; total: number; percent?: number };
  processingMs: number;
}

export interface Summary {
  mappingReview: number;
  unmatched: number;
  failedToday: number;
  toValidate: number;
  toCertify: number;
  running: number;
  parallelFiles: number;
  workersPerFile: number;
}

export interface FieldRule {
  attr: string;
  path: string;
  decode?: string;
  qualifier?: string;
}

export interface MappingRules {
  externalRef?: string;
  action?: string;
  deleteValues?: string[];
  recordType?: string;
  fields: FieldRule[];
}

export interface MappingVersion {
  versionNo: number;
  status: string;
  rules: MappingRules;
  createdBy?: string;
  createdAt?: string;
  approvedBy?: string;
  approvedAt?: string;
}

export interface ProfileRow {
  path: string;
  occurs: number;
  recordsWith: number;
  samples?: string;
  refList?: string;
}

export interface Layout {
  format: string;
  recordElements: string[];
  recordParent?: string;
  refLists: string[];
  header: string[];
  delimiter?: string;
  jsonArray?: string;
}

export interface MappingView {
  approved?: MappingVersion;
  draft?: MappingVersion;
  file?: { batchId: number; fileName: string; records: number; layout?: Layout; refLists: { [k: string]: number };
           profile: ProfileRow[] };
  attributes: { code: string; label: string; multi: boolean }[];
}

export interface Attr { t: string; v: string; q?: string; }
export interface Issue { code: string; severity: string; field?: string; value?: string; message: string; }

export interface PreviewResult {
  batchId: number;
  fileName: string;
  checked: number;
  rejected: number;
  issueCounts: { [code: string]: number };
  filled: { [attr: string]: number };
  records: { seq: number; record: { recordType: string; externalRef?: string; attrs: Attr[] }; issues: Issue[] }[];
}

export interface ExportFile {
  exportId: number;
  listId: number;
  versionNo: number;
  format: string;
  kind: string;
  fileName: string;
  recordCount: number;
  sizeBytes: number;
  sha256: string;
  createdAt: string;
}

export interface VersionView {
  list: ListDef;
  version: ListVersion;
  issues?: { reject: { [c: string]: number }; flag: { [c: string]: number }; warnings: string[] };
  previousTotal: number;
  batch?: Batch;
  steps?: Step[];
  exports: ExportFile[];
}

export interface ChangeRow {
  version: number;
  type: string;
  seq: number;
  rglId?: string;
  externalRef?: string;
  recordType?: string;
  primaryName?: string;
  country?: string;
  summary?: string;
  batchId: number;
  rawSeq?: number;
  detail?: any;
  record?: RecordView;
}

export interface ChangePage { type: string; total: number; page: number; size: number; rows: ChangeRow[]; }

export interface AttrGroup { type: string; label: string; values: string[]; }

export interface RecordView {
  rglId: string;
  listId: number;
  listCode?: string;
  listName?: string;
  externalRef?: string;
  recordType: string;
  primaryName: string;
  validFrom: number;
  validTo?: number;
  batchId: number;
  rawSeq?: number;
  flags?: string;
  attributes: AttrGroup[];
}

export interface HistoryView {
  current: RecordView;
  active: boolean;
  periods: { validFrom: number; validTo?: number; primaryName: string; attributes: AttrGroup[] }[];
  events: ChangeRow[];
}

export interface SearchRow {
  rglId: string;
  externalRef?: string;
  recordType: string;
  primaryName: string;
  dob?: string;
  countries?: string;
  listRefs?: string;
  validFrom: number;
  validTo?: number;
  active: boolean;
  listId: number;
  listCode?: string;
  listName?: string;
}

export interface RawView { batchId: number; seq: number; fileName: string; available: boolean; format?: string; text: string; }

export interface User {
  username: string;
  displayName: string;
  roles: string[];
  active: boolean;
  createdAt?: string;
}

export const ROLES = ['ADMIN', 'OPERATOR', 'VALIDATOR', 'CERTIFIER', 'VIEWER', 'SUBSCRIBER'];
