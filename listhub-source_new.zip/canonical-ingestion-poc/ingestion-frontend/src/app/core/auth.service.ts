import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, switchMap, tap } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { User } from './models';

/** Login session of the current user and their roles. */
@Injectable({ providedIn: 'root' })
export class AuthService {

  user: User | null = null;

  constructor(private http: HttpClient) { }

  /** Loads the current user once (null when not logged in). */
  load(): Observable<User | null> {
    if (this.user) {
      return of(this.user);
    }
    return this.http.get<User>(`${environment.apiBase}/auth/me`).pipe(
      tap(u => this.user = u),
      catchError(() => of(null)));
  }

  login(username: string, password: string): Observable<User | null> {
    const body = new HttpParams().set('username', username).set('password', password);
    return this.http.get(`${environment.apiBase}/auth/csrf`).pipe(
      switchMap(() => this.http.post(`${environment.apiBase}/auth/login`, body.toString(),
        { headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' }) })),
      switchMap(() => { this.user = null; return this.load(); }));
  }

  logout(): Observable<unknown> {
    return this.http.post(`${environment.apiBase}/auth/logout`, {}).pipe(
      catchError(() => of(null)), tap(() => this.user = null));
  }

  changePassword(current: string, password: string): Observable<unknown> {
    return this.http.post(`${environment.apiBase}/auth/password`, { current, password });
  }

  has(...roles: string[]): boolean {
    if (!this.user) {
      return false;
    }
    return this.user.roles.indexOf('ADMIN') >= 0 || roles.some(r => this.user!.roles.indexOf(r) >= 0);
  }

  get name(): string {
    return this.user ? this.user.displayName || this.user.username : '';
  }

  isLoggedIn(): Observable<boolean> {
    return this.load().pipe(map(u => !!u));
  }
}
