import { Component } from '@angular/core';
import { AuthService } from '../core/auth.service';

@Component({
  selector: 'app-admin-shell',
  template: `
    <div class="frame">
      <aside class="side">
        <nav aria-label="Administration">
          <h4>Ingestion</h4>
          <a routerLink="/admin/import" routerLinkActive="on">Automatic import</a>
          <a routerLink="/admin/batches" routerLinkActive="on">Batches follow-up</a>
          <h4 *ngIf="auth.has('ADMIN')">Access</h4>
          <a routerLink="/admin/users" routerLinkActive="on" *ngIf="auth.has('ADMIN')">Users</a>
        </nav>
      </aside>
      <main class="main"><router-outlet></router-outlet></main>
    </div>
  `
})
export class AdminShellComponent {
  constructor(public auth: AuthService) { }
}
