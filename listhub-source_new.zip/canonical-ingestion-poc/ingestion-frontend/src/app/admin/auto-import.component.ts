import { Component, OnInit } from '@angular/core';
import { ApiService } from '../core/api.service';
import { AuthService } from '../core/auth.service';
import { errorText } from '../core/http.interceptor';
import { BatchView, ListDef, ListRow } from '../core/models';

@Component({
  selector: 'app-auto-import',
  template: `
    <div class="crumb">Administration / Automatic import</div>
    <div class="head"><div><h1>Automatic import</h1><p>Files put in the inbound folder are routed to a list by their name. Each list
      owns one file name pattern; the part the provider changes on every delivery is written as <span class="mono">*</span>.
      When two patterns match, the one with more fixed characters wins.</p></div></div>

    <section class="panel">
      <h2>Test a file name</h2>
      <form class="row" (ngSubmit)="test()">
        <input class="in mono grow" name="fn" [(ngModel)]="fileName" placeholder="s_xml_1158_158_20261107_1_f.xml" aria-label="File name">
        <button class="btn" type="submit">Test</button>
      </form>
      <div class="msg ok" *ngIf="routed && routed.list" style="margin-top: 10px">Goes to list <b>{{ routed.list.listCode }} {{ routed.list.name }}</b>
        (pattern <span class="mono">{{ routed.list.filePattern }}</span>), {{ routed.delivery }} delivery.</div>
      <div class="msg err" *ngIf="routed && !routed.list" style="margin-top: 10px">No list matches this name: the file would wait in “Files with no list”.</div>
    </section>

    <section>
      <div class="panel-head"><h2>Patterns and lists</h2><a class="btn" routerLink="/lists/new" *ngIf="auth.has('ADMIN')">New list</a></div>
      <div class="panel flush scroll">
        <table>
          <thead><tr><th>File name pattern</th><th>Delta pattern</th><th>List</th><th>Format</th><th>Approval</th><th>Status</th></tr></thead>
          <tbody>
            <tr *ngFor="let r of lists">
              <td class="mono">{{ r.list.filePattern || '–' }}</td>
              <td class="mono small">{{ r.list.deltaPattern || '–' }}</td>
              <td><a [routerLink]="['/lists', r.list.listId]">{{ r.list.listCode }} {{ r.list.name }}</a></td>
              <td>{{ r.list.fileFormat }}</td>
              <td>{{ r.list.workflow === 'AUTO' ? 'Automatic' : 'Validate + certify' }}</td>
              <td><span [class]="r.list.active ? 'pill p-ok' : 'pill p-grey'">{{ r.list.active ? 'Active' : 'Inactive' }}</span></td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <section class="panel" [style.border-color]="unmatched.length ? '#E8B7B1' : ''">
      <h2 [style.color]="unmatched.length ? 'var(--bad)' : ''">Files with no list ({{ unmatched.length }})</h2>
      <p class="muted" *ngIf="!unmatched.length">None: every received file matched a list.</p>
      <div class="msg err" *ngIf="error">{{ error }}</div>
      <div class="row" *ngFor="let b of unmatched" style="border-top: 1px solid var(--line-2); padding-top: 10px; margin-top: 10px">
        <div class="grow"><span class="mono">{{ b.batch.fileName }}</span>
          <div class="small muted">received {{ b.batch.receivedAt | when }} · {{ b.batch.fileSize | bytes }} · stored, not loaded</div></div>
        <ng-container *ngIf="auth.has('OPERATOR')">
          <select class="in" [(ngModel)]="assignTo[b.batch.batchId]" [name]="'as' + b.batch.batchId" aria-label="List">
            <option [ngValue]="undefined">Choose a list...</option>
            <option *ngFor="let r of lists" [ngValue]="r.list.listId">{{ r.list.listCode }} {{ r.list.name }}</option></select>
          <button class="btn primary" type="button" [disabled]="!assignTo[b.batch.batchId]" (click)="assign(b.batch.batchId)">Assign and load</button>
        </ng-container>
      </div>
    </section>
  `
})
export class AutoImportComponent implements OnInit {
  lists: ListRow[] = [];
  unmatched: BatchView[] = [];
  fileName = '';
  routed: { list?: ListDef; delivery?: string } | null = null;
  assignTo: { [batchId: number]: number | undefined } = {};
  error = '';

  constructor(private api: ApiService, public auth: AuthService) { }

  ngOnInit(): void {
    this.api.lists().subscribe(l => this.lists = l);
    this.loadUnmatched();
  }

  loadUnmatched(): void {
    this.api.batches(90).subscribe(b => this.unmatched = b.filter(x => x.batch.status === 'UNMATCHED'));
  }

  test(): void {
    if (this.fileName.trim()) {
      this.api.route(this.fileName.trim()).subscribe(r => this.routed = r);
    }
  }

  assign(batchId: number): void {
    const listId = this.assignTo[batchId];
    if (!listId) { return; }
    this.api.assign(batchId, listId).subscribe(() => this.loadUnmatched(), e => this.error = errorText(e));
  }
}
