import { Component, OnInit } from '@angular/core';
import { ApiService } from '../core/api.service';
import { AuthService } from '../core/auth.service';
import { errorText } from '../core/http.interceptor';
import { ROLES, User } from '../core/models';

@Component({
  selector: 'app-users',
  template: `
    <div class="crumb">Administration / Users</div>
    <div class="head"><div><h1>Users</h1><p>Validation and certification of a version must be done by two different users.
      Subscribers use the API only (/api/v1) with their user name and password.</p></div></div>
    <div class="msg err" *ngIf="error">{{ error }}</div>
    <div class="msg ok" *ngIf="info">{{ info }}</div>
    <div class="panel flush scroll">
      <table>
        <thead><tr><th>User</th><th>Name</th><th>Roles</th><th>Active</th><th></th></tr></thead>
        <tbody>
          <tr *ngFor="let u of users">
            <td class="mono">{{ u.username }}</td>
            <td><input class="in" [(ngModel)]="u.displayName" [name]="'n' + u.username"></td>
            <td><label class="check" *ngFor="let r of roles"><input type="checkbox" [checked]="u.roles.indexOf(r) >= 0" (change)="toggle(u, r)"> {{ r.toLowerCase() }}</label></td>
            <td><input type="checkbox" [(ngModel)]="u.active" [name]="'a' + u.username" aria-label="Active"></td>
            <td class="nowrap"><button class="btn small" type="button" (click)="save(u)">Save</button>
              <button class="btn small" type="button" (click)="reset(u)">New password</button></td>
          </tr>
        </tbody>
      </table>
    </div>
    <form class="panel" (ngSubmit)="create()">
      <h2>Add a user</h2>
      <div class="form">
        <label class="field">User name<input name="u" [(ngModel)]="nu.username" required maxlength="60"></label>
        <label class="field">Name<input name="d" [(ngModel)]="nu.displayName" maxlength="120"></label>
        <label class="field span2">First password<input name="p" type="password" [(ngModel)]="nu.password" autocomplete="new-password">
          <span class="hint">At least 10 characters with a letter and a digit</span></label>
        <div class="field span4">Roles<div><label class="check" *ngFor="let r of roles"><input type="checkbox"
            [checked]="nu.roles.indexOf(r) >= 0" (change)="toggleNew(r)"> {{ r.toLowerCase() }}</label></div></div>
      </div>
      <button class="btn primary" type="submit" style="margin-top: 14px">Add the user</button>
    </form>
  `
})
export class UsersComponent implements OnInit {
  users: User[] = [];
  roles = ROLES;
  nu = { username: '', displayName: '', password: '', roles: ['VIEWER'] as string[] };
  error = '';
  info = '';

  constructor(private api: ApiService, public auth: AuthService) { }

  ngOnInit(): void { this.load(); }

  load(): void { this.api.users().subscribe(u => this.users = u, e => this.error = errorText(e)); }

  toggle(u: User, r: string): void {
    u.roles = u.roles.indexOf(r) >= 0 ? u.roles.filter(x => x !== r) : u.roles.concat(r);
  }

  toggleNew(r: string): void {
    this.nu.roles = this.nu.roles.indexOf(r) >= 0 ? this.nu.roles.filter(x => x !== r) : this.nu.roles.concat(r);
  }

  save(u: User): void {
    this.clear();
    this.api.updateUser(u.username, { displayName: u.displayName, roles: u.roles, active: u.active })
      .subscribe(() => this.info = 'Saved ' + u.username, e => this.error = errorText(e));
  }

  reset(u: User): void {
    const p = window.prompt('New password for ' + u.username + ' (10+ characters, a letter and a digit)');
    if (p) {
      this.clear();
      this.api.resetPassword(u.username, p).subscribe(() => this.info = 'Password changed for ' + u.username, e => this.error = errorText(e));
    }
  }

  create(): void {
    this.clear();
    this.api.createUser(this.nu).subscribe(() => {
      this.info = 'User ' + this.nu.username + ' added';
      this.nu = { username: '', displayName: '', password: '', roles: ['VIEWER'] };
      this.load();
    }, e => this.error = errorText(e));
  }

  private clear(): void { this.error = ''; this.info = ''; }
}
