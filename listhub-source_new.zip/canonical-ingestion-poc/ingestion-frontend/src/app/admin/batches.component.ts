import { Component, OnDestroy, OnInit } from '@angular/core';
import { interval, Subscription } from 'rxjs';
import { startWith, switchMap } from 'rxjs/operators';
import { ApiService } from '../core/api.service';
import { BatchView } from '../core/models';
import { statusClass } from '../shared/format';

const COLORS: { [k: string]: string } = { RECEIVE: '#B8C1CC', RAW_LOAD: '#16233A', CANONICAL: '#1E4E8C', EXPORT: '#2F6B4F' };

@Component({
  selector: 'app-batches',
  template: `
    <div class="crumb">Administration / Batches follow-up</div>
    <div class="head"><div><h1>Batches follow-up</h1><p>Every received file and the time of each step. Validation and certification are
      manual and not counted in the time.</p></div>
      <div class="row"><select class="in" [(ngModel)]="days" (ngModelChange)="reload()" aria-label="Period">
        <option [ngValue]="0">Today</option><option [ngValue]="7">Last 7 days</option><option [ngValue]="30">Last 30 days</option></select></div></div>
    <div class="row small">
      <span *ngFor="let k of stepCodes" class="row" style="gap: 6px"><span [style.background]="colors[k]" style="width: 12px; height: 12px; border-radius: 3px; display: inline-block"></span>{{ k | step }}</span>
    </div>
    <div class="cols">
      <section class="wide panel flush scroll">
        <table>
          <thead><tr><th>File</th><th>List</th><th>Status</th><th style="width: 30%">Time per step</th><th class="num">Total</th></tr></thead>
          <tbody>
            <tr *ngFor="let b of batches" class="click" [class.sel]="sel?.batch?.batchId === b.batch.batchId" (click)="sel = b">
              <td><span class="mono small">{{ b.batch.fileName }}</span><div class="small muted">batch {{ b.batch.batchId }} · {{ b.batch.receivedAt | when }} ·
                {{ b.batch.recordCount | n }} records</div></td>
              <td class="small">{{ b.listCode || '–' }} {{ b.listName || '' }}</td>
              <td><span [class]="cls(b.batch.status)">{{ b.batch.status | status }}</span>
                <div *ngIf="b.progress" class="small muted">{{ b.progress.phase }} {{ b.progress.percent }}%</div></td>
              <td><div class="bar"><span *ngFor="let s of b.steps" [style.width.%]="pct(b, s.durationMs)" [style.background]="colors[s.code]" [title]="s.code"></span></div></td>
              <td class="num nowrap" style="font-weight: 600">{{ b.processingMs | dur }}</td>
            </tr>
            <tr *ngIf="!batches.length"><td colspan="5" class="empty">No file in this period.</td></tr>
          </tbody>
        </table>
      </section>
      <section class="narrow panel" *ngIf="sel as b">
        <h2>Batch {{ b.batch.batchId }}</h2>
        <p class="mono small">{{ b.batch.fileName }}</p>
        <p class="small muted">{{ b.batch.message }}</p>
        <div *ngFor="let s of b.steps" style="margin-bottom: 12px">
          <div class="row" style="justify-content: space-between"><b>{{ s.code | step }}</b><b>{{ s.durationMs | dur }}</b></div>
          <div class="bar" style="margin: 4px 0"><span [style.width.%]="pct(b, s.durationMs)" [style.background]="colors[s.code]"></span></div>
          <div class="small muted">{{ s.result || 'running…' }}</div>
        </div>
        <div class="row" style="justify-content: space-between; border-top: 1px solid var(--line); padding-top: 10px"><b>Total</b><b>{{ b.processingMs | dur }}</b></div>
        <a class="btn" style="margin-top: 12px" *ngIf="b.batch.versionNo" [routerLink]="['/lists', b.batch.listId, 'versions', b.batch.versionNo]">Open version {{ b.batch.versionNo }}</a>
      </section>
    </div>
  `
})
export class BatchesComponent implements OnInit, OnDestroy {
  batches: BatchView[] = [];
  sel: BatchView | null = null;
  days = 7;
  colors = COLORS;
  stepCodes = Object.keys(COLORS);
  cls = statusClass;
  private sub?: Subscription;

  constructor(private api: ApiService) { }

  ngOnInit(): void { this.reload(); }

  reload(): void {
    this.sub?.unsubscribe();
    this.sub = interval(5000).pipe(startWith(0), switchMap(() => this.api.batches(this.days))).subscribe(b => {
      this.batches = b;
      if (this.sel) {
        this.sel = b.find(x => x.batch.batchId === this.sel!.batch.batchId) || null;
      } else if (b.length) {
        this.sel = b[0];
      }
    });
  }

  ngOnDestroy(): void { this.sub?.unsubscribe(); }

  pct(b: BatchView, ms: number | undefined): number {
    return b.processingMs && ms ? Math.max(1, ms * 100 / b.processingMs) : 0;
  }
}
