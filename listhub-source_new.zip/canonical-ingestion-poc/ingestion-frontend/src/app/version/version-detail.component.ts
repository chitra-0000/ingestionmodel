import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../core/api.service';
import { AuthService } from '../core/auth.service';
import { errorText } from '../core/http.interceptor';
import { ChangePage, ChangeRow, RawView, VersionView } from '../core/models';
import { statusClass } from '../shared/format';

interface CardDef { type: string; title: string; sub: string; css: string; }

const CARDS: { [k: string]: CardDef } = {
  CREATED: { type: 'CREATED', title: 'Created', sub: 'new in the provider file; each got a new internal id', css: 'c-created' },
  DELETED: { type: 'DELETED', title: 'Deleted', sub: 'closed in this version; history kept', css: 'c-deleted' },
  MODIFIED: { type: 'MODIFIED', title: 'Modified', sub: 'name, date of birth, country, id or list changed', css: 'c-modified' },
  MINOR: { type: 'MINOR', title: 'Minor updates', sub: 'only a source, note or date changed', css: 'c-minor' },
  REJECTED: { type: 'REJECTED', title: 'Rejected: not loaded', sub: 'failed a blocking quality check', css: 'c-rejected' },
  FLAGGED: { type: 'FLAGGED', title: 'Loaded with a flag', sub: 'loaded; a value needs a look', css: 'c-flagged' }
};

@Component({
  selector: 'app-version-detail',
  templateUrl: './version-detail.component.html'
})
export class VersionDetailComponent implements OnInit {
  listId = 0;
  v = 0;
  view: VersionView | null = null;
  type = 'MODIFIED';
  q = '';
  page = 0;
  size = 25;
  changes: ChangePage | null = null;
  selected: ChangeRow | null = null;
  raw: RawView | null = null;
  pdf = '';
  comment = '';
  error = '';
  info = '';
  busy = false;
  cards = CARDS;
  cls = statusClass;

  constructor(private route: ActivatedRoute, public api: ApiService, public auth: AuthService) { }

  ngOnInit(): void {
    this.listId = +(this.route.parent!.snapshot.paramMap.get('id') || 0);
    this.route.paramMap.subscribe(p => {
      this.v = +(p.get('v') || 0);
      this.load();
    });
  }

  load(): void {
    this.api.version(this.listId, this.v).subscribe(view => {
      this.view = view;
      const ver = view.version;
      const first = ver.modifiedCount ? 'MODIFIED' : ver.createdCount ? 'CREATED' : ver.deletedCount ? 'DELETED'
        : ver.rejectedCount ? 'REJECTED' : 'MODIFIED';
      this.pick(first);
    }, e => this.error = errorText(e));
  }

  count(type: string): number {
    if (!this.view) { return 0; }
    const v = this.view.version;
    switch (type) {
      case 'CREATED': return v.createdCount;
      case 'DELETED': return v.deletedCount;
      case 'MODIFIED': return v.modifiedCount;
      case 'MINOR': return v.minorCount;
      case 'REJECTED': return v.rejectedCount;
      default: return v.flaggedCount;
    }
  }

  pick(type: string): void {
    this.type = type;
    this.page = 0;
    this.q = '';
    this.fetch();
  }

  fetch(): void {
    this.api.changes(this.listId, this.v, this.type, this.q, this.page, this.size).subscribe(c => {
      this.changes = c;
      this.selected = null;
      this.raw = null;
      if (c.rows.length) { this.open(c.rows[0]); }
    }, e => this.error = errorText(e));
  }

  go(delta: number): void {
    this.page = Math.max(0, this.page + delta);
    this.fetch();
  }

  get pages(): number {
    return this.changes ? Math.max(1, Math.ceil(this.changes.total / this.size)) : 1;
  }

  open(r: ChangeRow): void {
    this.raw = null;
    this.api.change(this.listId, this.v, r.type, r.seq).subscribe(c => this.selected = c, e => this.error = errorText(e));
  }

  showRaw(): void {
    if (this.raw) { this.raw = null; return; }
    const s = this.selected;
    if (s && s.rawSeq) {
      this.api.raw(s.batchId, s.rawSeq).subscribe(r => this.raw = r, e => this.error = errorText(e));
    }
  }

  openPdf(): void {
    const s = this.selected;
    if (s && s.rglId) {
      this.pdf = this.api.pdfUrl(s.rglId, s.type === 'DELETED' ? this.v - 1 : this.v);
    }
  }

  note(): string {
    const s = this.selected;
    if (!s) { return ''; }
    switch (s.type) {
      case 'CREATED': return 'New internal id ' + s.rglId + ': provider id ' + (s.externalRef || '(match key)') + ' was not known in this list.';
      case 'MODIFIED': return 'Same internal id as before: provider id ' + (s.externalRef || '') + ' matched. The previous values stay in the history.';
      case 'MINOR': return 'Only minor attributes changed (source, note, provider date). Not sent as a change to screening.';
      case 'DELETED': return (s.summary || '') + '. The record and its history stay searchable.';
      case 'REJECTED': return 'Not loaded in this version. It stays in stage 1 (raw), so you can see what the provider sent.';
      default: return 'Loaded and published as received; the value below needs a look.';
    }
  }

  detailChanges(): { field: string; before?: string; after?: string }[] {
    return this.selected && this.selected.detail && this.selected.detail.changes ? this.selected.detail.changes : [];
  }

  detailIssues(): { code: string; severity: string; field?: string; value?: string; message: string }[] {
    return this.selected && this.selected.detail && this.selected.detail.issues ? this.selected.detail.issues : [];
  }

  detailValues(): string[][] {
    return this.selected && this.selected.detail && this.selected.detail.values ? this.selected.detail.values : [];
  }

  issueRows(kind: 'reject' | 'flag'): { code: string; n: number; pct: number }[] {
    const m = this.view && this.view.issues ? this.view.issues[kind] : null;
    if (!m) { return []; }
    const total = Object.keys(m).reduce((a, k) => a + m[k], 0) || 1;
    return Object.keys(m).map(k => ({ code: k, n: m[k], pct: Math.round(m[k] * 100 / total) }));
  }

  codeLabel(c: string): string {
    const l: { [k: string]: string } = {
      NO_NAME: 'Primary name missing', NO_KEY: 'Provider id missing', DUP_KEY: 'Provider id twice in the file',
      PARSE: 'Record cannot be read', BAD_DATE: 'Date is not a valid date', BAD_COUNTRY: 'Country not recognised'
    };
    return l[c] || c;
  }

  stepMs(code: string): number | undefined {
    const s = this.view && this.view.steps ? this.view.steps.find(x => x.code === code) : undefined;
    return s ? s.durationMs : undefined;
  }

  canValidate(): boolean { return !!this.view && this.view.version.status === 'TO_VALIDATE' && this.auth.has('VALIDATOR'); }

  canCertify(): boolean {
    return !!this.view && this.view.version.status === 'VALIDATED' && this.auth.has('CERTIFIER')
      && !!this.auth.user && this.auth.user.username !== this.view.version.validatedBy;
  }

  canReject(): boolean {
    return !!this.view && (this.view.version.status === 'TO_VALIDATE' || this.view.version.status === 'VALIDATED')
      && this.auth.has('VALIDATOR', 'CERTIFIER');
  }

  validate(): void { this.act(this.api.validate(this.listId, this.v, this.comment), 'Version validated. Another user must certify it.'); }
  certify(): void { this.act(this.api.certify(this.listId, this.v), 'Version certified and published. Export files are written.'); }
  reject(): void { this.act(this.api.reject(this.listId, this.v, this.comment), 'Version rejected: its records were taken back.'); }
  reExport(): void { this.act(this.api.reExport(this.listId, this.v), 'Export files written again.'); }

  private act(obs: import('rxjs').Observable<unknown>, msg: string): void {
    this.busy = true;
    this.error = '';
    obs.subscribe(() => { this.busy = false; this.info = msg; this.load(); }, e => { this.busy = false; this.error = errorText(e); });
  }
}
