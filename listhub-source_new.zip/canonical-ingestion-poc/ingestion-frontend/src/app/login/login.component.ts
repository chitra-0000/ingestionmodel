import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../core/auth.service';

@Component({
  selector: 'app-login',
  template: `
    <div class="login">
      <form (ngSubmit)="submit()" autocomplete="on">
        <div class="row" style="gap: 10px">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1E4E8C" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h10"></path><path d="M17 17l2 2 3-4"></path></svg>
          <h1 style="font-size: 22px">ListHub</h1>
        </div>
        <p class="muted" style="margin: 0">Sanctions and monitoring lists: load, check, publish.</p>
        <label class="field">User name
          <input name="username" [(ngModel)]="username" autocomplete="username" required>
        </label>
        <label class="field">Password
          <input name="password" type="password" [(ngModel)]="password" autocomplete="current-password" required>
        </label>
        <div class="msg err" *ngIf="error">{{ error }}</div>
        <button class="btn primary" type="submit" [disabled]="busy || !username || !password">Sign in</button>
      </form>
    </div>
  `
})
export class LoginComponent {
  username = '';
  password = '';
  error = '';
  busy = false;

  constructor(private auth: AuthService, private router: Router) { }

  submit(): void {
    this.busy = true;
    this.error = '';
    this.auth.login(this.username, this.password).subscribe(u => {
      this.busy = false;
      if (u) {
        this.router.navigateByUrl('/');
      } else {
        this.error = 'Wrong user name or password';
      }
    }, () => {
      this.busy = false;
      this.error = 'Wrong user name or password';
    });
  }
}
