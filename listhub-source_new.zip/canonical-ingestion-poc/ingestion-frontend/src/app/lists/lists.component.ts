import { Component, OnInit } from '@angular/core';
import { ApiService } from '../core/api.service';
import { AuthService } from '../core/auth.service';
import { ListRow } from '../core/models';
import { statusClass } from '../shared/format';

@Component({
  selector: 'app-lists',
  template: `
    <div class="page">
      <div class="head">
        <div><h1>Lists</h1><p>Each list receives the files whose name matches its pattern. Open a list to see its versions,
          its mapping and its files.</p></div>
        <div class="row">
          <input class="in" placeholder="Filter by code, name or provider" [(ngModel)]="filter" aria-label="Filter lists">
          <a class="btn primary" routerLink="/lists/new" *ngIf="auth.has('ADMIN')">New list</a>
        </div>
      </div>
      <div class="panel flush scroll">
        <table>
          <thead><tr><th>Code</th><th>Name</th><th>Provider</th><th>File name pattern</th><th class="num">Records</th>
            <th>Last version</th><th>Published</th><th>Mapping</th></tr></thead>
          <tbody>
            <tr *ngFor="let r of shown()" class="click" [routerLink]="['/lists', r.list.listId]">
              <td class="mono">{{ r.list.listCode }}</td>
              <td><a [routerLink]="['/lists', r.list.listId]">{{ r.list.name }}</a>
                <span class="pill p-grey" *ngIf="!r.list.active" style="margin-left: 6px">Inactive</span></td>
              <td>{{ r.list.providerCode }}</td>
              <td class="mono small">{{ r.list.filePattern || '–' }}</td>
              <td class="num">{{ r.records | n }}</td>
              <td><ng-container *ngIf="r.lastVersion; else none">V{{ r.lastVersion.versionNo }}
                <span [class]="cls(r.lastVersion.status)">{{ r.lastVersion.status | status }}</span></ng-container>
                <ng-template #none><span class="muted">–</span></ng-template></td>
              <td>{{ r.publishedVersion ? 'V' + r.publishedVersion : '–' }}</td>
              <td><span [class]="r.mappingApproved ? 'pill p-ok' : 'pill p-warn'">{{ r.mappingApproved ? 'Approved' : 'To review' }}</span></td>
            </tr>
            <tr *ngIf="loaded && !rows.length"><td colspan="8" class="empty">No list yet. Create the first one with “New list”.</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  `
})
export class ListsComponent implements OnInit {
  rows: ListRow[] = [];
  filter = '';
  loaded = false;
  cls = statusClass;

  constructor(private api: ApiService, public auth: AuthService) { }

  ngOnInit(): void {
    this.api.lists().subscribe(r => { this.rows = r; this.loaded = true; });
  }

  shown(): ListRow[] {
    const f = this.filter.trim().toLowerCase();
    return !f ? this.rows : this.rows.filter(r => (r.list.listCode + ' ' + r.list.name + ' ' + r.list.providerCode).toLowerCase().indexOf(f) >= 0);
  }
}
