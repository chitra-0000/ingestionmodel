import { Component, EventEmitter, Input, Output } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

/** The record sheet PDF in a dialog, served by the backend (same origin). */
@Component({
  selector: 'app-pdf-viewer',
  template: `
    <div class="overlay" role="dialog" aria-modal="true" aria-label="Record PDF" (click)="close.emit()">
      <div class="modal" (click)="$event.stopPropagation()">
        <div class="modal-bar">
          <span class="mono">{{ title }}</span>
          <span class="row" style="gap: 8px">
            <a class="btn small" [href]="url" download>Download</a>
            <a class="btn small" [href]="url" target="_blank" rel="noopener">Open in a new tab</a>
            <button class="btn small" type="button" (click)="close.emit()">Close</button>
          </span>
        </div>
        <iframe [src]="safe" title="Record sheet"></iframe>
      </div>
    </div>
  `
})
export class PdfViewerComponent {
  @Input() title = '';
  @Output() close = new EventEmitter<void>();
  url = '';
  safe: SafeResourceUrl | null = null;

  constructor(private sanitizer: DomSanitizer) { }

  /** Only our own API path is ever passed here (built by ApiService.pdfUrl). */
  @Input() set src(v: string) {
    this.url = v;
    this.safe = v.startsWith('/api/') ? this.sanitizer.bypassSecurityTrustResourceUrl(v) : null;
  }
}
