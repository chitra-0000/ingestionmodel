import { Pipe, PipeTransform } from '@angular/core';

/** 1234567 -> 12,34,567 is not used: numbers are shown with thousands separators of the browser locale. */
@Pipe({ name: 'n' })
export class NumberPipe implements PipeTransform {
  transform(v: number | null | undefined): string {
    return v === null || v === undefined ? '–' : Number(v).toLocaleString('en-IN');
  }
}

@Pipe({ name: 'bytes' })
export class BytesPipe implements PipeTransform {
  transform(v: number | null | undefined): string {
    if (v === null || v === undefined) { return '–'; }
    const u = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    let n = v;
    while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return (i === 0 ? n : n.toFixed(1)) + ' ' + u[i];
  }
}

@Pipe({ name: 'dur' })
export class DurationPipe implements PipeTransform {
  transform(ms: number | null | undefined): string {
    if (ms === null || ms === undefined) { return '–'; }
    const s = Math.round(ms / 1000);
    if (s < 60) { return (ms < 1000 && ms > 0 ? '<1' : s) + ' s'; }
    const m = Math.floor(s / 60);
    const r = s % 60;
    return r ? `${m} min ${r} s` : `${m} min`;
  }
}

@Pipe({ name: 'when' })
export class WhenPipe implements PipeTransform {
  transform(v: string | null | undefined): string {
    if (!v) { return '–'; }
    const d = new Date(v);
    const today = new Date();
    const time = d.toTimeString().substring(0, 5);
    if (d.toDateString() === today.toDateString()) { return time; }
    return d.toISOString().substring(0, 10) + ' ' + time;
  }
}

/** CSS class of a batch / version / change status. */
export function statusClass(s: string | undefined): string {
  switch (s) {
    case 'PUBLISHED': case 'CREATED': return 'pill p-ok';
    case 'FAILED': case 'REJECTED': case 'DELETED': case 'UNMATCHED': return 'pill p-bad';
    case 'MAPPING_REVIEW': case 'WAITING': case 'FLAGGED': case 'DUPLICATE': return 'pill p-warn';
    case 'TO_VALIDATE': case 'VALIDATED': case 'MODIFIED': return 'pill p-act';
    default: return 'pill p-grey';
  }
}

const LABELS: { [k: string]: string } = {
  QUEUED: 'Queued', UNMATCHED: 'No matching list', LOADING: 'Raw load running', LOADED: 'Raw loaded',
  MAPPING_REVIEW: 'Mapping review', WAITING: 'Waiting', PROCESSING: 'Canonical running', TO_VALIDATE: 'To validate',
  VALIDATED: 'To certify', PUBLISHED: 'Published', REJECTED: 'Rejected', DUPLICATE: 'Same as previous', FAILED: 'Failed',
  CREATED: 'Created', MODIFIED: 'Modified', MINOR: 'Minor update', DELETED: 'Deleted', FLAGGED: 'Flagged'
};

@Pipe({ name: 'status' })
export class StatusPipe implements PipeTransform {
  transform(s: string | undefined): string { return s ? (LABELS[s] || s) : '–'; }
}

const STEPS: { [k: string]: string } = {
  RECEIVE: 'File received', RAW_LOAD: 'Raw load (stage 1)', CANONICAL: 'Canonical, quality, changes (stage 2)',
  EXPORT: 'Publication and export files'
};

@Pipe({ name: 'step' })
export class StepPipe implements PipeTransform {
  transform(s: string): string { return STEPS[s] || s; }
}
