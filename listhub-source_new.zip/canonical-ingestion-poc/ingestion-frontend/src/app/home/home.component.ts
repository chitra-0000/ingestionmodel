import { Component, OnDestroy, OnInit } from '@angular/core';
import { interval, Subscription } from 'rxjs';
import { startWith, switchMap } from 'rxjs/operators';
import { ApiService } from '../core/api.service';
import { AuthService } from '../core/auth.service';
import { BatchView, Summary } from '../core/models';
import { statusClass } from '../shared/format';

@Component({
  selector: 'app-home',
  template: `
    <div class="page">
      <div class="cols">
        <section class="narrow" style="max-width: 420px; display: flex; flex-direction: column; gap: 16px">
          <div>
            <h1>Welcome, {{ auth.name }}</h1>
            <p class="muted" style="margin-top: 8px">Files dropped in the inbound folder are loaded by themselves: every record is
              stored as received, mapped to one common record, checked, and a new list version waits for validation.</p>
          </div>
          <div class="row">
            <a class="btn primary" routerLink="/lists">Lists and upload</a>
            <a class="btn" routerLink="/records">Search records</a>
          </div>
          <div class="panel" *ngIf="summary">
            <h2>Waiting for you</h2>
            <div class="grid2" style="gap: 10px">
              <a class="card c-modified" routerLink="/lists"><span class="lbl">To validate</span><span class="big">{{ summary.toValidate }}</span></a>
              <a class="card c-modified" routerLink="/lists"><span class="lbl">To certify</span><span class="big">{{ summary.toCertify }}</span></a>
              <a class="card c-flagged" routerLink="/admin/batches"><span class="lbl">Mapping review</span><span class="big">{{ summary.mappingReview }}</span></a>
              <a class="card c-deleted" routerLink="/admin/import"><span class="lbl">Files with no list</span><span class="big">{{ summary.unmatched }}</span></a>
            </div>
            <p class="muted small" style="margin: 12px 0 0">Running now: {{ summary.running }} files ·
              {{ summary.parallelFiles }} files at a time, {{ summary.workersPerFile }} workers each.</p>
          </div>
        </section>
        <section class="wide">
          <div class="panel-head"><h2>Today's files</h2><a routerLink="/admin/batches">Batches follow-up</a></div>
          <div class="panel flush scroll">
            <table>
              <thead><tr><th>List</th><th>File</th><th>Status</th><th class="num">Records</th><th class="num">Time</th></tr></thead>
              <tbody>
                <tr *ngFor="let b of today">
                  <td><a *ngIf="b.batch.listId" [routerLink]="b.batch.versionNo ? ['/lists', b.batch.listId, 'versions', b.batch.versionNo] : ['/lists', b.batch.listId, 'import']">
                      {{ b.listCode }} {{ b.listName }}</a><span *ngIf="!b.batch.listId" class="muted">No list</span>
                    <div class="small muted" *ngIf="b.batch.versionNo">Version {{ b.batch.versionNo }}</div></td>
                  <td class="mono small">{{ b.batch.fileName }}</td>
                  <td><span [class]="cls(b.batch.status)">{{ b.batch.status | status }}</span>
                    <div class="progress" *ngIf="b.progress?.percent !== undefined && b.progress?.percent !== null" style="margin-top: 6px">
                      <span [style.width.%]="b.progress?.percent"></span></div>
                    <div class="small muted" *ngIf="b.progress">{{ b.progress.phase }} {{ b.progress.percent }}%</div></td>
                  <td class="num">{{ b.batch.recordCount | n }}</td>
                  <td class="num nowrap">{{ b.processingMs | dur }}</td>
                </tr>
                <tr *ngIf="!today.length"><td colspan="5" class="empty">No file received today.</td></tr>
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  `
})
export class HomeComponent implements OnInit, OnDestroy {
  summary: Summary | null = null;
  today: BatchView[] = [];
  private sub?: Subscription;
  cls = statusClass;

  constructor(private api: ApiService, public auth: AuthService) { }

  ngOnInit(): void {
    this.sub = interval(10000).pipe(startWith(0), switchMap(() => this.api.batches(0))).subscribe(b => this.today = b);
    this.api.summary().subscribe(s => this.summary = s);
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }
}
