package com.bank.ingestion;

import com.bank.ingestion.domain.Batch;
import com.bank.ingestion.domain.BatchStatus;
import com.bank.ingestion.domain.ListDef;
import com.bank.ingestion.domain.ListVersion;
import com.bank.ingestion.repository.BatchRepository;
import com.bank.ingestion.repository.VersionRepository;
import com.bank.ingestion.service.admin.ListService;
import com.bank.ingestion.service.batch.BatchService;
import com.bank.ingestion.service.canonical.MappingService;
import com.bank.ingestion.service.version.VersionService;
import com.bank.ingestion.tools.SampleFiles;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Volume run (not part of the normal build): mvn test -Dtest=VolumeRunTest -Dperf.records=1000000 -Dperf.dir=/data/perf
 * Loads a full file (version 1), publishes it, then a second full file (version 2) and prints the time of each step.
 */
@SpringBootTest
@ActiveProfiles("h2")
@EnabledIfSystemProperty(named = "perf.records", matches = "\\d+")
class VolumeRunTest {

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) {
        r.add("listhub.base-dir", () -> System.getProperty("perf.dir", "target/perf"));
        r.add("listhub.inbound.enabled", () -> "false");
        r.add("listhub.admin.password", () -> "Admin12345678");
        r.add("listhub.profile-records", () -> "5000");
    }

    @Autowired ListService lists;
    @Autowired BatchService batches;
    @Autowired BatchRepository batchRepo;
    @Autowired MappingService mappings;
    @Autowired VersionService versionService;
    @Autowired VersionRepository versions;

    @Test
    void run() throws Exception {
        int records = Integer.parseInt(System.getProperty("perf.records"));
        Path dir = Paths.get(System.getProperty("perf.dir", "target/perf")).toAbsolutePath();
        Files.createDirectories(dir);
        ListDef l = new ListDef();
        l.setListCode("P" + (System.currentTimeMillis() % 100000));
        l.setName("Volume run");
        l.setProviderCode("DOWJONES");
        l.setFilePattern("vol_*");
        l.setExportFormats("CSV");
        long listId = lists.create(l, "admin").getListId();

        for (int v = 1; v <= 2; v++) {
            Path f = dir.resolve("vol_" + v + ".xml");
            long g = System.currentTimeMillis();
            SampleFiles.djXml(f, records, v);
            System.out.printf("PERF file v%d: %,d bytes generated in %d s%n", v, Files.size(f), (System.currentTimeMillis() - g) / 1000);
            Path work = dir.resolve("work").resolve("vol_" + v + ".xml");
            Files.createDirectories(work.getParent());
            Files.move(f, work);
            long t0 = System.currentTimeMillis();
            Batch b = batches.register(work, "vol_" + v + ".xml", Files.size(work), System.nanoTime(), "UPLOAD", listId, "perf");
            b = waitFor(b.getBatchId(), v > 1);
            if (b.getStatus() == BatchStatus.MAPPING_REVIEW) {
                mappings.approve(listId, "admin");
                batches.resume();
                b = waitFor(b.getBatchId(), true);
            }
            long total = System.currentTimeMillis() - t0;
            ListVersion lv = versions.find(listId, v).orElseThrow(IllegalStateException::new);
            Map<Long, List<BatchRepository.Step>> steps = batchRepo.steps(Collections.singletonList(b.getBatchId()));
            for (BatchRepository.Step s : steps.get(b.getBatchId())) {
                System.out.printf("PERF v%d %-10s %8.1f s  %s%n", v, s.code, s.durationMs == null ? 0 : s.durationMs / 1000.0, s.result);
            }
            System.out.printf("PERF v%d end to end (without approval wait) %.1f s; created %,d modified %,d minor %,d deleted %,d "
                            + "unchanged %,d rejected %,d%n", v, total / 1000.0, lv.getCreatedCount(), lv.getModifiedCount(),
                    lv.getMinorCount(), lv.getDeletedCount(), lv.getUnchangedCount(), lv.getRejectedCount());
            long p0 = System.currentTimeMillis();
            versionService.validate(listId, v, "anna", null);
            versionService.certify(listId, v, "bruno");
            System.out.printf("PERF v%d publication with export %.1f s%n", v, (System.currentTimeMillis() - p0) / 1000.0);
            Files.deleteIfExists(Paths.get(batches.get(b.getBatchId()).getWorkPath()));
        }
    }

    private Batch waitFor(long id, boolean pastReview) throws InterruptedException {
        while (true) {
            Batch b = batches.get(id);
            if (b.getStatus() == BatchStatus.TO_VALIDATE || b.getStatus().isFinal()
                    || (!pastReview && b.getStatus() == BatchStatus.MAPPING_REVIEW)) {
                return b;
            }
            Thread.sleep(500);
        }
    }
}
