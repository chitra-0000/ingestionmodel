package com.bank.ingestion;

import com.bank.ingestion.domain.AttrType;
import com.bank.ingestion.domain.CanonicalRecord;
import com.bank.ingestion.domain.Layout;
import com.bank.ingestion.domain.MappingRules;
import com.bank.ingestion.service.admin.ListService;
import com.bank.ingestion.service.canonical.AutoMapper;
import com.bank.ingestion.service.canonical.DateNormalizer;
import com.bank.ingestion.service.canonical.Mapper;
import com.bank.ingestion.service.canonical.RecordDiff;
import com.bank.ingestion.service.raw.FieldProfiler;
import com.bank.ingestion.service.raw.PathExpr;
import com.bank.ingestion.service.raw.RNode;
import com.bank.ingestion.service.raw.RawFileReader;
import com.bank.ingestion.service.raw.RecordParser;
import com.bank.ingestion.service.raw.RefTable;
import com.bank.ingestion.tools.SampleFiles;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class UnitTests {

    /** Collects what the reader finds. */
    static final class Collect implements RawFileReader.Sink {
        final List<byte[]> records = new ArrayList<>();
        final List<String> keys = new ArrayList<>();
        final Map<String, Map<String, String>> refs = new LinkedHashMap<>();

        @Override
        public void record(String element, String key, byte[] payload) {
            records.add(payload);
            keys.add(key);
        }

        @Override
        public void ref(String listName, String code, String label) {
            refs.computeIfAbsent(listName, k -> new HashMap<>()).put(code, label);
        }
    }

    private static InputStream in(String s) {
        return new ByteArrayInputStream(s.getBytes(StandardCharsets.UTF_8));
    }

    @Test
    void xmlLayoutRecordsAndReferenceListsAreFoundWithoutConfiguration(@TempDir Path dir) throws IOException {
        Path f = dir.resolve("s_xml.xml");
        SampleFiles.djXml(f, 50, 1);
        Layout layout;
        try (InputStream in = Files.newInputStream(f)) {
            layout = RawFileReader.detectXml(in, null);
        }
        assertEquals("SanctionsFile/Records", layout.getRecordParent());
        assertTrue(layout.getRecordElements().containsAll(Arrays.asList("Person", "Entity")));
        Collect c = new Collect();
        try (InputStream in = Files.newInputStream(f)) {
            assertEquals(50, RawFileReader.readXml(in, layout, c));
        }
        assertEquals("100001", c.keys.get(0));
        assertEquals("Date of Birth", c.refs.get("DateTypeList").get("1"));
        assertEquals("India", c.refs.get("CountryList").get("IN"));
        assertEquals("Passport No.", c.refs.get("IdentificationTypeList").get("1"));
        // nothing lost: every tag and attribute of the record is in the stored fragment
        String first = new String(c.records.get(0), StandardCharsets.UTF_8);
        assertTrue(first.contains("<DateValue Day=") && first.contains("SinceYear=") && first.contains("<Source name="));
    }

    @Test
    void autoMapperDecodesTypedElementsThroughTheFileReferenceLists(@TempDir Path dir) throws IOException {
        Path f = dir.resolve("s_xml.xml");
        SampleFiles.djXml(f, 200, 1);
        Layout layout;
        try (InputStream in = Files.newInputStream(f)) {
            layout = RawFileReader.detectXml(in, null);
        }
        Collect c = new Collect();
        try (InputStream in = Files.newInputStream(f)) {
            RawFileReader.readXml(in, layout, c);
        }
        RefTable refs = new RefTable(c.refs);
        FieldProfiler profiler = new FieldProfiler();
        RecordParser parser = new RecordParser(layout);
        for (byte[] r : c.records) {
            profiler.add(parser.parse(r));
        }
        List<AutoMapper.Field> fields = new ArrayList<>();
        Map<String, String> refListOf = new HashMap<>();
        for (FieldProfiler.Entry e : profiler.finish(refs)) {
            fields.add(new AutoMapper.Field(e.getPath(), e.getRecordsWith(), e.getRefList()));
            refListOf.put(e.getPath(), e.getRefList());
        }
        assertTrue(refListOf.containsKey("DateDetails/Date[@DateType='Date of Birth']/DateValue"), "typed path written with its label");
        assertEquals("SanctionsReferencesList", refListOf.get("SanctionsReferences/Reference"));

        MappingRules rules = AutoMapper.propose(layout, fields);
        assertEquals("@id", rules.getExternalRef());
        assertEquals("@action", rules.getAction());
        Map<String, String> byAttr = new HashMap<>();
        for (MappingRules.FieldRule r : rules.getFields()) {
            byAttr.merge(r.getAttr(), r.getPath(), (a, b) -> a + " || " + b);
        }
        assertEquals("NameDetails/Name[@NameType='Primary Name']/NameValue", byAttr.get("PRIMARY_NAME"));
        assertTrue(byAttr.get("ALIAS").contains("NameDetails/Name[@NameType='Also Known As']/NameValue"));
        assertEquals("DateDetails/Date[@DateType='Date of Birth']/DateValue", byAttr.get("DOB"));
        assertTrue(byAttr.get("NATIONALITY").contains("Citizenship"));
        assertTrue(byAttr.get("ID_DOC").contains("IDValue"));
        assertEquals("SanctionsReferences/Reference", byAttr.get("SANCTION_REF"));

        Mapper mapper = new Mapper(rules, refs, new DateNormalizer("DMY"));
        CanonicalRecord person = mapper.map(parser.parse(c.records.get(0)));
        assertEquals("PERSON", person.getRecordType());
        assertEquals("100001", person.getExternalRef());
        assertEquals("Elena Sokolov 1", person.first(AttrType.PRIMARY_NAME));
        assertEquals("1941-02-02", person.first(AttrType.DOB));
        assertEquals("IR", person.first(AttrType.NATIONALITY));
        assertEquals("EU - Consolidated Financial Sanctions List", person.first(AttrType.SANCTION_REF));
        assertTrue(person.values(AttrType.ID_DOC).get(0).endsWith("(Passport No.)"));
        assertFalse(person.isRejected());
    }

    @Test
    void pathPredicatesMatchRawValuesOrReferenceLabels() {
        RNode rec = new RNode("Person");
        RNode dd = rec.add(new RNode("DateDetails"));
        RNode d = dd.add(new RNode("Date"));
        d.attr("DateType", "1");
        RNode v = d.add(new RNode("DateValue"));
        v.attr("Day", "12");
        v.attr("Month", "Apr");
        v.attr("Year", "1971");
        Map<String, Map<String, String>> lists = new HashMap<>();
        lists.put("DateTypeList", java.util.Collections.singletonMap("1", "Date of Birth"));
        RefTable refs = new RefTable(lists);
        assertEquals("12 Apr 1971", PathExpr.of("DateDetails/Date[@DateType='Date of Birth']/DateValue").first(rec, refs));
        assertEquals("12 Apr 1971", PathExpr.of("DateDetails/Date[@DateType='1']/DateValue").first(rec, refs));
        assertEquals("1971", PathExpr.of("DateDetails/*/DateValue/@Year").first(rec, refs));
        assertNull(PathExpr.of("DateDetails/Date[@DateType='Deceased']/DateValue").first(rec, refs));
        assertEquals("Person", PathExpr.of("name()").first(rec, refs));
        assertThrows(IllegalArgumentException.class, () -> PathExpr.of("A[@x=unquoted]"));
        assertThrows(IllegalArgumentException.class, () -> PathExpr.of("@id/B"));
    }

    @Test
    void csvAndJsonRecordsBecomeTheSameTree() throws IOException {
        Collect c = new Collect();
        Layout csv = new Layout();
        RawFileReader.readCsv(in("﻿Ref;Full Name;Nationality\nA1;\"Doe; John\";India\nA2;Jane Roe;Iran\n"), csv, c);
        assertEquals(Arrays.asList("Ref", "Full Name", "Nationality"), csv.getHeader());
        RNode row = new RecordParser(csv).parse(c.records.get(0));
        assertEquals("Doe; John", PathExpr.of("Full Name").first(row, RefTable.EMPTY));

        Collect j = new Collect();
        Layout json = new Layout();
        assertEquals(2, RawFileReader.readJson(in("{\"meta\":{\"x\":1},\"records\":[{\"uid\":\"P1\",\"name\":\"A\","
                + "\"aliases\":[\"B\",\"C\"]},{\"uid\":\"P2\",\"name\":\"D\"}]}"), json, j));
        assertEquals("records", json.getJsonArray());
        RNode obj = new RecordParser(json).parse(j.records.get(0));
        assertEquals(Arrays.asList("B", "C"), PathExpr.of("aliases").values(obj, RefTable.EMPTY));
    }

    @Test
    void mapperRejectsWithoutNameAndFlagsBadDatesAndCountries() {
        MappingRules rules = new MappingRules();
        rules.setExternalRef("Ref");
        rules.getFields().add(new MappingRules.FieldRule("PRIMARY_NAME", "Name", null, null));
        rules.getFields().add(new MappingRules.FieldRule("DOB", "Born", null, null));
        rules.getFields().add(new MappingRules.FieldRule("NATIONALITY", "Country", null, null));
        Mapper m = new Mapper(rules, RefTable.EMPTY, new DateNormalizer("DMY"));
        RNode r = new RNode("row");
        r.add(new RNode("Ref")).appendText("X1");
        r.add(new RNode("Born")).appendText("30/02/1972");
        r.add(new RNode("Country")).appendText("Atlantis");
        CanonicalRecord c = m.map(r);
        assertTrue(c.isRejected());
        r.add(new RNode("Name")).appendText("John Doe");
        c = m.map(r);
        assertFalse(c.isRejected());
        assertTrue(c.isFlagged());
        assertEquals(2, c.getIssues().size());
    }

    @Test
    void diffSaysWhatChanged() {
        CanonicalRecord a = new CanonicalRecord();
        a.add(AttrType.PRIMARY_NAME, "Ravi Sharma", null);
        a.add(AttrType.NATIONALITY, "IN", null);
        CanonicalRecord b = new CanonicalRecord();
        b.add(AttrType.PRIMARY_NAME, "Ravi Sharma", null);
        b.add(AttrType.NATIONALITY, "IN", null);
        b.add(AttrType.NATIONALITY, "AE", null);
        b.add(AttrType.ALIAS, "R. K. Sharma", null);
        List<RecordDiff.Item> d = RecordDiff.diff(a, b);
        assertEquals("Aliases added; Nationality changed", RecordDiff.summary(d));
    }

    @Test
    void fileNamePatternsRouteFilesAndTellDeltaFromFull() {
        assertTrue(ListService.matches("s_xml_1158_158_*", "s_xml_1158_158_20261107_1_f.xml"));
        assertFalse(ListService.matches("s_xml_1158_158_*", "s_xml_1158_062_20261107_1_f.xml"));
        assertTrue(ListService.matches("*_d.xml", "S_XML_1158_158_20261107_1_D.XML"));
        assertTrue(ListService.matches("pfa2_*", "pfa2_20261107_2200_f.xml"));
    }

    @Test
    void attributeFallbacksAreConservative() {
        assertNotNull(AttrType.of("alias"));
        assertThrows(IllegalArgumentException.class, () -> AttrType.of("nope"));
    }
}
