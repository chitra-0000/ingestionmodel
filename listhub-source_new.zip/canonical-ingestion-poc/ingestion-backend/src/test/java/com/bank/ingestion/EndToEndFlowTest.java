package com.bank.ingestion;

import com.bank.ingestion.domain.Batch;
import com.bank.ingestion.domain.BatchStatus;
import com.bank.ingestion.domain.ListDef;
import com.bank.ingestion.domain.ListVersion;
import com.bank.ingestion.domain.VersionStatus;
import com.bank.ingestion.repository.ExportRepository;
import com.bank.ingestion.repository.VersionRepository;
import com.bank.ingestion.service.admin.ListService;
import com.bank.ingestion.service.admin.UserService;
import com.bank.ingestion.service.batch.BatchService;
import com.bank.ingestion.service.canonical.MappingService;
import com.bank.ingestion.service.version.RecordService;
import com.bank.ingestion.service.version.VersionService;
import com.bank.ingestion.tools.SampleFiles;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Whole flow on H2 with generated S_XML-like files: first file -> mapping proposal -> approval -> version 1 ->
 * validate + certify (two users) -> published + exports; second full file -> created / modified / minor /
 * deleted / rejected / flagged; delta file -> deletion and change by the provider; history of one person.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("h2mem")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EndToEndFlowTest {

    private static final int RECORDS = 600;
    private static Path base;

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) throws IOException {
        base = Files.createTempDirectory("listhub-test");
        r.add("listhub.base-dir", base::toString);
        r.add("listhub.inbound.enabled", () -> "false");
        r.add("listhub.admin.password", () -> "Admin12345678");
        r.add("listhub.workers-per-file", () -> "3");
    }

    @Autowired ListService lists;
    @Autowired BatchService batches;
    @Autowired MappingService mappings;
    @Autowired VersionService versionService;
    @Autowired VersionRepository versions;
    @Autowired ExportRepository exports;
    @Autowired RecordService records;
    @Autowired UserService users;
    @Autowired MockMvc mvc;

    private static long listId;

    private Batch load(String fileName, Path source) throws Exception {
        Path work = base.resolve("work").resolve(System.nanoTime() + "_" + fileName);
        Files.createDirectories(work.getParent());
        Files.copy(source, work);
        Batch b = batches.register(work, fileName, Files.size(work), System.nanoTime(), "UPLOAD", null, "tester");
        return waitFor(b.getBatchId());
    }

    private Batch waitFor(long batchId) throws InterruptedException {
        return waitFor(batchId, true);
    }

    /** Waits until the batch stops moving; MAPPING_REVIEW counts as stopped only when acceptReview. */
    private Batch waitFor(long batchId, boolean acceptReview) throws InterruptedException {
        for (int i = 0; i < 600; i++) {
            Batch b = batches.get(batchId);
            if (b.getStatus() == BatchStatus.TO_VALIDATE || b.getStatus().isFinal()
                    || (acceptReview && b.getStatus() == BatchStatus.MAPPING_REVIEW)) {
                return b;
            }
            Thread.sleep(100);
        }
        throw new AssertionError("Batch " + batchId + " did not finish: " + batches.get(batchId).getStatus());
    }

    private void approveVersion(int v) {
        versionService.validate(listId, v, "anna", "checked");
        assertThrows(RuntimeException.class, () -> versionService.certify(listId, v, "anna"), "four eyes");
        versionService.certify(listId, v, "bruno");
        assertEquals(VersionStatus.PUBLISHED, versions.find(listId, v).get().getStatus());
    }

    @Test
    @Order(1)
    void firstFileNeedsMappingThenBecomesVersion1() throws Exception {
        ListDef l = new ListDef();
        l.setListCode("001");
        l.setName("Dow Jones - Sanctions");
        l.setProviderCode("DOWJONES");
        l.setFilePattern("s_xml_1158_158_*");
        l.setDeltaPattern("*_d.xml");
        l.setExportFormats("CSV,XML");
        listId = lists.create(l, "admin").getListId();

        Path f1 = base.resolve("v1.xml");
        SampleFiles.djXml(f1, RECORDS, 1);
        Batch b = load("s_xml_1158_158_20261101_1_f.xml", f1);
        assertEquals(BatchStatus.MAPPING_REVIEW, b.getStatus(), "first file of a list: mapping proposed, waits for approval");
        assertEquals(RECORDS, b.getRecordCount());
        assertTrue(mappings.hasDraft(listId));

        mappings.approve(listId, "admin");
        batches.resume();
        b = waitFor(b.getBatchId(), false);
        assertEquals(BatchStatus.TO_VALIDATE, b.getStatus(), b.getMessage());
        ListVersion v1 = versions.find(listId, 1).get();
        assertEquals(RECORDS, v1.getCreatedCount());
        assertEquals(RECORDS, v1.getTotalRecords());
        assertEquals(0, v1.getRejectedCount());

        approveVersion(1);
        List<ExportRepository.ExportFile> files = exports.byVersion(listId, 1);
        assertEquals(2, files.size(), "full CSV and full XML");
        for (ExportRepository.ExportFile f : files) {
            assertEquals(RECORDS, f.recordCount);
            assertTrue(Files.size(java.nio.file.Paths.get(f.filePath)) > 0);
        }
    }

    @Test
    @Order(2)
    void secondFullFileShowsEveryKindOfChange() throws Exception {
        Path f2 = base.resolve("v2.xml");
        SampleFiles.djXml(f2, RECORDS, 2);
        Batch b = load("s_xml_1158_158_20261102_1_f.xml", f2);
        assertEquals(BatchStatus.TO_VALIDATE, b.getStatus(), b.getMessage());
        ListVersion v2 = versions.find(listId, 2).get();
        assertEquals("FULL", v2.getDelivery());
        assertEquals(6, v2.getCreatedCount());
        assertEquals(14, v2.getModifiedCount(), "12 new aliases + 2 dates that changed");
        assertEquals(9, v2.getMinorCount(), "source only");
        assertEquals(6, v2.getDeletedCount());
        assertEquals(3, v2.getRejectedCount(), "2 without name + 1 duplicate provider id");
        assertEquals(2, v2.getFlaggedCount(), "dates that do not exist");
        assertEquals(RECORDS, v2.getTotalRecords());
        assertEquals(601 - 3 - 14 - 9 - 6, v2.getUnchangedCount());

        Map<String, Object> page = mvcJson("/api/lists/" + listId + "/versions/2/changes?type=MODIFIED&size=50");
        assertTrue(page.get("total").toString().equals("14"));
        approveVersion(2);
        assertEquals(3, exports.byVersion(listId, 2).size(), "full CSV, delta CSV, full XML");
    }

    @Test
    @Order(3)
    void deltaFileDeletesAndChangesOnlyWhatTheProviderSays() throws Exception {
        Path d = base.resolve("d.xml");
        SampleFiles.djDelta(d, RECORDS, 2);
        Batch b = load("s_xml_1158_158_20261103_2_d.xml", d);
        assertEquals("DELTA", b.getDelivery());
        ListVersion v3 = versions.find(listId, 3).get();
        assertEquals(1, v3.getDeletedCount());
        assertEquals(1, v3.getModifiedCount());
        assertEquals(1, v3.getCreatedCount());
        assertEquals(RECORDS, v3.getTotalRecords());

        // History of record 50: created in v1, modified in v2 and in v3, same internal id all along
        // internal ids are given in processing order, so find record 50 by its provider id
        String rgl = (String) records.search("100050", listId, null, true).get(0).get("rglId");
        Map<String, Object> h = records.history(rgl);
        List<?> periods = (List<?>) h.get("periods");
        assertEquals(3, periods.size());
        List<?> events = (List<?>) h.get("events");
        assertEquals(Arrays.asList("CREATED", "MODIFIED", "MODIFIED"), events.stream().map(e -> ((Map<?, ?>) e).get("type")).collect(
                java.util.stream.Collectors.toList()));

        // rejecting the delta version restores version 2 exactly
        versionService.reject(listId, 3, "anna", "test");
        assertEquals(RECORDS, versions.find(listId, 2).get().getTotalRecords());
        assertEquals(2, ((List<?>) records.history(rgl).get("periods")).size());
    }

    @Test
    @Order(4)
    void apiNeedsLoginCsrfAndRoles() throws Exception {
        mvc.perform(get("/api/lists")).andExpect(status().isUnauthorized());
        mvc.perform(get("/api/lists").with(user("v").roles("VIEWER"))).andExpect(status().isOk());
        mvc.perform(post("/api/lists").with(user("v").roles("VIEWER")).contentType("application/json").content("{}"))
                .andExpect(status().isForbidden());
        mvc.perform(post("/api/lists").with(user("a").roles("ADMIN")).contentType("application/json").content("{}"))
                .andExpect(status().isForbidden()); // no CSRF token
        mvc.perform(post("/api/lists").with(user("a").roles("ADMIN")).with(csrf()).contentType("application/json")
                .content("{\"listCode\":\"../x\",\"name\":\"x\",\"providerCode\":\"X1\"}")).andExpect(status().isBadRequest());
        mvc.perform(get("/api/v1/lists").with(user("s").roles("SUBSCRIBER"))).andExpect(status().isOk());
        mvc.perform(get("/api/records/" + records.search("100002", listId, null, true).get(0).get("rglId") + "/pdf").with(user("v").roles("VIEWER"))).andExpect(status().isOk());
        assertFalse(users.list().isEmpty());
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> mvcJson(String url) throws Exception {
        String body = mvc.perform(get(url).with(user("v").roles("VIEWER"))).andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        return com.bank.ingestion.util.Json.read(body, Map.class);
    }
}
