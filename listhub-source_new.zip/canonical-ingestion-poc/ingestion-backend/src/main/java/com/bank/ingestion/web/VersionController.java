package com.bank.ingestion.web;

import com.bank.ingestion.config.ListHubProperties;
import com.bank.ingestion.domain.ChangeType;
import com.bank.ingestion.domain.ListVersion;
import com.bank.ingestion.repository.BatchRepository;
import com.bank.ingestion.repository.ExportRepository;
import com.bank.ingestion.repository.VersionRepository;
import com.bank.ingestion.service.admin.ListService;
import com.bank.ingestion.service.raw.CsvParser;
import com.bank.ingestion.service.version.RecordService;
import com.bank.ingestion.service.version.VersionService;
import com.bank.ingestion.util.ApiException;
import com.bank.ingestion.util.Json;
import com.bank.ingestion.util.Texts;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** A list version: summary, changes by type, record drill-down, approval, export files. */
@RestController
@RequestMapping("/api")
public class VersionController {

    private final VersionService service;
    private final VersionRepository versions;
    private final BatchRepository batches;
    private final ExportRepository exports;
    private final RecordService records;
    private final ListService lists;
    private final ListHubProperties props;

    public VersionController(VersionService service, VersionRepository versions, BatchRepository batches,
                             ExportRepository exports, RecordService records, ListService lists, ListHubProperties props) {
        this.service = service;
        this.versions = versions;
        this.batches = batches;
        this.exports = exports;
        this.records = records;
        this.lists = lists;
        this.props = props;
    }

    @GetMapping("/lists/{id}/versions/{v}")
    @PreAuthorize(Roles.VIEW)
    public Map<String, Object> version(@PathVariable long id, @PathVariable int v) {
        ListVersion lv = service.get(id, v);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("list", lists.get(id));
        m.put("version", lv);
        m.put("issues", lv.getIssuesJson() == null ? null : Json.read(lv.getIssuesJson(), Map.class));
        lv.setIssuesJson(null);
        long previousTotal = lv.getTotalRecords() - lv.getCreatedCount() + lv.getDeletedCount();
        m.put("previousTotal", previousTotal);
        batches.find(lv.getBatchId()).ifPresent(b -> {
            b.setLayoutJson(null);
            b.setWorkPath(null);
            m.put("batch", b);
        });
        m.put("steps", batches.steps(java.util.Collections.singletonList(lv.getBatchId())).get(lv.getBatchId()));
        m.put("exports", exports.byVersion(id, v));
        return m;
    }

    @GetMapping("/lists/{id}/versions/{v}/changes")
    @PreAuthorize(Roles.VIEW)
    public Map<String, Object> changes(@PathVariable long id, @PathVariable int v, @RequestParam String type,
                                       @RequestParam(required = false) String q, @RequestParam(defaultValue = "0") int page,
                                       @RequestParam(defaultValue = "25") int size) {
        String t = type(type);
        int s = Math.max(1, Math.min(size, 500));
        int p = Math.max(0, page);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("type", t);
        m.put("total", versions.countChanges(id, v, t, q));
        m.put("page", p);
        m.put("size", s);
        List<Map<String, Object>> rows = new ArrayList<>();
        for (VersionRepository.Change c : versions.changes(id, v, t, q, p * s, s)) {
            Map<String, Object> r = records.changeView(c);
            r.remove("detail");
            rows.add(r);
        }
        m.put("rows", rows);
        return m;
    }

    @GetMapping("/lists/{id}/versions/{v}/changes/{type}/{seq}")
    @PreAuthorize(Roles.VIEW)
    public Map<String, Object> change(@PathVariable long id, @PathVariable int v, @PathVariable String type,
                                      @PathVariable long seq) {
        return records.changeDetail(id, v, type(type), seq);
    }

    /** Every change of one type as CSV (streamed: works for 5M rows). */
    @GetMapping("/lists/{id}/versions/{v}/changes.csv")
    @PreAuthorize(Roles.VIEW)
    public ResponseEntity<StreamingResponseBody> changesCsv(@PathVariable long id, @PathVariable int v, @RequestParam String type) {
        String t = type(type);
        String code = Texts.safeFileName(lists.get(id).getListCode());
        StreamingResponseBody body = out -> {
            Writer w = new OutputStreamWriter(out, StandardCharsets.UTF_8);
            StringBuilder sb = new StringBuilder();
            CsvParser.encode(Arrays.asList("CHANGE", "RGL_ID", "EXTERNAL_REF", "RECORD_TYPE", "PRIMARY_NAME", "COUNTRY", "DETAIL"), ',', sb);
            w.write(sb.append("\r\n").toString());
            int page = 0;
            List<VersionRepository.Change> part;
            do {
                part = versions.changes(id, v, t, null, page * 5000, 5000);
                for (VersionRepository.Change c : part) {
                    sb.setLength(0);
                    CsvParser.encode(Arrays.asList(c.changeType, c.rglId, c.externalRef, c.recordType, safe(c.primaryName),
                            c.country, safe(c.summary)), ',', sb);
                    w.write(sb.append("\r\n").toString());
                }
                page++;
            } while (part.size() == 5000);
            w.flush();
        };
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment()
                        .filename(code + "_v" + v + "_" + t.toLowerCase(Locale.ROOT) + ".csv").build().toString())
                .contentType(new MediaType("text", "csv", StandardCharsets.UTF_8))
                .body(body);
    }

    private static String safe(String v) {
        return v != null && !v.isEmpty() && "=+-@".indexOf(v.charAt(0)) >= 0 ? "'" + v : v;
    }

    @PostMapping("/lists/{id}/versions/{v}/validate")
    @PreAuthorize(Roles.VALIDATE)
    public ListVersion validate(@PathVariable long id, @PathVariable int v, @RequestBody(required = false) Map<String, String> body,
                                Authentication auth) {
        return service.validate(id, v, auth.getName(), body == null ? null : body.get("comment"));
    }

    @PostMapping("/lists/{id}/versions/{v}/certify")
    @PreAuthorize(Roles.CERTIFY)
    public ListVersion certify(@PathVariable long id, @PathVariable int v, Authentication auth) {
        return service.certify(id, v, auth.getName());
    }

    @PostMapping("/lists/{id}/versions/{v}/reject")
    @PreAuthorize(Roles.DECIDE)
    public ListVersion reject(@PathVariable long id, @PathVariable int v, @RequestBody(required = false) Map<String, String> body,
                              Authentication auth) {
        return service.reject(id, v, auth.getName(), body == null ? null : body.get("comment"));
    }

    @PostMapping("/lists/{id}/versions/{v}/export")
    @PreAuthorize(Roles.ADMIN)
    public List<ExportRepository.ExportFile> export(@PathVariable long id, @PathVariable int v) throws IOException {
        return service.reExport(id, v);
    }

    @GetMapping("/exports/{exportId}/download")
    @PreAuthorize(Roles.VIEW + " or " + Roles.SUBSCRIBE)
    public ResponseEntity<InputStreamResource> download(@PathVariable long exportId) throws IOException {
        ExportRepository.ExportFile f = exports.find(exportId).orElseThrow(() -> ApiException.notFound("Export file not found"));
        return file(f, props);
    }

    static ResponseEntity<InputStreamResource> file(ExportRepository.ExportFile f, ListHubProperties props) throws IOException {
        Path p = Paths.get(f.filePath).toAbsolutePath().normalize();
        if (!p.startsWith(props.outboundDir()) || !Files.isRegularFile(p)) {
            throw ApiException.notFound("The export file is not in the outbound folder any more");
        }
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(f.fileName).build().toString())
                .contentLength(Files.size(p))
                .contentType(f.fileName.endsWith(".xml") ? MediaType.APPLICATION_XML : new MediaType("text", "csv", StandardCharsets.UTF_8))
                .body(new InputStreamResource(Files.newInputStream(p)));
    }

    private static String type(String raw) {
        try {
            return ChangeType.valueOf(raw.trim().toUpperCase(Locale.ROOT)).name();
        } catch (IllegalArgumentException e) {
            throw ApiException.badRequest("Unknown change type");
        }
    }
}
