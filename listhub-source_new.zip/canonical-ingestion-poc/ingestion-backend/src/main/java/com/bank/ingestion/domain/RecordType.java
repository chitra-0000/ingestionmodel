package com.bank.ingestion.domain;

import java.util.Locale;

/** Kind of subject, from the record element name or a type field. */
public enum RecordType {
    PERSON, ENTITY, VESSEL, AIRCRAFT, OTHER;

    public static RecordType guess(String raw) {
        if (raw == null) {
            return OTHER;
        }
        String v = raw.trim().toLowerCase(Locale.ROOT);
        if (v.isEmpty()) {
            return OTHER;
        }
        if (v.startsWith("pers") || v.startsWith("indiv") || v.equals("p") || v.equals("i") || v.contains("natural")) {
            return PERSON;
        }
        if (v.startsWith("ent") || v.startsWith("comp") || v.startsWith("org") || v.equals("e") || v.equals("c")
                || v.contains("legal") || v.contains("company")) {
            return ENTITY;
        }
        if (v.startsWith("vess") || v.startsWith("ship")) {
            return VESSEL;
        }
        if (v.startsWith("airc") || v.startsWith("plane")) {
            return AIRCRAFT;
        }
        return OTHER;
    }
}
