package com.bank.ingestion.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Angular routes (/lists/12, /records ...) are served index.html so that a browser refresh or a bookmark
 * works. Files with an extension and /api are not matched.
 */
@Controller
public class SpaController {

    @GetMapping({"/", "/{p1:[^.]*}", "/{p1:^(?!api$).*}/{p2:[^.]*}", "/{p1:^(?!api$).*}/{p2:[^.]*}/{p3:[^.]*}",
            "/{p1:^(?!api$).*}/{p2:[^.]*}/{p3:[^.]*}/{p4:[^.]*}"})
    public String index() {
        return "forward:/index.html";
    }
}
