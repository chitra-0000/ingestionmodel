package com.bank.ingestion.service.canonical;

import com.bank.ingestion.util.Texts;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.Set;

/**
 * ISO 3166-1 alpha-2 normalisation from the JDK's own country list: accepts alpha-2, alpha-3 and English
 * names ("IND", "India", "in" -> "IN"), plus common short forms. Built once; immutable and thread-safe.
 */
public final class CountryNormalizer {

    private static final Set<String> ALPHA2;
    private static final Map<String, String> LOOKUP;

    static {
        Set<String> alpha2 = new HashSet<>();
        Map<String, String> lookup = new HashMap<>();
        for (String code : Locale.getISOCountries()) {
            alpha2.add(code);
            Locale l = new Locale("", code);
            lookup.put(Texts.normaliseName(l.getDisplayCountry(Locale.ENGLISH)), code);
            try {
                lookup.put(l.getISO3Country().toLowerCase(Locale.ROOT), code);
            } catch (MissingResourceException e) {
                // A few territories have no alpha-3 code in the JDK; alpha-2 and the name still resolve.
            }
        }
        // Kosovo uses the user-assigned code XK on most sanctions lists.
        alpha2.add("XK");
        lookup.put("kosovo", "XK");
        lookup.put("xkx", "XK");
        String[][] aliases = {
                {"uk", "GB"}, {"greatbritain", "GB"}, {"england", "GB"}, {"usa", "US"}, {"unitedstatesofamerica", "US"},
                {"america", "US"}, {"russia", "RU"}, {"russianfederation", "RU"}, {"southkorea", "KR"},
                {"republicofkorea", "KR"}, {"northkorea", "KP"}, {"dprk", "KP"}, {"iran", "IR"}, {"syria", "SY"},
                {"vietnam", "VN"}, {"laos", "LA"}, {"bolivia", "BO"}, {"venezuela", "VE"}, {"tanzania", "TZ"},
                {"moldova", "MD"}, {"czechrepublic", "CZ"}, {"czechia", "CZ"}, {"ivorycoast", "CI"},
                {"cotedivoire", "CI"}, {"burma", "MM"}, {"myanmar", "MM"}, {"uae", "AE"}, {"turkey", "TR"},
                {"turkiye", "TR"}, {"palestine", "PS"}, {"taiwan", "TW"}, {"macedonia", "MK"}, {"northmacedonia", "MK"},
                {"congo", "CG"}, {"drc", "CD"}, {"democraticrepublicofthecongo", "CD"}, {"holland", "NL"}};
        for (String[] a : aliases) {
            lookup.put(a[0], a[1]);
        }
        ALPHA2 = Collections.unmodifiableSet(alpha2);
        LOOKUP = Collections.unmodifiableMap(lookup);
    }

    private CountryNormalizer() {
    }

    /** @return ISO alpha-2 code, or null when the value is not a recognised country */
    public static String normalise(String raw) {
        if (raw == null) {
            return null;
        }
        String v = raw.trim();
        if (v.length() == 2) {
            String upper = v.toUpperCase(Locale.ROOT);
            if (ALPHA2.contains(upper)) {
                return upper;
            }
        }
        return LOOKUP.get(Texts.normaliseName(v));
    }
}
