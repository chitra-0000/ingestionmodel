package com.bank.ingestion.service.canonical;

import com.bank.ingestion.domain.AttrType;
import com.bank.ingestion.domain.Layout;
import com.bank.ingestion.domain.MappingRules;
import com.bank.ingestion.util.Texts;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Proposes a mapping from the field profile of a file, without XSLT and without AI: names of elements,
 * columns and attributes, and the labels of typed elements (NameType, DateType, CountryType, IDType...),
 * are matched against a dictionary of canonical attributes. Codes found in a reference list of the file
 * are decoded through it. The proposal is a draft that a user reviews, changes and approves once per list.
 */
public final class AutoMapper {

    /** One profiled path (from RAW_FIELD_PROFILE). */
    public static final class Field {
        final String path;
        final long recordsWith;
        final String refList;

        public Field(String path, long recordsWith, String refList) {
            this.path = path;
            this.recordsWith = recordsWith;
            this.refList = refList;
        }
    }

    private static final Map<String, AttrType> WORDS = new HashMap<>();
    private static final String[] ID_REF = {"id", "uid", "externalid", "providerid", "recordid", "entityid", "personid",
            "uniqueid", "referencenumber", "refno", "reference", "ref", "djid", "listentryid"};
    private static final String[] ACTION = {"action", "operation", "changetype", "recordaction"};
    private static final String[] TYPE = {"recordtype", "type", "entitytype", "subjecttype", "partytype", "kind"};

    static {
        word(AttrType.PRIMARY_NAME, "primaryname", "fullname", "name", "wholename", "entityname", "partyname",
                "subjectname", "primary", "nameprimary");
        word(AttrType.FIRST_NAME, "firstname", "givenname", "forename", "firstnames");
        word(AttrType.LAST_NAME, "lastname", "surname", "familyname");
        word(AttrType.ALIAS, "alias", "aliases", "aka", "alsoknownas", "lowqualityaka", "formerlyknownas",
                "spellingvariation", "othername", "akaname", "maidenname", "nickname");
        word(AttrType.GENDER, "gender", "sex");
        word(AttrType.DOB, "dateofbirth", "dob", "birthdate", "datebirth");
        word(AttrType.BIRTH_PLACE, "placeofbirth", "birthplace", "pob");
        word(AttrType.NATIONALITY, "nationality", "citizenship", "nationalities");
        word(AttrType.RESIDENCE, "residentof", "residence", "countryofresidence");
        word(AttrType.COUNTRY, "country", "countrycode", "jurisdiction", "countryofregistration",
                "countryofreportedallegation", "countryofaffiliation", "addresscountry");
        word(AttrType.ADDRESS, "address", "addresses", "fulladdress");
        word(AttrType.ID_DOC, "passport", "passportnumber", "nationalid", "idnumber", "identification", "idvalue",
                "taxid", "registrationnumber", "ssn", "documentnumber", "idno");
        word(AttrType.SANCTION_REF, "sanctionsreference", "sanctionsreferences", "sanctionsreferencename", "program",
                "programme", "sanctionlist", "sanctionslist", "regime", "listname");
        word(AttrType.DESCRIPTION, "description", "description1", "description2", "description3", "category",
                "subcategory");
        word(AttrType.OCCUPATION, "occupation", "occtitle", "role", "position", "title", "function");
        word(AttrType.STATUS, "activestatus", "status", "recordstatus");
        word(AttrType.SOURCE, "source", "sourcedescription", "sourcename");
        word(AttrType.URL, "url", "link", "sourceurl");
        word(AttrType.NOTE, "note", "notes", "remarks", "remark", "comment", "comments", "profilenotes", "profile");
        word(AttrType.LAST_UPDATED, "lastupdated", "datemodified", "updated", "lastmodified");
    }

    private AutoMapper() {
    }

    private static void word(AttrType t, String... words) {
        for (String w : words) {
            WORDS.put(w, t);
        }
    }

    public static MappingRules propose(Layout layout, List<Field> fields) {
        MappingRules rules = new MappingRules();
        boolean xml = "XML".equalsIgnoreCase(layout.getFormat());
        rules.setExternalRef(findTop(fields, ID_REF, xml));
        rules.setAction(findTop(fields, ACTION, xml));
        if (xml) {
            rules.setRecordType("name()");
        } else {
            rules.setRecordType(findTop(fields, TYPE, false));
        }

        Map<AttrType, List<Field>> byAttr = new LinkedHashMap<>();
        for (Field f : fields) {
            if (f.path.equals(rules.getExternalRef()) || f.path.equals(rules.getAction()) || f.path.equals(rules.getRecordType())) {
                continue;
            }
            AttrType t = attrFor(f.path);
            if (t != null) {
                byAttr.computeIfAbsent(t, k -> new ArrayList<>()).add(f);
            }
        }
        for (Map.Entry<AttrType, List<Field>> e : byAttr.entrySet()) {
            AttrType t = e.getKey();
            List<Field> list = e.getValue();
            if (!t.multi()) {
                Field best = list.get(0);
                for (Field f : list) {
                    if (f.recordsWith > best.recordsWith) {
                        best = f;
                    }
                }
                list = java.util.Collections.singletonList(best);
            }
            for (Field f : list) {
                rules.getFields().add(new MappingRules.FieldRule(t.name(), f.path, f.refList, qualifier(t, f.path)));
            }
        }
        return rules;
    }

    /** A top-level field (record attribute in XML, column in CSV / JSON) with one of the given names. */
    private static String findTop(List<Field> fields, String[] names, boolean xml) {
        for (String n : names) {
            for (Field f : fields) {
                String p = f.path;
                boolean top = xml ? p.startsWith("@") && p.indexOf('/') < 0 : p.indexOf('/') < 0 && !p.startsWith("@");
                if (top && n.equals(Texts.normaliseName(xml ? p.substring(1) : p))) {
                    return p;
                }
            }
        }
        return null;
    }

    /** Canonical attribute for a path, or null. */
    static AttrType attrFor(String path) {
        String[] steps = splitSteps(path);
        String last = steps[steps.length - 1];
        String attrName = null;
        String lastElement = last;
        if (last.startsWith("@")) {
            attrName = Texts.normaliseName(last.substring(1));
            lastElement = steps.length > 1 ? steps[steps.length - 2] : "";
        }
        String elementName = Texts.normaliseName(stripPredicate(lastElement));

        // Typed element: its label decides (Name[@NameType='Primary Name']/NameValue, ID[@IDType='Passport No.']/IDValue)
        int typedIndex = lastTypedStep(steps);
        if (typedIndex >= 0) {
            int after = steps.length - 1 - typedIndex - (attrName != null ? 1 : 0);
            boolean valueOfType = after <= 1 && (attrName == null || "code".equals(attrName) || "value".equals(attrName)
                    || "name".equals(attrName));
            String typeAttr = Texts.normaliseName(predicateAttr(steps[typedIndex]));
            String label = Texts.normaliseName(predicateValue(steps[typedIndex]));
            AttrType byLabel = WORDS.get(label);
            if (valueOfType) {
                if (byLabel != null) {
                    return byLabel;
                }
                if (typeAttr.startsWith("id") || typeAttr.startsWith("identification") || typeAttr.startsWith("document")) {
                    return AttrType.ID_DOC;
                }
                if (label.contains("aka") || label.contains("knownas") || label.contains("variation")) {
                    return AttrType.ALIAS;
                }
            } else if (byLabel == AttrType.ALIAS && attrName == null
                    && (WORDS.get(elementName) == AttrType.FIRST_NAME || WORDS.get(elementName) == AttrType.LAST_NAME)) {
                return null;
            }
        }
        if (attrName != null) {
            if (steps.length == 1 && "date".equals(attrName)) {
                return AttrType.LAST_UPDATED;
            }
            boolean generic = "code".equals(attrName) || "value".equals(attrName) || "name".equals(attrName)
                    || "text".equals(attrName);
            if (generic && WORDS.get(elementName) != null) {
                return WORDS.get(elementName);
            }
            if (generic && steps.length > 1) {
                return null;
            }
            return WORDS.get(attrName);
        }
        AttrType t = WORDS.get(elementName);
        if (t == null && steps.length > 1) {
            // Reference under SanctionsReferences, Value under Nationality ...
            String parent = Texts.normaliseName(stripPredicate(steps[steps.length - 2]));
            AttrType p = WORDS.get(parent);
            if (p != null && (elementName.equals("reference") || elementName.equals("value") || elementName.endsWith("value")
                    || elementName.equals("item"))) {
                return p;
            }
        }
        return t;
    }

    private static String qualifier(AttrType t, String path) {
        if (t != AttrType.ID_DOC) {
            return null;
        }
        String[] steps = splitSteps(path);
        int i = lastTypedStep(steps);
        return i < 0 ? null : predicateValue(steps[i]);
    }

    private static int lastTypedStep(String[] steps) {
        for (int i = steps.length - 1; i >= 0; i--) {
            if (steps[i].contains("[@") && steps[i].contains("='")) {
                return i;
            }
        }
        return -1;
    }

    private static String[] splitSteps(String path) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean quote = false;
        for (int i = 0; i < path.length(); i++) {
            char c = path.charAt(i);
            if (c == '\'') {
                quote = !quote;
            }
            if (c == '/' && !quote) {
                out.add(cur.toString());
                cur.setLength(0);
            } else {
                cur.append(c);
            }
        }
        out.add(cur.toString());
        return out.toArray(new String[0]);
    }

    private static String stripPredicate(String step) {
        int b = step.indexOf('[');
        return b < 0 ? step : step.substring(0, b);
    }

    private static String predicateAttr(String step) {
        int a = step.indexOf("[@");
        int e = step.indexOf('=', a);
        return a < 0 || e < 0 ? "" : step.substring(a + 2, e);
    }

    private static String predicateValue(String step) {
        int a = step.indexOf("='");
        int e = step.indexOf("']", a);
        return a < 0 || e < 0 ? "" : step.substring(a + 2, e);
    }
}
