package com.bank.ingestion.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/** Generated export files (EXPORT_FILE). */
@Repository
public class ExportRepository {

    /** One export file. */
    public static final class ExportFile {
        public long exportId;
        public long listId;
        public int versionNo;
        public String format;
        public String kind;
        public String fileName;
        public String filePath;
        public long recordCount;
        public long sizeBytes;
        public String sha256;
        public LocalDateTime createdAt;
    }

    private static final RowMapper<ExportFile> FILE = (rs, i) -> {
        ExportFile f = new ExportFile();
        f.exportId = rs.getLong("EXPORT_ID");
        f.listId = rs.getLong("LIST_ID");
        f.versionNo = rs.getInt("VERSION_NO");
        f.format = rs.getString("FORMAT");
        f.kind = rs.getString("KIND");
        f.fileName = rs.getString("FILE_NAME");
        f.filePath = rs.getString("FILE_PATH");
        f.recordCount = rs.getLong("RECORD_COUNT");
        f.sizeBytes = rs.getLong("SIZE_BYTES");
        f.sha256 = rs.getString("SHA256");
        f.createdAt = Db.time(rs, "CREATED_AT");
        return f;
    };

    private static final String COLS = "EXPORT_ID, LIST_ID, VERSION_NO, FORMAT, KIND, FILE_NAME, FILE_PATH, RECORD_COUNT, "
            + "SIZE_BYTES, SHA256, CREATED_AT";

    private final JdbcTemplate jdbc;

    public ExportRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void insert(ExportFile f) {
        jdbc.update("INSERT INTO EXPORT_FILE (" + COLS + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", f.exportId, f.listId,
                f.versionNo, f.format, f.kind, f.fileName, f.filePath, f.recordCount, f.sizeBytes, f.sha256, Db.now());
    }

    public List<ExportFile> byVersion(long listId, int version) {
        return jdbc.query("SELECT " + COLS + " FROM EXPORT_FILE WHERE LIST_ID = ? AND VERSION_NO = ? ORDER BY FORMAT, KIND",
                FILE, listId, version);
    }

    public Optional<ExportFile> find(long exportId) {
        return jdbc.query("SELECT " + COLS + " FROM EXPORT_FILE WHERE EXPORT_ID = ?", FILE, exportId).stream().findFirst();
    }

    public void deleteVersion(long listId, int version) {
        jdbc.update("DELETE FROM EXPORT_FILE WHERE LIST_ID = ? AND VERSION_NO = ?", listId, version);
    }
}
