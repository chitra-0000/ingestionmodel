package com.bank.ingestion.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * Ids from the database sequences without one round trip per row: LH_ID_SEQ moves by 1000, so each
 * NEXTVAL reserves a block of 1000 ids for this JVM (hi/lo). Safe across several servers.
 */
@Component
public class IdAllocator {

    private static final int BLOCK = 1000;

    private final JdbcTemplate jdbc;
    private long next;
    private long limit;

    public IdAllocator(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** Next row id (CANONICAL_RECORD, EXPORT_FILE). */
    public synchronized long nextRowId() {
        if (next >= limit) {
            Long start = jdbc.queryForObject("SELECT LH_ID_SEQ.NEXTVAL FROM DUAL", Long.class);
            if (start == null) {
                throw new IllegalStateException("Sequence LH_ID_SEQ returned no value");
            }
            next = start;
            limit = start + BLOCK;
        }
        return next++;
    }

    /** Next small id (batches, lists, mappings): one sequence value each, gap-free in practice. */
    public long nextSmallId() {
        Long v = jdbc.queryForObject("SELECT LH_SMALL_SEQ.NEXTVAL FROM DUAL", Long.class);
        if (v == null) {
            throw new IllegalStateException("Sequence LH_SMALL_SEQ returned no value");
        }
        return v;
    }
}
