package com.bank.ingestion.repository;

import com.bank.ingestion.domain.Batch;
import com.bank.ingestion.domain.BatchStatus;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Batches (one per received file) and the time of each of their steps. */
@Repository
public class BatchRepository {

    private static final String COLS = "BATCH_ID, LIST_ID, FILE_NAME, FILE_SIZE, FILE_MTIME, SOURCE, FILE_FORMAT, DELIVERY, "
            + "SHA256, STATUS, MESSAGE, VERSION_NO, RECORD_COUNT, REF_COUNT, WORK_PATH, LAYOUT_JSON, SUBMITTED_BY, "
            + "RECEIVED_AT, STARTED_AT, FINISHED_AT";

    private static final RowMapper<Batch> BATCH = (rs, i) -> {
        Batch b = new Batch();
        b.setBatchId(rs.getLong("BATCH_ID"));
        b.setListId(Db.longOrNull(rs, "LIST_ID"));
        b.setFileName(rs.getString("FILE_NAME"));
        b.setFileSize(rs.getLong("FILE_SIZE"));
        b.setFileMtime(rs.getLong("FILE_MTIME"));
        b.setSource(rs.getString("SOURCE"));
        b.setFileFormat(rs.getString("FILE_FORMAT"));
        b.setDelivery(rs.getString("DELIVERY"));
        b.setSha256(rs.getString("SHA256"));
        b.setStatus(BatchStatus.valueOf(rs.getString("STATUS")));
        b.setMessage(rs.getString("MESSAGE"));
        b.setVersionNo(Db.intOrNull(rs, "VERSION_NO"));
        b.setRecordCount(rs.getLong("RECORD_COUNT"));
        b.setRefCount(rs.getLong("REF_COUNT"));
        b.setWorkPath(rs.getString("WORK_PATH"));
        b.setLayoutJson(rs.getString("LAYOUT_JSON"));
        b.setSubmittedBy(rs.getString("SUBMITTED_BY"));
        b.setReceivedAt(Db.time(rs, "RECEIVED_AT"));
        b.setStartedAt(Db.time(rs, "STARTED_AT"));
        b.setFinishedAt(Db.time(rs, "FINISHED_AT"));
        return b;
    };

    private final NamedParameterJdbcTemplate jdbc;

    public BatchRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** Claims a file: fails with DuplicateKeyException when another server (or an earlier poll) has it. */
    public void insert(Batch b) {
        jdbc.update("INSERT INTO LOAD_BATCH (BATCH_ID, LIST_ID, FILE_NAME, FILE_SIZE, FILE_MTIME, SOURCE, STATUS, MESSAGE, "
                + "WORK_PATH, SUBMITTED_BY, RECEIVED_AT) VALUES (:id, :list, :name, :size, :mtime, :source, :status, :msg, "
                + ":path, :by, :at)", new MapSqlParameterSource()
                .addValue("id", b.getBatchId())
                .addValue("list", b.getListId())
                .addValue("name", Db.cut(b.getFileName(), 255))
                .addValue("size", b.getFileSize())
                .addValue("mtime", b.getFileMtime())
                .addValue("source", b.getSource())
                .addValue("status", b.getStatus().name())
                .addValue("msg", Db.cut(b.getMessage(), 1000))
                .addValue("path", b.getWorkPath())
                .addValue("by", b.getSubmittedBy())
                .addValue("at", Db.ts(b.getReceivedAt())));
    }

    public Optional<Batch> find(long batchId) {
        return jdbc.query("SELECT " + COLS + " FROM LOAD_BATCH WHERE BATCH_ID = :id",
                new MapSqlParameterSource("id", batchId), BATCH).stream().findFirst();
    }

    public void setStatus(long batchId, BatchStatus status, String message) {
        jdbc.update("UPDATE LOAD_BATCH SET STATUS = :s, MESSAGE = :m WHERE BATCH_ID = :id",
                new MapSqlParameterSource("s", status.name()).addValue("m", Db.cut(message, 1000)).addValue("id", batchId));
    }

    public void finish(long batchId, BatchStatus status, String message) {
        jdbc.update("UPDATE LOAD_BATCH SET STATUS = :s, MESSAGE = :m, FINISHED_AT = :now WHERE BATCH_ID = :id",
                new MapSqlParameterSource("s", status.name()).addValue("m", Db.cut(message, 1000))
                        .addValue("now", Db.now()).addValue("id", batchId));
    }

    public void assignList(long batchId, long listId, String delivery) {
        jdbc.update("UPDATE LOAD_BATCH SET LIST_ID = :l, DELIVERY = :d WHERE BATCH_ID = :id",
                new MapSqlParameterSource("l", listId).addValue("d", delivery).addValue("id", batchId));
    }

    public void started(long batchId) {
        jdbc.update("UPDATE LOAD_BATCH SET STATUS = 'LOADING', STARTED_AT = :now, MESSAGE = NULL WHERE BATCH_ID = :id",
                new MapSqlParameterSource("now", Db.now()).addValue("id", batchId));
    }

    public void stage1Done(long batchId, String format, String sha256, long records, long refs, String layoutJson,
                           BatchStatus next) {
        jdbc.update("UPDATE LOAD_BATCH SET FILE_FORMAT = :f, SHA256 = :sha, RECORD_COUNT = :r, REF_COUNT = :refs, "
                        + "LAYOUT_JSON = :layout, STATUS = :s WHERE BATCH_ID = :id",
                new MapSqlParameterSource("f", format).addValue("sha", sha256).addValue("r", records).addValue("refs", refs)
                        .addValue("layout", layoutJson).addValue("s", next.name()).addValue("id", batchId));
    }

    public void setVersion(long batchId, int versionNo) {
        jdbc.update("UPDATE LOAD_BATCH SET VERSION_NO = :v WHERE BATCH_ID = :id",
                new MapSqlParameterSource("v", versionNo).addValue("id", batchId));
    }

    public void setWorkPath(long batchId, String path) {
        jdbc.update("UPDATE LOAD_BATCH SET WORK_PATH = :p WHERE BATCH_ID = :id",
                new MapSqlParameterSource("p", path).addValue("id", batchId));
    }

    /** Batches of the given statuses, oldest first. */
    public List<Batch> byStatus(Collection<BatchStatus> statuses) {
        List<String> names = new ArrayList<>();
        for (BatchStatus s : statuses) {
            names.add(s.name());
        }
        return jdbc.query("SELECT " + COLS + " FROM LOAD_BATCH WHERE STATUS IN (:s) ORDER BY RECEIVED_AT, BATCH_ID",
                new MapSqlParameterSource("s", names), BATCH);
    }

    /** Latest batches, optionally of one list, newest first. */
    public List<Batch> latest(Long listId, int max) {
        MapSqlParameterSource p = new MapSqlParameterSource("max", max);
        String where = "";
        if (listId != null) {
            where = " WHERE LIST_ID = :list";
            p.addValue("list", listId);
        }
        return jdbc.query("SELECT " + COLS + " FROM LOAD_BATCH" + where
                + " ORDER BY RECEIVED_AT DESC, BATCH_ID DESC FETCH FIRST :max ROWS ONLY", p, BATCH);
    }

    public List<Batch> since(LocalDateTime from) {
        return jdbc.query("SELECT " + COLS + " FROM LOAD_BATCH WHERE RECEIVED_AT >= :from ORDER BY RECEIVED_AT DESC, BATCH_ID DESC",
                new MapSqlParameterSource("from", Db.ts(from)), BATCH);
    }

    /** SHA-256 of the last batch of the list that produced a version (duplicate detection). */
    public Optional<String> lastLoadedSha(long listId, long excludeBatchId) {
        return jdbc.queryForList("SELECT SHA256 FROM LOAD_BATCH WHERE LIST_ID = :l AND BATCH_ID <> :b AND VERSION_NO IS NOT NULL "
                        + "AND STATUS IN ('TO_VALIDATE', 'PUBLISHED') ORDER BY BATCH_ID DESC FETCH FIRST 1 ROWS ONLY",
                new MapSqlParameterSource("l", listId).addValue("b", excludeBatchId), String.class).stream().findFirst();
    }

    /** Last batch of a list with a stage 1 done (its profile feeds the mapping screen). */
    public Optional<Batch> lastLoaded(long listId) {
        return jdbc.query("SELECT " + COLS + " FROM LOAD_BATCH WHERE LIST_ID = :l AND LAYOUT_JSON IS NOT NULL "
                        + "AND STATUS NOT IN ('FAILED', 'DUPLICATE') ORDER BY BATCH_ID DESC FETCH FIRST 1 ROWS ONLY",
                new MapSqlParameterSource("l", listId), BATCH).stream().findFirst();
    }

    /** Batches whose raw records are older than the retention and can be removed. */
    public List<Long> rawExpired(LocalDateTime before) {
        return jdbc.queryForList("SELECT BATCH_ID FROM LOAD_BATCH WHERE RECEIVED_AT < :b AND STATUS IN "
                        + "('PUBLISHED', 'REJECTED', 'DUPLICATE', 'FAILED') ORDER BY BATCH_ID",
                new MapSqlParameterSource("b", Db.ts(before)), Long.class);
    }

    // ------------------------------------------------------------------ steps

    /** Time of one step. */
    public static final class Step {
        public String code;
        public LocalDateTime startedAt;
        public LocalDateTime finishedAt;
        public Long durationMs;
        public String result;
    }

    public void stepStart(long batchId, String step) {
        MapSqlParameterSource p = new MapSqlParameterSource("b", batchId).addValue("s", step).addValue("now", Db.now());
        int n = jdbc.update("UPDATE BATCH_STEP SET STARTED_AT = :now, FINISHED_AT = NULL, DURATION_MS = NULL, RESULT = NULL "
                + "WHERE BATCH_ID = :b AND STEP_CODE = :s", p);
        if (n == 0) {
            jdbc.update("INSERT INTO BATCH_STEP (BATCH_ID, STEP_CODE, STARTED_AT) VALUES (:b, :s, :now)", p);
        }
    }

    public void stepEnd(long batchId, String step, long durationMs, String result) {
        jdbc.update("UPDATE BATCH_STEP SET FINISHED_AT = :now, DURATION_MS = :d, RESULT = :r WHERE BATCH_ID = :b AND STEP_CODE = :s",
                new MapSqlParameterSource("now", Db.now()).addValue("d", durationMs).addValue("r", Db.cut(result, 500))
                        .addValue("b", batchId).addValue("s", step));
    }

    public Map<Long, List<Step>> steps(Collection<Long> batchIds) {
        Map<Long, List<Step>> out = new LinkedHashMap<>();
        if (batchIds.isEmpty()) {
            return out;
        }
        jdbc.query("SELECT BATCH_ID, STEP_CODE, STARTED_AT, FINISHED_AT, DURATION_MS, RESULT FROM BATCH_STEP "
                + "WHERE BATCH_ID IN (:ids) ORDER BY BATCH_ID, STARTED_AT", new MapSqlParameterSource("ids", batchIds), rs -> {
            Step s = new Step();
            s.code = rs.getString("STEP_CODE");
            s.startedAt = Db.time(rs, "STARTED_AT");
            s.finishedAt = Db.time(rs, "FINISHED_AT");
            s.durationMs = Db.longOrNull(rs, "DURATION_MS");
            s.result = rs.getString("RESULT");
            out.computeIfAbsent(rs.getLong("BATCH_ID"), k -> new ArrayList<>()).add(s);
        });
        return out;
    }
}
