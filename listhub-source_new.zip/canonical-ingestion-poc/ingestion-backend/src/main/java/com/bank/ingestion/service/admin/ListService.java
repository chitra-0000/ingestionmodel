package com.bank.ingestion.service.admin;

import com.bank.ingestion.domain.AttrType;
import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.domain.ListDef;
import com.bank.ingestion.repository.IdAllocator;
import com.bank.ingestion.repository.ListRepository;
import com.bank.ingestion.util.ApiException;
import com.bank.ingestion.util.Texts;
import org.springframework.stereotype.Service;

import java.util.Locale;
import java.util.Optional;
import java.util.regex.Pattern;

/** Lists: create, change, and route a file name to its list. */
@Service
public class ListService {

    private static final Pattern ID_PREFIX = Pattern.compile("^[A-Z][A-Z0-9]{0,9}$");

    private final ListRepository lists;
    private final IdAllocator ids;

    public ListService(ListRepository lists, IdAllocator ids) {
        this.lists = lists;
        this.ids = ids;
    }

    public ListDef get(long listId) {
        return lists.find(listId).orElseThrow(() -> ApiException.notFound("List not found"));
    }

    public ListDef create(ListDef in, String user) {
        ListDef l = validate(in);
        if (lists.findByCode(l.getListCode()).isPresent()) {
            throw ApiException.conflict("A list with code " + l.getListCode() + " already exists");
        }
        l.setListId(ids.nextSmallId());
        l.setCreatedBy(user);
        lists.insert(l);
        return get(l.getListId());
    }

    public ListDef update(long listId, ListDef in) {
        ListDef current = get(listId);
        ListDef l = validate(in);
        l.setListId(listId);
        Optional<ListDef> sameCode = lists.findByCode(l.getListCode());
        if (sameCode.isPresent() && sameCode.get().getListId() != listId) {
            throw ApiException.conflict("A list with code " + l.getListCode() + " already exists");
        }
        if (!current.getListCode().equals(l.getListCode()) || !current.getIdPrefix().equals(l.getIdPrefix())) {
            // The code and prefix are part of every internal id already given: they cannot change afterwards.
            throw ApiException.badRequest("The list code and the id prefix cannot be changed once the list exists");
        }
        lists.update(l);
        return get(listId);
    }

    private static ListDef validate(ListDef in) {
        ListDef l = new ListDef();
        l.setListCode(Texts.requireListCode(in.getListCode()));
        if (Texts.isBlank(in.getName()) || in.getName().length() > 200) {
            throw ApiException.badRequest("The list name is required (at most 200 characters)");
        }
        l.setName(in.getName().trim());
        l.setProviderCode(Texts.requireProviderCode(in.getProviderCode()));
        l.setCategory(Texts.truncate(trimOrNull(in.getCategory()), 40));
        try {
            l.setFileFormat(FileFormat.of(in.getFileFormat()).name());
        } catch (IllegalArgumentException e) {
            throw ApiException.badRequest("File format must be XML, CSV, JSON or AUTO");
        }
        l.setFilePattern(pattern(in.getFilePattern(), "File name pattern"));
        l.setDeltaPattern(pattern(in.getDeltaPattern(), "Delta file pattern"));
        l.setRecordElements(Texts.truncate(trimOrNull(in.getRecordElements()), 500));
        String prefix = in.getIdPrefix() == null ? "RGL" : in.getIdPrefix().trim().toUpperCase(Locale.ROOT);
        if (!ID_PREFIX.matcher(prefix).matches()) {
            throw ApiException.badRequest("Id prefix: 1-10 letters or digits, starting with a letter (e.g. RGL or BNP)");
        }
        l.setIdPrefix(prefix);
        String matchKey = trimOrNull(in.getMatchKeyAttrs());
        if (matchKey != null) {
            StringBuilder sb = new StringBuilder();
            for (String a : matchKey.split(",")) {
                if (a.trim().isEmpty()) {
                    continue;
                }
                try {
                    sb.append(sb.length() == 0 ? "" : ",").append(AttrType.of(a).name());
                } catch (IllegalArgumentException e) {
                    throw ApiException.badRequest("Unknown attribute in the match key: " + Texts.truncate(a, 40));
                }
            }
            matchKey = sb.length() == 0 ? null : sb.toString();
        }
        l.setMatchKeyAttrs(matchKey);
        String wf = in.getWorkflow() == null ? "MANUAL" : in.getWorkflow().trim().toUpperCase(Locale.ROOT);
        if (!"MANUAL".equals(wf) && !"AUTO".equals(wf)) {
            throw ApiException.badRequest("Workflow must be MANUAL or AUTO");
        }
        l.setWorkflow(wf);
        String exports = in.getExportFormats() == null ? "CSV,XML" : in.getExportFormats().toUpperCase(Locale.ROOT).replace(" ", "");
        for (String f : exports.split(",")) {
            if (!f.isEmpty() && !"CSV".equals(f) && !"XML".equals(f)) {
                throw ApiException.badRequest("Export formats: CSV and / or XML");
            }
        }
        l.setExportFormats(exports);
        if (in.getMaxRejectPercent() < 0 || in.getMaxRejectPercent() > 100) {
            throw ApiException.badRequest("Maximum rejected share must be between 0 and 100 %");
        }
        l.setMaxRejectPercent(in.getMaxRejectPercent());
        l.setActive(in.isActive());
        l.setDescription(Texts.truncate(trimOrNull(in.getDescription()), 1000));
        return l;
    }

    private static String pattern(String raw, String what) {
        String p = trimOrNull(raw);
        if (p == null) {
            return null;
        }
        if (p.length() > 200 || p.contains("/") || p.contains("\\")) {
            throw ApiException.badRequest(what + ": a file name with * for the changing part, at most 200 characters");
        }
        return p;
    }

    private static String trimOrNull(String s) {
        return s == null || s.trim().isEmpty() ? null : s.trim();
    }

    // ------------------------------------------------------------------ routing

    /** The list a file name belongs to: the matching pattern with the most fixed characters wins. */
    public Optional<ListDef> route(String fileName) {
        ListDef best = null;
        int bestScore = -1;
        for (ListDef l : lists.findAll()) {
            if (!l.isActive() || l.getFilePattern() == null) {
                continue;
            }
            if (matches(l.getFilePattern(), fileName)) {
                int score = l.getFilePattern().replace("*", "").length();
                if (score > bestScore) {
                    best = l;
                    bestScore = score;
                }
            }
        }
        return Optional.ofNullable(best);
    }

    /** FULL or DELTA for a file of this list. */
    public static String delivery(ListDef list, String fileName) {
        return list.getDeltaPattern() != null && matches(list.getDeltaPattern(), fileName) ? "DELTA" : "FULL";
    }

    /** Glob match, case-insensitive: "*" = any text, "?" = one character. */
    public static boolean matches(String glob, String name) {
        StringBuilder re = new StringBuilder("^");
        for (char c : glob.toCharArray()) {
            if (c == '*') {
                re.append(".*");
            } else if (c == '?') {
                re.append('.');
            } else {
                re.append(Pattern.quote(String.valueOf(c)));
            }
        }
        re.append('$');
        return Pattern.compile(re.toString(), Pattern.CASE_INSENSITIVE).matcher(name).matches();
    }
}
