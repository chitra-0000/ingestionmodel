package com.bank.ingestion.service.batch;

import com.bank.ingestion.config.ListHubProperties;
import com.bank.ingestion.domain.Batch;
import com.bank.ingestion.domain.BatchStatus;
import com.bank.ingestion.domain.Layout;
import com.bank.ingestion.domain.ListDef;
import com.bank.ingestion.domain.ListVersion;
import com.bank.ingestion.domain.MappingRules;
import com.bank.ingestion.domain.VersionStatus;
import com.bank.ingestion.repository.BatchRepository;
import com.bank.ingestion.repository.CanonicalRepository;
import com.bank.ingestion.repository.IdAllocator;
import com.bank.ingestion.repository.RawRepository;
import com.bank.ingestion.repository.VersionRepository;
import com.bank.ingestion.service.admin.ListService;
import com.bank.ingestion.service.canonical.CanonicalProcessor;
import com.bank.ingestion.service.canonical.MappingService;
import com.bank.ingestion.service.raw.RawLoader;
import com.bank.ingestion.service.version.VersionService;
import com.bank.ingestion.util.ApiException;
import com.bank.ingestion.util.Json;
import com.bank.ingestion.util.Texts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

/**
 * Runs batches end to end: claim -> stage 1 (raw) -> stage 2 (canonical, new version) -> waits for approval.
 *
 * Up to listhub.parallel-files files are loaded at the same time; the others wait in the queue (QUEUED).
 * Stage 2 of one list runs one version at a time, in arrival order: a file whose list still has an open
 * version waits (WAITING) and starts by itself once that version is published or rejected.
 */
@Service
public class BatchService {

    private static final Logger LOG = LoggerFactory.getLogger(BatchService.class);
    public static final String STEP_RECEIVE = "RECEIVE";
    public static final String STEP_RAW = "RAW_LOAD";
    public static final String STEP_CANONICAL = "CANONICAL";

    private static final Set<BatchStatus> READY_FOR_STAGE2 = new HashSet<>(Arrays.asList(
            BatchStatus.LOADED, BatchStatus.WAITING, BatchStatus.MAPPING_REVIEW));
    /** Statuses of a file that has not had its version yet (stage 2 keeps the arrival order within a list). */
    private static final Set<BatchStatus> NOT_YET_VERSIONED = new HashSet<>(Arrays.asList(
            BatchStatus.QUEUED, BatchStatus.LOADING, BatchStatus.LOADED, BatchStatus.WAITING, BatchStatus.MAPPING_REVIEW));

    private final BatchRepository batches;
    private final RawRepository raw;
    private final CanonicalRepository canonical;
    private final VersionRepository versions;
    private final IdAllocator ids;
    private final ListService lists;
    private final MappingService mappings;
    private final RawLoader rawLoader;
    private final CanonicalProcessor processor;
    private final VersionService versionService;
    private final ListHubProperties props;
    private final ExecutorService pool;
    /** Batches queued or running in this JVM. */
    private final Set<Long> inFlight = ConcurrentHashMap.newKeySet();
    /** One stage 2 at a time per list. */
    private final Map<Long, Object> listLocks = new ConcurrentHashMap<>();

    public BatchService(BatchRepository batches, RawRepository raw, CanonicalRepository canonical, VersionRepository versions,
                        IdAllocator ids, ListService lists, MappingService mappings, RawLoader rawLoader,
                        CanonicalProcessor processor, VersionService versionService, ListHubProperties props) {
        this.batches = batches;
        this.raw = raw;
        this.canonical = canonical;
        this.versions = versions;
        this.ids = ids;
        this.lists = lists;
        this.mappings = mappings;
        this.rawLoader = rawLoader;
        this.processor = processor;
        this.versionService = versionService;
        this.props = props;
        int parallel = props.effectiveParallelFiles();
        this.pool = Executors.newFixedThreadPool(parallel, r -> {
            Thread t = new Thread(r, "batch-runner");
            t.setDaemon(true);
            return t;
        });
        LOG.info("ListHub: {} files in parallel, {} workers per file", parallel, props.effectiveWorkersPerFile());
    }

    @PreDestroy
    void stop() {
        pool.shutdownNow();
    }

    // ================================================================== intake

    /**
     * Registers a file already moved into the work folder (from the inbound folder or an upload).
     * The (name, size, time) triple is unique in the database: when two servers see the same file, one wins.
     */
    public Batch register(Path workFile, String originalName, long size, long mtime, String source, Long listId, String user) {
        Batch b = new Batch();
        b.setBatchId(ids.nextSmallId());
        b.setFileName(Texts.truncate(originalName, 255));
        b.setFileSize(size);
        b.setFileMtime(mtime);
        b.setSource(source);
        b.setSubmittedBy(user);
        b.setReceivedAt(LocalDateTime.now());
        b.setWorkPath(workFile == null ? null : workFile.toString());
        ListDef list = listId != null ? lists.get(listId) : lists.route(originalName).orElse(null);
        if (list == null) {
            b.setStatus(BatchStatus.UNMATCHED);
            b.setMessage("No list's file name pattern matches this file. Assign it to a list.");
        } else {
            b.setListId(list.getListId());
            b.setStatus(BatchStatus.QUEUED);
        }
        batches.insert(b);
        if (list != null) {
            batches.assignList(b.getBatchId(), list.getListId(), ListService.delivery(list, originalName));
        }
        batches.stepStart(b.getBatchId(), STEP_RECEIVE);
        batches.stepEnd(b.getBatchId(), STEP_RECEIVE, 0, list == null ? "No matching list" : "Routed to list " + list.getListCode());
        if (list != null) {
            submit(b.getBatchId());
        }
        return batches.find(b.getBatchId()).orElse(b);
    }

    /** An unmatched (or failed) file is given to a list by a user. */
    public Batch assign(long batchId, long listId) {
        Batch b = get(batchId);
        if (b.getStatus() != BatchStatus.UNMATCHED && b.getStatus() != BatchStatus.FAILED) {
            throw ApiException.conflict("Only an unmatched or failed file can be assigned");
        }
        ListDef list = lists.get(listId);
        batches.assignList(batchId, listId, ListService.delivery(list, b.getFileName()));
        batches.setStatus(batchId, BatchStatus.QUEUED, "Assigned to list " + list.getListCode());
        submit(batchId);
        return get(batchId);
    }

    public Batch retry(long batchId) {
        Batch b = get(batchId);
        if (b.getStatus() != BatchStatus.FAILED) {
            throw ApiException.conflict("Only a failed file can be loaded again");
        }
        if (b.getListId() == null) {
            throw ApiException.badRequest("Assign the file to a list first");
        }
        batches.setStatus(batchId, BatchStatus.QUEUED, "Loaded again");
        submit(batchId);
        return get(batchId);
    }

    public Batch get(long batchId) {
        return batches.find(batchId).orElseThrow(() -> ApiException.notFound("Batch not found"));
    }

    private void submit(long batchId) {
        if (!inFlight.add(batchId)) {
            return;
        }
        try {
            pool.execute(() -> {
                try {
                    run(batchId);
                } finally {
                    inFlight.remove(batchId);
                }
            });
        } catch (RejectedExecutionException e) {
            inFlight.remove(batchId);
            LOG.warn("Batch {} could not be queued (shutting down)", batchId);
        }
    }

    // ================================================================== run

    private void run(long batchId) {
        Batch b = batches.find(batchId).orElse(null);
        if (b == null) {
            return;
        }
        try {
            if (b.getStatus() == BatchStatus.QUEUED) {
                stage1(b);
                b = get(batchId);
            }
            if (READY_FOR_STAGE2.contains(b.getStatus())) {
                stage2(b);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            batches.finish(batchId, BatchStatus.FAILED, "Stopped");
        } catch (Exception e) {
            LOG.error("Batch {} failed", batchId, e);
            batches.finish(batchId, BatchStatus.FAILED, "Failed: " + Texts.truncate(e.getMessage(), 800));
            moveFile(batches.find(batchId).orElse(b), props.errorDir());
        }
    }

    private void stage1(Batch b) throws IOException, InterruptedException {
        long batchId = b.getBatchId();
        ListDef list = lists.get(b.getListId());
        Path file = workFile(b);
        batches.started(batchId);
        batches.stepStart(batchId, STEP_RAW);
        raw.deleteBatch(batchId);
        long t0 = System.currentTimeMillis();
        RawLoader.Result r;
        try {
            Layout previous = batches.lastLoaded(list.getListId())
                    .filter(x -> x.getBatchId() != batchId && x.getLayoutJson() != null)
                    .map(x -> Json.read(x.getLayoutJson(), Layout.class)).orElse(null);
            r = rawLoader.load(batchId, list, file, previous);
        } catch (IOException | RuntimeException e) {
            batches.stepEnd(batchId, STEP_RAW, System.currentTimeMillis() - t0, "Failed: " + Texts.truncate(e.getMessage(), 300));
            raw.deleteBatch(batchId);
            throw e;
        }
        long ms = System.currentTimeMillis() - t0;
        batches.stepEnd(batchId, STEP_RAW, ms, String.format("%,d records, %,d reference codes in %d lists, %d field paths",
                r.records, r.refs, r.refLists, r.profilePaths));
        Optional<String> lastSha = batches.lastLoadedSha(list.getListId(), batchId);
        if (lastSha.isPresent() && lastSha.get().equals(r.sha256)) {
            batches.stage1Done(batchId, r.format, r.sha256, r.records, r.refs, Json.write(r.layout), BatchStatus.DUPLICATE);
            batches.finish(batchId, BatchStatus.DUPLICATE, "Same content as the list's previous file: nothing to do");
            raw.deleteBatch(batchId);
            moveFile(get(batchId), props.archiveDir());
            return;
        }
        batches.stage1Done(batchId, r.format, r.sha256, r.records, r.refs, Json.write(r.layout), BatchStatus.LOADED);
        mappings.ensureDraft(list.getListId(), get(batchId));
    }

    private void stage2(Batch b) throws InterruptedException {
        long listId = b.getListId();
        synchronized (listLocks.computeIfAbsent(listId, k -> new Object())) {
            Batch current = get(b.getBatchId());
            if (!READY_FOR_STAGE2.contains(current.getStatus())) {
                return;
            }
            Optional<ListVersion> open = versions.open(listId);
            if (open.isPresent()) {
                batches.setStatus(b.getBatchId(), BatchStatus.WAITING, "Waits for version " + open.get().getVersionNo()
                        + " of the list to be published or rejected");
                return;
            }
            for (Batch earlier : batches.byStatus(NOT_YET_VERSIONED)) {
                if (earlier.getListId() != null && earlier.getListId() == listId && earlier.getBatchId() < b.getBatchId()) {
                    batches.setStatus(b.getBatchId(), BatchStatus.WAITING, "Waits for the earlier file " + earlier.getFileName());
                    return;
                }
            }
            Optional<Map.Entry<Integer, MappingRules>> mapping = mappings.approved(listId);
            if (!mapping.isPresent()) {
                batches.setStatus(b.getBatchId(), BatchStatus.MAPPING_REVIEW,
                        "Review and approve the mapping of the list; loading continues by itself afterwards");
                return;
            }
            process(current, lists.get(listId), mapping.get().getKey(), mapping.get().getValue());
        }
    }

    private void process(Batch b, ListDef list, int mappingVersion, MappingRules rules) throws InterruptedException {
        long batchId = b.getBatchId();
        int version = versions.nextVersionNo(list.getListId());
        boolean full = !"DELTA".equals(b.getDelivery());
        ListVersion v = new ListVersion();
        v.setListId(list.getListId());
        v.setVersionNo(version);
        v.setBatchId(batchId);
        v.setStatus(VersionStatus.TO_VALIDATE);
        v.setDelivery(full ? "FULL" : "DELTA");
        v.setMappingVersion(mappingVersion);
        versions.insert(v);
        batches.setVersion(batchId, version);
        batches.setStatus(batchId, BatchStatus.PROCESSING, null);
        batches.stepStart(batchId, STEP_CANONICAL);
        long t0 = System.currentTimeMillis();
        CanonicalProcessor.Result r;
        try {
            r = processor.process(batchId, list, Json.read(b.getLayoutJson(), Layout.class), rules, version, full, b.getRecordCount());
        } catch (RuntimeException | InterruptedException e) {
            batches.stepEnd(batchId, STEP_CANONICAL, System.currentTimeMillis() - t0, "Failed: " + Texts.truncate(e.getMessage(), 300));
            canonical.rollback(list.getListId(), version);
            versions.delete(list.getListId(), version);
            throw e;
        }
        long ms = System.currentTimeMillis() - t0;
        v.setFileRecords(r.fileRecords);
        v.setTotalRecords(r.totalAfter);
        v.setCreatedCount(r.created);
        v.setModifiedCount(r.modified);
        v.setMinorCount(r.minor);
        v.setDeletedCount(r.deleted);
        v.setUnchangedCount(r.unchanged);
        v.setRejectedCount(r.rejected);
        v.setFlaggedCount(r.flagged);
        double rejectPct = r.fileRecords == 0 ? 0 : r.rejected * 100.0 / r.fileRecords;
        if (rejectPct > list.getMaxRejectPercent()) {
            r.warnings.add(String.format("%.2f %% of the records were rejected (limit %.2f %%)", rejectPct, list.getMaxRejectPercent()));
        }
        Map<String, Object> issues = new LinkedHashMap<>();
        issues.put("reject", r.rejectCodes);
        issues.put("flag", r.flagCodes);
        issues.put("warnings", r.warnings);
        v.setIssuesJson(Json.write(issues));
        versions.updateCounts(v);
        batches.stepEnd(batchId, STEP_CANONICAL, ms, String.format("%,d created, %,d modified, %,d minor, %,d deleted, "
                        + "%,d unchanged, %,d rejected, %,d flagged", r.created, r.modified, r.minor, r.deleted, r.unchanged,
                r.rejected, r.flagged));
        batches.setStatus(batchId, BatchStatus.TO_VALIDATE, "Version " + version + " ready for validation");
        moveFile(get(batchId), props.archiveDir());
        if (list.isAutoWorkflow() && r.warnings.isEmpty()) {
            versionService.publish(list.getListId(), version, VersionService.SYSTEM_USER);
        }
    }

    // ================================================================== resume

    /** A version was published or rejected: the next waiting file of that list can start. */
    @EventListener
    public void onVersionDecided(VersionService.VersionDecided e) {
        resume();
    }

    /** Starts stage 2 for the oldest ready batch of every list (also after a mapping approval). */
    @Scheduled(fixedDelay = 15000, initialDelay = 15000)
    public void resume() {
        Set<Long> listsSeen = new HashSet<>();
        for (Batch b : batches.byStatus(READY_FOR_STAGE2)) {
            if (b.getListId() == null || !listsSeen.add(b.getListId())) {
                continue;
            }
            if (b.getStatus() == BatchStatus.MAPPING_REVIEW && !mappings.approved(b.getListId()).isPresent()) {
                continue;
            }
            if (b.getStatus() == BatchStatus.WAITING && versions.open(b.getListId()).isPresent()) {
                continue;
            }
            submit(b.getBatchId());
        }
        for (Batch b : batches.byStatus(java.util.Collections.singleton(BatchStatus.QUEUED))) {
            submit(b.getBatchId());
        }
    }

    /** After a restart: work interrupted in the middle is started again from a clean state. */
    @EventListener(ApplicationReadyEvent.class)
    public void recover() {
        for (Batch b : batches.byStatus(Arrays.asList(BatchStatus.LOADING, BatchStatus.PROCESSING))) {
            if (b.getStatus() == BatchStatus.LOADING) {
                raw.deleteBatch(b.getBatchId());
                batches.setStatus(b.getBatchId(), BatchStatus.QUEUED, "Restarted after an interruption");
            } else {
                if (b.getVersionNo() != null) {
                    canonical.rollback(b.getListId(), b.getVersionNo());
                    versions.delete(b.getListId(), b.getVersionNo());
                }
                batches.setStatus(b.getBatchId(), BatchStatus.LOADED, "Restarted after an interruption");
            }
            LOG.warn("Batch {} was interrupted ({}); it is started again", b.getBatchId(), b.getStatus());
        }
        resume();
    }

    // ================================================================== files

    private Path workFile(Batch b) throws IOException {
        if (b.getWorkPath() == null) {
            throw new IOException("The file of batch " + b.getBatchId() + " is not available");
        }
        Path p = java.nio.file.Paths.get(b.getWorkPath()).toAbsolutePath().normalize();
        if (!p.startsWith(props.base()) || !Files.isRegularFile(p)) {
            throw new IOException("The file of batch " + b.getBatchId() + " is not in the work folder any more");
        }
        return p;
    }

    /** Moves the batch's file to archive/<day>/ or error/ (best effort; the batch result does not depend on it). */
    private void moveFile(Batch b, Path targetRoot) {
        if (b == null || b.getWorkPath() == null) {
            return;
        }
        try {
            Path src = java.nio.file.Paths.get(b.getWorkPath()).toAbsolutePath().normalize();
            if (!src.startsWith(props.base()) || !Files.exists(src)) {
                return;
            }
            Path dir = targetRoot.equals(props.archiveDir()) ? targetRoot.resolve(LocalDate.now().toString()) : targetRoot;
            Files.createDirectories(dir);
            Path dst = dir.resolve(src.getFileName());
            Files.move(src, dst, StandardCopyOption.REPLACE_EXISTING);
            batches.setWorkPath(b.getBatchId(), dst.toString());
        } catch (IOException e) {
            LOG.warn("Batch {}: file not moved to {}: {}", b.getBatchId(), targetRoot, e.getMessage());
        }
    }

    /** Opens the batch's original file (archive or work), for download. */
    public InputStream openFile(long batchId) throws IOException {
        return Files.newInputStream(workFileAnyState(get(batchId)));
    }

    private Path workFileAnyState(Batch b) throws IOException {
        if (b.getWorkPath() == null) {
            throw new IOException("No file");
        }
        Path p = java.nio.file.Paths.get(b.getWorkPath()).toAbsolutePath().normalize();
        if (!p.startsWith(props.base()) || !Files.isRegularFile(p)) {
            throw ApiException.notFound("The file is not available any more");
        }
        return p;
    }

    public List<Batch> latest(Long listId, int max) {
        return batches.latest(listId, max);
    }
}
