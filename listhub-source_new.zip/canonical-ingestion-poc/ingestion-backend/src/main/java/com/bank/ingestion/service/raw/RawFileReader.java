package com.bank.ingestion.service.raw;

import com.bank.ingestion.config.XmlSecurity;
import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.domain.Layout;
import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.StreamReadConstraints;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PushbackInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Stage 1 reader: streams a provider file once and hands every record to the sink as bytes
 * (XML fragment, CSV line or JSON object), plus the reference lists found in the file.
 * Memory use does not depend on the file size.
 */
public final class RawFileReader {

    /** Receives what the reader finds. Called from the reader thread only. */
    public interface Sink {
        void record(String element, String key, byte[] payload);

        void ref(String listName, String code, String label);
    }

    private static final XMLInputFactory XML_IN = XmlSecurity.newXmlInputFactory();
    private static final XMLOutputFactory XML_OUT = XMLOutputFactory.newInstance();
    private static final JsonFactory JSON = JsonFactory.builder()
            .streamReadConstraints(StreamReadConstraints.builder().maxStringLength(10_000_000).maxNestingDepth(200).build())
            .build();
    /** Attributes that hold a record's own id (key shown in the raw table). */
    private static final Set<String> ID_ATTRS = new HashSet<>(Arrays.asList("id", "uid", "ref", "reference", "entityid", "personid"));
    private static final Set<String> LABEL_ATTRS = new HashSet<>(Arrays.asList("name", "label", "description", "value", "text", "desc"));
    private static final long LAYOUT_SCAN_BYTES = 64L * 1024 * 1024;
    private static final int LAYOUT_ENOUGH_RECORDS = 2000;

    private RawFileReader() {
    }

    // ================================================================== format and layout

    /** XML, JSON or CSV from the first non-blank character of the file. */
    public static FileFormat sniff(InputStream in) throws IOException {
        PushbackInputStream p = new PushbackInputStream(in, 4);
        int c;
        do {
            c = p.read();
        } while (c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == 0xEF || c == 0xBB || c == 0xBF);
        if (c == '<') {
            return FileFormat.XML;
        }
        if (c == '{' || c == '[') {
            return FileFormat.JSON;
        }
        return FileFormat.CSV;
    }

    /**
     * XML layout from the beginning of the file: the element that holds the most "complex" children
     * (children that have children) is the record parent; its children are the records.
     * Reference lists (elements named ...List) are skipped. Configured record elements win.
     */
    public static Layout detectXml(InputStream in, List<String> configuredRecordElements) throws IOException {
        Layout layout = new Layout();
        layout.setFormat(FileFormat.XML.name());
        if (configuredRecordElements != null && !configuredRecordElements.isEmpty()) {
            layout.setRecordElements(new ArrayList<>(configuredRecordElements));
            return layout;
        }
        CountingInputStream counted = new CountingInputStream(new BufferedInputStream(in, 1 << 16));
        Map<String, int[]> childCounts = new HashMap<>();
        Map<String, int[]> instances = new HashMap<>();
        Map<String, Set<String>> complexChildren = new LinkedHashMap<>();
        Deque<String> path = new ArrayDeque<>();
        Deque<boolean[]> hasChild = new ArrayDeque<>();
        int listDepth = -1;
        try {
            XMLStreamReader r = XML_IN.createXMLStreamReader(counted);
            int best = 0;
            while (r.hasNext() && counted.count() < LAYOUT_SCAN_BYTES) {
                int ev = r.next();
                if (ev == XMLStreamConstants.START_ELEMENT) {
                    String name = r.getLocalName();
                    if (!hasChild.isEmpty()) {
                        hasChild.peek()[0] = true;
                    }
                    path.push(name);
                    hasChild.push(new boolean[]{false, r.getAttributeCount() > 0});
                    if (listDepth < 0 && isRefListName(name)) {
                        listDepth = path.size();
                    }
                    if (listDepth < 0) {
                        instances.computeIfAbsent(join(path), k -> new int[1])[0]++;
                    }
                } else if (ev == XMLStreamConstants.END_ELEMENT) {
                    boolean[] state = hasChild.pop();
                    boolean complex = state[0] || state[1];
                    String name = path.pop();
                    if (listDepth > 0 && path.size() + 1 == listDepth) {
                        listDepth = -1;
                    } else if (listDepth < 0 && complex && !path.isEmpty()) {
                        String parent = join(path);
                        complexChildren.computeIfAbsent(parent, k -> new HashSet<>()).add(name);
                        int[] cnt = childCounts.computeIfAbsent(parent, k -> new int[1]);
                        cnt[0]++;
                        best = Math.max(best, cnt[0]);
                    }
                    if (best >= LAYOUT_ENOUGH_RECORDS) {
                        break;
                    }
                }
            }
        } catch (XMLStreamException e) {
            // End of the sample in the middle of an element, or a broken file: decide from what was read.
            if (childCounts.isEmpty()) {
                throw new IOException("The file is not well-formed XML: " + e.getMessage(), e);
            }
        }
        // The record container holds many records per instance (Records: thousands), a record holds few
        // complex children per instance (Person: NameDetails, DateDetails ...): pick the highest ratio.
        String parent = null;
        double max = 0;
        for (Map.Entry<String, int[]> e : childCounts.entrySet()) {
            int[] inst = instances.get(e.getKey());
            // per instance, and shallower wins on a tie (a record's own NameDetails also repeat children)
            double ratio = e.getValue()[0] / (double) (inst == null ? 1 : Math.max(1, inst[0]))
                    / (1 + e.getKey().split("/").length);
            if (ratio > max) {
                max = ratio;
                parent = e.getKey();
            }
        }
        if (parent == null) {
            throw new IOException("No repeating record element found in the XML file. Set the record element names on the list.");
        }
        layout.setRecordParent(parent);
        layout.setRecordElements(new ArrayList<>(complexChildren.get(parent)));
        return layout;
    }

    public static boolean isRefListName(String name) {
        return name.length() > 4 && name.toLowerCase(Locale.ROOT).endsWith("list");
    }

    private static String join(Deque<String> path) {
        StringBuilder sb = new StringBuilder();
        java.util.Iterator<String> it = path.descendingIterator();
        while (it.hasNext()) {
            if (sb.length() > 0) {
                sb.append('/');
            }
            sb.append(it.next());
        }
        return sb.toString();
    }

    // ================================================================== XML

    /**
     * Streams the XML file: records go to the sink as UTF-8 fragments with every element, attribute and text
     * of the record (namespace prefixes dropped); entries of ...List elements outside the records go to ref().
     */
    public static long readXml(InputStream in, Layout layout, Sink sink) throws IOException {
        Set<String> recordNames = new HashSet<>(layout.getRecordElements());
        String recordParent = layout.getRecordParent();
        Deque<String> path = new ArrayDeque<>();
        long count = 0;
        try {
            XMLStreamReader r = XML_IN.createXMLStreamReader(new BufferedInputStream(in, 1 << 16));
            int refDepth = -1;
            String refList = null;
            while (r.hasNext()) {
                int ev = r.next();
                if (ev == XMLStreamConstants.START_ELEMENT) {
                    String name = r.getLocalName();
                    if (refDepth < 0 && recordNames.contains(name)
                            && (recordParent == null || recordParent.equals(join(path)))) {
                        String key = idAttr(r);
                        byte[] bytes = copyElement(r);
                        sink.record(name, key, bytes);
                        count++;
                        continue;
                    }
                    path.push(name);
                    if (refDepth < 0 && isRefListName(name)) {
                        refDepth = path.size();
                        refList = name;
                    } else if (refDepth > 0 && path.size() == refDepth + 1) {
                        readRefEntry(r, refList, sink);
                        path.pop();
                    }
                } else if (ev == XMLStreamConstants.END_ELEMENT) {
                    if (refDepth > 0 && path.size() == refDepth) {
                        refDepth = -1;
                        refList = null;
                    }
                    path.pop();
                }
            }
        } catch (XMLStreamException e) {
            throw new IOException("XML error after record " + count + ": " + e.getMessage(), e);
        }
        return count;
    }

    private static String idAttr(XMLStreamReader r) {
        for (int i = 0; i < r.getAttributeCount(); i++) {
            if (ID_ATTRS.contains(r.getAttributeLocalName(i).toLowerCase(Locale.ROOT))) {
                return r.getAttributeValue(i);
            }
        }
        return null;
    }

    /** Copies the current element and its subtree to bytes; the reader ends on the element's END_ELEMENT. */
    private static byte[] copyElement(XMLStreamReader r) throws XMLStreamException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(2048);
        XMLStreamWriter w = XML_OUT.createXMLStreamWriter(out, "UTF-8");
        int depth = 0;
        do {
            int ev = r.getEventType();
            if (ev == XMLStreamConstants.START_ELEMENT) {
                w.writeStartElement(r.getLocalName());
                for (int i = 0; i < r.getAttributeCount(); i++) {
                    w.writeAttribute(r.getAttributeLocalName(i), r.getAttributeValue(i));
                }
                depth++;
            } else if (ev == XMLStreamConstants.END_ELEMENT) {
                w.writeEndElement();
                depth--;
                if (depth == 0) {
                    break;
                }
            } else if (ev == XMLStreamConstants.CHARACTERS || ev == XMLStreamConstants.CDATA
                    || ev == XMLStreamConstants.SPACE) {
                w.writeCharacters(r.getText());
            }
            r.next();
        } while (true);
        w.flush();
        w.close();
        return out.toByteArray();
    }

    /** One entry of a reference list: code from an id/code attribute, label from a name attribute or the text. */
    private static void readRefEntry(XMLStreamReader r, String listName, Sink sink) throws XMLStreamException {
        String code = null;
        String label = null;
        String firstAttr = null;
        String secondAttr = null;
        for (int i = 0; i < r.getAttributeCount(); i++) {
            String an = r.getAttributeLocalName(i).toLowerCase(Locale.ROOT);
            String av = r.getAttributeValue(i);
            if (code == null && (an.equals("code") || an.equals("id") || an.endsWith("id") || an.endsWith("code"))) {
                code = av;
            } else if (label == null && LABEL_ATTRS.contains(an)) {
                label = av;
            }
            if (firstAttr == null) {
                firstAttr = av;
            } else if (secondAttr == null) {
                secondAttr = av;
            }
        }
        StringBuilder text = new StringBuilder();
        int depth = 1;
        while (depth > 0 && r.hasNext()) {
            int ev = r.next();
            if (ev == XMLStreamConstants.START_ELEMENT) {
                depth++;
            } else if (ev == XMLStreamConstants.END_ELEMENT) {
                depth--;
            } else if (ev == XMLStreamConstants.CHARACTERS || ev == XMLStreamConstants.CDATA) {
                text.append(r.getText());
            }
        }
        String t = text.toString().trim();
        if (code == null) {
            code = firstAttr != null ? firstAttr : t;
        }
        if (label == null) {
            label = !t.isEmpty() ? t : (secondAttr != null ? secondAttr : code);
        }
        if (code != null && !code.trim().isEmpty()) {
            sink.ref(listName, code.trim(), label == null ? null : label.trim());
        }
    }

    // ================================================================== CSV

    /** Reads the header (delimiter detected from it) and streams each row as one CSV line. */
    public static long readCsv(InputStream in, Layout layout, Sink sink) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8), 1 << 16);
        br.mark(1 << 20);
        int first = br.read();
        if (first != 0xFEFF) {
            br.reset();
        }
        br.mark(1 << 20);
        String firstLine = br.readLine();
        if (firstLine == null) {
            throw new IOException("The CSV file is empty");
        }
        br.reset();
        char delimiter = CsvParser.detectDelimiter(firstLine);
        CsvParser parser = new CsvParser(br, delimiter);
        List<String> header = parser.next();
        if (header == null || header.isEmpty()) {
            throw new IOException("The CSV file has no header line");
        }
        List<String> cleaned = new ArrayList<>(header.size());
        for (String h : header) {
            cleaned.add(h.trim());
        }
        layout.setFormat(FileFormat.CSV.name());
        layout.setHeader(cleaned);
        layout.setDelimiter(String.valueOf(delimiter));
        long count = 0;
        List<String> row;
        StringBuilder line = new StringBuilder(512);
        while ((row = parser.next()) != null) {
            line.setLength(0);
            CsvParser.encode(row, delimiter, line);
            sink.record("row", null, line.toString().getBytes(StandardCharsets.UTF_8));
            count++;
        }
        return count;
    }

    // ================================================================== JSON

    /**
     * Records = the objects of the top-level array, or of the first array found in the top-level object
     * (e.g. {"records": [...]}). Each object is copied as compact JSON.
     */
    public static long readJson(InputStream in, Layout layout, Sink sink) throws IOException {
        layout.setFormat(FileFormat.JSON.name());
        long count = 0;
        try (JsonParser p = JSON.createParser(new BufferedInputStream(in, 1 << 16))) {
            JsonToken t = p.nextToken();
            if (t == JsonToken.START_OBJECT) {
                String field = null;
                while ((t = p.nextToken()) != null && t != JsonToken.START_ARRAY) {
                    if (t == JsonToken.FIELD_NAME) {
                        field = p.getCurrentName();
                    } else if (t == JsonToken.START_OBJECT) {
                        p.skipChildren();
                    }
                }
                if (t == null) {
                    throw new IOException("No array of records found in the JSON file");
                }
                layout.setJsonArray(field);
            } else if (t != JsonToken.START_ARRAY) {
                throw new IOException("A JSON file must be an array of records or an object holding one");
            }
            while ((t = p.nextToken()) == JsonToken.START_OBJECT) {
                ByteArrayOutputStream out = new ByteArrayOutputStream(1024);
                try (JsonGenerator g = JSON.createGenerator(out, JsonEncoding.UTF8)) {
                    g.copyCurrentStructure(p);
                }
                sink.record("record", null, out.toByteArray());
                count++;
            }
        }
        return count;
    }

    /** Byte counter used by the layout scan. */
    static final class CountingInputStream extends java.io.FilterInputStream {
        private long count;

        CountingInputStream(InputStream in) {
            super(in);
        }

        long count() {
            return count;
        }

        @Override
        public int read() throws IOException {
            int b = super.read();
            if (b >= 0) {
                count++;
            }
            return b;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            int n = super.read(b, off, len);
            if (n > 0) {
                count += n;
            }
            return n;
        }
    }
}
