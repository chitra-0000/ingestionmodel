package com.bank.ingestion.domain;

import java.util.ArrayList;
import java.util.List;

/** What stage 1 found out about a file: format, record elements, reference lists, CSV header. */
public class Layout {

    private String format;
    /** XML: names of the record elements, e.g. Person, Entity. */
    private List<String> recordElements = new ArrayList<>();
    /** XML: path of the element holding the records, e.g. PFA/Records. */
    private String recordParent;
    /** XML: reference lists found (name -> number of entries). */
    private List<String> refLists = new ArrayList<>();
    /** CSV: header and delimiter. */
    private List<String> header = new ArrayList<>();
    private String delimiter;
    /** JSON: name of the array holding the records (empty = top-level array). */
    private String jsonArray;

    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format; }
    public List<String> getRecordElements() { return recordElements; }
    public void setRecordElements(List<String> recordElements) { this.recordElements = recordElements; }
    public String getRecordParent() { return recordParent; }
    public void setRecordParent(String recordParent) { this.recordParent = recordParent; }
    public List<String> getRefLists() { return refLists; }
    public void setRefLists(List<String> refLists) { this.refLists = refLists; }
    public List<String> getHeader() { return header; }
    public void setHeader(List<String> header) { this.header = header; }
    public String getDelimiter() { return delimiter; }
    public void setDelimiter(String delimiter) { this.delimiter = delimiter; }
    public String getJsonArray() { return jsonArray; }
    public void setJsonArray(String jsonArray) { this.jsonArray = jsonArray; }
}
