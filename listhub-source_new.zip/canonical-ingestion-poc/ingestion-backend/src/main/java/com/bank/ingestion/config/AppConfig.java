package com.bank.ingestion.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Configuration
public class AppConfig implements WebMvcConfigurer {

    private static final Logger LOG = LoggerFactory.getLogger(AppConfig.class);

    private final ListHubProperties props;

    public AppConfig(ListHubProperties props) {
        this.props = props;
    }

    /** Creates the folders at start-up and says where they are. */
    @PostConstruct
    void folders() throws IOException {
        for (Path p : new Path[]{props.inboundDir(), props.workDir(), props.archiveDir(), props.errorDir(), props.outboundDir()}) {
            Files.createDirectories(p);
        }
        LOG.info("ListHub folders under {}: inbound (watched), work, archive, error, outbound", props.base());
    }

    @Bean
    public TransactionTemplate transactionTemplate(DataSource dataSource) {
        return new TransactionTemplate(new DataSourceTransactionManager(dataSource));
    }

    /** Angular dev server only (ng serve on another port); the WAR serves the screens from the same origin. */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOrigins(props.getAllowedOrigin())
                .allowedMethods("GET", "POST", "PUT", "DELETE")
                .allowedHeaders("Content-Type", "X-XSRF-TOKEN")
                .allowCredentials(true)
                .maxAge(3600);
    }
}
