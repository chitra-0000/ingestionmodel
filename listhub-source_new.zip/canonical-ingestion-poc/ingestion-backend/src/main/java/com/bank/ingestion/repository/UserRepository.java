package com.bank.ingestion.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/** Application users (APP_USER). */
@Repository
public class UserRepository {

    /** One user. The password hash never leaves the server. */
    public static final class User {
        public String username;
        public String displayName;
        public String passwordHash;
        public String roles;
        public boolean active;
        public LocalDateTime createdAt;
    }

    private static final RowMapper<User> USER = (rs, i) -> {
        User u = new User();
        u.username = rs.getString("USERNAME");
        u.displayName = rs.getString("DISPLAY_NAME");
        u.passwordHash = rs.getString("PASSWORD_HASH");
        u.roles = rs.getString("ROLES");
        u.active = rs.getInt("ACTIVE") == 1;
        u.createdAt = Db.time(rs, "CREATED_AT");
        return u;
    };

    private final JdbcTemplate jdbc;

    public UserRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public long count() {
        Long n = jdbc.queryForObject("SELECT COUNT(*) FROM APP_USER", Long.class);
        return n == null ? 0 : n;
    }

    public Optional<User> find(String username) {
        return jdbc.query("SELECT USERNAME, DISPLAY_NAME, PASSWORD_HASH, ROLES, ACTIVE, CREATED_AT FROM APP_USER WHERE USERNAME = ?",
                USER, username).stream().findFirst();
    }

    public List<User> findAll() {
        return jdbc.query("SELECT USERNAME, DISPLAY_NAME, PASSWORD_HASH, ROLES, ACTIVE, CREATED_AT FROM APP_USER ORDER BY USERNAME", USER);
    }

    public void insert(User u) {
        jdbc.update("INSERT INTO APP_USER (USERNAME, DISPLAY_NAME, PASSWORD_HASH, ROLES, ACTIVE, CREATED_AT) VALUES (?, ?, ?, ?, ?, ?)",
                u.username, u.displayName, u.passwordHash, u.roles, u.active ? 1 : 0, Db.now());
    }

    public void update(String username, String displayName, String roles, boolean active) {
        jdbc.update("UPDATE APP_USER SET DISPLAY_NAME = ?, ROLES = ?, ACTIVE = ? WHERE USERNAME = ?",
                displayName, roles, active ? 1 : 0, username);
    }

    public void setPassword(String username, String hash) {
        jdbc.update("UPDATE APP_USER SET PASSWORD_HASH = ? WHERE USERNAME = ?", hash, username);
    }
}
