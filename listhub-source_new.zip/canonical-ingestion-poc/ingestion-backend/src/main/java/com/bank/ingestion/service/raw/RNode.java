package com.bank.ingestion.service.raw;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Light tree of one provider record, the same for XML, CSV and JSON: element name, attributes, text, children.
 * Mapping paths and the field profile work on this tree only, so they do not depend on the file format.
 */
public final class RNode {

    private final String name;
    private List<String> attrNames;
    private List<String> attrValues;
    private List<RNode> children;
    private StringBuilder text;

    public RNode(String name) {
        this.name = name;
    }

    public String name() {
        return name;
    }

    public void attr(String attrName, String value) {
        if (attrNames == null) {
            attrNames = new ArrayList<>(4);
            attrValues = new ArrayList<>(4);
        }
        attrNames.add(attrName);
        attrValues.add(value);
    }

    public String attr(String attrName) {
        if (attrNames == null) {
            return null;
        }
        for (int i = 0; i < attrNames.size(); i++) {
            if (attrNames.get(i).equalsIgnoreCase(attrName)) {
                return attrValues.get(i);
            }
        }
        return null;
    }

    public List<String> attrNames() {
        return attrNames == null ? Collections.<String>emptyList() : attrNames;
    }

    public List<String> attrValues() {
        return attrValues == null ? Collections.<String>emptyList() : attrValues;
    }

    public RNode add(RNode child) {
        if (children == null) {
            children = new ArrayList<>(6);
        }
        children.add(child);
        return child;
    }

    public List<RNode> children() {
        return children == null ? Collections.<RNode>emptyList() : children;
    }

    public boolean hasChildren() {
        return children != null && !children.isEmpty();
    }

    public void appendText(String s) {
        if (text == null) {
            text = new StringBuilder(s.length());
        }
        text.append(s);
    }

    /** Own text, trimmed; null when blank. */
    public String text() {
        if (text == null) {
            return null;
        }
        String t = text.toString().trim();
        return t.isEmpty() ? null : t;
    }

    /**
     * Value of an element: its own text; else the texts of its descendants joined with a space
     * (NameValue = FirstName Surname); else its attribute values joined (DateValue Day Month Year).
     */
    public String value() {
        String t = text();
        if (t != null) {
            return t;
        }
        if (hasChildren()) {
            StringBuilder sb = new StringBuilder();
            collect(this, sb);
            String s = sb.toString().trim();
            return s.isEmpty() ? null : s;
        }
        if (attrValues != null) {
            StringBuilder sb = new StringBuilder();
            for (String v : attrValues) {
                if (v != null && !v.trim().isEmpty()) {
                    if (sb.length() > 0) {
                        sb.append(' ');
                    }
                    sb.append(v.trim());
                }
            }
            return sb.length() == 0 ? null : sb.toString();
        }
        return null;
    }

    private static void collect(RNode n, StringBuilder sb) {
        for (RNode c : n.children()) {
            String t = c.text();
            if (t != null) {
                if (sb.length() > 0) {
                    sb.append(' ');
                }
                sb.append(t);
            }
            collect(c, sb);
        }
    }
}
