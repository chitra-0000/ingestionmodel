package com.bank.ingestion.service.version;

import com.bank.ingestion.domain.BatchStatus;
import com.bank.ingestion.domain.ListDef;
import com.bank.ingestion.domain.ListVersion;
import com.bank.ingestion.domain.VersionStatus;
import com.bank.ingestion.repository.BatchRepository;
import com.bank.ingestion.repository.CanonicalRepository;
import com.bank.ingestion.repository.ExportRepository;
import com.bank.ingestion.repository.VersionRepository;
import com.bank.ingestion.service.admin.ListService;
import com.bank.ingestion.service.export.ExportService;
import com.bank.ingestion.util.ApiException;
import com.bank.ingestion.util.Texts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

import java.io.IOException;
import java.util.List;

/**
 * Approval of a list version: validate (user A) -> certify (user B, not A) = publish.
 * Publication writes the export files and makes the version the one the subscriber API serves.
 * Rejection undoes the version's records; the next waiting file of the list then starts.
 */
@Service
public class VersionService {

    /** Published when a version is published or rejected: the next waiting batch of the list may start. */
    public static final class VersionDecided {
        private final long listId;

        public VersionDecided(long listId) {
            this.listId = listId;
        }

        public long getListId() {
            return listId;
        }
    }

    private static final Logger LOG = LoggerFactory.getLogger(VersionService.class);
    public static final String SYSTEM_USER = "system";

    private final VersionRepository versions;
    private final CanonicalRepository canonical;
    private final BatchRepository batches;
    private final ExportService exportService;
    private final ListService lists;
    private final TransactionTemplate tx;
    private final ApplicationEventPublisher events;

    public VersionService(VersionRepository versions, CanonicalRepository canonical, BatchRepository batches,
                          ExportService exportService, ListService lists, TransactionTemplate tx,
                          ApplicationEventPublisher events) {
        this.versions = versions;
        this.canonical = canonical;
        this.batches = batches;
        this.exportService = exportService;
        this.lists = lists;
        this.tx = tx;
        this.events = events;
    }

    public ListVersion get(long listId, int version) {
        return versions.find(listId, version).orElseThrow(() -> ApiException.notFound("Version not found"));
    }

    public synchronized ListVersion validate(long listId, int version, String user, String comment) {
        ListVersion v = get(listId, version);
        if (v.getStatus() != VersionStatus.TO_VALIDATE) {
            throw ApiException.conflict("Version " + version + " is " + v.getStatus() + ", not waiting for validation");
        }
        versions.validate(listId, version, user, comment);
        LOG.info("List {} version {} validated by {}", listId, version, Texts.forLog(user));
        return get(listId, version);
    }

    /** Certification by a second user publishes the version. */
    public synchronized ListVersion certify(long listId, int version, String user) {
        ListVersion v = get(listId, version);
        if (v.getStatus() != VersionStatus.VALIDATED) {
            throw ApiException.conflict("Version " + version + " must be validated before certification");
        }
        if (user.equalsIgnoreCase(v.getValidatedBy())) {
            throw ApiException.conflict("Four eyes: the version was validated by you; another user must certify it");
        }
        publish(listId, version, user);
        return get(listId, version);
    }

    /** Publication (certification, or automatic for lists with the AUTO workflow). */
    public void publish(long listId, int version, String user) {
        ListDef list = lists.get(listId);
        ListVersion v = get(listId, version);
        long t0 = System.currentTimeMillis();
        batches.stepStart(v.getBatchId(), "EXPORT");
        tx.execute(s -> {
            versions.certifyAndPublish(listId, version, user);
            batches.finish(v.getBatchId(), BatchStatus.PUBLISHED, "Version " + version + " published");
            return null;
        });
        String result;
        try {
            List<ExportRepository.ExportFile> files = exportService.export(list, version);
            result = files.size() + " files";
        } catch (IOException | RuntimeException e) {
            LOG.error("List {} version {}: export failed (the version stays published; export can be run again)",
                    list.getListCode(), version, e);
            result = "Export failed: " + Texts.truncate(e.getMessage(), 200);
        }
        batches.stepEnd(v.getBatchId(), "EXPORT", System.currentTimeMillis() - t0, result);
        LOG.info("List {} version {} published by {}", list.getListCode(), version, Texts.forLog(user));
        events.publishEvent(new VersionDecided(listId));
    }

    /** Re-runs the export of a published version (after a failure, or a lost outbound folder). */
    public List<ExportRepository.ExportFile> reExport(long listId, int version) throws IOException {
        ListVersion v = get(listId, version);
        if (v.getStatus() != VersionStatus.PUBLISHED) {
            throw ApiException.conflict("Only a published version can be exported");
        }
        return exportService.export(lists.get(listId), version);
    }

    public synchronized ListVersion reject(long listId, int version, String user, String comment) {
        ListVersion v = get(listId, version);
        if (!v.getStatus().isOpen()) {
            throw ApiException.conflict("Version " + version + " is " + v.getStatus() + " and cannot be rejected");
        }
        tx.execute(s -> {
            canonical.rollback(listId, version);
            versions.deleteChanges(listId, version);
            versions.reject(listId, version, user, comment);
            batches.finish(v.getBatchId(), BatchStatus.REJECTED, "Version " + version + " rejected by " + user
                    + (Texts.isBlank(comment) ? "" : ": " + comment));
            return null;
        });
        LOG.info("List {} version {} rejected by {}", listId, version, Texts.forLog(user));
        events.publishEvent(new VersionDecided(listId));
        return get(listId, version);
    }
}
