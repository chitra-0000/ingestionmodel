package com.bank.ingestion.domain;

import java.util.Locale;

/** Formats a provider file can have. AUTO on a list = decided from the file itself. */
public enum FileFormat {
    XML, CSV, JSON, AUTO;

    public static FileFormat of(String value) {
        if (value == null || value.trim().isEmpty()) {
            return AUTO;
        }
        return FileFormat.valueOf(value.trim().toUpperCase(Locale.ROOT));
    }
}
