package com.bank.ingestion.web;

import com.bank.ingestion.service.admin.UserService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/** User onboarding (administrators only). */
@RestController
@RequestMapping("/api/users")
@PreAuthorize(Roles.ADMIN)
public class UserController {

    /** Body of create / update. */
    public static class UserRequest {
        public String username;
        public String displayName;
        public String password;
        public List<String> roles;
        public Boolean active;
    }

    private final UserService users;

    public UserController(UserService users) {
        this.users = users;
    }

    @GetMapping
    public List<Map<String, Object>> list() {
        return users.list();
    }

    @PostMapping
    public Map<String, Object> create(@RequestBody UserRequest r) {
        return users.create(r.username, r.displayName, r.password, r.roles);
    }

    @PutMapping("/{username}")
    public Map<String, Object> update(@PathVariable String username, @RequestBody UserRequest r, Authentication auth) {
        return users.update(username, r.displayName, r.roles, r.active == null || r.active, auth.getName());
    }

    @PostMapping("/{username}/password")
    public Map<String, String> password(@PathVariable String username, @RequestBody UserRequest r) {
        users.resetPassword(username, r.password);
        return Collections.singletonMap("result", "ok");
    }
}
