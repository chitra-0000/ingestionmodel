package com.bank.ingestion.service.canonical;

import com.bank.ingestion.config.ListHubProperties;
import com.bank.ingestion.domain.AttrType;
import com.bank.ingestion.domain.Batch;
import com.bank.ingestion.domain.CanonicalRecord;
import com.bank.ingestion.domain.Layout;
import com.bank.ingestion.domain.MappingRules;
import com.bank.ingestion.repository.BatchRepository;
import com.bank.ingestion.repository.IdAllocator;
import com.bank.ingestion.repository.ListRepository;
import com.bank.ingestion.repository.RawRepository;
import com.bank.ingestion.service.raw.RecordParser;
import com.bank.ingestion.service.raw.RefTable;
import com.bank.ingestion.util.ApiException;
import com.bank.ingestion.util.Gzip;
import com.bank.ingestion.util.Json;
import com.bank.ingestion.util.Texts;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

/** Mapping of a list: proposal from the file profile, edits, preview on real records, approval. */
@Service
public class MappingService {

    private static final int MAX_RULES = 200;

    private final ListRepository lists;
    private final BatchRepository batches;
    private final RawRepository raw;
    private final IdAllocator ids;
    private final ListHubProperties props;

    public MappingService(ListRepository lists, BatchRepository batches, RawRepository raw, IdAllocator ids,
                          ListHubProperties props) {
        this.lists = lists;
        this.batches = batches;
        this.raw = raw;
        this.ids = ids;
        this.props = props;
    }

    /** Approved rules of a list, with their version number. */
    public Optional<Map.Entry<Integer, MappingRules>> approved(long listId) {
        return lists.approvedMapping(listId).map(m -> new java.util.AbstractMap.SimpleEntry<>(m.versionNo,
                Json.read(m.rulesJson, MappingRules.class)));
    }

    public boolean hasDraft(long listId) {
        return lists.draftMapping(listId).isPresent();
    }

    /** Everything the mapping screen shows. */
    public Map<String, Object> view(long listId) {
        Map<String, Object> out = new LinkedHashMap<>();
        Optional<ListRepository.Mapping> approved = lists.approvedMapping(listId);
        Optional<ListRepository.Mapping> draft = lists.draftMapping(listId);
        out.put("approved", approved.map(MappingService::mappingView).orElse(null));
        out.put("draft", draft.map(MappingService::mappingView).orElse(null));
        Optional<Batch> last = batches.lastLoaded(listId);
        if (last.isPresent()) {
            Batch b = last.get();
            Map<String, Object> file = new LinkedHashMap<>();
            file.put("batchId", b.getBatchId());
            file.put("fileName", b.getFileName());
            file.put("records", b.getRecordCount());
            file.put("layout", b.getLayoutJson() == null ? null : Json.read(b.getLayoutJson(), Layout.class));
            file.put("refLists", raw.refListSizes(b.getBatchId()));
            file.put("profile", raw.profile(b.getBatchId()));
            out.put("file", file);
        }
        List<Map<String, Object>> attrs = new ArrayList<>();
        for (AttrType t : AttrType.values()) {
            Map<String, Object> a = new LinkedHashMap<>();
            a.put("code", t.name());
            a.put("label", t.label());
            a.put("multi", t.multi());
            attrs.add(a);
        }
        out.put("attributes", attrs);
        return out;
    }

    private static Map<String, Object> mappingView(ListRepository.Mapping m) {
        Map<String, Object> v = new LinkedHashMap<>();
        v.put("versionNo", m.versionNo);
        v.put("status", m.status);
        v.put("rules", Json.read(m.rulesJson, MappingRules.class));
        v.put("createdBy", m.createdBy);
        v.put("createdAt", m.createdAt);
        v.put("approvedBy", m.approvedBy);
        v.put("approvedAt", m.approvedAt);
        return v;
    }

    /** Draft proposed from the profile of the list's last file. */
    public MappingRules proposeDraft(long listId, String user) {
        Batch b = batches.lastLoaded(listId).orElseThrow(() ->
                ApiException.badRequest("Load a file of this list first: the proposal is built from its fields"));
        MappingRules rules = propose(b);
        saveDraft(listId, rules, user);
        return rules;
    }

    MappingRules propose(Batch b) {
        Layout layout = Json.read(b.getLayoutJson(), Layout.class);
        List<AutoMapper.Field> fields = new ArrayList<>();
        for (Map<String, Object> p : raw.profile(b.getBatchId())) {
            fields.add(new AutoMapper.Field((String) p.get("path"), ((Number) p.get("recordsWith")).longValue(),
                    (String) p.get("refList")));
        }
        return AutoMapper.propose(layout, fields);
    }

    /** Creates a draft from the batch's profile when the list has no mapping at all (first file of a list). */
    public void ensureDraft(long listId, Batch b) {
        if (!lists.approvedMapping(listId).isPresent() && !lists.draftMapping(listId).isPresent()) {
            saveDraft(listId, propose(b), "system");
        }
    }

    public void saveDraft(long listId, MappingRules rules, String user) {
        check(rules);
        lists.saveDraft(ids.nextSmallId(), listId, Json.write(rules), user);
    }

    public int approve(long listId, String user) {
        ListRepository.Mapping draft = lists.draftMapping(listId).orElseThrow(() -> ApiException.badRequest("No draft to approve"));
        check(Json.read(draft.rulesJson, MappingRules.class));
        return lists.approveDraft(listId, user);
    }

    /** Rules must compile and name known attributes; at least a name rule. */
    private static void check(MappingRules rules) {
        if (rules == null || rules.getFields() == null) {
            throw ApiException.badRequest("The mapping has no rules");
        }
        if (rules.getFields().size() > MAX_RULES) {
            throw ApiException.badRequest("At most " + MAX_RULES + " rules");
        }
        boolean name = false;
        try {
            new Mapper(rules, RefTable.EMPTY, new DateNormalizer("DMY"));
        } catch (IllegalArgumentException e) {
            throw ApiException.badRequest("Mapping rule not valid: " + Texts.truncate(e.getMessage(), 300));
        }
        for (MappingRules.FieldRule r : rules.getFields()) {
            if (AttrType.PRIMARY_NAME.name().equals(r.getAttr()) || AttrType.FIRST_NAME.name().equals(r.getAttr())
                    || AttrType.LAST_NAME.name().equals(r.getAttr())) {
                name = true;
            }
        }
        if (!name) {
            throw ApiException.badRequest("Map at least the primary name (or first and last name)");
        }
    }

    /** Applies rules (the draft, or the given rules) to the first records of the list's last file. */
    public Map<String, Object> preview(long listId, MappingRules given, int max) {
        MappingRules rules = given;
        if (rules == null) {
            ListRepository.Mapping m = lists.draftMapping(listId).orElseGet(() -> lists.approvedMapping(listId)
                    .orElseThrow(() -> ApiException.badRequest("No mapping to preview")));
            rules = Json.read(m.rulesJson, MappingRules.class);
        }
        check(rules);
        Batch b = batches.lastLoaded(listId).orElseThrow(() -> ApiException.badRequest("Load a file of this list first"));
        Layout layout = Json.read(b.getLayoutJson(), Layout.class);
        RefTable refs = raw.refs(b.getBatchId());
        Mapper mapper = new Mapper(rules, refs, new DateNormalizer(props.getSlashDateOrder()));
        RecordParser parser = new RecordParser(layout);
        List<Map<String, Object>> records = new ArrayList<>();
        Map<String, Integer> issueCounts = new TreeMap<>();
        Map<String, Integer> filled = new TreeMap<>();
        int rejected = 0;
        List<Object[]> first = raw.first(b.getBatchId(), Math.max(1, Math.min(max, 500)));
        for (Object[] r : first) {
            CanonicalRecord c;
            try {
                c = mapper.map(parser.parse(Gzip.decompress((byte[]) r[1])));
            } catch (IOException | RuntimeException e) {
                c = new CanonicalRecord();
                c.issue("PARSE", "REJECT", "Record", null, "Raw record cannot be read");
            }
            if (mapper.hasExternalRef() && Texts.isBlank(c.getExternalRef())) {
                c.issue("NO_KEY", "REJECT", "Provider ID", null, "Provider ID missing");
            }
            if (c.isRejected()) {
                rejected++;
            }
            for (CanonicalRecord.Issue i : c.getIssues()) {
                issueCounts.merge(i.getCode(), 1, Integer::sum);
            }
            java.util.Set<String> types = new java.util.HashSet<>();
            for (CanonicalRecord.Attr a : c.getAttrs()) {
                types.add(a.getT());
            }
            for (String t : types) {
                filled.merge(t, 1, Integer::sum);
            }
            if (records.size() < 50) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("seq", r[0]);
                m.put("record", c);
                m.put("issues", c.getIssues());
                records.add(m);
            }
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("batchId", b.getBatchId());
        out.put("fileName", b.getFileName());
        out.put("checked", first.size());
        out.put("rejected", rejected);
        out.put("issueCounts", issueCounts);
        out.put("filled", filled);
        out.put("records", records);
        return out;
    }
}
