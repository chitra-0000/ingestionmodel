package com.bank.ingestion.service.raw;

import com.bank.ingestion.config.XmlSecurity;
import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.domain.Layout;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/** Turns one stored raw record (bytes) back into an RNode tree, for any format. Thread-safe. */
public final class RecordParser {

    private static final XMLInputFactory XML_IN = XmlSecurity.newXmlInputFactory();
    private static final ObjectMapper JSON = new ObjectMapper();

    private final FileFormat format;
    private final List<String> header;
    private final char delimiter;

    public RecordParser(Layout layout) {
        this.format = FileFormat.of(layout.getFormat());
        this.header = layout.getHeader();
        this.delimiter = layout.getDelimiter() == null || layout.getDelimiter().isEmpty() ? ',' : layout.getDelimiter().charAt(0);
    }

    public RNode parse(byte[] payload) throws IOException {
        switch (format) {
            case XML:
                return xml(payload);
            case CSV:
                return csv(payload);
            case JSON:
                return json(payload);
            default:
                throw new IOException("Unknown record format " + format);
        }
    }

    /** Text form of a stored record, for the "raw record" view. */
    public static String text(byte[] payload) {
        return new String(payload, StandardCharsets.UTF_8);
    }

    private static RNode xml(byte[] payload) throws IOException {
        try {
            XMLStreamReader r = XML_IN.createXMLStreamReader(new ByteArrayInputStream(payload), "UTF-8");
            Deque<RNode> stack = new ArrayDeque<>();
            RNode root = null;
            while (r.hasNext()) {
                int ev = r.next();
                if (ev == XMLStreamConstants.START_ELEMENT) {
                    RNode n = new RNode(r.getLocalName());
                    for (int i = 0; i < r.getAttributeCount(); i++) {
                        n.attr(r.getAttributeLocalName(i), r.getAttributeValue(i));
                    }
                    if (stack.isEmpty()) {
                        root = n;
                    } else {
                        stack.peek().add(n);
                    }
                    stack.push(n);
                } else if (ev == XMLStreamConstants.END_ELEMENT) {
                    stack.pop();
                } else if ((ev == XMLStreamConstants.CHARACTERS || ev == XMLStreamConstants.CDATA) && !stack.isEmpty()) {
                    stack.peek().appendText(r.getText());
                }
            }
            if (root == null) {
                throw new IOException("Empty XML record");
            }
            return root;
        } catch (XMLStreamException e) {
            throw new IOException("Raw XML record cannot be read: " + e.getMessage(), e);
        }
    }

    private RNode csv(byte[] payload) throws IOException {
        List<String> fields = CsvParser.parseLine(new String(payload, StandardCharsets.UTF_8), delimiter);
        RNode row = new RNode("row");
        for (int i = 0; i < fields.size(); i++) {
            String name = header != null && i < header.size() ? header.get(i) : "column" + (i + 1);
            RNode c = row.add(new RNode(name));
            c.appendText(fields.get(i));
        }
        return row;
    }

    private static RNode json(byte[] payload) throws IOException {
        JsonNode node = JSON.readTree(payload);
        RNode root = new RNode("record");
        fill(root, node);
        return root;
    }

    private static void fill(RNode target, JsonNode node) {
        if (node.isObject()) {
            Iterator<Map.Entry<String, JsonNode>> it = node.fields();
            while (it.hasNext()) {
                Map.Entry<String, JsonNode> e = it.next();
                addField(target, e.getKey(), e.getValue());
            }
        } else if (!node.isNull()) {
            target.appendText(node.asText());
        }
    }

    private static void addField(RNode target, String name, JsonNode value) {
        if (value.isArray()) {
            for (JsonNode item : value) {
                RNode c = target.add(new RNode(name));
                fill(c, item);
            }
        } else {
            RNode c = target.add(new RNode(name));
            fill(c, value);
        }
    }
}
