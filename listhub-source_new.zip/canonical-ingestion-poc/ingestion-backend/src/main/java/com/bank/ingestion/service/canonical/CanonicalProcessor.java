package com.bank.ingestion.service.canonical;

import com.bank.ingestion.config.ListHubProperties;
import com.bank.ingestion.domain.AttrType;
import com.bank.ingestion.domain.CanonicalRecord;
import com.bank.ingestion.domain.ChangeType;
import com.bank.ingestion.domain.Layout;
import com.bank.ingestion.domain.ListDef;
import com.bank.ingestion.domain.MappingRules;
import com.bank.ingestion.repository.CanonicalRepository;
import com.bank.ingestion.repository.RawRepository;
import com.bank.ingestion.repository.VersionRepository;
import com.bank.ingestion.repository.IdAllocator;
import com.bank.ingestion.service.batch.Progress;
import com.bank.ingestion.service.raw.RNode;
import com.bank.ingestion.service.raw.RecordParser;
import com.bank.ingestion.service.raw.RefTable;
import com.bank.ingestion.util.Gzip;
import com.bank.ingestion.util.Hashes;
import com.bank.ingestion.util.Json;
import com.bank.ingestion.util.Texts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Stage 2: raw records -> canonical records, for one batch = one new version of a list.
 *
 * <ol>
 *   <li>The list's identities are loaded into memory (key -> internal id, open row, content hash).</li>
 *   <li>A reader streams the raw records; N workers parse, map, check quality, find or create the identity and
 *       compare the content hash with the open row: unchanged records cost no write at all.</li>
 *   <li>Changed records get a new row (valid from this version) and their old row is closed; every change is
 *       written to RECORD_CHANGE with its before / after values.</li>
 *   <li>Full delivery: identities not seen in the file are closed (DELETED). Delta delivery: only records the
 *       provider marks as deleted are closed.</li>
 * </ol>
 */
@Service
public class CanonicalProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(CanonicalProcessor.class);
    private static final List<long[]> POISON_IDS = Collections.emptyList();
    private static final String REJECT = "REJECT";
    /** A full file that deletes more than this share of the list gets a warning (and is never auto-published). */
    private static final double LARGE_DELETION_SHARE = 0.30;

    /** Counts and findings of a stage 2 run. */
    public static final class Result {
        public long fileRecords;
        public long created;
        public long modified;
        public long minor;
        public long deleted;
        public long unchanged;
        public long rejected;
        public long flagged;
        public long totalAfter;
        public final Map<String, Long> rejectCodes = new TreeMap<>();
        public final Map<String, Long> flagCodes = new TreeMap<>();
        public final List<String> warnings = new ArrayList<>();
    }

    /** What the processor knows about one identity during a run. */
    static final class Ident {
        final long rglNo;
        volatile long rowId;
        volatile long hash;
        volatile long mainHash;
        final AtomicInteger seen = new AtomicInteger();

        Ident(long rglNo, long rowId, long hash, long mainHash) {
            this.rglNo = rglNo;
            this.rowId = rowId;
            this.hash = hash;
            this.mainHash = mainHash;
        }
    }

    private final RawRepository raw;
    private final CanonicalRepository canonical;
    private final VersionRepository versions;
    private final IdAllocator ids;
    private final TransactionTemplate tx;
    private final ListHubProperties props;
    private final Progress progress;

    public CanonicalProcessor(RawRepository raw, CanonicalRepository canonical, VersionRepository versions, IdAllocator ids,
                              TransactionTemplate tx, ListHubProperties props, Progress progress) {
        this.raw = raw;
        this.canonical = canonical;
        this.versions = versions;
        this.ids = ids;
        this.tx = tx;
        this.props = props;
        this.progress = progress;
    }

    /** Everything one run needs, shared read-only by the workers. */
    private final class Run {
        final long batchId;
        final ListDef list;
        final int version;
        final boolean full;
        final Mapper mapper;
        final RecordParser parser;
        final Set<String> minorAttrs;
        final List<AttrType> matchKey;
        final Map<String, Ident> idents;
        final AtomicLong nextRglNo;
        final Result result = new Result();
        final AtomicLong created = new AtomicLong();
        final AtomicLong modified = new AtomicLong();
        final AtomicLong minor = new AtomicLong();
        final AtomicLong deleted = new AtomicLong();
        final AtomicLong unchanged = new AtomicLong();
        final AtomicLong rejected = new AtomicLong();
        final AtomicLong flagged = new AtomicLong();
        final Map<String, AtomicLong> rejectCodes = new ConcurrentHashMap<>();
        final Map<String, AtomicLong> flagCodes = new ConcurrentHashMap<>();

        Run(long batchId, ListDef list, int version, boolean full, Mapper mapper, RecordParser parser,
            Map<String, Ident> idents, long maxRglNo) {
            this.batchId = batchId;
            this.list = list;
            this.version = version;
            this.full = full;
            this.mapper = mapper;
            this.parser = parser;
            this.minorAttrs = props.minorAttrSet();
            this.matchKey = matchKeyAttrs(list);
            this.idents = idents;
            this.nextRglNo = new AtomicLong(maxRglNo);
        }

        String rglId(long no) {
            String n = Long.toString(no);
            StringBuilder sb = new StringBuilder(list.getIdPrefix()).append('-').append(list.getListCode()).append('-');
            for (int i = n.length(); i < props.getIdDigits(); i++) {
                sb.append('0');
            }
            return sb.append(n).toString();
        }
    }

    public Result process(long batchId, ListDef list, Layout layout, MappingRules rules, int version, boolean fullDelivery,
                          long expectedRecords) throws InterruptedException {
        long t0 = System.currentTimeMillis();
        RefTable refs = raw.refs(batchId);
        Mapper mapper = new Mapper(rules, refs, new DateNormalizer(props.getSlashDateOrder()));
        Map<String, Ident> idents = new ConcurrentHashMap<>((int) Math.min(Integer.MAX_VALUE / 2, Math.max(16, expectedRecords * 4 / 3)));
        int[] activeBefore = {0};
        canonical.streamIdentities(list.getListId(), props.getFetchSize(), (key, rglNo, rowId, hash, mainHash) -> {
            idents.put(key, new Ident(rglNo, rowId, Hashes.parse(hash), Hashes.parse(mainHash)));
            if (rowId > 0) {
                activeBefore[0]++;
            }
        });
        long maxRgl = canonical.maxRglNo(list.getListId());
        LOG.info("Batch {}: list {} has {} identities ({} active), loaded in {} ms", batchId, list.getListCode(), idents.size(),
                activeBefore[0], System.currentTimeMillis() - t0);

        Run run = new Run(batchId, list, version, fullDelivery, mapper, new RecordParser(layout), idents, maxRgl);
        Progress.Item live = progress.start(batchId, "Canonical records", expectedRecords);
        int workers = props.effectiveWorkersPerFile();
        BlockingQueue<List<long[]>> queue = new ArrayBlockingQueue<>(workers * 4);
        Map<Long, byte[]> payloads = new ConcurrentHashMap<>();
        AtomicReference<Throwable> failure = new AtomicReference<>();
        ExecutorService pool = Executors.newFixedThreadPool(workers, r -> {
            Thread t = new Thread(r, "canonical-" + batchId);
            t.setDaemon(true);
            return t;
        });
        for (int i = 0; i < workers; i++) {
            pool.execute(() -> workLoop(run, queue, payloads, failure, live));
        }
        int chunkSize = Math.max(100, props.getChunkSize());
        long[] read = {0};
        try {
            List<long[]>[] chunk = new List[]{new ArrayList<>(chunkSize)};
            raw.stream(batchId, props.getFetchSize(), (seq, gz) -> {
                if (failure.get() != null) {
                    throw new IllegalStateException("Stopped: a worker failed", failure.get());
                }
                payloads.put(seq, gz);
                chunk[0].add(new long[]{seq});
                read[0]++;
                if (chunk[0].size() >= chunkSize) {
                    putQuietly(queue, chunk[0]);
                    chunk[0] = new ArrayList<>(chunkSize);
                }
            });
            if (!chunk[0].isEmpty()) {
                putQuietly(queue, chunk[0]);
            }
        } catch (RuntimeException e) {
            failure.compareAndSet(null, e);
        } finally {
            for (int i = 0; i < workers; i++) {
                queue.put(POISON_IDS);
            }
            pool.shutdown();
            if (!pool.awaitTermination(12, TimeUnit.HOURS)) {
                pool.shutdownNow();
            }
            progress.end(batchId);
        }
        if (failure.get() != null) {
            throw new IllegalStateException("Stage 2 failed: " + failure.get().getMessage(), failure.get());
        }

        Result r = run.result;
        r.fileRecords = read[0];
        if (fullDelivery) {
            closeNotSeen(run);
        }
        r.created = run.created.get();
        r.modified = run.modified.get();
        r.minor = run.minor.get();
        r.deleted = run.deleted.get();
        r.unchanged = run.unchanged.get();
        r.rejected = run.rejected.get();
        r.flagged = run.flagged.get();
        r.totalAfter = activeBefore[0] + r.created - r.deleted;
        for (Map.Entry<String, AtomicLong> e : run.rejectCodes.entrySet()) {
            r.rejectCodes.put(e.getKey(), e.getValue().get());
        }
        for (Map.Entry<String, AtomicLong> e : run.flagCodes.entrySet()) {
            r.flagCodes.put(e.getKey(), e.getValue().get());
        }
        if (fullDelivery && activeBefore[0] > 0 && r.deleted > activeBefore[0] * LARGE_DELETION_SHARE) {
            r.warnings.add("This full file deletes " + r.deleted + " of " + activeBefore[0]
                    + " records. Check that the provider file is complete before validating.");
        }
        if (fullDelivery && r.fileRecords == 0) {
            r.warnings.add("The file has no records: every record of the list would be deleted.");
        }
        LOG.info("Batch {}: stage 2 done in {} ms: {} created, {} modified, {} minor, {} deleted, {} unchanged, {} rejected, "
                        + "{} flagged", batchId, System.currentTimeMillis() - t0, r.created, r.modified, r.minor, r.deleted,
                r.unchanged, r.rejected, r.flagged);
        return r;
    }

    private static void putQuietly(BlockingQueue<List<long[]>> queue, List<long[]> chunk) {
        try {
            queue.put(chunk);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Interrupted", e);
        }
    }

    // ================================================================== worker

    private void workLoop(Run run, BlockingQueue<List<long[]>> queue, Map<Long, byte[]> payloads,
                          AtomicReference<Throwable> failure, Progress.Item live) {
        Writes w = new Writes();
        int batchSize = Math.max(100, props.getBatchSize());
        try {
            while (true) {
                List<long[]> chunk = queue.take();
                if (chunk == POISON_IDS) {
                    break;
                }
                if (failure.get() != null) {
                    for (long[] s : chunk) {
                        payloads.remove(s[0]);
                    }
                    continue;
                }
                try {
                    for (long[] s : chunk) {
                        byte[] gz = payloads.remove(s[0]);
                        one(run, s[0], gz, w);
                    }
                    live.add(chunk.size());
                    if (w.size() >= batchSize) {
                        flush(run, w);
                    }
                } catch (RuntimeException e) {
                    failure.compareAndSet(null, e);
                    LOG.error("Batch {}: stage 2 worker failed", run.batchId, e);
                }
            }
            if (failure.get() == null) {
                flush(run, w);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            failure.compareAndSet(null, e);
        } catch (RuntimeException e) {
            failure.compareAndSet(null, e);
            LOG.error("Batch {}: stage 2 write failed", run.batchId, e);
        }
    }

    /** Pending writes of one worker, flushed in one transaction. */
    private static final class Writes {
        final List<CanonicalRepository.Identity> identities = new ArrayList<>();
        final List<CanonicalRepository.Row> rows = new ArrayList<>();
        final List<Long> close = new ArrayList<>();
        final List<VersionRepository.Change> changes = new ArrayList<>();
        /** Modified records: change + old row id + new record, the detail is computed at flush time. */
        final List<Object[]> diffs = new ArrayList<>();

        int size() {
            return rows.size() + changes.size() + close.size();
        }

        void clear() {
            identities.clear();
            rows.clear();
            close.clear();
            changes.clear();
            diffs.clear();
        }
    }

    private void one(Run run, long seq, byte[] gz, Writes w) {
        CanonicalRecord c;
        try {
            RNode node = run.parser.parse(Gzip.decompress(gz));
            c = run.mapper.map(node);
        } catch (IOException | RuntimeException e) {
            c = new CanonicalRecord();
            c.issue("PARSE", REJECT, "Record", null, "Raw record cannot be read: " + Texts.truncate(e.getMessage(), 200));
        }
        String key = key(run, c);
        if (c.isRejected()) {
            // A known record that arrives broken keeps its previous version (it is not deleted).
            Ident known = key == null ? null : run.idents.get(key);
            if (known != null) {
                known.seen.set(run.version);
            }
            reject(run, seq, c, w);
            return;
        }
        if (c.isDeleteAction()) {
            deleteByProvider(run, seq, key, c, w);
            return;
        }

        Ident ident = run.idents.get(key);
        boolean isNew = false;
        if (ident == null) {
            Ident fresh = new Ident(run.nextRglNo.incrementAndGet(), 0L, 0L, 0L);
            Ident prev = run.idents.putIfAbsent(key, fresh);
            if (prev == null) {
                ident = fresh;
                isNew = true;
                w.identities.add(new CanonicalRepository.Identity(run.rglId(fresh.rglNo), fresh.rglNo,
                        key.startsWith("M:") ? "MATCH" : "EXT", cutKey(key)));
            } else {
                ident = prev;
            }
        }
        if (ident.seen.getAndSet(run.version) == run.version) {
            c.issue("DUP_KEY", REJECT, "Provider ID", c.getExternalRef(), "Same provider ID twice in the file: " + key);
            reject(run, seq, c, w);
            return;
        }

        String content = Json.write(c);
        long hash = Hashes.hash64(content);
        long mainHash = Hashes.hash64(Json.write(c.without(run.minorAttrs)));
        String rglId = run.rglId(ident.rglNo);
        if (c.isFlagged()) {
            run.flagged.incrementAndGet();
            for (CanonicalRecord.Issue i : c.getIssues()) {
                run.flagCodes.computeIfAbsent(i.getCode(), k -> new AtomicLong()).incrementAndGet();
            }
            w.changes.add(change(run, ChangeType.FLAGGED, seq, rglId, c, issuesSummary(c), issuesJson(c, false), seq));
        }
        if (!isNew && ident.rowId > 0 && ident.hash == hash) {
            run.unchanged.incrementAndGet();
            return;
        }
        long rowId = ids.nextRowId();
        w.rows.add(row(run, rowId, rglId, seq, c, content, hash, mainHash));
        if (isNew || ident.rowId == 0) {
            run.created.incrementAndGet();
            w.changes.add(change(run, ChangeType.CREATED, seq, rglId, c,
                    isNew ? "New record" : "Back in the list with the same internal id", null, seq));
        } else {
            ChangeType type = ident.mainHash == mainHash ? ChangeType.MINOR : ChangeType.MODIFIED;
            (type == ChangeType.MINOR ? run.minor : run.modified).incrementAndGet();
            VersionRepository.Change ch = change(run, type, seq, rglId, c, null, null, seq);
            w.diffs.add(new Object[]{ch, ident.rowId, c});
            w.close.add(ident.rowId);
        }
        ident.rowId = rowId;
        ident.hash = hash;
        ident.mainHash = mainHash;
    }

    private static String cutKey(String key) {
        return key.length() <= 200 ? key : key.substring(0, 200);
    }

    private void reject(Run run, long seq, CanonicalRecord c, Writes w) {
        run.rejected.incrementAndGet();
        for (CanonicalRecord.Issue i : c.getIssues()) {
            if (i.isReject()) {
                run.rejectCodes.computeIfAbsent(i.getCode(), k -> new AtomicLong()).incrementAndGet();
            }
        }
        w.changes.add(change(run, ChangeType.REJECTED, seq, null, c, issuesSummary(c), issuesJson(c, true), seq));
    }

    /** Delta file: the provider says the record is deleted. */
    private void deleteByProvider(Run run, long seq, String key, CanonicalRecord c, Writes w) {
        Ident ident = key == null ? null : run.idents.get(key);
        if (ident == null || ident.rowId == 0 || ident.seen.getAndSet(run.version) == run.version) {
            return;
        }
        run.deleted.incrementAndGet();
        w.close.add(ident.rowId);
        Map<Long, CanonicalRepository.Row> old = canonical.rowsById(Collections.singletonList(ident.rowId));
        CanonicalRepository.Row o = old.get(ident.rowId);
        VersionRepository.Change ch = new VersionRepository.Change();
        ch.changeType = ChangeType.DELETED.name();
        ch.seqNo = ident.rglNo;
        ch.rglId = run.rglId(ident.rglNo);
        ch.externalRef = c.getExternalRef();
        ch.recordType = o == null ? c.getRecordType() : o.recordType;
        ch.primaryName = o == null ? null : o.primaryName;
        ch.country = o == null ? null : firstPart(o.countries);
        ch.summary = "Deleted by the provider (delta file)";
        ch.detailJson = Json.write(Collections.singletonMap("lastVersion", run.version - 1));
        ch.batchId = run.batchId;
        ch.rawSeq = seq;
        w.changes.add(ch);
        ident.rowId = 0;
    }

    /** Identity key: the provider reference, or a hash of the list's match-key attributes. */
    private static String key(Run run, CanonicalRecord c) {
        if (run.mapper.hasExternalRef()) {
            String ref = c.getExternalRef();
            if (ref == null || ref.trim().isEmpty()) {
                c.issue("NO_KEY", REJECT, "Provider ID", null, "Provider ID missing");
                return null;
            }
            return ref.trim();
        }
        StringBuilder sb = new StringBuilder(c.getRecordType()).append('|');
        boolean any = false;
        for (AttrType t : run.matchKey) {
            List<String> v = new ArrayList<>(c.plainValues(t));
            Collections.sort(v);
            for (String s : v) {
                sb.append(Texts.searchForm(s)).append(';');
                any = true;
            }
            sb.append('|');
        }
        if (!any) {
            c.issue("NO_KEY", REJECT, "Match key", null, "None of the match-key attributes has a value");
            return null;
        }
        return "M:" + Hashes.hex(Hashes.hash64(sb.toString()));
    }

    private static List<AttrType> matchKeyAttrs(ListDef list) {
        String s = list.getMatchKeyAttrs();
        if (s == null || s.trim().isEmpty()) {
            return Arrays.asList(AttrType.PRIMARY_NAME, AttrType.DOB, AttrType.NATIONALITY);
        }
        List<AttrType> out = new ArrayList<>();
        for (String p : s.split(",")) {
            if (!p.trim().isEmpty()) {
                out.add(AttrType.of(p));
            }
        }
        return out;
    }

    // ================================================================== rows and changes

    private CanonicalRepository.Row row(Run run, long rowId, String rglId, long seq, CanonicalRecord c, String content,
                                        long hash, long mainHash) {
        CanonicalRepository.Row r = new CanonicalRepository.Row();
        r.rowId = rowId;
        r.rglId = rglId;
        r.listId = run.list.getListId();
        r.validFrom = run.version;
        r.batchId = run.batchId;
        r.rawSeq = seq;
        r.externalRef = c.getExternalRef();
        r.recordType = c.getRecordType();
        r.primaryName = c.first(AttrType.PRIMARY_NAME);
        Set<String> names = new LinkedHashSet<>();
        for (AttrType t : new AttrType[]{AttrType.PRIMARY_NAME, AttrType.ALIAS, AttrType.FIRST_NAME, AttrType.LAST_NAME}) {
            for (String v : c.plainValues(t)) {
                names.add(Texts.searchForm(v));
            }
        }
        r.nameSearch = String.join(" | ", names);
        r.gender = c.first(AttrType.GENDER);
        r.dob = join(c.plainValues(AttrType.DOB));
        r.nationalities = join(c.plainValues(AttrType.NATIONALITY));
        Set<String> countries = new LinkedHashSet<>();
        countries.addAll(c.plainValues(AttrType.NATIONALITY));
        countries.addAll(c.plainValues(AttrType.RESIDENCE));
        countries.addAll(c.plainValues(AttrType.COUNTRY));
        r.countries = join(new ArrayList<>(countries));
        r.idNumbers = join(c.values(AttrType.ID_DOC));
        r.listRefs = join(c.plainValues(AttrType.SANCTION_REF));
        r.status = c.first(AttrType.STATUS);
        Set<String> flags = new LinkedHashSet<>();
        for (CanonicalRecord.Issue i : c.getIssues()) {
            flags.add(i.getCode());
        }
        r.dqFlags = flags.isEmpty() ? null : String.join(",", flags);
        r.contentHash = Hashes.hex(hash);
        r.mainHash = Hashes.hex(mainHash);
        r.content = content;
        return r;
    }

    private static String join(List<String> values) {
        return values.isEmpty() ? null : String.join(" | ", values);
    }

    private static String firstPart(String joined) {
        if (joined == null) {
            return null;
        }
        int i = joined.indexOf(" | ");
        return i < 0 ? joined : joined.substring(0, i);
    }

    private static VersionRepository.Change change(Run run, ChangeType type, long seqNo, String rglId, CanonicalRecord c,
                                                   String summary, String detail, Long rawSeq) {
        VersionRepository.Change ch = new VersionRepository.Change();
        ch.changeType = type.name();
        ch.seqNo = seqNo;
        ch.rglId = rglId;
        ch.externalRef = c.getExternalRef();
        ch.recordType = c.getRecordType();
        ch.primaryName = c.first(AttrType.PRIMARY_NAME);
        List<String> countries = c.plainValues(AttrType.NATIONALITY);
        if (countries.isEmpty()) {
            countries = c.plainValues(AttrType.COUNTRY);
        }
        ch.country = countries.isEmpty() ? null : countries.get(0);
        ch.summary = summary;
        ch.detailJson = detail;
        ch.batchId = run.batchId;
        ch.rawSeq = rawSeq;
        return ch;
    }

    private static String issuesSummary(CanonicalRecord c) {
        List<String> m = new ArrayList<>();
        for (CanonicalRecord.Issue i : c.getIssues()) {
            m.add(i.getMessage());
        }
        return Texts.truncate(String.join("; ", m), 1000);
    }

    private static String issuesJson(CanonicalRecord c, boolean withValues) {
        Map<String, Object> d = new LinkedHashMap<>();
        d.put("issues", c.getIssues());
        if (withValues) {
            List<String[]> values = new ArrayList<>();
            for (CanonicalRecord.Attr a : c.getAttrs()) {
                values.add(new String[]{label(a.getT()), a.getQ() == null ? a.getV() : a.getV() + " (" + a.getQ() + ")"});
            }
            d.put("values", values);
        }
        return Json.write(d);
    }

    private static String label(String type) {
        try {
            return AttrType.valueOf(type).label();
        } catch (IllegalArgumentException e) {
            return type;
        }
    }

    // ================================================================== writes

    private void flush(Run run, Writes w) {
        if (w.size() == 0 && w.identities.isEmpty() && w.diffs.isEmpty()) {
            return;
        }
        if (!w.diffs.isEmpty()) {
            List<Long> oldIds = new ArrayList<>();
            for (Object[] d : w.diffs) {
                oldIds.add((Long) d[1]);
            }
            Map<Long, CanonicalRepository.Row> old = canonical.rowsById(oldIds);
            for (Object[] d : w.diffs) {
                VersionRepository.Change ch = (VersionRepository.Change) d[0];
                CanonicalRepository.Row o = old.get((Long) d[1]);
                CanonicalRecord before = o == null ? new CanonicalRecord() : Json.read(o.content, CanonicalRecord.class);
                List<RecordDiff.Item> items = RecordDiff.diff(before, (CanonicalRecord) d[2]);
                ch.summary = RecordDiff.summary(items);
                ch.detailJson = Json.write(Collections.singletonMap("changes", items));
                w.changes.add(ch);
            }
        }
        tx.execute(status -> {
            canonical.insertIdentities(run.list.getListId(), run.version, w.identities);
            canonical.insertRows(w.rows);
            canonical.closeRows(w.close, run.version - 1);
            versions.insertChanges(run.list.getListId(), run.version, w.changes);
            return null;
        });
        w.clear();
    }

    /** Full delivery: every active identity not in the file is closed. */
    private void closeNotSeen(Run run) {
        List<Ident> gone = new ArrayList<>();
        for (Ident i : run.idents.values()) {
            if (i.rowId > 0 && i.seen.get() != run.version) {
                gone.add(i);
            }
        }
        if (gone.isEmpty()) {
            return;
        }
        for (int from = 0; from < gone.size(); from += 1000) {
            List<Ident> part = gone.subList(from, Math.min(gone.size(), from + 1000));
            List<Long> rowIds = new ArrayList<>();
            for (Ident i : part) {
                rowIds.add(i.rowId);
            }
            Map<Long, CanonicalRepository.Row> old = canonical.rowsById(rowIds);
            List<VersionRepository.Change> changes = new ArrayList<>();
            for (Ident i : part) {
                CanonicalRepository.Row o = old.get(i.rowId);
                VersionRepository.Change ch = new VersionRepository.Change();
                ch.changeType = ChangeType.DELETED.name();
                ch.seqNo = i.rglNo;
                ch.rglId = run.rglId(i.rglNo);
                ch.externalRef = o == null ? null : o.externalRef;
                ch.recordType = o == null ? null : o.recordType;
                ch.primaryName = o == null ? null : o.primaryName;
                ch.country = o == null ? null : firstPart(o.countries);
                ch.summary = "Not in the full file: closed (history kept)";
                ch.detailJson = Json.write(Collections.singletonMap("lastVersion", run.version - 1));
                ch.batchId = run.batchId;
                changes.add(ch);
                i.rowId = 0;
            }
            tx.execute(status -> {
                canonical.closeRows(rowIds, run.version - 1);
                versions.insertChanges(run.list.getListId(), run.version, changes);
                return null;
            });
            run.deleted.addAndGet(part.size());
        }
    }
}
