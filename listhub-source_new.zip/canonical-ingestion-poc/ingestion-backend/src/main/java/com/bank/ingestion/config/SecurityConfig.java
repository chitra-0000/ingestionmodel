package com.bank.ingestion.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.security.web.csrf.CsrfTokenRequestAttributeHandler;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collections;

/**
 * Security of the screens and the API.
 * <ul>
 *   <li>Screens: session login (form POST /api/auth/login), CSRF token in the XSRF-TOKEN cookie sent back by
 *       Angular in the X-XSRF-TOKEN header.</li>
 *   <li>Subscriber API /api/v1/**: HTTP Basic, stateless; no session, so no CSRF exposure.</li>
 *   <li>Roles are checked on each endpoint (@PreAuthorize).</li>
 * </ul>
 */
@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    private static final ObjectMapper JSON = new ObjectMapper();

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(10);
    }

    /** Subscriber API: Basic authentication, no session. */
    @Bean
    @org.springframework.core.annotation.Order(1)
    public SecurityFilterChain subscriberApi(HttpSecurity http) throws Exception {
        http.requestMatcher(new AntPathRequestMatcher("/api/v1/**"))
                .authorizeHttpRequests(a -> a.anyRequest().authenticated())
                .httpBasic(b -> b.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)))
                .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                // Stateless Basic-auth API used by machines: no cookie session, so CSRF does not apply here.
                .csrf(c -> c.disable());
        headers(http);
        return http.build();
    }

    /** Screens and their API. */
    @Bean
    @org.springframework.core.annotation.Order(2)
    public SecurityFilterChain screens(HttpSecurity http) throws Exception {
        CsrfTokenRequestAttributeHandler csrfHandler = new CsrfTokenRequestAttributeHandler();
        csrfHandler.setCsrfRequestAttributeName(null);
        http.authorizeHttpRequests(a -> a
                        .antMatchers("/api/auth/login", "/api/auth/csrf").permitAll()
                        .antMatchers("/api/**").authenticated()
                        .anyRequest().permitAll())
                .csrf(c -> c.csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
                        .csrfTokenRequestHandler(csrfHandler))
                .addFilterAfter(new CsrfCookieFilter(), org.springframework.security.web.csrf.CsrfFilter.class)
                .formLogin(f -> f.loginProcessingUrl("/api/auth/login")
                        .successHandler((req, res, auth) -> json(res, HttpStatus.OK, "ok"))
                        .failureHandler((req, res, e) -> json(res, HttpStatus.UNAUTHORIZED, "Wrong user name or password")))
                .logout(l -> l.logoutUrl("/api/auth/logout")
                        .logoutSuccessHandler((req, res, auth) -> json(res, HttpStatus.OK, "ok")))
                .exceptionHandling(e -> e.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)))
                .sessionManagement(s -> s.sessionFixation().changeSessionId().maximumSessions(5));
        headers(http);
        return http.build();
    }

    private static void headers(HttpSecurity http) throws Exception {
        http.headers(h -> h
                .contentSecurityPolicy(c -> c.policyDirectives("default-src 'self'; img-src 'self' data:; "
                        + "style-src 'self' 'unsafe-inline'; font-src 'self' data:; script-src 'self'; frame-src 'self' blob:; "
                        + "object-src 'self' blob:; frame-ancestors 'self'; form-action 'self'; base-uri 'self'"))
                .referrerPolicy(r -> r.policy(ReferrerPolicyHeaderWriter.ReferrerPolicy.SAME_ORIGIN))
                .frameOptions(f -> f.sameOrigin()));
    }

    private static void json(HttpServletResponse res, HttpStatus status, String message) throws IOException {
        res.setStatus(status.value());
        res.setContentType(MediaType.APPLICATION_JSON_VALUE);
        JSON.writeValue(res.getOutputStream(), Collections.singletonMap(status.is2xxSuccessful() ? "result" : "error", message));
    }

    /** Makes sure the XSRF-TOKEN cookie is written on every response (Angular reads it). */
    static final class CsrfCookieFilter extends OncePerRequestFilter {
        @Override
        protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
                throws ServletException, IOException {
            CsrfToken token = (CsrfToken) request.getAttribute(CsrfToken.class.getName());
            if (token != null) {
                token.getToken();
            }
            chain.doFilter(request, response);
        }
    }
}
