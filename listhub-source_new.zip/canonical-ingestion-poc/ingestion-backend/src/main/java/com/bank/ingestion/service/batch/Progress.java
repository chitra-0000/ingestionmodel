package com.bank.ingestion.service.batch;

import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/** Live progress of running batches, for the screens (kept in memory only). */
@Component
public class Progress {

    /** Progress of one batch. */
    public static final class Item {
        private volatile String phase;
        private final AtomicLong done = new AtomicLong();
        private volatile long total;

        public String phase() { return phase; }
        public long done() { return done.get(); }
        public long total() { return total; }
        public void add(long n) { done.addAndGet(n); }
        public void set(long n) { done.set(n); }
    }

    private final Map<Long, Item> items = new ConcurrentHashMap<>();

    public Item start(long batchId, String phase, long total) {
        Item i = new Item();
        i.phase = phase;
        i.total = total;
        items.put(batchId, i);
        return i;
    }

    public void end(long batchId) {
        items.remove(batchId);
    }

    public Map<String, Object> view(long batchId) {
        Item i = items.get(batchId);
        if (i == null) {
            return null;
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("phase", i.phase);
        m.put("done", i.done());
        m.put("total", i.total);
        m.put("percent", i.total > 0 ? Math.min(100, (int) (i.done() * 100 / i.total)) : null);
        return m;
    }
}
