package com.bank.ingestion.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Stage 2 tables: identities and versioned canonical records. */
@Repository
public class CanonicalRepository {

    /** One CANONICAL_RECORD row. */
    public static final class Row {
        public long rowId;
        public String rglId;
        public long listId;
        public int validFrom;
        public Integer validTo;
        public long batchId;
        public Long rawSeq;
        public String externalRef;
        public String recordType;
        public String primaryName;
        public String nameSearch;
        public String gender;
        public String dob;
        public String nationalities;
        public String countries;
        public String idNumbers;
        public String listRefs;
        public String status;
        public String dqFlags;
        public String contentHash;
        public String mainHash;
        public String content;
    }

    /** One identity to insert. */
    public static final class Identity {
        public final String rglId;
        public final long rglNo;
        public final String keyType;
        public final String keyValue;

        public Identity(String rglId, long rglNo, String keyType, String keyValue) {
            this.rglId = rglId;
            this.rglNo = rglNo;
            this.keyType = keyType;
            this.keyValue = keyValue;
        }
    }

    /** Receives the identities of a list at the start of stage 2. */
    public interface IdentityConsumer {
        void accept(String key, long rglNo, long rowId, String contentHash, String mainHash) throws SQLException;
    }

    /** Receives rows of a version (export). */
    public interface RowConsumer {
        void accept(Row row) throws SQLException;
    }

    static final String ROW_COLS = "ROW_ID, RGL_ID, LIST_ID, VALID_FROM, VALID_TO, BATCH_ID, RAW_SEQ, EXTERNAL_REF, RECORD_TYPE, "
            + "PRIMARY_NAME, NAME_SEARCH, GENDER, DOB, NATIONALITIES, COUNTRIES, ID_NUMBERS, LIST_REFS, STATUS, DQ_FLAGS, "
            + "CONTENT_HASH, MAIN_HASH, CONTENT";

    static final RowMapper<Row> ROW = (rs, i) -> map(rs);

    private final JdbcTemplate jdbc;
    private final NamedParameterJdbcTemplate named;

    public CanonicalRepository(JdbcTemplate jdbc, NamedParameterJdbcTemplate named) {
        this.jdbc = jdbc;
        this.named = named;
    }

    static Row map(ResultSet rs) throws SQLException {
        Row r = new Row();
        r.rowId = rs.getLong("ROW_ID");
        r.rglId = rs.getString("RGL_ID");
        r.listId = rs.getLong("LIST_ID");
        r.validFrom = rs.getInt("VALID_FROM");
        r.validTo = Db.intOrNull(rs, "VALID_TO");
        r.batchId = rs.getLong("BATCH_ID");
        r.rawSeq = Db.longOrNull(rs, "RAW_SEQ");
        r.externalRef = rs.getString("EXTERNAL_REF");
        r.recordType = rs.getString("RECORD_TYPE");
        r.primaryName = rs.getString("PRIMARY_NAME");
        r.nameSearch = rs.getString("NAME_SEARCH");
        r.gender = rs.getString("GENDER");
        r.dob = rs.getString("DOB");
        r.nationalities = rs.getString("NATIONALITIES");
        r.countries = rs.getString("COUNTRIES");
        r.idNumbers = rs.getString("ID_NUMBERS");
        r.listRefs = rs.getString("LIST_REFS");
        r.status = rs.getString("STATUS");
        r.dqFlags = rs.getString("DQ_FLAGS");
        r.contentHash = rs.getString("CONTENT_HASH");
        r.mainHash = rs.getString("MAIN_HASH");
        r.content = rs.getString("CONTENT");
        return r;
    }

    // ------------------------------------------------------------------ stage 2 writes

    /** Streams every identity of the list with its open row (if any). */
    public void streamIdentities(long listId, int fetchSize, IdentityConsumer consumer) {
        jdbc.query(con -> {
            PreparedStatement ps = con.prepareStatement("SELECT i.KEY_VALUE, i.RGL_NO, r.ROW_ID, r.CONTENT_HASH, r.MAIN_HASH "
                            + "FROM RECORD_IDENTITY i LEFT JOIN CANONICAL_RECORD r ON r.RGL_ID = i.RGL_ID AND r.VALID_TO IS NULL "
                            + "WHERE i.LIST_ID = ?", ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            ps.setFetchSize(fetchSize);
            ps.setLong(1, listId);
            return ps;
        }, (ResultSet rs) -> {
            long rowId = rs.getLong(3);
            consumer.accept(rs.getString(1), rs.getLong(2), rs.wasNull() ? 0L : rowId, rs.getString(4), rs.getString(5));
        });
    }

    public long maxRglNo(long listId) {
        Long v = jdbc.queryForObject("SELECT MAX(RGL_NO) FROM RECORD_IDENTITY WHERE LIST_ID = ?", Long.class, listId);
        return v == null ? 0L : v;
    }

    public void insertIdentities(long listId, int version, List<Identity> ids) {
        if (ids.isEmpty()) {
            return;
        }
        jdbc.batchUpdate("INSERT INTO RECORD_IDENTITY (RGL_ID, LIST_ID, RGL_NO, KEY_TYPE, KEY_VALUE, FIRST_VERSION) "
                + "VALUES (?, ?, ?, ?, ?, ?)", ids, ids.size(), (PreparedStatement ps, Identity i) -> {
                    ps.setString(1, i.rglId);
                    ps.setLong(2, listId);
                    ps.setLong(3, i.rglNo);
                    ps.setString(4, i.keyType);
                    ps.setString(5, i.keyValue);
                    ps.setInt(6, version);
                });
    }

    public void insertRows(List<Row> rows) {
        if (rows.isEmpty()) {
            return;
        }
        jdbc.batchUpdate("INSERT INTO CANONICAL_RECORD (" + ROW_COLS + ") VALUES "
                + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", rows, rows.size(),
                (PreparedStatement ps, Row r) -> {
                    int k = 1;
                    ps.setLong(k++, r.rowId);
                    ps.setString(k++, r.rglId);
                    ps.setLong(k++, r.listId);
                    ps.setInt(k++, r.validFrom);
                    ps.setNull(k++, Types.INTEGER);
                    ps.setLong(k++, r.batchId);
                    if (r.rawSeq == null) {
                        ps.setNull(k++, Types.BIGINT);
                    } else {
                        ps.setLong(k++, r.rawSeq);
                    }
                    ps.setString(k++, Db.cut(r.externalRef, 200));
                    ps.setString(k++, r.recordType);
                    ps.setString(k++, Db.cut(r.primaryName, 500));
                    ps.setString(k++, Db.cut(r.nameSearch, 4000));
                    ps.setString(k++, Db.cut(r.gender, 10));
                    ps.setString(k++, Db.cut(r.dob, 500));
                    ps.setString(k++, Db.cut(r.nationalities, 500));
                    ps.setString(k++, Db.cut(r.countries, 1000));
                    ps.setString(k++, Db.cut(r.idNumbers, 2000));
                    ps.setString(k++, Db.cut(r.listRefs, 2000));
                    ps.setString(k++, Db.cut(r.status, 40));
                    ps.setString(k++, Db.cut(r.dqFlags, 200));
                    ps.setString(k++, r.contentHash);
                    ps.setString(k++, r.mainHash);
                    ps.setString(k, r.content);
                });
    }

    /** Ends the validity of rows: they are valid up to and including validTo. */
    public void closeRows(Collection<Long> rowIds, int validTo) {
        if (rowIds.isEmpty()) {
            return;
        }
        List<Long> ids = new ArrayList<>(rowIds);
        jdbc.batchUpdate("UPDATE CANONICAL_RECORD SET VALID_TO = ? WHERE ROW_ID = ?", ids, ids.size(),
                (PreparedStatement ps, Long id) -> {
                    ps.setInt(1, validTo);
                    ps.setLong(2, id);
                });
    }

    /** Rows by id (in chunks of 1000 for the IN list). */
    public Map<Long, Row> rowsById(Collection<Long> rowIds) {
        Map<Long, Row> out = new HashMap<>();
        List<Long> ids = new ArrayList<>(rowIds);
        for (int i = 0; i < ids.size(); i += 1000) {
            named.query("SELECT " + ROW_COLS + " FROM CANONICAL_RECORD WHERE ROW_ID IN (:ids)",
                    new MapSqlParameterSource("ids", ids.subList(i, Math.min(ids.size(), i + 1000))), (ResultSet rs) -> {
                        Row r = map(rs);
                        out.put(r.rowId, r);
                    });
        }
        return out;
    }

    // ------------------------------------------------------------------ rollback of a version

    /** Undoes stage 2 of a version: its new rows and identities go, rows it closed are open again. */
    public void rollback(long listId, int version) {
        jdbc.update("DELETE FROM CANONICAL_RECORD WHERE LIST_ID = ? AND VALID_FROM = ?", listId, version);
        jdbc.update("UPDATE CANONICAL_RECORD SET VALID_TO = NULL WHERE LIST_ID = ? AND VALID_TO = ?", listId, version - 1);
        jdbc.update("DELETE FROM RECORD_IDENTITY WHERE LIST_ID = ? AND FIRST_VERSION = ?", listId, version);
    }

    // ------------------------------------------------------------------ reads

    public long countValid(long listId, int version) {
        Long n = jdbc.queryForObject("SELECT COUNT(*) FROM CANONICAL_RECORD WHERE LIST_ID = ? AND VALID_FROM <= ? "
                + "AND (VALID_TO IS NULL OR VALID_TO >= ?)", Long.class, listId, version, version);
        return n == null ? 0 : n;
    }

    /** Rows valid in a version, streamed (export). */
    public void streamValid(long listId, int version, int fetchSize, RowConsumer consumer) {
        jdbc.query(con -> {
            PreparedStatement ps = con.prepareStatement("SELECT " + ROW_COLS + " FROM CANONICAL_RECORD WHERE LIST_ID = ? "
                    + "AND VALID_FROM <= ? AND (VALID_TO IS NULL OR VALID_TO >= ?)", ResultSet.TYPE_FORWARD_ONLY,
                    ResultSet.CONCUR_READ_ONLY);
            ps.setFetchSize(fetchSize);
            ps.setLong(1, listId);
            ps.setInt(2, version);
            ps.setInt(3, version);
            return ps;
        }, (ResultSet rs) -> {
            consumer.accept(map(rs));
        });
    }

    /** Page of rows valid in a version (subscriber API), ordered by internal id. */
    public List<Row> pageValid(long listId, int version, int offset, int size) {
        return named.query("SELECT " + ROW_COLS + " FROM CANONICAL_RECORD WHERE LIST_ID = :l AND VALID_FROM <= :v "
                        + "AND (VALID_TO IS NULL OR VALID_TO >= :v) ORDER BY RGL_ID OFFSET :o ROWS FETCH NEXT :s ROWS ONLY",
                new MapSqlParameterSource("l", listId).addValue("v", version).addValue("o", offset).addValue("s", size), ROW);
    }

    /** Every row of an identity, oldest first (history). */
    public List<Row> history(String rglId) {
        return named.query("SELECT " + ROW_COLS + " FROM CANONICAL_RECORD WHERE RGL_ID = :id ORDER BY VALID_FROM",
                new MapSqlParameterSource("id", rglId), ROW);
    }

    /** Row of an identity valid in a version (or the latest when version is null). */
    public Optional<Row> rowAt(String rglId, Integer version) {
        if (version == null) {
            List<Row> h = history(rglId);
            return h.isEmpty() ? Optional.<Row>empty() : Optional.of(h.get(h.size() - 1));
        }
        return named.query("SELECT " + ROW_COLS + " FROM CANONICAL_RECORD WHERE RGL_ID = :id AND VALID_FROM <= :v "
                        + "AND (VALID_TO IS NULL OR VALID_TO >= :v)",
                new MapSqlParameterSource("id", rglId).addValue("v", version), ROW).stream().findFirst();
    }

    public Optional<Map<String, Object>> identity(String rglId) {
        return named.queryForList("SELECT RGL_ID, LIST_ID, RGL_NO, KEY_TYPE, KEY_VALUE, FIRST_VERSION FROM RECORD_IDENTITY "
                + "WHERE RGL_ID = :id", new MapSqlParameterSource("id", rglId)).stream().findFirst();
    }

    /**
     * Name / id search on the latest row of each identity. Text is matched on the search form of every name
     * and on the internal and provider ids.
     */
    public List<Row> search(String text, Long listId, String recordType, boolean includeDeleted, int max) {
        StringBuilder sql = new StringBuilder("SELECT " + ROW_COLS + " FROM CANONICAL_RECORD c WHERE ");
        MapSqlParameterSource p = new MapSqlParameterSource("max", max);
        if (includeDeleted) {
            sql.append("c.ROW_ID IN (SELECT MAX(ROW_ID) FROM CANONICAL_RECORD GROUP BY RGL_ID)");
        } else {
            sql.append("c.VALID_TO IS NULL");
        }
        if (text != null && !text.trim().isEmpty()) {
            sql.append(" AND (c.NAME_SEARCH LIKE :q ESCAPE '\\' OR UPPER(c.RGL_ID) = :exact OR UPPER(c.EXTERNAL_REF) = :exact)");
            p.addValue("q", com.bank.ingestion.util.Texts.likeContains(com.bank.ingestion.util.Texts.searchForm(text)));
            p.addValue("exact", text.trim().toUpperCase(java.util.Locale.ROOT));
        }
        if (listId != null) {
            sql.append(" AND c.LIST_ID = :l");
            p.addValue("l", listId);
        }
        if (recordType != null && !recordType.isEmpty()) {
            sql.append(" AND c.RECORD_TYPE = :t");
            p.addValue("t", recordType);
        }
        sql.append(" ORDER BY c.PRIMARY_NAME FETCH FIRST :max ROWS ONLY");
        return named.query(sql.toString(), p, ROW);
    }

    /** Number of open records per list (lists screen). */
    public Map<Long, Long> openCounts() {
        Map<Long, Long> out = new HashMap<>();
        jdbc.query("SELECT LIST_ID, COUNT(*) FROM CANONICAL_RECORD WHERE VALID_TO IS NULL GROUP BY LIST_ID", (ResultSet rs) -> {
            out.put(rs.getLong(1), rs.getLong(2));
        });
        return out;
    }
}
