package com.bank.ingestion.repository;

import com.bank.ingestion.domain.ListDef;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Lists and their mappings. */
@Repository
public class ListRepository {

    private static final String LIST_COLS = "LIST_ID, LIST_CODE, NAME, PROVIDER_CODE, CATEGORY, FILE_FORMAT, FILE_PATTERN, "
            + "DELTA_PATTERN, RECORD_ELEMENTS, ID_PREFIX, MATCH_KEY_ATTRS, WORKFLOW, EXPORT_FORMATS, MAX_REJECT_PERCENT, "
            + "ACTIVE, DESCRIPTION, CREATED_BY, CREATED_AT";

    private static final RowMapper<ListDef> LIST = (rs, i) -> {
        ListDef l = new ListDef();
        l.setListId(rs.getLong("LIST_ID"));
        l.setListCode(rs.getString("LIST_CODE"));
        l.setName(rs.getString("NAME"));
        l.setProviderCode(rs.getString("PROVIDER_CODE"));
        l.setCategory(rs.getString("CATEGORY"));
        l.setFileFormat(rs.getString("FILE_FORMAT"));
        l.setFilePattern(rs.getString("FILE_PATTERN"));
        l.setDeltaPattern(rs.getString("DELTA_PATTERN"));
        l.setRecordElements(rs.getString("RECORD_ELEMENTS"));
        l.setIdPrefix(rs.getString("ID_PREFIX"));
        l.setMatchKeyAttrs(rs.getString("MATCH_KEY_ATTRS"));
        l.setWorkflow(rs.getString("WORKFLOW"));
        l.setExportFormats(rs.getString("EXPORT_FORMATS"));
        l.setMaxRejectPercent(rs.getDouble("MAX_REJECT_PERCENT"));
        l.setActive(rs.getInt("ACTIVE") == 1);
        l.setDescription(rs.getString("DESCRIPTION"));
        l.setCreatedBy(rs.getString("CREATED_BY"));
        l.setCreatedAt(Db.time(rs, "CREATED_AT"));
        return l;
    };

    private final NamedParameterJdbcTemplate jdbc;

    public ListRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<ListDef> findAll() {
        return jdbc.query("SELECT " + LIST_COLS + " FROM LIST_DEF ORDER BY LIST_CODE", LIST);
    }

    public Optional<ListDef> find(long listId) {
        return jdbc.query("SELECT " + LIST_COLS + " FROM LIST_DEF WHERE LIST_ID = :id",
                new MapSqlParameterSource("id", listId), LIST).stream().findFirst();
    }

    public Optional<ListDef> findByCode(String code) {
        return jdbc.query("SELECT " + LIST_COLS + " FROM LIST_DEF WHERE LIST_CODE = :c",
                new MapSqlParameterSource("c", code), LIST).stream().findFirst();
    }

    public void insert(ListDef l) {
        jdbc.update("INSERT INTO LIST_DEF (" + LIST_COLS + ") VALUES (:id, :code, :name, :provider, :category, :format, "
                + ":pattern, :delta, :elements, :prefix, :matchKey, :workflow, :exports, :maxReject, :active, :descr, "
                + ":createdBy, :createdAt)", params(l).addValue("createdBy", l.getCreatedBy()).addValue("createdAt", Db.now()));
    }

    public void update(ListDef l) {
        jdbc.update("UPDATE LIST_DEF SET LIST_CODE = :code, NAME = :name, PROVIDER_CODE = :provider, CATEGORY = :category, "
                + "FILE_FORMAT = :format, FILE_PATTERN = :pattern, DELTA_PATTERN = :delta, RECORD_ELEMENTS = :elements, "
                + "ID_PREFIX = :prefix, MATCH_KEY_ATTRS = :matchKey, WORKFLOW = :workflow, EXPORT_FORMATS = :exports, "
                + "MAX_REJECT_PERCENT = :maxReject, ACTIVE = :active, DESCRIPTION = :descr WHERE LIST_ID = :id", params(l));
    }

    private static MapSqlParameterSource params(ListDef l) {
        return new MapSqlParameterSource()
                .addValue("id", l.getListId())
                .addValue("code", l.getListCode())
                .addValue("name", l.getName())
                .addValue("provider", l.getProviderCode())
                .addValue("category", l.getCategory())
                .addValue("format", l.getFileFormat())
                .addValue("pattern", l.getFilePattern())
                .addValue("delta", l.getDeltaPattern())
                .addValue("elements", l.getRecordElements())
                .addValue("prefix", l.getIdPrefix())
                .addValue("matchKey", l.getMatchKeyAttrs())
                .addValue("workflow", l.getWorkflow())
                .addValue("exports", l.getExportFormats())
                .addValue("maxReject", l.getMaxRejectPercent())
                .addValue("active", l.isActive() ? 1 : 0)
                .addValue("descr", l.getDescription());
    }

    // ------------------------------------------------------------------ mappings

    /** A stored mapping version. */
    public static final class Mapping {
        public long mappingId;
        public long listId;
        public int versionNo;
        public String status;
        public String rulesJson;
        public String createdBy;
        public java.time.LocalDateTime createdAt;
        public String approvedBy;
        public java.time.LocalDateTime approvedAt;
    }

    private static final RowMapper<Mapping> MAPPING = (rs, i) -> {
        Mapping m = new Mapping();
        m.mappingId = rs.getLong("MAPPING_ID");
        m.listId = rs.getLong("LIST_ID");
        m.versionNo = rs.getInt("VERSION_NO");
        m.status = rs.getString("STATUS");
        m.rulesJson = rs.getString("RULES_JSON");
        m.createdBy = rs.getString("CREATED_BY");
        m.createdAt = Db.time(rs, "CREATED_AT");
        m.approvedBy = rs.getString("APPROVED_BY");
        m.approvedAt = Db.time(rs, "APPROVED_AT");
        return m;
    };

    private static final String MAPPING_COLS = "MAPPING_ID, LIST_ID, VERSION_NO, STATUS, RULES_JSON, CREATED_BY, CREATED_AT, "
            + "APPROVED_BY, APPROVED_AT";

    public Optional<Mapping> approvedMapping(long listId) {
        return jdbc.query("SELECT " + MAPPING_COLS + " FROM LIST_MAPPING WHERE LIST_ID = :id AND STATUS = 'APPROVED' "
                + "ORDER BY VERSION_NO DESC", new MapSqlParameterSource("id", listId), MAPPING).stream().findFirst();
    }

    public Optional<Mapping> draftMapping(long listId) {
        return jdbc.query("SELECT " + MAPPING_COLS + " FROM LIST_MAPPING WHERE LIST_ID = :id AND STATUS = 'DRAFT' "
                + "ORDER BY VERSION_NO DESC", new MapSqlParameterSource("id", listId), MAPPING).stream().findFirst();
    }

    public List<Mapping> mappings(long listId) {
        return jdbc.query("SELECT " + MAPPING_COLS + " FROM LIST_MAPPING WHERE LIST_ID = :id ORDER BY VERSION_NO DESC",
                new MapSqlParameterSource("id", listId), MAPPING);
    }

    /** Saves the draft (one draft per list: replaced in place). */
    public void saveDraft(long mappingId, long listId, String rulesJson, String user) {
        Optional<Mapping> draft = draftMapping(listId);
        if (draft.isPresent()) {
            jdbc.update("UPDATE LIST_MAPPING SET RULES_JSON = :rules, CREATED_BY = :user, CREATED_AT = :now "
                            + "WHERE MAPPING_ID = :id",
                    new MapSqlParameterSource("rules", rulesJson).addValue("user", user).addValue("now", Db.now())
                            .addValue("id", draft.get().mappingId));
            return;
        }
        Integer max = jdbc.queryForObject("SELECT MAX(VERSION_NO) FROM LIST_MAPPING WHERE LIST_ID = :id",
                new MapSqlParameterSource("id", listId), Integer.class);
        Map<String, Object> p = new HashMap<>();
        p.put("mid", mappingId);
        p.put("lid", listId);
        p.put("v", max == null ? 1 : max + 1);
        p.put("rules", rulesJson);
        p.put("user", user);
        p.put("now", Db.now());
        jdbc.update("INSERT INTO LIST_MAPPING (MAPPING_ID, LIST_ID, VERSION_NO, STATUS, RULES_JSON, CREATED_BY, CREATED_AT) "
                + "VALUES (:mid, :lid, :v, 'DRAFT', :rules, :user, :now)", p);
    }

    /** The draft becomes the approved mapping; the previous approved one is kept as SUPERSEDED. */
    public int approveDraft(long listId, String user) {
        Optional<Mapping> draft = draftMapping(listId);
        if (!draft.isPresent()) {
            return 0;
        }
        jdbc.update("UPDATE LIST_MAPPING SET STATUS = 'SUPERSEDED' WHERE LIST_ID = :id AND STATUS = 'APPROVED'",
                new MapSqlParameterSource("id", listId));
        jdbc.update("UPDATE LIST_MAPPING SET STATUS = 'APPROVED', APPROVED_BY = :user, APPROVED_AT = :now WHERE MAPPING_ID = :mid",
                new MapSqlParameterSource("user", user).addValue("now", Db.now()).addValue("mid", draft.get().mappingId));
        return draft.get().versionNo;
    }
}
