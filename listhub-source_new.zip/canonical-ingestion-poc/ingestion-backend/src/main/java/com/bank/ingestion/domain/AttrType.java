package com.bank.ingestion.domain;

import java.util.Locale;

/** Canonical attributes: the same for every provider. */
public enum AttrType {
    PRIMARY_NAME("Primary name", false),
    FIRST_NAME("First name", false),
    LAST_NAME("Last name", false),
    ALIAS("Aliases", true),
    GENDER("Gender", false),
    DOB("Date of birth", true),
    BIRTH_PLACE("Place of birth", true),
    NATIONALITY("Nationality", true),
    RESIDENCE("Residence", true),
    COUNTRY("Country", true),
    ADDRESS("Address", true),
    ID_DOC("ID documents", true),
    SANCTION_REF("Sanctions lists", true),
    DESCRIPTION("Description", true),
    OCCUPATION("Role / occupation", true),
    STATUS("Status", false),
    SOURCE("Source", true),
    URL("Link", true),
    NOTE("Note", true),
    LAST_UPDATED("Last updated by provider", false);

    private final String label;
    private final boolean multi;

    AttrType(String label, boolean multi) {
        this.label = label;
        this.multi = multi;
    }

    public String label() { return label; }
    public boolean multi() { return multi; }

    /** Attributes whose values are countries (normalised to ISO alpha-2). */
    public boolean isCountry() {
        return this == NATIONALITY || this == RESIDENCE || this == COUNTRY;
    }

    public static AttrType of(String value) {
        return AttrType.valueOf(value.trim().toUpperCase(Locale.ROOT));
    }
}
