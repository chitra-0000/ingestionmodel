package com.bank.ingestion.web;

import com.bank.ingestion.service.admin.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.Map;

/** Who am I, password change. Login and logout are handled by Spring Security (SecurityConfig). */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserService users;

    public AuthController(UserService users) {
        this.users = users;
    }

    /** Called by the login screen first: the response sets the XSRF-TOKEN cookie. */
    @GetMapping("/csrf")
    public Map<String, String> csrf() {
        return Collections.singletonMap("result", "ok");
    }

    @GetMapping("/me")
    public Map<String, Object> me(Authentication auth) {
        return users.me(auth.getName());
    }

    @PostMapping("/password")
    public Map<String, String> password(@RequestBody Map<String, String> body, Authentication auth) {
        users.changeOwnPassword(auth.getName(), body.get("current"), body.get("password"));
        return Collections.singletonMap("result", "ok");
    }
}
