package com.bank.ingestion.service.admin;

import com.bank.ingestion.config.ListHubProperties;
import com.bank.ingestion.domain.Role;
import com.bank.ingestion.repository.UserRepository;
import com.bank.ingestion.util.ApiException;
import com.bank.ingestion.util.Texts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/** Users and roles. Passwords are stored as BCrypt hashes only. */
@Service
public class UserService implements UserDetailsService {

    private static final Logger LOG = LoggerFactory.getLogger(UserService.class);
    private static final Pattern USERNAME = Pattern.compile("^[A-Za-z0-9._-]{2,60}$");
    private static final String ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";

    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final ListHubProperties props;

    public UserService(UserRepository users, PasswordEncoder encoder, ListHubProperties props) {
        this.users = users;
        this.encoder = encoder;
        this.props = props;
    }

    @Override
    public UserDetails loadUserByUsername(String username) {
        UserRepository.User u = users.find(username).orElseThrow(() -> new UsernameNotFoundException("Unknown user"));
        return User.withUsername(u.username).password(u.passwordHash).authorities(authorities(u.roles))
                .disabled(!u.active).build();
    }

    private static List<GrantedAuthority> authorities(String roles) {
        List<GrantedAuthority> out = new ArrayList<>();
        for (String r : roles.split(",")) {
            if (!r.trim().isEmpty()) {
                out.add(new SimpleGrantedAuthority("ROLE_" + r.trim()));
            }
        }
        return out;
    }

    /** First start: creates the administrator (password from LISTHUB_ADMIN_PASSWORD, or a random one in a file). */
    @EventListener(ApplicationReadyEvent.class)
    public void bootstrap() throws IOException {
        if (users.count() > 0) {
            return;
        }
        String password = props.getAdmin().getPassword();
        boolean generated = false;
        if (password == null || password.trim().isEmpty()) {
            password = randomPassword();
            generated = true;
        } else {
            checkPassword(password);
        }
        UserRepository.User u = new UserRepository.User();
        u.username = props.getAdmin().getUsername();
        u.displayName = "Administrator";
        u.passwordHash = encoder.encode(password);
        u.roles = Role.ADMIN.name();
        u.active = true;
        users.insert(u);
        if (generated) {
            Path f = props.base().resolve("initial-admin-password.txt");
            Files.createDirectories(props.base());
            Files.write(f, ("user: " + u.username + "\npassword: " + password + "\n").getBytes(StandardCharsets.UTF_8));
            if (FileSystems.getDefault().supportedFileAttributeViews().contains("posix")) {
                Files.setPosixFilePermissions(f, PosixFilePermissions.fromString("rw-------"));
            }
            LOG.warn("First start: administrator '{}' created; its password is in {} (delete the file after the first login)",
                    u.username, f);
        } else {
            LOG.info("First start: administrator '{}' created from LISTHUB_ADMIN_PASSWORD", u.username);
        }
    }

    public List<Map<String, Object>> list() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (UserRepository.User u : users.findAll()) {
            out.add(view(u));
        }
        return out;
    }

    public Map<String, Object> me(String username) {
        return view(users.find(username).orElseThrow(() -> ApiException.notFound("Unknown user")));
    }

    private static Map<String, Object> view(UserRepository.User u) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("username", u.username);
        m.put("displayName", u.displayName);
        m.put("roles", u.roles.split(","));
        m.put("active", u.active);
        m.put("createdAt", u.createdAt);
        return m;
    }

    public Map<String, Object> create(String username, String displayName, String password, List<String> roles) {
        if (username == null || !USERNAME.matcher(username).matches()) {
            throw ApiException.badRequest("User name: 2-60 letters, digits, dot, dash or underscore");
        }
        if (users.find(username).isPresent()) {
            throw ApiException.conflict("This user already exists");
        }
        checkPassword(password);
        UserRepository.User u = new UserRepository.User();
        u.username = username;
        u.displayName = displayName(displayName, username);
        u.passwordHash = encoder.encode(password);
        u.roles = roles(roles);
        u.active = true;
        users.insert(u);
        return me(username);
    }

    public Map<String, Object> update(String username, String displayName, List<String> roles, boolean active, String actor) {
        UserRepository.User u = users.find(username).orElseThrow(() -> ApiException.notFound("Unknown user"));
        String newRoles = roles(roles);
        if (username.equalsIgnoreCase(actor) && (!active || !newRoles.contains(Role.ADMIN.name()))) {
            throw ApiException.badRequest("You cannot remove your own administrator role or deactivate yourself");
        }
        users.update(username, displayName(displayName, u.displayName), newRoles, active);
        return me(username);
    }

    public void resetPassword(String username, String password) {
        users.find(username).orElseThrow(() -> ApiException.notFound("Unknown user"));
        checkPassword(password);
        users.setPassword(username, encoder.encode(password));
    }

    public void changeOwnPassword(String username, String current, String password) {
        UserRepository.User u = users.find(username).orElseThrow(() -> ApiException.notFound("Unknown user"));
        if (current == null || !encoder.matches(current, u.passwordHash)) {
            throw ApiException.badRequest("The current password is not correct");
        }
        checkPassword(password);
        users.setPassword(username, encoder.encode(password));
    }

    private static String displayName(String value, String fallback) {
        String d = value == null || value.trim().isEmpty() ? fallback : value.trim();
        return Texts.truncate(d, 120);
    }

    private static String roles(List<String> roles) {
        if (roles == null || roles.isEmpty()) {
            throw ApiException.badRequest("Give the user at least one role");
        }
        List<String> out = new ArrayList<>();
        for (String r : roles) {
            try {
                String role = Role.valueOf(r.trim().toUpperCase(Locale.ROOT)).name();
                if (!out.contains(role)) {
                    out.add(role);
                }
            } catch (IllegalArgumentException e) {
                throw ApiException.badRequest("Unknown role: " + Texts.truncate(r, 30));
            }
        }
        return String.join(",", out);
    }

    /** At least 10 characters with a letter and a digit. */
    private static void checkPassword(String p) {
        if (p == null || p.length() < 10 || p.length() > 100 || !p.matches(".*[A-Za-z].*") || !p.matches(".*[0-9].*")) {
            throw ApiException.badRequest("Password: 10 to 100 characters, with at least one letter and one digit");
        }
    }

    private static String randomPassword() {
        SecureRandom r = new SecureRandom();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 14; i++) {
            sb.append(ALPHABET.charAt(r.nextInt(ALPHABET.length())));
        }
        return sb.append(r.nextInt(10)).toString();
    }
}
