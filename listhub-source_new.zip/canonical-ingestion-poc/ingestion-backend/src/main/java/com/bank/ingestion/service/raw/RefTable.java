package com.bank.ingestion.service.raw;

import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Reference lists of one file (code -> label), e.g. CountryList IN -> India, DateTypeList 1 -> Date of Birth.
 * Read-only once built; shared by the worker threads of a batch.
 */
public final class RefTable {

    public static final RefTable EMPTY = new RefTable(Collections.<String, Map<String, String>>emptyMap());

    /** list name (lower case) -> code -> label. */
    private final Map<String, Map<String, String>> lists;
    private final java.util.Set<String> originalNames;

    public RefTable(Map<String, Map<String, String>> lists) {
        Map<String, Map<String, String>> m = new HashMap<>();
        for (Map.Entry<String, Map<String, String>> e : lists.entrySet()) {
            m.put(e.getKey().toLowerCase(Locale.ROOT), e.getValue());
        }
        this.lists = m;
        this.originalNames = java.util.Collections.unmodifiableSet(new java.util.TreeSet<>(lists.keySet()));
    }

    public boolean isEmpty() {
        return lists.isEmpty();
    }

    public Map<String, String> list(String name) {
        return name == null ? null : lists.get(name.toLowerCase(Locale.ROOT));
    }

    /** List names as written in the file. */
    public java.util.Set<String> names() {
        return originalNames;
    }

    /** Label of a code in the named list; null when the list or the code is unknown. */
    public String decode(String listName, String code) {
        Map<String, String> l = list(listName);
        return l == null || code == null ? null : l.get(code.trim());
    }

    /**
     * Label of an attribute value through the list named after the attribute: DateType -> DateTypeList,
     * CountryType -> CountryTypeList, IDType -> IDTypeList (or IdentificationTypeList).
     */
    public String decodeAttr(String attrName, String code) {
        if (code == null || lists.isEmpty()) {
            return null;
        }
        String base = attrName.toLowerCase(Locale.ROOT);
        String v = decode(base + "list", code);
        if (v == null && base.endsWith("type")) {
            String stem = base.substring(0, base.length() - 4);
            v = decode(stem + "typelist", code);
            if (v == null && "id".equals(stem)) {
                v = decode("identificationtypelist", code);
            }
            if (v == null) {
                v = decode(stem + "list", code);
            }
        }
        return v;
    }
}
