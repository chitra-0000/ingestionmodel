package com.bank.ingestion.web;

import com.bank.ingestion.domain.ChangeType;
import com.bank.ingestion.repository.VersionRepository;
import com.bank.ingestion.service.export.PdfService;
import com.bank.ingestion.service.version.RecordService;
import com.bank.ingestion.util.Texts;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/** Record search, detail, history, PDF sheet and the raw record. */
@RestController
@RequestMapping("/api")
@PreAuthorize(Roles.VIEW)
public class RecordController {

    private final RecordService records;
    private final VersionRepository versions;
    private final PdfService pdf;

    public RecordController(RecordService records, VersionRepository versions, PdfService pdf) {
        this.records = records;
        this.versions = versions;
        this.pdf = pdf;
    }

    @GetMapping("/records/search")
    public List<Map<String, Object>> search(@RequestParam(required = false) String q, @RequestParam(required = false) Long listId,
                                            @RequestParam(required = false) String type,
                                            @RequestParam(defaultValue = "false") boolean deleted) {
        return records.search(q, listId, type, deleted);
    }

    @GetMapping("/records/{rglId}")
    public Map<String, Object> detail(@PathVariable String rglId, @RequestParam(required = false) Integer version) {
        return records.detail(rglId, version);
    }

    @GetMapping("/records/{rglId}/history")
    public Map<String, Object> history(@PathVariable String rglId) {
        return records.history(rglId);
    }

    /** Record sheet as valid in a version, with what changed in that version. */
    @GetMapping("/records/{rglId}/pdf")
    public ResponseEntity<byte[]> pdf(@PathVariable String rglId, @RequestParam(required = false) Integer version) {
        Map<String, Object> record = records.detail(rglId, version);
        Map<String, Object> change = null;
        int v = version == null ? (Integer) record.get("validFrom") : version;
        for (VersionRepository.Change c : versions.changesOf(rglId)) {
            if (c.versionNo == v && !ChangeType.FLAGGED.name().equals(c.changeType)) {
                change = records.changeView(c);
            }
        }
        byte[] bytes = pdf.recordSheet(record, change, v);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.inline()
                        .filename(Texts.safeFileName(rglId) + "_v" + v + ".pdf").build().toString())
                .contentType(MediaType.APPLICATION_PDF)
                .body(bytes);
    }

    @GetMapping("/raw/{batchId}/{seq}")
    public Map<String, Object> raw(@PathVariable long batchId, @PathVariable long seq) {
        return records.rawRecord(batchId, seq);
    }
}
