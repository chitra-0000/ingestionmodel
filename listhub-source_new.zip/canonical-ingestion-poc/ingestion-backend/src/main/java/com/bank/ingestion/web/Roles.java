package com.bank.ingestion.web;

/** Role checks used in @PreAuthorize. ADMIN can do everything. */
public final class Roles {

    /** Every screen user (subscribers use the /api/v1 API only). */
    public static final String VIEW = "hasAnyRole('ADMIN','OPERATOR','VALIDATOR','CERTIFIER','VIEWER')";
    public static final String OPERATE = "hasAnyRole('ADMIN','OPERATOR')";
    public static final String ADMIN = "hasRole('ADMIN')";
    public static final String VALIDATE = "hasAnyRole('ADMIN','VALIDATOR')";
    public static final String CERTIFY = "hasAnyRole('ADMIN','CERTIFIER')";
    public static final String DECIDE = "hasAnyRole('ADMIN','VALIDATOR','CERTIFIER')";
    public static final String SUBSCRIBE = "hasAnyRole('ADMIN','SUBSCRIBER','VIEWER')";

    private Roles() {
    }
}
