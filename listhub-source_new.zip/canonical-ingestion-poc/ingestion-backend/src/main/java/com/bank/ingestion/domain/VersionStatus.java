package com.bank.ingestion.domain;

/** TO_VALIDATE -> VALIDATED -> PUBLISHED (certification publishes), or REJECTED. */
public enum VersionStatus {
    TO_VALIDATE, VALIDATED, PUBLISHED, REJECTED;

    public boolean isOpen() {
        return this == TO_VALIDATE || this == VALIDATED;
    }
}
