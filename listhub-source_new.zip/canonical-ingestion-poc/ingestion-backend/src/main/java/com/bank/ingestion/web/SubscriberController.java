package com.bank.ingestion.web;

import com.bank.ingestion.config.ListHubProperties;
import com.bank.ingestion.domain.CanonicalRecord;
import com.bank.ingestion.domain.ListDef;
import com.bank.ingestion.domain.ListVersion;
import com.bank.ingestion.repository.CanonicalRepository;
import com.bank.ingestion.repository.ExportRepository;
import com.bank.ingestion.repository.ListRepository;
import com.bank.ingestion.repository.VersionRepository;
import com.bank.ingestion.service.version.RecordService;
import com.bank.ingestion.util.ApiException;
import com.bank.ingestion.util.Json;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Subscriber API (HTTP Basic, user with the SUBSCRIBER role). Only PUBLISHED versions are visible here:
 * a version being validated is never served.
 */
@RestController
@RequestMapping("/api/v1")
@PreAuthorize(Roles.SUBSCRIBE)
public class SubscriberController {

    private final ListRepository lists;
    private final VersionRepository versions;
    private final CanonicalRepository canonical;
    private final ExportRepository exports;
    private final ListHubProperties props;

    public SubscriberController(ListRepository lists, VersionRepository versions, CanonicalRepository canonical,
                                ExportRepository exports, ListHubProperties props) {
        this.lists = lists;
        this.versions = versions;
        this.canonical = canonical;
        this.exports = exports;
        this.props = props;
    }

    @GetMapping("/lists")
    public List<Map<String, Object>> lists() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (ListDef l : lists.findAll()) {
            Optional<ListVersion> v = versions.lastPublished(l.getListId());
            if (!v.isPresent()) {
                continue;
            }
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("code", l.getListCode());
            m.put("name", l.getName());
            m.put("provider", l.getProviderCode());
            m.put("version", v.get().getVersionNo());
            m.put("publishedAt", v.get().getPublishedAt());
            m.put("records", v.get().getTotalRecords());
            out.add(m);
        }
        return out;
    }

    /** Records of the published version, page by page (ordered by internal id). */
    @GetMapping("/lists/{code}/records")
    public Map<String, Object> records(@PathVariable String code, @RequestParam(defaultValue = "0") int page,
                                       @RequestParam(defaultValue = "1000") int size) {
        ListDef l = list(code);
        ListVersion v = published(l);
        int s = Math.max(1, Math.min(size, props.getMaxApiPageSize()));
        int p = Math.max(0, page);
        List<Map<String, Object>> rows = new ArrayList<>();
        for (CanonicalRepository.Row r : canonical.pageValid(l.getListId(), v.getVersionNo(), p * s, s)) {
            rows.add(record(r));
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("list", l.getListCode());
        m.put("version", v.getVersionNo());
        m.put("total", v.getTotalRecords());
        m.put("page", p);
        m.put("size", s);
        m.put("records", rows);
        return m;
    }

    @GetMapping("/lists/{code}/records/{rglId}")
    public Map<String, Object> record(@PathVariable String code, @PathVariable String rglId) {
        ListDef l = list(code);
        ListVersion v = published(l);
        CanonicalRepository.Row r = canonical.rowAt(rglId, v.getVersionNo())
                .filter(x -> x.listId == l.getListId())
                .orElseThrow(() -> ApiException.notFound("Record not in the published version"));
        return record(r);
    }

    /** Changes of a published version (default: the latest). */
    @GetMapping("/lists/{code}/changes")
    public Map<String, Object> changes(@PathVariable String code, @RequestParam(required = false) Integer version,
                                       @RequestParam(defaultValue = "MODIFIED") String type,
                                       @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "1000") int size) {
        ListDef l = list(code);
        int v = version == null ? published(l).getVersionNo() : version;
        ListVersion lv = versions.find(l.getListId(), v).orElseThrow(() -> ApiException.notFound("Version not found"));
        if (lv.getStatus() != com.bank.ingestion.domain.VersionStatus.PUBLISHED) {
            throw ApiException.notFound("Version not published");
        }
        String t = type.toUpperCase(java.util.Locale.ROOT);
        if (!"CREATED".equals(t) && !"MODIFIED".equals(t) && !"MINOR".equals(t) && !"DELETED".equals(t)) {
            throw ApiException.badRequest("type: CREATED, MODIFIED, MINOR or DELETED");
        }
        int s = Math.max(1, Math.min(size, props.getMaxApiPageSize()));
        List<Map<String, Object>> rows = new ArrayList<>();
        for (VersionRepository.Change c : versions.changes(l.getListId(), v, t, null, Math.max(0, page) * s, s)) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("rglId", c.rglId);
            m.put("externalRef", c.externalRef);
            m.put("primaryName", c.primaryName);
            m.put("summary", c.summary);
            rows.add(m);
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("list", l.getListCode());
        m.put("version", v);
        m.put("type", t);
        m.put("total", versions.countChanges(l.getListId(), v, t, null));
        m.put("changes", rows);
        return m;
    }

    @GetMapping("/lists/{code}/files")
    public List<ExportRepository.ExportFile> files(@PathVariable String code) {
        ListDef l = list(code);
        List<ExportRepository.ExportFile> f = exports.byVersion(l.getListId(), published(l).getVersionNo());
        for (ExportRepository.ExportFile e : f) {
            e.filePath = null;
        }
        return f;
    }

    @GetMapping("/files/{exportId}")
    public ResponseEntity<InputStreamResource> file(@PathVariable long exportId) throws IOException {
        ExportRepository.ExportFile f = exports.find(exportId).orElseThrow(() -> ApiException.notFound("File not found"));
        ListVersion v = versions.find(f.listId, f.versionNo).orElseThrow(() -> ApiException.notFound("File not found"));
        if (v.getStatus() != com.bank.ingestion.domain.VersionStatus.PUBLISHED) {
            throw ApiException.notFound("File not found");
        }
        return VersionController.file(f, props);
    }

    private ListDef list(String code) {
        return lists.findByCode(code).orElseThrow(() -> ApiException.notFound("Unknown list"));
    }

    private ListVersion published(ListDef l) {
        return versions.lastPublished(l.getListId()).orElseThrow(() -> ApiException.notFound("The list has no published version yet"));
    }

    private static Map<String, Object> record(CanonicalRepository.Row r) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("rglId", r.rglId);
        m.put("externalRef", r.externalRef);
        m.put("recordType", r.recordType);
        m.put("primaryName", r.primaryName);
        m.put("validFrom", r.validFrom);
        m.put("attributes", RecordService.grouped(Json.read(r.content, CanonicalRecord.class)));
        return m;
    }
}
