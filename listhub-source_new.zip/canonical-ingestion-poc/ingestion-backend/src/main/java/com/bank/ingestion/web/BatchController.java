package com.bank.ingestion.web;

import com.bank.ingestion.config.ListHubProperties;
import com.bank.ingestion.domain.Batch;
import com.bank.ingestion.domain.BatchStatus;
import com.bank.ingestion.domain.ListDef;
import com.bank.ingestion.domain.ListVersion;
import com.bank.ingestion.repository.BatchRepository;
import com.bank.ingestion.repository.ListRepository;
import com.bank.ingestion.repository.VersionRepository;
import com.bank.ingestion.service.batch.BatchService;
import com.bank.ingestion.service.batch.Progress;
import com.bank.ingestion.util.ApiException;
import com.bank.ingestion.util.Texts;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Files: upload, follow-up with the time of each step, assign an unmatched file, load again. */
@RestController
@RequestMapping("/api/batches")
public class BatchController {

    private final BatchService service;
    private final BatchRepository batches;
    private final ListRepository lists;
    private final VersionRepository versions;
    private final Progress progress;
    private final ListHubProperties props;

    public BatchController(BatchService service, BatchRepository batches, ListRepository lists, VersionRepository versions,
                           Progress progress, ListHubProperties props) {
        this.service = service;
        this.batches = batches;
        this.lists = lists;
        this.versions = versions;
        this.progress = progress;
        this.props = props;
    }

    /** Upload from the screen: streamed to the work folder, then loaded like a file from the inbound folder. */
    @PostMapping("/upload")
    @PreAuthorize(Roles.OPERATE)
    public Batch upload(@RequestPart("file") MultipartFile file, @RequestParam(required = false) Long listId,
                        Authentication auth) throws IOException {
        if (file.isEmpty()) {
            throw ApiException.badRequest("The file is empty");
        }
        String name = Texts.safeFileName(file.getOriginalFilename());
        Path work = props.workDir().resolve(System.currentTimeMillis() + "_" + name);
        Files.createDirectories(props.workDir());
        try (InputStream in = file.getInputStream()) {
            Files.copy(in, work, StandardCopyOption.REPLACE_EXISTING);
        }
        return service.register(work, name, Files.size(work), System.currentTimeMillis(), "UPLOAD", listId, auth.getName());
    }

    /** Batches of the last days (all lists, or one list) with their steps and live progress. */
    @GetMapping
    @PreAuthorize(Roles.VIEW)
    public List<Map<String, Object>> list(@RequestParam(required = false) Long listId,
                                          @RequestParam(defaultValue = "7") int days) {
        List<Batch> found = listId != null ? batches.latest(listId, 200)
                : batches.since(LocalDate.now().minusDays(Math.max(0, Math.min(days, 90))).atStartOfDay());
        return views(found);
    }

    @GetMapping("/{id}")
    @PreAuthorize(Roles.VIEW)
    public Map<String, Object> one(@PathVariable long id) {
        return views(java.util.Collections.singletonList(service.get(id))).get(0);
    }

    @PostMapping("/{id}/assign")
    @PreAuthorize(Roles.OPERATE)
    public Batch assign(@PathVariable long id, @RequestBody Map<String, Long> body) {
        Long listId = body.get("listId");
        if (listId == null) {
            throw ApiException.badRequest("listId is required");
        }
        return service.assign(id, listId);
    }

    @PostMapping("/{id}/retry")
    @PreAuthorize(Roles.OPERATE)
    public Batch retry(@PathVariable long id) {
        return service.retry(id);
    }

    @GetMapping("/{id}/file")
    @PreAuthorize(Roles.OPERATE)
    public ResponseEntity<InputStreamResource> file(@PathVariable long id) throws IOException {
        Batch b = service.get(id);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(Texts.safeFileName(b.getFileName()))
                        .build().toString())
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(new InputStreamResource(service.openFile(id)));
    }

    /** Overview counts for the home page. */
    @GetMapping("/summary")
    @PreAuthorize(Roles.VIEW)
    public Map<String, Object> summary() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("mappingReview", batches.byStatus(java.util.Collections.singleton(BatchStatus.MAPPING_REVIEW)).size());
        m.put("unmatched", batches.byStatus(java.util.Collections.singleton(BatchStatus.UNMATCHED)).size());
        m.put("failedToday", (int) batches.since(LocalDate.now().atStartOfDay()).stream()
                .filter(b -> b.getStatus() == BatchStatus.FAILED).count());
        int toValidate = 0;
        int toCertify = 0;
        for (ListDef l : lists.findAll()) {
            java.util.Optional<ListVersion> open = versions.open(l.getListId());
            if (open.isPresent()) {
                if (open.get().getStatus() == com.bank.ingestion.domain.VersionStatus.TO_VALIDATE) {
                    toValidate++;
                } else {
                    toCertify++;
                }
            }
        }
        m.put("toValidate", toValidate);
        m.put("toCertify", toCertify);
        m.put("running", batches.byStatus(Arrays.asList(BatchStatus.QUEUED, BatchStatus.LOADING, BatchStatus.PROCESSING)).size());
        m.put("parallelFiles", props.effectiveParallelFiles());
        m.put("workersPerFile", props.effectiveWorkersPerFile());
        return m;
    }

    private List<Map<String, Object>> views(List<Batch> found) {
        Map<Long, ListDef> byId = new HashMap<>();
        for (ListDef l : lists.findAll()) {
            byId.put(l.getListId(), l);
        }
        List<Long> ids = new ArrayList<>();
        for (Batch b : found) {
            ids.add(b.getBatchId());
        }
        Map<Long, List<BatchRepository.Step>> steps = batches.steps(ids);
        List<Map<String, Object>> out = new ArrayList<>();
        for (Batch b : found) {
            Map<String, Object> m = new LinkedHashMap<>();
            b.setLayoutJson(null);
            b.setWorkPath(null);
            m.put("batch", b);
            ListDef l = b.getListId() == null ? null : byId.get(b.getListId());
            m.put("listCode", l == null ? null : l.getListCode());
            m.put("listName", l == null ? null : l.getName());
            m.put("steps", steps.getOrDefault(b.getBatchId(), new ArrayList<>()));
            m.put("progress", progress.view(b.getBatchId()));
            long total = 0;
            for (BatchRepository.Step s : steps.getOrDefault(b.getBatchId(), new ArrayList<>())) {
                total += s.durationMs == null ? 0 : s.durationMs;
            }
            m.put("processingMs", total);
            out.add(m);
        }
        return out;
    }
}
