package com.bank.ingestion.domain;

/**
 * Roles of the screens and the API. ADMIN can do everything. Validation and certification of the same
 * version must be done by two different users (four eyes).
 */
public enum Role {
    ADMIN, OPERATOR, VALIDATOR, CERTIFIER, VIEWER, SUBSCRIBER
}
