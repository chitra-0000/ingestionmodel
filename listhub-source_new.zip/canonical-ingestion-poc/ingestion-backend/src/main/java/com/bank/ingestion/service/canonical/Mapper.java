package com.bank.ingestion.service.canonical;

import com.bank.ingestion.domain.AttrType;
import com.bank.ingestion.domain.CanonicalRecord;
import com.bank.ingestion.domain.MappingRules;
import com.bank.ingestion.domain.RecordType;
import com.bank.ingestion.service.raw.PathExpr;
import com.bank.ingestion.service.raw.RNode;
import com.bank.ingestion.service.raw.RefTable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Applies a list's mapping rules to one raw record: path values, reference-list decoding, normalisation
 * (dates to ISO, countries to ISO alpha-2, gender to M/F) and the record-level quality checks.
 * Immutable and thread-safe: one instance is shared by the stage 2 workers of a batch.
 */
public final class Mapper {

    private final List<Compiled> fields = new ArrayList<>();
    private final PathExpr externalRef;
    private final PathExpr action;
    private final PathExpr recordType;
    private final Set<String> deleteValues = new HashSet<>();
    private final RefTable refs;
    private final DateNormalizer dates;

    private static final class Compiled {
        final AttrType attr;
        final PathExpr path;
        final String decode;
        final String qualifier;

        Compiled(AttrType attr, PathExpr path, String decode, String qualifier) {
            this.attr = attr;
            this.path = path;
            this.decode = decode;
            this.qualifier = qualifier;
        }
    }

    /** @throws IllegalArgumentException when a rule has an unknown attribute or a bad path */
    public Mapper(MappingRules rules, RefTable refs, DateNormalizer dates) {
        this.refs = refs;
        this.dates = dates;
        this.externalRef = blank(rules.getExternalRef()) ? null : PathExpr.of(rules.getExternalRef());
        this.action = blank(rules.getAction()) ? null : PathExpr.of(rules.getAction());
        this.recordType = blank(rules.getRecordType()) ? null : PathExpr.of(rules.getRecordType());
        if (rules.getDeleteValues() != null) {
            for (String d : rules.getDeleteValues()) {
                deleteValues.add(d.trim().toLowerCase(Locale.ROOT));
            }
        }
        if (deleteValues.isEmpty()) {
            deleteValues.add("del");
            deleteValues.add("delete");
            deleteValues.add("deleted");
            deleteValues.add("d");
            deleteValues.add("remove");
        }
        for (MappingRules.FieldRule r : rules.getFields()) {
            if (blank(r.getAttr()) || blank(r.getPath())) {
                continue;
            }
            fields.add(new Compiled(AttrType.of(r.getAttr()), PathExpr.of(r.getPath()),
                    blank(r.getDecode()) ? null : r.getDecode().trim(), blank(r.getQualifier()) ? null : r.getQualifier()));
        }
    }

    public boolean hasExternalRef() {
        return externalRef != null;
    }

    public CanonicalRecord map(RNode rec) {
        CanonicalRecord c = new CanonicalRecord();
        if (externalRef != null) {
            c.setExternalRef(externalRef.first(rec, refs));
        }
        if (action != null) {
            String a = action.first(rec, refs);
            c.setDeleteAction(a != null && deleteValues.contains(a.trim().toLowerCase(Locale.ROOT)));
        }
        String type = recordType == null ? rec.name() : recordType.first(rec, refs);
        c.setRecordType(RecordType.guess(type).name());

        for (Compiled f : fields) {
            for (String v : f.path.values(rec, refs)) {
                add(c, f, v);
            }
        }
        if (c.first(AttrType.PRIMARY_NAME) == null) {
            String first = c.first(AttrType.FIRST_NAME);
            String last = c.first(AttrType.LAST_NAME);
            String joined = ((first == null ? "" : first) + " " + (last == null ? "" : last)).trim();
            if (!joined.isEmpty()) {
                c.add(AttrType.PRIMARY_NAME, joined, null);
            }
        }
        if (c.first(AttrType.PRIMARY_NAME) == null && !c.isDeleteAction()) {
            c.issue("NO_NAME", "REJECT", AttrType.PRIMARY_NAME.label(), null, "Primary name missing");
        }
        c.sort();
        return c;
    }

    private void add(CanonicalRecord c, Compiled f, String raw) {
        String value = raw;
        String label = f.decode == null ? null : refs.decode(f.decode, raw);
        if (f.attr.isCountry()) {
            String iso = CountryNormalizer.normalise(raw);
            if (iso == null && label != null) {
                iso = CountryNormalizer.normalise(label);
            }
            if (iso == null) {
                c.issue("BAD_COUNTRY", "FLAG", f.attr.label(), raw, "Country not recognised: " + raw);
                value = label == null ? raw : label;
            } else {
                value = iso;
            }
        } else if (f.attr == AttrType.DOB) {
            String iso = dates.normalise(raw);
            if (iso == null) {
                c.issue("BAD_DATE", "FLAG", f.attr.label(), raw, "Not a valid date: " + raw);
            } else {
                value = iso;
            }
        } else if (f.attr == AttrType.GENDER) {
            value = gender(raw);
        } else if (label != null) {
            value = label;
        }
        if (!f.attr.multi() && c.first(f.attr) != null) {
            if (f.attr == AttrType.PRIMARY_NAME) {
                c.add(AttrType.ALIAS, value, f.qualifier);
            }
            return;
        }
        c.add(f.attr, value, f.qualifier);
    }

    private static String gender(String raw) {
        String g = raw.trim().toLowerCase(Locale.ROOT);
        if (g.equals("m") || g.startsWith("male") || g.equals("man")) {
            return "M";
        }
        if (g.equals("f") || g.startsWith("female") || g.equals("woman")) {
            return "F";
        }
        return raw.trim();
    }

    private static boolean blank(String s) {
        return s == null || s.trim().isEmpty();
    }
}
