package com.bank.ingestion.service.batch;

import com.bank.ingestion.config.ListHubProperties;
import com.bank.ingestion.repository.BatchRepository;
import com.bank.ingestion.repository.RawRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * Nightly clean-up: raw records of finished batches older than listhub.raw-retention-days are removed.
 * Canonical records, versions and changes are never removed (they are the history).
 */
@Component
public class Housekeeping {

    private static final Logger LOG = LoggerFactory.getLogger(Housekeeping.class);

    private final BatchRepository batches;
    private final RawRepository raw;
    private final ListHubProperties props;

    public Housekeeping(BatchRepository batches, RawRepository raw, ListHubProperties props) {
        this.batches = batches;
        this.raw = raw;
        this.props = props;
    }

    @Scheduled(cron = "${listhub.housekeeping-cron:0 30 2 * * *}")
    public void run() {
        if (props.getRawRetentionDays() <= 0) {
            return;
        }
        LocalDateTime before = LocalDateTime.now().minusDays(props.getRawRetentionDays());
        long rows = 0;
        int count = 0;
        for (Long id : batches.rawExpired(before)) {
            rows += raw.deleteBatch(id);
            count++;
        }
        if (count > 0) {
            LOG.info("Housekeeping: raw records of {} batches older than {} days removed ({} rows)", count,
                    props.getRawRetentionDays(), rows);
        }
    }
}
