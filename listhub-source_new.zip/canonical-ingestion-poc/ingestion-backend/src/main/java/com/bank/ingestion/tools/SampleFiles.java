package com.bank.ingestion.tools;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Generates provider-like test files (not real data): a sanctions XML in the style of a Dow Jones S_XML file
 * (reference lists with codes + Person / Entity records), and CSV / JSON files of another provider.
 *
 * Successive versions change the same records in a known way, to show history:
 * every 50th record gets a new alias (MODIFIED), every 70th a new source (MINOR), every 100th disappears
 * (DELETED), 1 % new records are added (CREATED), every 500th has no name (REJECTED) and every 300th a
 * date that does not exist (FLAGGED).
 *
 * Usage: java -cp listhub.war -Dloader.main=com.bank.ingestion.tools.SampleFiles org.springframework.boot.loader.PropertiesLauncher
 *        out-dir records [versions]
 * or from the IDE: main(out-dir, records, versions).
 */
public final class SampleFiles {

    private static final String[] FIRST = {"Viktor", "Elena", "Hamid", "Li", "Omar", "Anita", "Sergei", "Yusuf", "Maria",
            "Ahmed", "Ivan", "Fatima", "Chen", "Ravi", "Olga", "Karim", "Nadia", "Pavel", "Amir", "Sofia"};
    private static final String[] LAST = {"Sokolov", "Morozova", "Karimi", "Zhang", "Al-Fayed", "Sharma", "Volkov", "Haddad",
            "Petrova", "Rahman", "Ivanov", "Nasser", "Wei", "Kumar", "Smirnova", "Benali", "Orlova", "Novak", "Tehrani", "Rossi"};
    private static final String[] COMPANY = {"Northern Shipping", "Golden Crescent Trading", "Sea Star Maritime", "Delta Metals",
            "Blue Ocean Fisheries", "Petro Trade Holdings", "Al Noor Exchange", "Eastern Energy", "Silk Road Logistics",
            "Polar Mining"};
    private static final String[] SUFFIX = {"LLC", "FZE", "JSC", "Ltd", "Co.", "SA", "GmbH", "Holding"};
    private static final String[] COUNTRIES = {"RU", "IR", "AE", "CN", "SY", "IN", "BY", "KP", "LB", "PA", "TR", "VE"};
    private static final String[] COUNTRY_NAMES = {"Russia", "Iran", "United Arab Emirates", "China", "Syria", "India",
            "Belarus", "North Korea", "Lebanon", "Panama", "Turkey", "Venezuela"};
    private static final String[] MONTHS = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    private static final String[][] REFS = {{"101", "OFAC - Specially Designated Nationals (SDN) List"},
            {"158", "EU - Consolidated Financial Sanctions List"}, {"207", "UK - HM Treasury Financial Sanctions"},
            {"062", "France - National Asset Freeze Register"}, {"301", "UN - Security Council Consolidated List"}};

    private SampleFiles() {
    }

    public static void main(String[] args) throws IOException {
        Path dir = Paths.get(args.length > 0 ? args[0] : "sample-files");
        int records = args.length > 1 ? Integer.parseInt(args[1]) : 1000;
        int versions = args.length > 2 ? Integer.parseInt(args[2]) : 3;
        Files.createDirectories(dir);
        for (int v = 1; v <= versions; v++) {
            Path f = dir.resolve(String.format("s_xml_1158_158_202611%02d_1_f.xml", v));
            djXml(f, records, v);
            System.out.println("Wrote " + f + " (" + Files.size(f) + " bytes)");
        }
        Path d = dir.resolve(String.format("s_xml_1158_158_202611%02d_2_d.xml", versions));
        djDelta(d, records, versions);
        System.out.println("Wrote " + d);
        Path csv = dir.resolve("partner_watchlist_20261107.csv");
        csv(csv, Math.min(records, 100000), 1);
        System.out.println("Wrote " + csv);
        Path json = dir.resolve("pep_feed_20261107.json");
        json(json, Math.min(records, 100000), 1);
        System.out.println("Wrote " + json);
    }

    // ------------------------------------------------------------------ DJ-like sanctions XML

    /** Full file of version v. */
    public static void djXml(Path file, int records, int v) throws IOException {
        try (Writer w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
            w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
            w.write("<SanctionsFile date=\"202611" + String.format("%02d", v) + "\" type=\"full\">\n");
            refLists(w);
            w.write(" <Records>\n");
            int total = records + (v - 1) * Math.max(1, records / 100);
            StringBuilder sb = new StringBuilder(2048);
            for (int i = 1; i <= total; i++) {
                if (v > 1 && i % 100 == 3 && i <= records) {
                    continue; // deleted from version 2 on
                }
                sb.setLength(0);
                record(sb, i, v, null);
                w.write(sb.toString());
                if (v > 1 && i == 10) {
                    sb.setLength(0);
                    record(sb, 10, v, null);
                    w.write(sb.toString()); // the same provider id twice in one file
                }
            }
            w.write(" </Records>\n</SanctionsFile>\n");
        }
    }

    /** Delta file after version v: one deletion, one change, one new record. */
    public static void djDelta(Path file, int records, int v) throws IOException {
        try (Writer w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
            w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<SanctionsFile type=\"delta\">\n");
            refLists(w);
            w.write(" <Records>\n");
            StringBuilder sb = new StringBuilder();
            sb.append("  <Person id=\"").append(id(1)).append("\" action=\"del\" date=\"08-Nov-2026\"/>\n");
            record(sb, 50, v + 1, "chg");
            record(sb, records + 900000, v + 1, "add");
            w.write(sb.toString());
            w.write(" </Records>\n</SanctionsFile>\n");
        }
    }

    private static void refLists(Writer w) throws IOException {
        w.write(" <DateTypeList>\n  <DateType Id=\"1\" name=\"Date of Birth\"/>\n  <DateType Id=\"2\" name=\"Deceased Date\"/>\n"
                + "  <DateType Id=\"3\" name=\"Date of Registration\"/>\n </DateTypeList>\n");
        w.write(" <CountryTypeList>\n  <CountryType Id=\"1\" name=\"Citizenship\"/>\n  <CountryType Id=\"2\" name=\"Resident of\"/>\n"
                + "  <CountryType Id=\"3\" name=\"Country of Registration\"/>\n </CountryTypeList>\n");
        w.write(" <IdentificationTypeList>\n  <IdentificationType Id=\"1\" name=\"Passport No.\"/>\n"
                + "  <IdentificationType Id=\"2\" name=\"National ID\"/>\n  <IdentificationType Id=\"3\" name=\"Company Registration No.\"/>\n"
                + " </IdentificationTypeList>\n");
        w.write(" <CountryList>\n");
        for (int i = 0; i < COUNTRIES.length; i++) {
            w.write("  <Country code=\"" + COUNTRIES[i] + "\" name=\"" + COUNTRY_NAMES[i] + "\"/>\n");
        }
        w.write(" </CountryList>\n <SanctionsReferencesList>\n");
        for (String[] r : REFS) {
            w.write("  <ReferenceName code=\"" + r[0] + "\" name=\"" + r[1] + "\"/>\n");
        }
        w.write(" </SanctionsReferencesList>\n");
    }

    private static String id(int i) {
        return String.valueOf(100000 + i);
    }

    private static void record(StringBuilder sb, int i, int v, String action) {
        boolean entity = i % 4 == 0;
        String tag = entity ? "Entity" : "Person";
        sb.append("  <").append(tag).append(" id=\"").append(id(i)).append("\" action=\"")
                .append(action != null ? action : v == 1 || i > 1000000 ? "add" : "chg")
                .append("\" date=\"").append(v > 1 && i % 50 == 0 ? "0" + Math.min(9, v) : "01").append("-Nov-2026\">\n");
        if (!entity) {
            sb.append("   <Gender>").append(i % 3 == 0 ? "Female" : "Male").append("</Gender>\n");
        }
        sb.append("   <ActiveStatus>Active</ActiveStatus>\n");
        sb.append("   <NameDetails>\n");
        boolean noName = v > 1 && i % 500 == 7;
        if (!noName) {
            sb.append("    <Name NameType=\"Primary Name\">\n     <NameValue>");
            if (entity) {
                sb.append("<EntityName>").append(company(i)).append("</EntityName>");
            } else {
                sb.append("<FirstName>").append(FIRST[i % FIRST.length]).append("</FirstName><Surname>")
                        .append(LAST[(i / FIRST.length) % LAST.length]).append(' ').append(i).append("</Surname>");
            }
            sb.append("</NameValue>\n    </Name>\n");
        }
        sb.append("    <Name NameType=\"Also Known As\">\n     <NameValue>");
        if (entity) {
            sb.append("<EntityName>").append(company(i).toUpperCase(java.util.Locale.ROOT)).append("</EntityName>");
        } else {
            sb.append("<FirstName>").append(FIRST[i % FIRST.length].charAt(0)).append(".</FirstName><Surname>")
                    .append(LAST[(i / FIRST.length) % LAST.length]).append(' ').append(i).append("</Surname>");
        }
        sb.append("</NameValue>\n    </Name>\n");
        if (v > 1 && i % 50 == 0) {
            sb.append("    <Name NameType=\"Also Known As\">\n     <NameValue><EntityName>Alias v").append(v)
                    .append(" ").append(i).append("</EntityName></NameValue>\n    </Name>\n");
        }
        sb.append("   </NameDetails>\n");
        if (!entity) {
            sb.append("   <DateDetails>\n    <Date DateType=\"1\">");
            if (v > 1 && i % 300 == 11) {
                sb.append("<DateValue Day=\"30\" Month=\"Feb\" Year=\"1972\"/>");
            } else {
                sb.append("<DateValue Day=\"").append(1 + i % 28).append("\" Month=\"").append(MONTHS[i % 12])
                        .append("\" Year=\"").append(1940 + i % 60).append("\"/>");
            }
            sb.append("</Date>\n   </DateDetails>\n");
        }
        sb.append("   <CountryDetails>\n    <Country CountryType=\"").append(entity ? "3" : "1").append("\"><CountryValue Code=\"")
                .append(COUNTRIES[i % COUNTRIES.length]).append("\"/></Country>\n");
        if (!entity && i % 5 == 0) {
            sb.append("    <Country CountryType=\"2\"><CountryValue Code=\"").append(COUNTRIES[(i + 3) % COUNTRIES.length])
                    .append("\"/></Country>\n");
        }
        sb.append("   </CountryDetails>\n");
        sb.append("   <IDNumberTypes>\n    <ID IDType=\"").append(entity ? "3" : "1").append("\"><IDValue>")
                .append(entity ? "REG-" : "P").append(7000000 + i * 7L).append("</IDValue></ID>\n   </IDNumberTypes>\n");
        if (entity) {
            sb.append("   <CompanyDetails>\n    <Address><AddressLine>").append(10 + i % 90).append(" Harbour Road</AddressLine>")
                    .append("<AddressCity>City ").append(i % 40).append("</AddressCity><AddressCountry>")
                    .append(COUNTRIES[i % COUNTRIES.length]).append("</AddressCountry></Address>\n   </CompanyDetails>\n");
        }
        sb.append("   <SanctionsReferences>\n    <Reference SinceYear=\"20").append(10 + i % 15).append("\">")
                .append(REFS[i % REFS.length][0]).append("</Reference>\n");
        if (i % 3 == 0) {
            sb.append("    <Reference SinceYear=\"2022\">").append(REFS[(i + 1) % REFS.length][0]).append("</Reference>\n");
        }
        sb.append("   </SanctionsReferences>\n");
        sb.append("   <SourceDescription><Source name=\"").append(v > 1 && i % 70 == 1 ? "Official gazette " + v : "Official gazette")
                .append("\"/></SourceDescription>\n");
        sb.append("  </").append(tag).append(">\n");
    }

    private static String company(int i) {
        return COMPANY[i % COMPANY.length] + " " + i + " " + SUFFIX[i % SUFFIX.length];
    }

    // ------------------------------------------------------------------ other providers

    public static void csv(Path file, int records, int v) throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
            w.write("Reference;Full Name;Alias;Date of Birth;Nationality;Passport;Program;Type\n");
            for (int i = 1; i <= records; i++) {
                w.write("PW-" + i + ";" + FIRST[i % FIRST.length] + " " + LAST[i % LAST.length] + " " + i + ";\""
                        + LAST[i % LAST.length] + ", " + FIRST[i % FIRST.length] + "\";" + (1 + i % 28) + "/" + (1 + i % 12)
                        + "/" + (1950 + i % 50) + ";" + COUNTRY_NAMES[i % COUNTRY_NAMES.length] + ";X" + (500000 + i)
                        + ";Partner watchlist " + v + ";Individual\n");
            }
        }
    }

    public static void json(Path file, int records, int v) throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
            w.write("{\"generated\":\"2026-11-07\",\"records\":[\n");
            for (int i = 1; i <= records; i++) {
                w.write((i > 1 ? ",\n" : "") + "{\"uid\":\"PEP-" + i + "\",\"type\":\"person\",\"name\":\"" + FIRST[i % FIRST.length]
                        + " " + LAST[(i + 5) % LAST.length] + "\",\"aliases\":[\"" + FIRST[i % FIRST.length].charAt(0) + ". "
                        + LAST[(i + 5) % LAST.length] + "\"],\"dob\":\"" + (1950 + i % 50) + "-0" + (1 + i % 9) + "-1"
                        + (i % 9) + "\",\"citizenship\":[\"" + COUNTRIES[i % COUNTRIES.length] + "\"],\"position\":\"Minister "
                        + (i % 20) + "\",\"status\":\"active\",\"version\":" + v + "}");
            }
            w.write("\n]}\n");
        }
    }
}
