package com.bank.ingestion.domain;

/** Life of one received file. */
public enum BatchStatus {
    /** Claimed from the inbound folder or uploaded, waiting for a loader thread. */
    QUEUED,
    /** No list's file name pattern matches: stored, not loaded until assigned to a list. */
    UNMATCHED,
    /** Stage 1 running: every record stored raw. */
    LOADING,
    /** Stage 1 done, waiting for stage 2. */
    LOADED,
    /** Stage 1 done, the list has no approved mapping yet. */
    MAPPING_REVIEW,
    /** Stage 1 done, an earlier version of the same list is still open (not published or rejected). */
    WAITING,
    /** Stage 2 running: canonical records, quality checks, changes. */
    PROCESSING,
    /** New list version ready, waiting for validation and certification. */
    TO_VALIDATE,
    PUBLISHED,
    REJECTED,
    /** Same content (SHA-256) as the last file of the list: nothing to do. */
    DUPLICATE,
    FAILED;

    public boolean isFinal() {
        return this == PUBLISHED || this == REJECTED || this == DUPLICATE || this == FAILED;
    }
}
