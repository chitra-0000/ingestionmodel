package com.bank.ingestion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * ListHub: provider list files in, canonical versioned records out.
 *
 * Flow of one file:
 * inbound folder (or upload) -> batch -> stage 1: every record stored raw (gzip) + reference lists + field profile
 * -> stage 2: mapping rules (no XSLT) -> quality checks -> internal id -> change detection -> new list version
 * -> validate / certify / publish -> export files (CSV, XML) and subscriber API.
 *
 * Runs as "java -jar listhub.war" (embedded Tomcat) or in an external Tomcat 9 (SpringBootServletInitializer).
 */
@SpringBootApplication
@ConfigurationPropertiesScan
@EnableScheduling
public class ListHubApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(ListHubApplication.class, args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(ListHubApplication.class);
    }
}
