package com.bank.ingestion.service.export;

import com.bank.ingestion.config.ListHubProperties;
import com.bank.ingestion.domain.AttrType;
import com.bank.ingestion.domain.CanonicalRecord;
import com.bank.ingestion.domain.ListDef;
import com.bank.ingestion.repository.CanonicalRepository;
import com.bank.ingestion.repository.ExportRepository;
import com.bank.ingestion.repository.IdAllocator;
import com.bank.ingestion.repository.VersionRepository;
import com.bank.ingestion.service.raw.CsvParser;
import com.bank.ingestion.util.Json;
import com.bank.ingestion.util.Texts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UncheckedIOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.DigestOutputStream;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Export files of a published version, written to outbound/<list code>/v<version>/:
 * full CSV, full XML (every record valid in the version) and delta CSV (changes of the version).
 * Files are written to a temporary name and renamed when complete, so a reader never sees half a file.
 * A Firco format is one more writer here once its specification is known.
 */
@Service
public class ExportService {

    private static final Logger LOG = LoggerFactory.getLogger(ExportService.class);
    private static final XMLOutputFactory XML_OUT = XMLOutputFactory.newInstance();
    private static final List<String> FULL_HEADER = Arrays.asList("RGL_ID", "EXTERNAL_REF", "RECORD_TYPE", "PRIMARY_NAME",
            "ALIASES", "GENDER", "DATE_OF_BIRTH", "NATIONALITIES", "COUNTRIES", "ID_DOCUMENTS", "SANCTIONS_LISTS", "STATUS",
            "VALID_FROM_VERSION");
    private static final List<String> DELTA_HEADER = Arrays.asList("CHANGE", "RGL_ID", "EXTERNAL_REF", "RECORD_TYPE",
            "PRIMARY_NAME", "WHAT_CHANGED");

    private final CanonicalRepository canonical;
    private final VersionRepository versions;
    private final ExportRepository exports;
    private final IdAllocator ids;
    private final ListHubProperties props;

    public ExportService(CanonicalRepository canonical, VersionRepository versions, ExportRepository exports, IdAllocator ids,
                         ListHubProperties props) {
        this.canonical = canonical;
        this.versions = versions;
        this.exports = exports;
        this.ids = ids;
        this.props = props;
    }

    public List<ExportRepository.ExportFile> export(ListDef list, int version) throws IOException {
        Path dir = props.outboundDir().resolve(Texts.safeFileName(list.getListCode())).resolve("v" + version);
        Files.createDirectories(dir);
        exports.deleteVersion(list.getListId(), version);
        List<ExportRepository.ExportFile> out = new ArrayList<>();
        String base = Texts.safeFileName(list.getListCode()) + "_v" + version;
        String formats = list.getExportFormats() == null ? "CSV" : list.getExportFormats().toUpperCase(Locale.ROOT);
        if (formats.contains("CSV")) {
            out.add(fullCsv(list, version, dir.resolve(base + "_full.csv")));
            if (version > 1) {
                out.add(deltaCsv(list, version, dir.resolve(base + "_delta.csv")));
            }
        }
        if (formats.contains("XML")) {
            out.add(fullXml(list, version, dir.resolve(base + "_full.xml")));
        }
        LOG.info("List {} version {}: {} export files written to {}", list.getListCode(), version, out.size(), dir);
        return out;
    }

    private ExportRepository.ExportFile fullCsv(ListDef list, int version, Path target) throws IOException {
        long[] count = {0};
        Written w = write(target, out -> {
            try (Writer wr = new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8), 1 << 16)) {
                line(wr, FULL_HEADER);
                canonical.streamValid(list.getListId(), version, props.getFetchSize(), r -> {
                    CanonicalRecord c = Json.read(r.content, CanonicalRecord.class);
                    try {
                        line(wr, Arrays.asList(r.rglId, r.externalRef, r.recordType, r.primaryName,
                                String.join(" | ", c.plainValues(AttrType.ALIAS)), r.gender, r.dob, r.nationalities,
                                r.countries, r.idNumbers, r.listRefs, r.status, String.valueOf(r.validFrom)));
                    } catch (IOException e) {
                        throw new UncheckedIOException(e);
                    }
                    count[0]++;
                });
            }
        });
        return record(list, version, "CSV", "FULL", target, count[0], w);
    }

    private ExportRepository.ExportFile deltaCsv(ListDef list, int version, Path target) throws IOException {
        long[] count = {0};
        Written w = write(target, out -> {
            try (Writer wr = new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8), 1 << 16)) {
                line(wr, DELTA_HEADER);
                versions.streamChanges(list.getListId(), version, props.getFetchSize(), c -> {
                    try {
                        line(wr, Arrays.asList(c.changeType, c.rglId, c.externalRef, c.recordType, c.primaryName, c.summary));
                    } catch (IOException e) {
                        throw new UncheckedIOException(e);
                    }
                    count[0]++;
                });
            }
        });
        return record(list, version, "CSV", "DELTA", target, count[0], w);
    }

    private ExportRepository.ExportFile fullXml(ListDef list, int version, Path target) throws IOException {
        long[] count = {0};
        Written w = write(target, out -> {
            try {
                XMLStreamWriter x = XML_OUT.createXMLStreamWriter(out, "UTF-8");
                x.writeStartDocument("UTF-8", "1.0");
                x.writeStartElement("List");
                x.writeAttribute("code", list.getListCode());
                x.writeAttribute("name", list.getName());
                x.writeAttribute("provider", list.getProviderCode());
                x.writeAttribute("version", String.valueOf(version));
                x.writeAttribute("generatedAt", LocalDateTime.now().withNano(0).toString());
                canonical.streamValid(list.getListId(), version, props.getFetchSize(), r -> {
                    CanonicalRecord c = Json.read(r.content, CanonicalRecord.class);
                    try {
                        x.writeStartElement("Record");
                        x.writeAttribute("rglId", r.rglId);
                        if (r.externalRef != null) {
                            x.writeAttribute("externalRef", r.externalRef);
                        }
                        x.writeAttribute("type", r.recordType);
                        x.writeAttribute("validFrom", String.valueOf(r.validFrom));
                        for (CanonicalRecord.Attr a : c.getAttrs()) {
                            x.writeStartElement("Attr");
                            x.writeAttribute("type", a.getT());
                            if (a.getQ() != null) {
                                x.writeAttribute("qualifier", a.getQ());
                            }
                            x.writeCharacters(a.getV());
                            x.writeEndElement();
                        }
                        x.writeEndElement();
                    } catch (XMLStreamException e) {
                        throw new IllegalStateException(e);
                    }
                    count[0]++;
                });
                x.writeEndElement();
                x.writeEndDocument();
                x.close();
            } catch (XMLStreamException e) {
                throw new IOException("XML export failed", e);
            }
        });
        return record(list, version, "XML", "FULL", target, count[0], w);
    }

    // ------------------------------------------------------------------ helpers

    private interface Body {
        void write(OutputStream out) throws IOException;
    }

    private static final class Written {
        long size;
        String sha;
    }

    private static Written write(Path target, Body body) throws IOException {
        Path tmp = target.resolveSibling(target.getFileName() + ".part");
        MessageDigest sha = Texts.newSha256();
        try (OutputStream out = new DigestOutputStream(new BufferedOutputStream(Files.newOutputStream(tmp), 1 << 16), sha)) {
            body.write(out);
        } catch (UncheckedIOException e) {
            Files.deleteIfExists(tmp);
            throw e.getCause();
        } catch (IOException | RuntimeException e) {
            Files.deleteIfExists(tmp);
            throw e;
        }
        Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        Written w = new Written();
        w.size = Files.size(target);
        w.sha = Texts.toHex(sha.digest());
        return w;
    }

    private ExportRepository.ExportFile record(ListDef list, int version, String format, String kind, Path file, long count,
                                               Written w) {
        ExportRepository.ExportFile f = new ExportRepository.ExportFile();
        f.exportId = ids.nextRowId();
        f.listId = list.getListId();
        f.versionNo = version;
        f.format = format;
        f.kind = kind;
        f.fileName = file.getFileName().toString();
        f.filePath = file.toString();
        f.recordCount = count;
        f.sizeBytes = w.size;
        f.sha256 = w.sha;
        exports.insert(f);
        return f;
    }

    /** One CSV line; values that a spreadsheet would run as a formula are prefixed with ' (CSV injection). */
    private static void line(Writer w, List<String> values) throws IOException {
        List<String> safe = new ArrayList<>(values.size());
        for (String v : values) {
            if (v != null && !v.isEmpty() && "=+-@\t\r".indexOf(v.charAt(0)) >= 0) {
                safe.add("'" + v);
            } else {
                safe.add(v);
            }
        }
        StringBuilder sb = new StringBuilder(256);
        CsvParser.encode(safe, ',', sb);
        sb.append("\r\n");
        w.write(sb.toString());
    }
}
