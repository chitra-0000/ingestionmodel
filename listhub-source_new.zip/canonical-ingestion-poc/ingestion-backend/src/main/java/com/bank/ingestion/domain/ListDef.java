package com.bank.ingestion.domain;

import java.time.LocalDateTime;

/** A list: where its files come from, how records are identified and how versions are approved. */
public class ListDef {

    private long listId;
    private String listCode;
    private String name;
    private String providerCode;
    private String category;
    /** XML, CSV, JSON or AUTO. */
    private String fileFormat = "AUTO";
    /** File name pattern with "*" for the part that changes, e.g. s_xml_1158_158_*. */
    private String filePattern;
    /** Files whose name also matches this pattern are delta deliveries, e.g. *_d.xml. Others are full. */
    private String deltaPattern;
    /** Record element names (XML), comma separated; empty = detected from the file. */
    private String recordElements;
    private String idPrefix = "RGL";
    /** When the provider gives no external reference: canonical attributes forming the match key. */
    private String matchKeyAttrs;
    /** MANUAL: validate + certify. AUTO: published when the quality threshold is met. */
    private String workflow = "MANUAL";
    private String exportFormats = "CSV,XML";
    private double maxRejectPercent = 5;
    private boolean active = true;
    private String description;
    private String createdBy;
    private LocalDateTime createdAt;

    public long getListId() { return listId; }
    public void setListId(long listId) { this.listId = listId; }
    public String getListCode() { return listCode; }
    public void setListCode(String listCode) { this.listCode = listCode; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getProviderCode() { return providerCode; }
    public void setProviderCode(String providerCode) { this.providerCode = providerCode; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getFileFormat() { return fileFormat; }
    public void setFileFormat(String fileFormat) { this.fileFormat = fileFormat; }
    public String getFilePattern() { return filePattern; }
    public void setFilePattern(String filePattern) { this.filePattern = filePattern; }
    public String getDeltaPattern() { return deltaPattern; }
    public void setDeltaPattern(String deltaPattern) { this.deltaPattern = deltaPattern; }
    public String getRecordElements() { return recordElements; }
    public void setRecordElements(String recordElements) { this.recordElements = recordElements; }
    public String getIdPrefix() { return idPrefix; }
    public void setIdPrefix(String idPrefix) { this.idPrefix = idPrefix; }
    public String getMatchKeyAttrs() { return matchKeyAttrs; }
    public void setMatchKeyAttrs(String matchKeyAttrs) { this.matchKeyAttrs = matchKeyAttrs; }
    public String getWorkflow() { return workflow; }
    public void setWorkflow(String workflow) { this.workflow = workflow; }
    public String getExportFormats() { return exportFormats; }
    public void setExportFormats(String exportFormats) { this.exportFormats = exportFormats; }
    public double getMaxRejectPercent() { return maxRejectPercent; }
    public void setMaxRejectPercent(double maxRejectPercent) { this.maxRejectPercent = maxRejectPercent; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getCreatedBy() { return createdBy; }
    public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    @com.fasterxml.jackson.annotation.JsonIgnore
    public boolean isAutoWorkflow() {
        return "AUTO".equalsIgnoreCase(workflow);
    }
}
