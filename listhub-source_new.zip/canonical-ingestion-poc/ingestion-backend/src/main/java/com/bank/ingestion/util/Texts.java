package com.bank.ingestion.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;

/** Small string helpers shared across services. */
public final class Texts {

    private static final Pattern PROVIDER_CODE = Pattern.compile("^[A-Z][A-Z0-9_]{1,29}$");
    private static final Pattern LIST_CODE = Pattern.compile("^[A-Za-z0-9_-]{1,20}$");
    private static final Pattern MARKS = Pattern.compile("\\p{M}+");
    private static final Pattern SPACES = Pattern.compile("\\s+");
    private static final char[] HEX = "0123456789abcdef".toCharArray();

    private Texts() {
    }

    /** Provider code becomes part of folder names, so it is strictly whitelisted. */
    public static String requireProviderCode(String raw) {
        String code = raw == null ? "" : raw.trim().toUpperCase(Locale.ROOT);
        if (!PROVIDER_CODE.matcher(code).matches()) {
            throw ApiException.badRequest("Provider code must be 2-30 characters: letters, digits or underscore, starting with a letter");
        }
        return code;
    }

    /** List code becomes part of the internal id, file names and folder names: letters, digits, - and _ only. */
    public static String requireListCode(String raw) {
        String code = raw == null ? "" : raw.trim();
        if (!LIST_CODE.matcher(code).matches()) {
            throw ApiException.badRequest("List code must be 1-20 characters: letters, digits, - or _");
        }
        return code;
    }

    /**
     * File name safe to use inside our folders: the last path segment only, no "..", control or reserved
     * characters (Fortify: path manipulation).
     */
    public static String safeFileName(String raw) {
        String name = raw == null ? "" : raw.replace('\\', '/');
        int slash = name.lastIndexOf('/');
        if (slash >= 0) {
            name = name.substring(slash + 1);
        }
        StringBuilder sb = new StringBuilder(name.length());
        for (int i = 0; i < name.length() && sb.length() < 200; i++) {
            char c = name.charAt(i);
            sb.append(Character.isLetterOrDigit(c) || c == '.' || c == '_' || c == '-' ? c : '_');
        }
        String s = sb.toString();
        while (s.startsWith(".")) {
            s = s.substring(1);
        }
        return s.isEmpty() ? "file" : s;
    }

    /** Search form of a name: lower case, accents removed, single spaces. */
    public static String searchForm(String value) {
        if (value == null) {
            return "";
        }
        String s = Normalizer.normalize(value, Normalizer.Form.NFD);
        s = MARKS.matcher(s).replaceAll("");
        return SPACES.matcher(s.toLowerCase(Locale.ROOT)).replaceAll(" ").trim();
    }

    /** Escapes LIKE wildcards; the query uses ESCAPE '\\'. */
    public static String likeContains(String value) {
        StringBuilder sb = new StringBuilder("%");
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c == '%' || c == '_' || c == '\\') {
                sb.append('\\');
            }
            sb.append(c);
        }
        return sb.append('%').toString();
    }

    /** Log-forging protection (Fortify): strip CR/LF and other control characters from user-supplied text. */
    public static String forLog(String value) {
        if (value == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder(Math.min(value.length(), 200));
        for (int i = 0; i < value.length() && i < 200; i++) {
            char c = value.charAt(i);
            sb.append(Character.isISOControl(c) ? '_' : c);
        }
        return sb.toString();
    }

    /** Lower case, letters and digits only: "First_Name" and "first-name" both become "firstname". */
    public static String normaliseName(String value) {
        if (value == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                sb.append(Character.toLowerCase(c));
            }
        }
        return sb.toString();
    }

    public static String truncate(String value, int max) {
        if (value == null || value.length() <= max) {
            return value;
        }
        return value.substring(0, max);
    }

    public static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    public static String sha256(String value) {
        return toHex(newSha256().digest(value.getBytes(StandardCharsets.UTF_8)));
    }

    public static MessageDigest newSha256() {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    public static String toHex(byte[] bytes) {
        char[] out = new char[bytes.length * 2];
        for (int i = 0; i < bytes.length; i++) {
            int v = bytes[i] & 0xFF;
            out[i * 2] = HEX[v >>> 4];
            out[i * 2 + 1] = HEX[v & 0x0F];
        }
        return new String(out);
    }
}
