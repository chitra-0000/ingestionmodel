package com.bank.ingestion.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * How a provider record becomes a canonical record: one path rule per attribute (no XSLT).
 *
 * Path syntax, relative to the record element (XML), the row (CSV, column names) or the object (JSON):
 * <pre>
 *   NameDetails/Name[@NameType='Primary Name']/NameValue   element value (its own text, else its children's
 *                                                           texts joined, else its attribute values joined)
 *   CountryDetails/Country[@CountryType='Citizenship']/CountryValue/@Code
 *   @id                                                    attribute of the record element
 *   name()                                                 record element name (Person, Entity)
 *   *                                                      any element name in a step
 * </pre>
 * A predicate value matches the raw attribute value or its label in the file's reference list
 * (DateType="1" matches 'Date of Birth' when DateTypeList says 1 = Date of Birth).
 */
public class MappingRules {

    /** Path of the provider's own unique reference (e.g. @id); empty when the provider has none. */
    private String externalRef;
    /** Path of a per-record action (delta files): values in deleteValues mean "delete". */
    private String action;
    private List<String> deleteValues = new ArrayList<>();
    /** Path giving the record type (Person / Entity ...); name() = record element name. */
    private String recordType;
    private List<FieldRule> fields = new ArrayList<>();

    public static class FieldRule {
        private String attr;
        private String path;
        /** Reference list used to turn a code into its label (e.g. CountryList, SanctionsReferencesList). */
        private String decode;
        /** Fixed qualifier stored with the value (e.g. Passport No.). */
        private String qualifier;

        public FieldRule() {
        }

        public FieldRule(String attr, String path, String decode, String qualifier) {
            this.attr = attr;
            this.path = path;
            this.decode = decode;
            this.qualifier = qualifier;
        }

        public String getAttr() { return attr; }
        public void setAttr(String attr) { this.attr = attr; }
        public String getPath() { return path; }
        public void setPath(String path) { this.path = path; }
        public String getDecode() { return decode; }
        public void setDecode(String decode) { this.decode = decode; }
        public String getQualifier() { return qualifier; }
        public void setQualifier(String qualifier) { this.qualifier = qualifier; }
    }

    public String getExternalRef() { return externalRef; }
    public void setExternalRef(String externalRef) { this.externalRef = externalRef; }
    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }
    public List<String> getDeleteValues() { return deleteValues; }
    public void setDeleteValues(List<String> deleteValues) { this.deleteValues = deleteValues; }
    public String getRecordType() { return recordType; }
    public void setRecordType(String recordType) { this.recordType = recordType; }
    public List<FieldRule> getFields() { return fields; }
    public void setFields(List<FieldRule> fields) { this.fields = fields; }
}
