package com.bank.ingestion.repository;

import com.bank.ingestion.domain.ListVersion;
import com.bank.ingestion.domain.VersionStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** List versions and the record changes of each version. */
@Repository
public class VersionRepository {

    private static final String COLS = "LIST_ID, VERSION_NO, BATCH_ID, STATUS, DELIVERY, MAPPING_VERSION, FILE_RECORDS, "
            + "TOTAL_RECORDS, CREATED_COUNT, MODIFIED_COUNT, MINOR_COUNT, DELETED_COUNT, UNCHANGED_COUNT, REJECTED_COUNT, "
            + "FLAGGED_COUNT, ISSUES_JSON, CREATED_AT, VALIDATED_BY, VALIDATED_AT, CERTIFIED_BY, CERTIFIED_AT, PUBLISHED_BY, "
            + "PUBLISHED_AT, REJECTED_BY, REJECTED_AT, COMMENT_TEXT";

    private static final RowMapper<ListVersion> VERSION = (rs, i) -> {
        ListVersion v = new ListVersion();
        v.setListId(rs.getLong("LIST_ID"));
        v.setVersionNo(rs.getInt("VERSION_NO"));
        v.setBatchId(rs.getLong("BATCH_ID"));
        v.setStatus(VersionStatus.valueOf(rs.getString("STATUS")));
        v.setDelivery(rs.getString("DELIVERY"));
        v.setMappingVersion(Db.intOrNull(rs, "MAPPING_VERSION"));
        v.setFileRecords(rs.getLong("FILE_RECORDS"));
        v.setTotalRecords(rs.getLong("TOTAL_RECORDS"));
        v.setCreatedCount(rs.getLong("CREATED_COUNT"));
        v.setModifiedCount(rs.getLong("MODIFIED_COUNT"));
        v.setMinorCount(rs.getLong("MINOR_COUNT"));
        v.setDeletedCount(rs.getLong("DELETED_COUNT"));
        v.setUnchangedCount(rs.getLong("UNCHANGED_COUNT"));
        v.setRejectedCount(rs.getLong("REJECTED_COUNT"));
        v.setFlaggedCount(rs.getLong("FLAGGED_COUNT"));
        v.setIssuesJson(rs.getString("ISSUES_JSON"));
        v.setCreatedAt(Db.time(rs, "CREATED_AT"));
        v.setValidatedBy(rs.getString("VALIDATED_BY"));
        v.setValidatedAt(Db.time(rs, "VALIDATED_AT"));
        v.setCertifiedBy(rs.getString("CERTIFIED_BY"));
        v.setCertifiedAt(Db.time(rs, "CERTIFIED_AT"));
        v.setPublishedBy(rs.getString("PUBLISHED_BY"));
        v.setPublishedAt(Db.time(rs, "PUBLISHED_AT"));
        v.setRejectedBy(rs.getString("REJECTED_BY"));
        v.setRejectedAt(Db.time(rs, "REJECTED_AT"));
        v.setCommentText(rs.getString("COMMENT_TEXT"));
        return v;
    };

    /** One RECORD_CHANGE row. */
    public static final class Change {
        public String changeType;
        public long seqNo;
        public String rglId;
        public String externalRef;
        public String recordType;
        public String primaryName;
        public String country;
        public String summary;
        public String detailJson;
        public long batchId;
        public Long rawSeq;
        public int versionNo;
        public long listId;
    }

    private static final RowMapper<Change> CHANGE = (rs, i) -> {
        Change c = new Change();
        c.listId = rs.getLong("LIST_ID");
        c.versionNo = rs.getInt("VERSION_NO");
        c.changeType = rs.getString("CHANGE_TYPE");
        c.seqNo = rs.getLong("SEQ_NO");
        c.rglId = rs.getString("RGL_ID");
        c.externalRef = rs.getString("EXTERNAL_REF");
        c.recordType = rs.getString("RECORD_TYPE");
        c.primaryName = rs.getString("PRIMARY_NAME");
        c.country = rs.getString("COUNTRY");
        c.summary = rs.getString("SUMMARY");
        c.detailJson = rs.getString("DETAIL_JSON");
        c.batchId = rs.getLong("BATCH_ID");
        c.rawSeq = Db.longOrNull(rs, "RAW_SEQ");
        return c;
    };

    private static final String CHANGE_COLS = "LIST_ID, VERSION_NO, CHANGE_TYPE, SEQ_NO, RGL_ID, EXTERNAL_REF, RECORD_TYPE, "
            + "PRIMARY_NAME, COUNTRY, SUMMARY, DETAIL_JSON, BATCH_ID, RAW_SEQ";

    private final JdbcTemplate jdbc;
    private final NamedParameterJdbcTemplate named;

    public VersionRepository(JdbcTemplate jdbc, NamedParameterJdbcTemplate named) {
        this.jdbc = jdbc;
        this.named = named;
    }

    public int nextVersionNo(long listId) {
        Integer max = jdbc.queryForObject("SELECT MAX(VERSION_NO) FROM LIST_VERSION WHERE LIST_ID = ?", Integer.class, listId);
        return max == null ? 1 : max + 1;
    }

    public void insert(ListVersion v) {
        jdbc.update("INSERT INTO LIST_VERSION (LIST_ID, VERSION_NO, BATCH_ID, STATUS, DELIVERY, MAPPING_VERSION, CREATED_AT) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?)", v.getListId(), v.getVersionNo(), v.getBatchId(), v.getStatus().name(),
                v.getDelivery(), v.getMappingVersion(), Db.now());
    }

    public void updateCounts(ListVersion v) {
        jdbc.update("UPDATE LIST_VERSION SET FILE_RECORDS = ?, TOTAL_RECORDS = ?, CREATED_COUNT = ?, MODIFIED_COUNT = ?, "
                        + "MINOR_COUNT = ?, DELETED_COUNT = ?, UNCHANGED_COUNT = ?, REJECTED_COUNT = ?, FLAGGED_COUNT = ?, "
                        + "ISSUES_JSON = ?, STATUS = ? WHERE LIST_ID = ? AND VERSION_NO = ?",
                v.getFileRecords(), v.getTotalRecords(), v.getCreatedCount(), v.getModifiedCount(), v.getMinorCount(),
                v.getDeletedCount(), v.getUnchangedCount(), v.getRejectedCount(), v.getFlaggedCount(), v.getIssuesJson(),
                v.getStatus().name(), v.getListId(), v.getVersionNo());
    }

    public Optional<ListVersion> find(long listId, int versionNo) {
        return named.query("SELECT " + COLS + " FROM LIST_VERSION WHERE LIST_ID = :l AND VERSION_NO = :v",
                new MapSqlParameterSource("l", listId).addValue("v", versionNo), VERSION).stream().findFirst();
    }

    public List<ListVersion> byList(long listId) {
        return named.query("SELECT " + COLS + " FROM LIST_VERSION WHERE LIST_ID = :l ORDER BY VERSION_NO DESC",
                new MapSqlParameterSource("l", listId), VERSION);
    }

    /** The version waiting for validation or certification, if any (at most one per list). */
    public Optional<ListVersion> open(long listId) {
        return named.query("SELECT " + COLS + " FROM LIST_VERSION WHERE LIST_ID = :l AND STATUS IN ('TO_VALIDATE', 'VALIDATED') "
                + "ORDER BY VERSION_NO DESC", new MapSqlParameterSource("l", listId), VERSION).stream().findFirst();
    }

    public Optional<ListVersion> lastPublished(long listId) {
        return named.query("SELECT " + COLS + " FROM LIST_VERSION WHERE LIST_ID = :l AND STATUS = 'PUBLISHED' "
                + "ORDER BY VERSION_NO DESC FETCH FIRST 1 ROWS ONLY", new MapSqlParameterSource("l", listId), VERSION)
                .stream().findFirst();
    }

    /** The last version that is not rejected (base for the next version's totals). */
    public Optional<ListVersion> lastKept(long listId) {
        return named.query("SELECT " + COLS + " FROM LIST_VERSION WHERE LIST_ID = :l AND STATUS <> 'REJECTED' "
                + "ORDER BY VERSION_NO DESC FETCH FIRST 1 ROWS ONLY", new MapSqlParameterSource("l", listId), VERSION)
                .stream().findFirst();
    }

    public void validate(long listId, int v, String user, String comment) {
        jdbc.update("UPDATE LIST_VERSION SET STATUS = 'VALIDATED', VALIDATED_BY = ?, VALIDATED_AT = ?, COMMENT_TEXT = ? "
                + "WHERE LIST_ID = ? AND VERSION_NO = ?", user, Db.now(), Db.cut(comment, 1000), listId, v);
    }

    public void certifyAndPublish(long listId, int v, String user) {
        jdbc.update("UPDATE LIST_VERSION SET STATUS = 'PUBLISHED', CERTIFIED_BY = ?, CERTIFIED_AT = ?, PUBLISHED_BY = ?, "
                + "PUBLISHED_AT = ? WHERE LIST_ID = ? AND VERSION_NO = ?", user, Db.now(), user, Db.now(), listId, v);
    }

    public void reject(long listId, int v, String user, String comment) {
        jdbc.update("UPDATE LIST_VERSION SET STATUS = 'REJECTED', REJECTED_BY = ?, REJECTED_AT = ?, COMMENT_TEXT = ? "
                + "WHERE LIST_ID = ? AND VERSION_NO = ?", user, Db.now(), Db.cut(comment, 1000), listId, v);
    }

    public void delete(long listId, int v) {
        jdbc.update("DELETE FROM RECORD_CHANGE WHERE LIST_ID = ? AND VERSION_NO = ?", listId, v);
        jdbc.update("DELETE FROM LIST_VERSION WHERE LIST_ID = ? AND VERSION_NO = ?", listId, v);
    }

    // ------------------------------------------------------------------ changes

    public void insertChanges(long listId, int version, List<Change> changes) {
        if (changes.isEmpty()) {
            return;
        }
        jdbc.batchUpdate("INSERT INTO RECORD_CHANGE (" + CHANGE_COLS + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                changes, changes.size(), (PreparedStatement ps, Change c) -> {
                    ps.setLong(1, listId);
                    ps.setInt(2, version);
                    ps.setString(3, c.changeType);
                    ps.setLong(4, c.seqNo);
                    ps.setString(5, c.rglId);
                    ps.setString(6, Db.cut(c.externalRef, 200));
                    ps.setString(7, c.recordType);
                    ps.setString(8, Db.cut(c.primaryName, 500));
                    ps.setString(9, Db.cut(c.country, 100));
                    ps.setString(10, Db.cut(c.summary, 1000));
                    ps.setString(11, c.detailJson);
                    ps.setLong(12, c.batchId);
                    if (c.rawSeq == null) {
                        ps.setNull(13, Types.BIGINT);
                    } else {
                        ps.setLong(13, c.rawSeq);
                    }
                });
    }

    public void deleteChanges(long listId, int version) {
        jdbc.update("DELETE FROM RECORD_CHANGE WHERE LIST_ID = ? AND VERSION_NO = ?", listId, version);
    }

    /** Changes of one type in a version, filtered by name / id text, paged. */
    public List<Change> changes(long listId, int version, String type, String text, int offset, int size) {
        MapSqlParameterSource p = new MapSqlParameterSource("l", listId).addValue("v", version).addValue("t", type)
                .addValue("o", offset).addValue("s", size);
        return named.query("SELECT " + CHANGE_COLS + " FROM RECORD_CHANGE WHERE LIST_ID = :l AND VERSION_NO = :v "
                + "AND CHANGE_TYPE = :t" + textFilter(text, p) + " ORDER BY SEQ_NO OFFSET :o ROWS FETCH NEXT :s ROWS ONLY", p, CHANGE);
    }

    public long countChanges(long listId, int version, String type, String text) {
        MapSqlParameterSource p = new MapSqlParameterSource("l", listId).addValue("v", version).addValue("t", type);
        Long n = named.queryForObject("SELECT COUNT(*) FROM RECORD_CHANGE WHERE LIST_ID = :l AND VERSION_NO = :v "
                + "AND CHANGE_TYPE = :t" + textFilter(text, p), p, Long.class);
        return n == null ? 0 : n;
    }

    private static String textFilter(String text, MapSqlParameterSource p) {
        if (text == null || text.trim().isEmpty()) {
            return "";
        }
        p.addValue("q", com.bank.ingestion.util.Texts.likeContains(text.trim().toUpperCase(java.util.Locale.ROOT)));
        return " AND (UPPER(PRIMARY_NAME) LIKE :q ESCAPE '\\' OR UPPER(RGL_ID) LIKE :q ESCAPE '\\' "
                + "OR UPPER(EXTERNAL_REF) LIKE :q ESCAPE '\\')";
    }

    public Optional<Change> change(long listId, int version, String type, long seqNo) {
        return named.query("SELECT " + CHANGE_COLS + " FROM RECORD_CHANGE WHERE LIST_ID = :l AND VERSION_NO = :v "
                        + "AND CHANGE_TYPE = :t AND SEQ_NO = :s",
                new MapSqlParameterSource("l", listId).addValue("v", version).addValue("t", type).addValue("s", seqNo), CHANGE)
                .stream().findFirst();
    }

    /** Every change of an identity across versions, oldest first (history). */
    public List<Change> changesOf(String rglId) {
        return named.query("SELECT " + CHANGE_COLS + " FROM RECORD_CHANGE WHERE RGL_ID = :id ORDER BY VERSION_NO, CHANGE_TYPE",
                new MapSqlParameterSource("id", rglId), CHANGE);
    }

    /** Streams the changes of a version (delta export). */
    public void streamChanges(long listId, int version, int fetchSize, java.util.function.Consumer<Change> consumer) {
        jdbc.query(con -> {
            PreparedStatement ps = con.prepareStatement("SELECT " + CHANGE_COLS + " FROM RECORD_CHANGE WHERE LIST_ID = ? "
                    + "AND VERSION_NO = ? AND CHANGE_TYPE IN ('CREATED', 'MODIFIED', 'MINOR', 'DELETED') ORDER BY CHANGE_TYPE, SEQ_NO",
                    ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            ps.setFetchSize(fetchSize);
            ps.setLong(1, listId);
            ps.setInt(2, version);
            return ps;
        }, (ResultSet rs) -> {
            consumer.accept(CHANGE.mapRow(rs, 0));
        });
    }

    /** Rejected / flagged counts per issue code (version detail breakdown). */
    public Map<String, Long> countByType(long listId, int version) {
        Map<String, Long> out = new LinkedHashMap<>();
        jdbc.query("SELECT CHANGE_TYPE, COUNT(*) FROM RECORD_CHANGE WHERE LIST_ID = ? AND VERSION_NO = ? GROUP BY CHANGE_TYPE",
                (ResultSet rs) -> {
                    out.put(rs.getString(1), rs.getLong(2));
                }, listId, version);
        return out;
    }
}
