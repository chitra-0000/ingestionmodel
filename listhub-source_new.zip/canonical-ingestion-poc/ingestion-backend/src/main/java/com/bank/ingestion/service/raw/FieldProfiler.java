package com.bank.ingestion.service.raw;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Finds every field path of a file from a sample of its records, with counts and sample values.
 * Elements typed by an attribute (Name NameType="Primary Name", Date DateType="1") get one path per type,
 * written with the type's label when the file's reference list knows the code. The mapping screen and the
 * auto-mapper read this profile. Not thread-safe: one profiler per batch, fed by the reader thread.
 */
public final class FieldProfiler {

    private static final int MAX_SAMPLES = 3;
    private static final int MAX_VALUES = 60;
    private static final int MAX_TYPED_VALUES = 40;
    private static final int MAX_PATHS = 3000;
    private static final int MAX_GROUP_CHILDREN = 8;

    /** One profiled path. */
    public static final class Entry {
        private String path;
        private long occurs;
        private long recordsWith;
        private final Set<String> samples = new LinkedHashSet<>();
        private final Set<String> values = new LinkedHashSet<>();
        private String refList;

        public String getPath() { return path; }
        public long getOccurs() { return occurs; }
        public long getRecordsWith() { return recordsWith; }
        public List<String> getSamples() { return new ArrayList<>(samples); }
        public String getRefList() { return refList; }
    }

    private final Map<String, Entry> entries = new LinkedHashMap<>();
    /** prefix + element + type attribute -> distinct type values (to stop typing on free text). */
    private final Map<String, Set<String>> typedValues = new HashMap<>();
    private long records;

    public long records() {
        return records;
    }

    public void add(RNode record) {
        records++;
        Set<String> seen = new HashSet<>();
        for (int i = 0; i < record.attrNames().size(); i++) {
            note("@" + record.attrNames().get(i), record.attrValues().get(i), seen);
        }
        for (RNode c : record.children()) {
            walk(c, "", seen);
        }
        for (String p : seen) {
            entries.get(p).recordsWith++;
        }
    }

    private void walk(RNode n, String prefix, Set<String> seen) {
        String typeAttr = typeAttr(n, prefix);
        String step = typeAttr == null ? n.name() : n.name() + "[@" + typeAttr + "='" + n.attr(typeAttr).trim() + "']";
        String path = prefix.isEmpty() ? step : prefix + "/" + step;
        String text = n.text();
        if (text != null) {
            note(path, text, seen);
        } else if (n.hasChildren() && isGroup(n)) {
            note(path, n.value(), seen);
        } else if (!n.hasChildren() && n.attrNames().size() > 1 && typeAttr == null) {
            note(path, n.value(), seen);
        }
        for (int i = 0; i < n.attrNames().size(); i++) {
            String a = n.attrNames().get(i);
            if (!a.equals(typeAttr)) {
                note(path + "/@" + a, n.attrValues().get(i), seen);
            }
        }
        for (RNode c : n.children()) {
            walk(c, path, seen);
        }
    }

    /** First attribute named ...Type with a short value, while its distinct values stay few. */
    private String typeAttr(RNode n, String prefix) {
        for (int i = 0; i < n.attrNames().size(); i++) {
            String a = n.attrNames().get(i);
            String v = n.attrValues().get(i);
            if (a.toLowerCase(Locale.ROOT).endsWith("type") && v != null && !v.trim().isEmpty() && v.length() <= 60
                    && v.indexOf('\'') < 0) {
                Set<String> distinct = typedValues.computeIfAbsent(prefix + "/" + n.name() + "@" + a, k -> new HashSet<>());
                if (distinct.contains(v.trim()) || distinct.size() < MAX_TYPED_VALUES) {
                    distinct.add(v.trim());
                    return a;
                }
            }
        }
        return null;
    }

    /** An element whose few children are different leaves (NameValue = FirstName + Surname): its joined value counts. */
    private static boolean isGroup(RNode n) {
        if (n.children().size() < 2 || n.children().size() > MAX_GROUP_CHILDREN) {
            return false;
        }
        Set<String> names = new HashSet<>();
        for (RNode c : n.children()) {
            if (c.hasChildren() || !names.add(c.name())) {
                return false;
            }
        }
        return true;
    }

    private void note(String path, String value, Set<String> seen) {
        if (value == null || value.trim().isEmpty()) {
            return;
        }
        Entry e = entries.get(path);
        if (e == null) {
            if (entries.size() >= MAX_PATHS) {
                return;
            }
            e = new Entry();
            e.path = path;
            entries.put(path, e);
        }
        e.occurs++;
        seen.add(path);
        String v = value.trim();
        if (e.values.size() < MAX_VALUES) {
            e.values.add(v.length() > 200 ? v.substring(0, 200) : v);
        }
    }

    /**
     * Profile with the reference lists applied: typed paths written with labels (DateType='Date of Birth'),
     * and the reference list whose codes most values are (e.g. CountryValue/@Code -> CountryList).
     */
    public List<Entry> finish(RefTable refs) {
        Map<String, Entry> merged = new LinkedHashMap<>();
        for (Entry e : entries.values()) {
            String labelled = labelPath(e.path, refs);
            Entry m = merged.get(labelled);
            if (m == null) {
                m = new Entry();
                m.path = labelled;
                merged.put(labelled, m);
            }
            m.occurs += e.occurs;
            m.recordsWith += e.recordsWith;
            for (String v : e.values) {
                if (m.values.size() < MAX_VALUES) {
                    m.values.add(v);
                }
            }
        }
        for (Entry m : merged.values()) {
            m.refList = bestRefList(m.values, refs);
            for (String v : m.values) {
                if (m.samples.size() >= MAX_SAMPLES) {
                    break;
                }
                String label = m.refList == null ? null : refs.decode(m.refList, v);
                String s = label == null ? v : v + " = " + label;
                m.samples.add(s.length() > 80 ? s.substring(0, 80) + "..." : s);
            }
        }
        return new ArrayList<>(merged.values());
    }

    /** Replaces [@XType='code'] by [@XType='label'] when the file's reference list knows the code. */
    static String labelPath(String path, RefTable refs) {
        if (refs.isEmpty() || path.indexOf("[@") < 0) {
            return path;
        }
        StringBuilder out = new StringBuilder(path.length() + 20);
        int i = 0;
        while (i < path.length()) {
            int open = path.indexOf("[@", i);
            if (open < 0) {
                out.append(path, i, path.length());
                break;
            }
            int eq = path.indexOf("='", open);
            int close = path.indexOf("']", open);
            if (eq < 0 || close < 0 || eq > close) {
                out.append(path, i, path.length());
                break;
            }
            String attr = path.substring(open + 2, eq);
            String code = path.substring(eq + 2, close);
            String label = refs.decodeAttr(attr, code);
            out.append(path, i, eq + 2).append(label == null || label.indexOf('\'') >= 0 ? code : label).append("']");
            i = close + 2;
        }
        return out.toString();
    }

    private static String bestRefList(Set<String> values, RefTable refs) {
        if (values.isEmpty() || refs.isEmpty()) {
            return null;
        }
        String best = null;
        double bestShare = 0.79;
        for (String name : refs.names()) {
            Map<String, String> list = refs.list(name);
            int hits = 0;
            int sameAsLabel = 0;
            for (String v : values) {
                String label = list.get(v);
                if (label != null) {
                    hits++;
                    if (label.equalsIgnoreCase(v)) {
                        sameAsLabel++;
                    }
                }
            }
            double share = hits / (double) values.size();
            if (share > bestShare && sameAsLabel < hits) {
                bestShare = share;
                best = name;
            }
        }
        return best;
    }
}
