package com.bank.ingestion.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * The common record: same shape for every provider. Stored as JSON in CANONICAL_RECORD.CONTENT,
 * with the most searched values copied to columns.
 */
public class CanonicalRecord {

    private String recordType;
    private String externalRef;
    private List<Attr> attrs = new ArrayList<>();
    /** Delta files: true when the provider says the record is deleted. Not stored. */
    @JsonIgnore
    private boolean deleteAction;
    /** Quality findings of this record. Not part of the content. */
    @JsonIgnore
    private final List<Issue> issues = new ArrayList<>();

    /** One value of an attribute. t = type, v = value, q = qualifier (e.g. "Passport No."). */
    public static class Attr {
        private String t;
        private String v;
        private String q;

        public Attr() {
        }

        public Attr(String t, String v, String q) {
            this.t = t;
            this.v = v;
            this.q = q;
        }

        public String getT() { return t; }
        public void setT(String t) { this.t = t; }
        public String getV() { return v; }
        public void setV(String v) { this.v = v; }
        public String getQ() { return q; }
        public void setQ(String q) { this.q = q; }
    }

    /** A quality finding. REJECT = not loaded, FLAG = loaded with a warning. */
    public static class Issue {
        private final String code;
        private final String severity;
        private final String field;
        private final String value;
        private final String message;

        public Issue(String code, String severity, String field, String value, String message) {
            this.code = code;
            this.severity = severity;
            this.field = field;
            this.value = value;
            this.message = message;
        }

        public String getCode() { return code; }
        public String getSeverity() { return severity; }
        public String getField() { return field; }
        public String getValue() { return value; }
        public String getMessage() { return message; }
        public boolean isReject() { return "REJECT".equals(severity); }
    }

    public void add(AttrType type, String value, String qualifier) {
        if (value == null) {
            return;
        }
        String v = value.trim();
        if (v.isEmpty()) {
            return;
        }
        for (Attr a : attrs) {
            if (a.t.equals(type.name()) && a.v.equals(v) && eq(a.q, qualifier)) {
                return;
            }
        }
        attrs.add(new Attr(type.name(), v, qualifier == null || qualifier.trim().isEmpty() ? null : qualifier.trim()));
    }

    public String first(AttrType type) {
        for (Attr a : attrs) {
            if (a.t.equals(type.name())) {
                return a.v;
            }
        }
        return null;
    }

    public List<String> values(AttrType type) {
        List<String> out = new ArrayList<>();
        for (Attr a : attrs) {
            if (a.t.equals(type.name())) {
                out.add(a.q == null ? a.v : a.v + " (" + a.q + ")");
            }
        }
        return out;
    }

    public List<String> plainValues(AttrType type) {
        List<String> out = new ArrayList<>();
        for (Attr a : attrs) {
            if (a.t.equals(type.name())) {
                out.add(a.v);
            }
        }
        return out;
    }

    public void removeAll(AttrType type) {
        attrs.removeIf(a -> a.t.equals(type.name()));
    }

    /** Stable order (attribute order of AttrType, then value), so equal records give equal JSON and hash. */
    public void sort() {
        Collections.sort(attrs, Comparator.<Attr>comparingInt(a -> ordinal(a.t))
                .thenComparing(a -> a.v)
                .thenComparing(a -> a.q == null ? "" : a.q));
    }

    /** Same record without the given (minor) attributes: used for the "main" hash. */
    public CanonicalRecord without(Set<String> types) {
        CanonicalRecord c = new CanonicalRecord();
        c.recordType = recordType;
        c.externalRef = externalRef;
        for (Attr a : attrs) {
            if (!types.contains(a.t)) {
                c.attrs.add(a);
            }
        }
        return c;
    }

    public void issue(String code, String severity, String field, String value, String message) {
        issues.add(new Issue(code, severity, field, value, message));
    }

    @JsonIgnore
    public boolean isRejected() {
        for (Issue i : issues) {
            if (i.isReject()) {
                return true;
            }
        }
        return false;
    }

    @JsonIgnore
    public boolean isFlagged() {
        return !issues.isEmpty() && !isRejected();
    }

    private static int ordinal(String t) {
        try {
            return AttrType.valueOf(t).ordinal();
        } catch (IllegalArgumentException e) {
            return Integer.MAX_VALUE;
        }
    }

    private static boolean eq(String a, String b) {
        return a == null ? b == null || b.trim().isEmpty() : a.equals(b == null ? null : b.trim());
    }

    public String getRecordType() { return recordType; }
    public void setRecordType(String recordType) { this.recordType = recordType; }
    public String getExternalRef() { return externalRef; }
    public void setExternalRef(String externalRef) { this.externalRef = externalRef; }
    public List<Attr> getAttrs() { return attrs; }
    public void setAttrs(List<Attr> attrs) { this.attrs = attrs; }
    public boolean isDeleteAction() { return deleteAction; }
    public void setDeleteAction(boolean deleteAction) { this.deleteAction = deleteAction; }
    public List<Issue> getIssues() { return issues; }
}
