package com.bank.ingestion.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.zip.Deflater;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/** Gzip of one raw record. Fastest level: records are small and the load is CPU-bound. */
public final class Gzip {

    /** A decompressed record larger than this is refused (zip-bomb guard). */
    private static final int MAX_RECORD_BYTES = 64 * 1024 * 1024;

    private Gzip() {
    }

    public static byte[] compress(byte[] data) {
        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(64, data.length / 4));
        try (GZIPOutputStream gz = new FastGzip(out)) {
            gz.write(data);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        return out.toByteArray();
    }

    public static byte[] decompress(byte[] gz) {
        try (InputStream in = new GZIPInputStream(new ByteArrayInputStream(gz), 8192)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(256, gz.length * 4));
            byte[] buf = new byte[8192];
            int n;
            int total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > MAX_RECORD_BYTES) {
                    throw new IllegalStateException("Raw record larger than " + MAX_RECORD_BYTES + " bytes");
                }
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    private static final class FastGzip extends GZIPOutputStream {
        FastGzip(ByteArrayOutputStream out) throws IOException {
            super(out, 4096);
            def.setLevel(Deflater.BEST_SPEED);
        }
    }
}
