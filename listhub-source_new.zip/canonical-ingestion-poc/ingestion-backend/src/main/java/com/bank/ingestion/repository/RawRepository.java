package com.bank.ingestion.repository;

import com.bank.ingestion.service.raw.FieldProfiler;
import com.bank.ingestion.service.raw.RefTable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Stage 1 tables: raw records, reference lists, field profile. */
@Repository
public class RawRepository {

    /** One raw record ready to insert. */
    public static final class RawRow {
        public final long seq;
        public final String element;
        public final String key;
        public final byte[] gz;

        public RawRow(long seq, String element, String key, byte[] gz) {
            this.seq = seq;
            this.element = element;
            this.key = key;
            this.gz = gz;
        }
    }

    /** Called for each raw record read by the stage 2 reader. */
    public interface RawConsumer {
        void accept(long seq, byte[] gz) throws SQLException;
    }

    private final JdbcTemplate jdbc;
    private final NamedParameterJdbcTemplate named;

    public RawRepository(JdbcTemplate jdbc, NamedParameterJdbcTemplate named) {
        this.jdbc = jdbc;
        this.named = named;
    }

    public void insertRecords(long batchId, List<RawRow> rows) {
        jdbc.batchUpdate("INSERT INTO RAW_RECORD (BATCH_ID, SEQ_NO, ELEMENT, RECORD_KEY, PAYLOAD) VALUES (?, ?, ?, ?, ?)",
                rows, rows.size(), (PreparedStatement ps, RawRow r) -> {
                    ps.setLong(1, batchId);
                    ps.setLong(2, r.seq);
                    ps.setString(3, Db.cut(r.element, 100));
                    ps.setString(4, Db.cut(r.key, 200));
                    ps.setBytes(5, r.gz);
                });
    }

    public void insertRefs(long batchId, Map<String, Map<String, String>> refs) {
        List<Object[]> rows = new ArrayList<>();
        for (Map.Entry<String, Map<String, String>> l : refs.entrySet()) {
            for (Map.Entry<String, String> e : l.getValue().entrySet()) {
                rows.add(new Object[]{batchId, Db.cut(l.getKey(), 100), Db.cut(e.getKey(), 200), Db.cut(e.getValue(), 1000)});
            }
        }
        for (int i = 0; i < rows.size(); i += 5000) {
            jdbc.batchUpdate("INSERT INTO RAW_REF (BATCH_ID, LIST_NAME, CODE, LABEL) VALUES (?, ?, ?, ?)",
                    rows.subList(i, Math.min(rows.size(), i + 5000)));
        }
    }

    public RefTable refs(long batchId) {
        Map<String, Map<String, String>> lists = new LinkedHashMap<>();
        jdbc.query("SELECT LIST_NAME, CODE, LABEL FROM RAW_REF WHERE BATCH_ID = ?", (ResultSet rs) -> {
            lists.computeIfAbsent(rs.getString(1), k -> new HashMap<>()).put(rs.getString(2), rs.getString(3));
        }, batchId);
        return new RefTable(lists);
    }

    /** Reference lists with their sizes. */
    public Map<String, Integer> refListSizes(long batchId) {
        Map<String, Integer> out = new LinkedHashMap<>();
        jdbc.query("SELECT LIST_NAME, COUNT(*) FROM RAW_REF WHERE BATCH_ID = ? GROUP BY LIST_NAME ORDER BY LIST_NAME",
                (ResultSet rs) -> {
                    out.put(rs.getString(1), rs.getInt(2));
                }, batchId);
        return out;
    }

    public void insertProfile(long batchId, List<FieldProfiler.Entry> entries) {
        List<Object[]> rows = new ArrayList<>();
        for (FieldProfiler.Entry e : entries) {
            rows.add(new Object[]{batchId, Db.cut(e.getPath(), 1000), null, e.getOccurs(), e.getRecordsWith(),
                    Db.cut(String.join(" | ", e.getSamples()), 1000), Db.cut(e.getRefList(), 100)});
        }
        if (!rows.isEmpty()) {
            jdbc.batchUpdate("INSERT INTO RAW_FIELD_PROFILE (BATCH_ID, PATH, LABEL, OCCURS, RECORDS_WITH, SAMPLES, REF_LIST) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)", rows);
        }
    }

    /** Profile rows: path, occurs, recordsWith, samples, refList. */
    public List<Map<String, Object>> profile(long batchId) {
        return named.query("SELECT PATH, OCCURS, RECORDS_WITH, SAMPLES, REF_LIST FROM RAW_FIELD_PROFILE WHERE BATCH_ID = :b",
                new MapSqlParameterSource("b", batchId), (rs, i) -> {
                    Map<String, Object> m = new LinkedHashMap<>();
                    m.put("path", rs.getString(1));
                    m.put("occurs", rs.getLong(2));
                    m.put("recordsWith", rs.getLong(3));
                    m.put("samples", rs.getString(4));
                    m.put("refList", rs.getString(5));
                    return m;
                });
    }

    /** Streams the raw records of a batch in file order (stage 2 reader). */
    public void stream(long batchId, int fetchSize, RawConsumer consumer) {
        jdbc.query(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "SELECT SEQ_NO, PAYLOAD FROM RAW_RECORD WHERE BATCH_ID = ? ORDER BY SEQ_NO",
                    ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            ps.setFetchSize(fetchSize);
            ps.setLong(1, batchId);
            return ps;
        }, (ResultSet rs) -> {
            consumer.accept(rs.getLong(1), rs.getBytes(2));
        });
    }

    /** First records of a batch (mapping preview). */
    public List<Object[]> first(long batchId, int max) {
        return named.query("SELECT SEQ_NO, PAYLOAD FROM RAW_RECORD WHERE BATCH_ID = :b ORDER BY SEQ_NO FETCH FIRST :m ROWS ONLY",
                new MapSqlParameterSource("b", batchId).addValue("m", max),
                (rs, i) -> new Object[]{rs.getLong(1), rs.getBytes(2)});
    }

    public Optional<byte[]> payload(long batchId, long seq) {
        return named.query("SELECT PAYLOAD FROM RAW_RECORD WHERE BATCH_ID = :b AND SEQ_NO = :s",
                new MapSqlParameterSource("b", batchId).addValue("s", seq), (rs, i) -> rs.getBytes(1)).stream().findFirst();
    }

    /** Removes a batch's raw rows in chunks (no long transaction, no huge undo on Oracle). */
    public long deleteBatch(long batchId) {
        long total = 0;
        int n;
        do {
            n = jdbc.update("DELETE FROM RAW_RECORD WHERE BATCH_ID = ? AND SEQ_NO IN "
                    + "(SELECT SEQ_NO FROM RAW_RECORD WHERE BATCH_ID = ? FETCH FIRST 50000 ROWS ONLY)", batchId, batchId);
            total += n;
        } while (n > 0);
        jdbc.update("DELETE FROM RAW_REF WHERE BATCH_ID = ?", batchId);
        jdbc.update("DELETE FROM RAW_FIELD_PROFILE WHERE BATCH_ID = ?", batchId);
        return total;
    }

    public void deleteProfileAndRefs(long batchId) {
        jdbc.update("DELETE FROM RAW_REF WHERE BATCH_ID = ?", batchId);
        jdbc.update("DELETE FROM RAW_FIELD_PROFILE WHERE BATCH_ID = ?", batchId);
    }

}
