package com.bank.ingestion.service.canonical;

import com.bank.ingestion.domain.AttrType;
import com.bank.ingestion.domain.CanonicalRecord;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/** Field-by-field difference of two versions of a record (version detail and history screens). */
public final class RecordDiff {

    /** One changed attribute. */
    public static final class Item {
        private final String field;
        private final String before;
        private final String after;

        public Item(String field, String before, String after) {
            this.field = field;
            this.before = before;
            this.after = after;
        }

        public String getField() { return field; }
        public String getBefore() { return before; }
        public String getAfter() { return after; }
    }

    private RecordDiff() {
    }

    public static List<Item> diff(CanonicalRecord before, CanonicalRecord after) {
        Map<String, TreeSet<String>> b = group(before);
        Map<String, TreeSet<String>> a = group(after);
        List<Item> out = new ArrayList<>();
        if (!eq(before.getRecordType(), after.getRecordType())) {
            out.add(new Item("Record type", before.getRecordType(), after.getRecordType()));
        }
        for (AttrType t : AttrType.values()) {
            TreeSet<String> bv = b.get(t.name());
            TreeSet<String> av = a.get(t.name());
            if (bv == null && av == null) {
                continue;
            }
            if (bv == null || av == null || !bv.equals(av)) {
                out.add(new Item(t.label(), bv == null ? null : String.join("; ", bv), av == null ? null : String.join("; ", av)));
            }
        }
        return out;
    }

    /** "Aliases added; Nationality changed" (at most three parts). */
    public static String summary(List<Item> items) {
        List<String> parts = new ArrayList<>();
        for (Item i : items) {
            if (parts.size() == 3) {
                parts.add("and " + (items.size() - 3) + " more");
                break;
            }
            String what = i.before == null ? "added" : i.after == null ? "removed" : "changed";
            parts.add(i.field + " " + what);
        }
        return parts.isEmpty() ? "No visible change" : String.join("; ", parts);
    }

    private static Map<String, TreeSet<String>> group(CanonicalRecord r) {
        Map<String, TreeSet<String>> m = new LinkedHashMap<>();
        for (CanonicalRecord.Attr a : r.getAttrs()) {
            m.computeIfAbsent(a.getT(), k -> new TreeSet<>()).add(a.getQ() == null ? a.getV() : a.getV() + " (" + a.getQ() + ")");
        }
        return m;
    }

    private static boolean eq(String x, String y) {
        return x == null ? y == null : x.equals(y);
    }
}
