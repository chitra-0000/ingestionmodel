package com.bank.ingestion.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** 64-bit content hashes (first 8 bytes of SHA-256), kept as 16 hex characters. */
public final class Hashes {

    private Hashes() {
    }

    public static long hash64(String text) {
        MessageDigest md = Texts.newSha256();
        byte[] d = md.digest(text.getBytes(StandardCharsets.UTF_8));
        long h = 0;
        for (int i = 0; i < 8; i++) {
            h = (h << 8) | (d[i] & 0xFFL);
        }
        return h;
    }

    public static String hex(long h) {
        String s = Long.toHexString(h);
        StringBuilder sb = new StringBuilder(16);
        for (int i = s.length(); i < 16; i++) {
            sb.append('0');
        }
        return sb.append(s).toString();
    }

    public static long parse(String hex) {
        return hex == null || hex.isEmpty() ? 0L : Long.parseUnsignedLong(hex, 16);
    }
}
