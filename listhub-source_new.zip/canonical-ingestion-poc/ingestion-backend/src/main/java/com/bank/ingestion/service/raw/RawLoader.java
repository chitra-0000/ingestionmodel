package com.bank.ingestion.service.raw;

import com.bank.ingestion.config.ListHubProperties;
import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.domain.Layout;
import com.bank.ingestion.domain.ListDef;
import com.bank.ingestion.repository.RawRepository;
import com.bank.ingestion.service.batch.Progress;
import com.bank.ingestion.util.Gzip;
import com.bank.ingestion.util.Texts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Stage 1: stores every record of a file exactly as received.
 *
 * One reader thread streams the file and cuts it into records; N worker threads gzip the records and insert
 * them in JDBC batches. A bounded queue between them keeps memory flat whatever the file size. The reference
 * lists of the file and a profile of its fields (first records) are stored at the end.
 */
@Service
public class RawLoader {

    private static final Logger LOG = LoggerFactory.getLogger(RawLoader.class);
    private static final List<RawItem> POISON = Collections.emptyList();

    /** Result of stage 1. */
    public static final class Result {
        public String format;
        public Layout layout;
        public String sha256;
        public long records;
        public long refs;
        public int refLists;
        public int profilePaths;
    }

    private static final class RawItem {
        final long seq;
        final String element;
        final String key;
        final byte[] bytes;

        RawItem(long seq, String element, String key, byte[] bytes) {
            this.seq = seq;
            this.element = element;
            this.key = key;
            this.bytes = bytes;
        }
    }

    private final RawRepository raw;
    private final ListHubProperties props;
    private final Progress progress;

    public RawLoader(RawRepository raw, ListHubProperties props, Progress progress) {
        this.raw = raw;
        this.props = props;
        this.progress = progress;
    }

    /**
     * @param previous layout of the list's previous file (XML record elements are reused, so a small delta file
     *                 is cut the same way as the full files), or null
     */
    public Result load(long batchId, ListDef list, Path file, Layout previous) throws IOException, InterruptedException {
        Result result = new Result();
        long size = Files.size(file);
        FileFormat format = FileFormat.of(list == null ? null : list.getFileFormat());
        if (format == FileFormat.AUTO) {
            try (InputStream in = Files.newInputStream(file)) {
                format = RawFileReader.sniff(in);
            }
        }
        result.format = format.name();
        Layout layout;
        if (format == FileFormat.XML && configuredElements(list).isEmpty() && previous != null
                && FileFormat.XML.name().equals(previous.getFormat()) && !previous.getRecordElements().isEmpty()) {
            layout = new Layout();
            layout.setFormat(format.name());
            layout.setRecordElements(new ArrayList<>(previous.getRecordElements()));
            layout.setRecordParent(previous.getRecordParent());
        } else if (format == FileFormat.XML) {
            try (InputStream in = Files.newInputStream(file)) {
                layout = RawFileReader.detectXml(in, configuredElements(list));
            }
        } else {
            layout = new Layout();
            layout.setFormat(format.name());
        }

        Progress.Item live = progress.start(batchId, "Raw load", size);
        int workers = props.effectiveWorkersPerFile();
        int chunkSize = Math.max(100, props.getChunkSize());
        BlockingQueue<List<RawItem>> queue = new ArrayBlockingQueue<>(workers * 4);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        AtomicLong inserted = new AtomicLong();
        ExecutorService pool = Executors.newFixedThreadPool(workers, r -> {
            Thread t = new Thread(r, "raw-" + batchId);
            t.setDaemon(true);
            return t;
        });
        for (int i = 0; i < workers; i++) {
            pool.execute(() -> writeLoop(batchId, queue, failure, inserted));
        }

        Map<String, Map<String, String>> refs = new LinkedHashMap<>();
        List<byte[]> profileSample = new ArrayList<>();
        int profileMax = Math.max(0, props.getProfileRecords());
        MessageDigest sha = Texts.newSha256();
        long count = 0;
        try (InputStream in = new Counting(new DigestInputStream(Files.newInputStream(file), sha), live)) {
            ChunkingSink sink = new ChunkingSink(queue, chunkSize, failure, refs, profileSample, profileMax);
            switch (format) {
                case XML:
                    count = RawFileReader.readXml(in, layout, sink);
                    break;
                case CSV:
                    count = RawFileReader.readCsv(in, layout, sink);
                    break;
                case JSON:
                    count = RawFileReader.readJson(in, layout, sink);
                    break;
                default:
                    throw new IOException("Unsupported format " + format);
            }
            sink.flush();
        } catch (IOException | RuntimeException e) {
            failure.compareAndSet(null, e);
        } finally {
            for (int i = 0; i < workers; i++) {
                queue.put(POISON);
            }
            pool.shutdown();
            if (!pool.awaitTermination(6, TimeUnit.HOURS)) {
                pool.shutdownNow();
            }
            progress.end(batchId);
        }
        Throwable f = failure.get();
        if (f != null) {
            if (f instanceof IOException) {
                throw (IOException) f;
            }
            throw new IOException("Raw load failed: " + f.getMessage(), f);
        }

        raw.insertRefs(batchId, refs);
        RefTable refTable = new RefTable(refs);
        FieldProfiler profiler = new FieldProfiler();
        RecordParser parser = new RecordParser(layout);
        for (byte[] p : profileSample) {
            try {
                profiler.add(parser.parse(p));
            } catch (IOException e) {
                LOG.debug("Batch {}: a sample record could not be profiled: {}", batchId, e.getMessage());
            }
        }
        List<FieldProfiler.Entry> profile = profiler.finish(refTable);
        raw.insertProfile(batchId, profile);

        layout.setRefLists(new ArrayList<>(refs.keySet()));
        result.layout = layout;
        result.sha256 = Texts.toHex(sha.digest());
        result.records = count;
        result.refLists = refs.size();
        long refCount = 0;
        for (Map<String, String> l : refs.values()) {
            refCount += l.size();
        }
        result.refs = refCount;
        result.profilePaths = profile.size();
        LOG.info("Batch {}: stage 1 stored {} records, {} reference lists ({} codes), {} field paths", batchId, count,
                refs.size(), refCount, profile.size());
        return result;
    }

    private static List<String> configuredElements(ListDef list) {
        if (list == null || list.getRecordElements() == null || list.getRecordElements().trim().isEmpty()) {
            return Collections.emptyList();
        }
        List<String> out = new ArrayList<>();
        for (String s : Arrays.asList(list.getRecordElements().split(","))) {
            if (!s.trim().isEmpty()) {
                out.add(s.trim());
            }
        }
        return out;
    }

    private void writeLoop(long batchId, BlockingQueue<List<RawItem>> queue, AtomicReference<Throwable> failure,
                           AtomicLong inserted) {
        int batchSize = Math.max(100, props.getBatchSize());
        List<RawRepository.RawRow> pending = new ArrayList<>(batchSize);
        try {
            while (true) {
                List<RawItem> chunk = queue.take();
                if (chunk == POISON) {
                    break;
                }
                if (failure.get() != null) {
                    // keep draining so the reader never blocks on a full queue
                    continue;
                }
                try {
                    for (RawItem it : chunk) {
                        pending.add(new RawRepository.RawRow(it.seq, it.element, it.key, Gzip.compress(it.bytes)));
                    }
                    if (pending.size() >= batchSize) {
                        raw.insertRecords(batchId, pending);
                        inserted.addAndGet(pending.size());
                        pending.clear();
                    }
                } catch (RuntimeException e) {
                    failure.compareAndSet(null, e);
                    LOG.error("Batch {}: raw insert failed", batchId, e);
                }
            }
            if (!pending.isEmpty() && failure.get() == null) {
                raw.insertRecords(batchId, pending);
                inserted.addAndGet(pending.size());
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            failure.compareAndSet(null, e);
        } catch (RuntimeException e) {
            failure.compareAndSet(null, e);
            LOG.error("Batch {}: raw insert failed", batchId, e);
        }
    }

    /** Collects records into chunks for the workers; keeps refs and the profile sample. */
    private static final class ChunkingSink implements RawFileReader.Sink {
        private final BlockingQueue<List<RawItem>> queue;
        private final int chunkSize;
        private final AtomicReference<Throwable> failure;
        private final Map<String, Map<String, String>> refs;
        private final List<byte[]> profileSample;
        private final int profileMax;
        private List<RawItem> chunk;
        private long seq;

        ChunkingSink(BlockingQueue<List<RawItem>> queue, int chunkSize, AtomicReference<Throwable> failure,
                     Map<String, Map<String, String>> refs, List<byte[]> profileSample, int profileMax) {
            this.queue = queue;
            this.chunkSize = chunkSize;
            this.failure = failure;
            this.refs = refs;
            this.profileSample = profileSample;
            this.profileMax = profileMax;
            this.chunk = new ArrayList<>(chunkSize);
        }

        @Override
        public void record(String element, String key, byte[] payload) {
            if (failure.get() != null) {
                throw new IllegalStateException("Stopped: a worker failed", failure.get());
            }
            seq++;
            if (profileSample.size() < profileMax) {
                profileSample.add(payload);
            }
            chunk.add(new RawItem(seq, element, key, payload));
            if (chunk.size() >= chunkSize) {
                flush();
            }
        }

        @Override
        public void ref(String listName, String code, String label) {
            refs.computeIfAbsent(listName, k -> new HashMap<>()).put(code, label);
        }

        void flush() {
            if (chunk.isEmpty()) {
                return;
            }
            try {
                queue.put(chunk);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException("Interrupted", e);
            }
            chunk = new ArrayList<>(chunkSize);
        }
    }

    /** Counts bytes read for the progress bar. */
    private static final class Counting extends FilterInputStream {
        private final Progress.Item live;

        Counting(InputStream in, Progress.Item live) {
            super(in);
            this.live = live;
        }

        @Override
        public int read() throws IOException {
            int b = super.read();
            if (b >= 0) {
                live.add(1);
            }
            return b;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            int n = super.read(b, off, len);
            if (n > 0) {
                live.add(n);
            }
            return n;
        }
    }
}
