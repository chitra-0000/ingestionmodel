package com.bank.ingestion.domain;

import java.time.LocalDateTime;

/** One received file and everything done with it. */
public class Batch {

    private long batchId;
    private Long listId;
    private String fileName;
    private long fileSize;
    private long fileMtime;
    /** FOLDER or UPLOAD. */
    private String source;
    private String fileFormat;
    /** FULL or DELTA. */
    private String delivery;
    private String sha256;
    private BatchStatus status;
    private String message;
    private Integer versionNo;
    private long recordCount;
    private long refCount;
    private String workPath;
    private String layoutJson;
    private String submittedBy;
    private LocalDateTime receivedAt;
    private LocalDateTime startedAt;
    private LocalDateTime finishedAt;

    public long getBatchId() { return batchId; }
    public void setBatchId(long batchId) { this.batchId = batchId; }
    public Long getListId() { return listId; }
    public void setListId(Long listId) { this.listId = listId; }
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
    public long getFileSize() { return fileSize; }
    public void setFileSize(long fileSize) { this.fileSize = fileSize; }
    public long getFileMtime() { return fileMtime; }
    public void setFileMtime(long fileMtime) { this.fileMtime = fileMtime; }
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
    public String getFileFormat() { return fileFormat; }
    public void setFileFormat(String fileFormat) { this.fileFormat = fileFormat; }
    public String getDelivery() { return delivery; }
    public void setDelivery(String delivery) { this.delivery = delivery; }
    public String getSha256() { return sha256; }
    public void setSha256(String sha256) { this.sha256 = sha256; }
    public BatchStatus getStatus() { return status; }
    public void setStatus(BatchStatus status) { this.status = status; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public Integer getVersionNo() { return versionNo; }
    public void setVersionNo(Integer versionNo) { this.versionNo = versionNo; }
    public long getRecordCount() { return recordCount; }
    public void setRecordCount(long recordCount) { this.recordCount = recordCount; }
    public long getRefCount() { return refCount; }
    public void setRefCount(long refCount) { this.refCount = refCount; }
    public String getWorkPath() { return workPath; }
    public void setWorkPath(String workPath) { this.workPath = workPath; }
    public String getLayoutJson() { return layoutJson; }
    public void setLayoutJson(String layoutJson) { this.layoutJson = layoutJson; }
    public String getSubmittedBy() { return submittedBy; }
    public void setSubmittedBy(String submittedBy) { this.submittedBy = submittedBy; }
    public LocalDateTime getReceivedAt() { return receivedAt; }
    public void setReceivedAt(LocalDateTime receivedAt) { this.receivedAt = receivedAt; }
    public LocalDateTime getStartedAt() { return startedAt; }
    public void setStartedAt(LocalDateTime startedAt) { this.startedAt = startedAt; }
    public LocalDateTime getFinishedAt() { return finishedAt; }
    public void setFinishedAt(LocalDateTime finishedAt) { this.finishedAt = finishedAt; }
}
