package com.bank.ingestion.service.version;

import com.bank.ingestion.domain.AttrType;
import com.bank.ingestion.domain.Batch;
import com.bank.ingestion.domain.CanonicalRecord;
import com.bank.ingestion.domain.Layout;
import com.bank.ingestion.domain.ListDef;
import com.bank.ingestion.repository.BatchRepository;
import com.bank.ingestion.repository.CanonicalRepository;
import com.bank.ingestion.repository.ListRepository;
import com.bank.ingestion.repository.RawRepository;
import com.bank.ingestion.repository.VersionRepository;
import com.bank.ingestion.service.raw.RNode;
import com.bank.ingestion.service.raw.RecordParser;
import com.bank.ingestion.util.ApiException;
import com.bank.ingestion.util.Gzip;
import com.bank.ingestion.util.Json;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Records for the screens: detail, history across versions, search, the raw record as received. */
@Service
public class RecordService {

    private final CanonicalRepository canonical;
    private final VersionRepository versions;
    private final ListRepository lists;
    private final BatchRepository batches;
    private final RawRepository raw;

    public RecordService(CanonicalRepository canonical, VersionRepository versions, ListRepository lists,
                         BatchRepository batches, RawRepository raw) {
        this.canonical = canonical;
        this.versions = versions;
        this.lists = lists;
        this.batches = batches;
        this.raw = raw;
    }

    /** The record as valid in a version (latest row when version is null). */
    public Map<String, Object> detail(String rglId, Integer version) {
        CanonicalRepository.Row row = canonical.rowAt(rglId, version)
                .orElseThrow(() -> ApiException.notFound("No record " + rglId + (version == null ? "" : " in version " + version)));
        return rowView(row);
    }

    public Map<String, Object> rowView(CanonicalRepository.Row row) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("rglId", row.rglId);
        m.put("listId", row.listId);
        lists.find(row.listId).ifPresent(l -> {
            m.put("listCode", l.getListCode());
            m.put("listName", l.getName());
        });
        m.put("externalRef", row.externalRef);
        m.put("recordType", row.recordType);
        m.put("primaryName", row.primaryName);
        m.put("validFrom", row.validFrom);
        m.put("validTo", row.validTo);
        m.put("batchId", row.batchId);
        m.put("rawSeq", row.rawSeq);
        m.put("flags", row.dqFlags);
        m.put("attributes", grouped(Json.read(row.content, CanonicalRecord.class)));
        return m;
    }

    /** Attributes grouped by type, with labels, in the canonical order. */
    public static List<Map<String, Object>> grouped(CanonicalRecord c) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (AttrType t : AttrType.values()) {
            List<String> v = c.values(t);
            if (!v.isEmpty()) {
                Map<String, Object> a = new LinkedHashMap<>();
                a.put("type", t.name());
                a.put("label", t.label());
                a.put("values", v);
                out.add(a);
            }
        }
        return out;
    }

    /** Every version of a record: periods of validity and what changed each time. */
    public Map<String, Object> history(String rglId) {
        List<CanonicalRepository.Row> rows = canonical.history(rglId);
        if (rows.isEmpty()) {
            throw ApiException.notFound("No record " + rglId);
        }
        CanonicalRepository.Row last = rows.get(rows.size() - 1);
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("current", rowView(last));
        out.put("active", last.validTo == null);
        List<Map<String, Object>> periods = new ArrayList<>();
        for (CanonicalRepository.Row r : rows) {
            Map<String, Object> p = new LinkedHashMap<>();
            p.put("validFrom", r.validFrom);
            p.put("validTo", r.validTo);
            p.put("primaryName", r.primaryName);
            p.put("attributes", grouped(Json.read(r.content, CanonicalRecord.class)));
            periods.add(p);
        }
        out.put("periods", periods);
        List<Map<String, Object>> events = new ArrayList<>();
        for (VersionRepository.Change c : versions.changesOf(rglId)) {
            events.add(changeView(c));
        }
        out.put("events", events);
        return out;
    }

    public Map<String, Object> changeView(VersionRepository.Change c) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("version", c.versionNo);
        m.put("type", c.changeType);
        m.put("seq", c.seqNo);
        m.put("rglId", c.rglId);
        m.put("externalRef", c.externalRef);
        m.put("recordType", c.recordType);
        m.put("primaryName", c.primaryName);
        m.put("country", c.country);
        m.put("summary", c.summary);
        m.put("batchId", c.batchId);
        m.put("rawSeq", c.rawSeq);
        if (c.detailJson != null) {
            m.put("detail", Json.read(c.detailJson, Map.class));
        }
        return m;
    }

    /** One change of a version with the record it concerns (version detail drill-down). */
    public Map<String, Object> changeDetail(long listId, int version, String type, long seq) {
        VersionRepository.Change c = versions.change(listId, version, type, seq)
                .orElseThrow(() -> ApiException.notFound("Change not found"));
        Map<String, Object> m = changeView(c);
        if (c.rglId != null) {
            int at = "DELETED".equals(type) ? version - 1 : version;
            canonical.rowAt(c.rglId, at).ifPresent(r -> m.put("record", rowView(r)));
        }
        return m;
    }

    public List<Map<String, Object>> search(String text, Long listId, String recordType, boolean includeDeleted) {
        List<Map<String, Object>> out = new ArrayList<>();
        Map<Long, ListDef> byId = new LinkedHashMap<>();
        for (ListDef l : lists.findAll()) {
            byId.put(l.getListId(), l);
        }
        for (CanonicalRepository.Row r : canonical.search(text, listId, recordType, includeDeleted, 200)) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("rglId", r.rglId);
            m.put("externalRef", r.externalRef);
            m.put("recordType", r.recordType);
            m.put("primaryName", r.primaryName);
            m.put("dob", r.dob);
            m.put("countries", r.countries);
            m.put("listRefs", r.listRefs);
            m.put("validFrom", r.validFrom);
            m.put("validTo", r.validTo);
            m.put("active", r.validTo == null);
            ListDef l = byId.get(r.listId);
            m.put("listId", r.listId);
            m.put("listCode", l == null ? null : l.getListCode());
            m.put("listName", l == null ? null : l.getName());
            out.add(m);
        }
        return out;
    }

    /** The raw record exactly as stored in stage 1, indented for reading. */
    public Map<String, Object> rawRecord(long batchId, long seq) {
        Batch b = batches.find(batchId).orElseThrow(() -> ApiException.notFound("Batch not found"));
        Optional<byte[]> gz = raw.payload(batchId, seq);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("batchId", batchId);
        m.put("seq", seq);
        m.put("fileName", b.getFileName());
        if (!gz.isPresent()) {
            m.put("available", false);
            m.put("text", "The raw records of this file were removed by housekeeping (retention period).");
            return m;
        }
        byte[] bytes = Gzip.decompress(gz.get());
        Layout layout = b.getLayoutJson() == null ? new Layout() : Json.read(b.getLayoutJson(), Layout.class);
        m.put("available", true);
        m.put("format", layout.getFormat());
        m.put("text", pretty(layout, bytes));
        return m;
    }

    private static String pretty(Layout layout, byte[] bytes) {
        try {
            if ("XML".equals(layout.getFormat())) {
                StringBuilder sb = new StringBuilder();
                xml(new RecordParser(layout).parse(bytes), 0, sb);
                return sb.toString();
            }
            if ("JSON".equals(layout.getFormat())) {
                return Json.MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(Json.MAPPER.readTree(bytes));
            }
            if ("CSV".equals(layout.getFormat())) {
                RNode row = new RecordParser(layout).parse(bytes);
                StringBuilder sb = new StringBuilder();
                for (RNode c : row.children()) {
                    sb.append(c.name()).append(": ").append(c.text() == null ? "" : c.text()).append('\n');
                }
                return sb.toString();
            }
        } catch (IOException | RuntimeException e) {
            // fall back to the stored text
        }
        return RecordParser.text(bytes);
    }

    private static void xml(RNode n, int depth, StringBuilder sb) {
        for (int i = 0; i < depth; i++) {
            sb.append("  ");
        }
        sb.append('<').append(n.name());
        for (int i = 0; i < n.attrNames().size(); i++) {
            sb.append(' ').append(n.attrNames().get(i)).append("=\"").append(esc(n.attrValues().get(i))).append('"');
        }
        String t = n.text();
        if (!n.hasChildren() && t == null) {
            sb.append("/>\n");
            return;
        }
        sb.append('>');
        if (!n.hasChildren()) {
            sb.append(esc(t)).append("</").append(n.name()).append(">\n");
            return;
        }
        sb.append('\n');
        if (t != null) {
            for (int i = 0; i <= depth; i++) {
                sb.append("  ");
            }
            sb.append(esc(t)).append('\n');
        }
        for (RNode c : n.children()) {
            xml(c, depth + 1, sb);
        }
        for (int i = 0; i < depth; i++) {
            sb.append("  ");
        }
        sb.append("</").append(n.name()).append(">\n");
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
