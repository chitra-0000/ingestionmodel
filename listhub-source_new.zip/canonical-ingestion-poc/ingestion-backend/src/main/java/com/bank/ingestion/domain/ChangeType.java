package com.bank.ingestion.domain;

/** What happened to a record in a version. FLAGGED comes in addition to the other types. */
public enum ChangeType {
    CREATED, MODIFIED, MINOR, DELETED, REJECTED, FLAGGED
}
