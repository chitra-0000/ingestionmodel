package com.bank.ingestion.domain;

import java.time.LocalDateTime;

/** One version of a list, with its change counts and approval trail. */
public class ListVersion {

    private long listId;
    private int versionNo;
    private long batchId;
    private VersionStatus status;
    private String delivery;
    private Integer mappingVersion;
    private long fileRecords;
    private long totalRecords;
    private long createdCount;
    private long modifiedCount;
    private long minorCount;
    private long deletedCount;
    private long unchangedCount;
    private long rejectedCount;
    private long flaggedCount;
    private String issuesJson;
    private LocalDateTime createdAt;
    private String validatedBy;
    private LocalDateTime validatedAt;
    private String certifiedBy;
    private LocalDateTime certifiedAt;
    private String publishedBy;
    private LocalDateTime publishedAt;
    private String rejectedBy;
    private LocalDateTime rejectedAt;
    private String commentText;

    public long getListId() { return listId; }
    public void setListId(long listId) { this.listId = listId; }
    public int getVersionNo() { return versionNo; }
    public void setVersionNo(int versionNo) { this.versionNo = versionNo; }
    public long getBatchId() { return batchId; }
    public void setBatchId(long batchId) { this.batchId = batchId; }
    public VersionStatus getStatus() { return status; }
    public void setStatus(VersionStatus status) { this.status = status; }
    public String getDelivery() { return delivery; }
    public void setDelivery(String delivery) { this.delivery = delivery; }
    public Integer getMappingVersion() { return mappingVersion; }
    public void setMappingVersion(Integer mappingVersion) { this.mappingVersion = mappingVersion; }
    public long getFileRecords() { return fileRecords; }
    public void setFileRecords(long fileRecords) { this.fileRecords = fileRecords; }
    public long getTotalRecords() { return totalRecords; }
    public void setTotalRecords(long totalRecords) { this.totalRecords = totalRecords; }
    public long getCreatedCount() { return createdCount; }
    public void setCreatedCount(long createdCount) { this.createdCount = createdCount; }
    public long getModifiedCount() { return modifiedCount; }
    public void setModifiedCount(long modifiedCount) { this.modifiedCount = modifiedCount; }
    public long getMinorCount() { return minorCount; }
    public void setMinorCount(long minorCount) { this.minorCount = minorCount; }
    public long getDeletedCount() { return deletedCount; }
    public void setDeletedCount(long deletedCount) { this.deletedCount = deletedCount; }
    public long getUnchangedCount() { return unchangedCount; }
    public void setUnchangedCount(long unchangedCount) { this.unchangedCount = unchangedCount; }
    public long getRejectedCount() { return rejectedCount; }
    public void setRejectedCount(long rejectedCount) { this.rejectedCount = rejectedCount; }
    public long getFlaggedCount() { return flaggedCount; }
    public void setFlaggedCount(long flaggedCount) { this.flaggedCount = flaggedCount; }
    public String getIssuesJson() { return issuesJson; }
    public void setIssuesJson(String issuesJson) { this.issuesJson = issuesJson; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public String getValidatedBy() { return validatedBy; }
    public void setValidatedBy(String validatedBy) { this.validatedBy = validatedBy; }
    public LocalDateTime getValidatedAt() { return validatedAt; }
    public void setValidatedAt(LocalDateTime validatedAt) { this.validatedAt = validatedAt; }
    public String getCertifiedBy() { return certifiedBy; }
    public void setCertifiedBy(String certifiedBy) { this.certifiedBy = certifiedBy; }
    public LocalDateTime getCertifiedAt() { return certifiedAt; }
    public void setCertifiedAt(LocalDateTime certifiedAt) { this.certifiedAt = certifiedAt; }
    public String getPublishedBy() { return publishedBy; }
    public void setPublishedBy(String publishedBy) { this.publishedBy = publishedBy; }
    public LocalDateTime getPublishedAt() { return publishedAt; }
    public void setPublishedAt(LocalDateTime publishedAt) { this.publishedAt = publishedAt; }
    public String getRejectedBy() { return rejectedBy; }
    public void setRejectedBy(String rejectedBy) { this.rejectedBy = rejectedBy; }
    public LocalDateTime getRejectedAt() { return rejectedAt; }
    public void setRejectedAt(LocalDateTime rejectedAt) { this.rejectedAt = rejectedAt; }
    public String getCommentText() { return commentText; }
    public void setCommentText(String commentText) { this.commentText = commentText; }
}
