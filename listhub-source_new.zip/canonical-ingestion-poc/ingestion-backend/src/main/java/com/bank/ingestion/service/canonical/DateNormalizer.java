package com.bank.ingestion.service.canonical;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Converts the date formats providers actually send into ISO text, keeping partial dates:
 * 1970-05-12, 12/05/1970, 12-05-1970, 12.05.1970, 19700512, 12 May 1970, 12-MAY-1970, May 12, 1970,
 * 1970-05-12T10:00:00Z, 1970-05, 05/1970, 1970. Regex first, so invalid input never costs an exception
 * on the happy path. Thread-safe.
 */
public final class DateNormalizer {

    private static final int MIN_YEAR = 1800;
    private static final int MAX_YEAR = 2100;

    private static final Pattern ISO = Pattern.compile("^(\\d{4})-(\\d{1,2})-(\\d{1,2})(?:[T ].*)?$");
    private static final Pattern COMPACT = Pattern.compile("^(\\d{4})(\\d{2})(\\d{2})$");
    private static final Pattern NUMERIC = Pattern.compile("^(\\d{1,2})[/.-](\\d{1,2})[/.-](\\d{4})$");
    private static final Pattern DAY_MONTH_NAME = Pattern.compile("^(\\d{1,2})[ -]([A-Za-z]{3,9})[ ,-]+(\\d{4})$");
    private static final Pattern MONTH_NAME_DAY = Pattern.compile("^([A-Za-z]{3,9}) (\\d{1,2}),? (\\d{4})$");
    private static final Pattern YEAR_MONTH = Pattern.compile("^(\\d{4})[-/](\\d{1,2})$");
    private static final Pattern MONTH_YEAR = Pattern.compile("^(\\d{1,2})[/.-](\\d{4})$");
    private static final Pattern YEAR = Pattern.compile("^(\\d{4})$");

    private static final Map<String, Integer> MONTHS = new HashMap<>();

    static {
        String[] names = {"january", "february", "march", "april", "may", "june", "july", "august", "september",
                "october", "november", "december"};
        for (int i = 0; i < names.length; i++) {
            MONTHS.put(names[i], i + 1);
            MONTHS.put(names[i].substring(0, 3), i + 1);
        }
        MONTHS.put("sept", 9);
    }

    private final boolean dayFirst;

    /** @param slashDateOrder "DMY" (default) or "MDY" for ambiguous numeric dates such as 03/04/1970 */
    public DateNormalizer(String slashDateOrder) {
        this.dayFirst = !"MDY".equalsIgnoreCase(slashDateOrder);
    }

    /** @return ISO text (YYYY-MM-DD, YYYY-MM or YYYY), or null when the value is not a valid date */
    public String normalise(String raw) {
        if (raw == null) {
            return null;
        }
        String v = raw.trim();
        Matcher m = ISO.matcher(v);
        if (m.matches()) {
            return full(m.group(1), m.group(2), m.group(3));
        }
        m = COMPACT.matcher(v);
        if (m.matches()) {
            return full(m.group(1), m.group(2), m.group(3));
        }
        m = NUMERIC.matcher(v);
        if (m.matches()) {
            return numeric(m.group(1), m.group(2), m.group(3));
        }
        m = DAY_MONTH_NAME.matcher(v);
        if (m.matches()) {
            Integer month = MONTHS.get(m.group(2).toLowerCase(Locale.ROOT));
            return month == null ? null : full(m.group(3), month.toString(), m.group(1));
        }
        m = MONTH_NAME_DAY.matcher(v);
        if (m.matches()) {
            Integer month = MONTHS.get(m.group(1).toLowerCase(Locale.ROOT));
            return month == null ? null : full(m.group(3), month.toString(), m.group(2));
        }
        m = YEAR_MONTH.matcher(v);
        if (m.matches()) {
            return yearMonth(m.group(1), m.group(2));
        }
        m = MONTH_YEAR.matcher(v);
        if (m.matches()) {
            return yearMonth(m.group(2), m.group(1));
        }
        m = YEAR.matcher(v);
        if (m.matches()) {
            int y = Integer.parseInt(m.group(1));
            return y >= MIN_YEAR && y <= MAX_YEAR ? m.group(1) : null;
        }
        return null;
    }

    private String numeric(String a, String b, String year) {
        int first = Integer.parseInt(a);
        int second = Integer.parseInt(b);
        boolean useDayFirst = dayFirst;
        if (first > 12 && second <= 12) {
            useDayFirst = true;
        } else if (second > 12 && first <= 12) {
            useDayFirst = false;
        }
        return useDayFirst ? full(year, b, a) : full(year, a, b);
    }

    private static String full(String y, String m, String d) {
        try {
            int year = Integer.parseInt(y);
            if (year < MIN_YEAR || year > MAX_YEAR) {
                return null;
            }
            return LocalDate.of(year, Integer.parseInt(m), Integer.parseInt(d)).toString();
        } catch (DateTimeException | NumberFormatException e) {
            return null;
        }
    }

    private static String yearMonth(String y, String m) {
        try {
            int year = Integer.parseInt(y);
            if (year < MIN_YEAR || year > MAX_YEAR) {
                return null;
            }
            return YearMonth.of(year, Integer.parseInt(m)).toString();
        } catch (DateTimeException | NumberFormatException e) {
            return null;
        }
    }

    /** True when the ISO (possibly partial) date lies after the given day. */
    public static boolean isAfter(String iso, LocalDate day) {
        if (iso.length() == 10) {
            return LocalDate.parse(iso).isAfter(day);
        }
        if (iso.length() == 7) {
            return YearMonth.parse(iso).isAfter(YearMonth.from(day));
        }
        return Integer.parseInt(iso) > day.getYear();
    }

    /** Year part of an ISO (possibly partial) date. */
    public static int year(String iso) {
        return Integer.parseInt(iso.substring(0, 4));
    }
}
