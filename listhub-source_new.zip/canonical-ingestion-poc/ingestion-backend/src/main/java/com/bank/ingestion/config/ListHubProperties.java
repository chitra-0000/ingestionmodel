package com.bank.ingestion.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

/** All "listhub.*" settings (application.properties). */
@ConfigurationProperties(prefix = "listhub")
public class ListHubProperties {

    private String baseDir = "./listhub-data";
    private final Inbound inbound = new Inbound();
    private final Admin admin = new Admin();
    private int parallelFiles;
    private int workersPerFile;
    private int batchSize = 5000;
    private int chunkSize = 1000;
    private int fetchSize = 5000;
    private int idDigits = 10;
    private String minorAttrs = "SOURCE,NOTE,LAST_UPDATED,URL";
    private String slashDateOrder = "DMY";
    private int profileRecords = 5000;
    private int rawRetentionDays = 30;
    private int maxApiPageSize = 5000;
    private String allowedOrigin = "http://localhost:4200";

    public static class Inbound {
        private boolean enabled = true;
        private long pollMs = 30000;
        private long stableMs = 20000;

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public long getPollMs() { return pollMs; }
        public void setPollMs(long pollMs) { this.pollMs = pollMs; }
        public long getStableMs() { return stableMs; }
        public void setStableMs(long stableMs) { this.stableMs = stableMs; }
    }

    public static class Admin {
        private String username = "admin";
        private String password = "";

        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
    }

    // ------------------------------------------------------------------ derived values

    public Path base() { return Paths.get(baseDir).toAbsolutePath().normalize(); }
    public Path inboundDir() { return base().resolve("inbound"); }
    public Path workDir() { return base().resolve("work"); }
    public Path archiveDir() { return base().resolve("archive"); }
    public Path errorDir() { return base().resolve("error"); }
    public Path outboundDir() { return base().resolve("outbound"); }

    /** Files loaded at the same time: from the property, or cores / 2 (1 to 3). */
    public int effectiveParallelFiles() {
        if (parallelFiles > 0) {
            return parallelFiles;
        }
        return Math.max(1, Math.min(3, Runtime.getRuntime().availableProcessors() / 2));
    }

    /** Worker threads per file: from the property, or cores - 1 (2 to 6). */
    public int effectiveWorkersPerFile() {
        if (workersPerFile > 0) {
            return workersPerFile;
        }
        return Math.max(2, Math.min(6, Runtime.getRuntime().availableProcessors() - 1));
    }

    public Set<String> minorAttrSet() {
        if (minorAttrs == null || minorAttrs.trim().isEmpty()) {
            return Collections.emptySet();
        }
        Set<String> s = new LinkedHashSet<>();
        for (String a : Arrays.asList(minorAttrs.split(","))) {
            if (!a.trim().isEmpty()) {
                s.add(a.trim().toUpperCase(Locale.ROOT));
            }
        }
        return s;
    }

    // ------------------------------------------------------------------ accessors

    public String getBaseDir() { return baseDir; }
    public void setBaseDir(String baseDir) { this.baseDir = baseDir; }
    public Inbound getInbound() { return inbound; }
    public Admin getAdmin() { return admin; }
    public int getParallelFiles() { return parallelFiles; }
    public void setParallelFiles(int parallelFiles) { this.parallelFiles = parallelFiles; }
    public int getWorkersPerFile() { return workersPerFile; }
    public void setWorkersPerFile(int workersPerFile) { this.workersPerFile = workersPerFile; }
    public int getBatchSize() { return batchSize; }
    public void setBatchSize(int batchSize) { this.batchSize = batchSize; }
    public int getChunkSize() { return chunkSize; }
    public void setChunkSize(int chunkSize) { this.chunkSize = chunkSize; }
    public int getFetchSize() { return fetchSize; }
    public void setFetchSize(int fetchSize) { this.fetchSize = fetchSize; }
    public int getIdDigits() { return idDigits; }
    public void setIdDigits(int idDigits) { this.idDigits = idDigits; }
    public String getMinorAttrs() { return minorAttrs; }
    public void setMinorAttrs(String minorAttrs) { this.minorAttrs = minorAttrs; }
    public String getSlashDateOrder() { return slashDateOrder; }
    public void setSlashDateOrder(String slashDateOrder) { this.slashDateOrder = slashDateOrder; }
    public int getProfileRecords() { return profileRecords; }
    public void setProfileRecords(int profileRecords) { this.profileRecords = profileRecords; }
    public int getRawRetentionDays() { return rawRetentionDays; }
    public void setRawRetentionDays(int rawRetentionDays) { this.rawRetentionDays = rawRetentionDays; }
    public int getMaxApiPageSize() { return maxApiPageSize; }
    public void setMaxApiPageSize(int maxApiPageSize) { this.maxApiPageSize = maxApiPageSize; }
    public String getAllowedOrigin() { return allowedOrigin; }
    public void setAllowedOrigin(String allowedOrigin) { this.allowedOrigin = allowedOrigin; }
}
