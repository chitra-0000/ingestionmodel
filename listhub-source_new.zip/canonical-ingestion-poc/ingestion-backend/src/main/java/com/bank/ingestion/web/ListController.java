package com.bank.ingestion.web;

import com.bank.ingestion.domain.Batch;
import com.bank.ingestion.domain.ListDef;
import com.bank.ingestion.domain.ListVersion;
import com.bank.ingestion.domain.MappingRules;
import com.bank.ingestion.repository.CanonicalRepository;
import com.bank.ingestion.repository.VersionRepository;
import com.bank.ingestion.service.admin.ListService;
import com.bank.ingestion.service.batch.BatchService;
import com.bank.ingestion.service.canonical.MappingService;
import com.bank.ingestion.repository.ListRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Lists, their versions and their mapping. */
@RestController
@RequestMapping("/api/lists")
public class ListController {

    private final ListService lists;
    private final ListRepository listRepo;
    private final VersionRepository versions;
    private final CanonicalRepository canonical;
    private final MappingService mappings;
    private final BatchService batches;

    public ListController(ListService lists, ListRepository listRepo, VersionRepository versions, CanonicalRepository canonical,
                          MappingService mappings, BatchService batches) {
        this.lists = lists;
        this.listRepo = listRepo;
        this.versions = versions;
        this.canonical = canonical;
        this.mappings = mappings;
        this.batches = batches;
    }

    @GetMapping
    @PreAuthorize(Roles.VIEW)
    public List<Map<String, Object>> all() {
        Map<Long, Long> counts = canonical.openCounts();
        List<Map<String, Object>> out = new ArrayList<>();
        for (ListDef l : listRepo.findAll()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("list", l);
            m.put("records", counts.getOrDefault(l.getListId(), 0L));
            List<ListVersion> v = versions.byList(l.getListId());
            m.put("lastVersion", v.isEmpty() ? null : v.get(0));
            Optional<ListVersion> pub = versions.lastPublished(l.getListId());
            m.put("publishedVersion", pub.map(ListVersion::getVersionNo).orElse(null));
            m.put("mappingApproved", mappings.approved(l.getListId()).isPresent());
            out.add(m);
        }
        return out;
    }

    @GetMapping("/{id}")
    @PreAuthorize(Roles.VIEW)
    public ListDef one(@PathVariable long id) {
        return lists.get(id);
    }

    @PostMapping
    @PreAuthorize(Roles.ADMIN)
    public ListDef create(@RequestBody ListDef body, Authentication auth) {
        return lists.create(body, auth.getName());
    }

    @PutMapping("/{id}")
    @PreAuthorize(Roles.ADMIN)
    public ListDef update(@PathVariable long id, @RequestBody ListDef body) {
        return lists.update(id, body);
    }

    @GetMapping("/{id}/versions")
    @PreAuthorize(Roles.VIEW)
    public List<ListVersion> versions(@PathVariable long id) {
        lists.get(id);
        return versions.byList(id);
    }

    @GetMapping("/{id}/batches")
    @PreAuthorize(Roles.VIEW)
    public List<Batch> batches(@PathVariable long id) {
        return batches.latest(id, 100);
    }

    /** Which list would receive a file with this name (pattern test on the screen). */
    @GetMapping("/route")
    @PreAuthorize(Roles.VIEW)
    public Map<String, Object> route(@RequestParam String fileName) {
        Map<String, Object> m = new LinkedHashMap<>();
        Optional<ListDef> l = lists.route(fileName);
        m.put("fileName", fileName);
        m.put("list", l.orElse(null));
        m.put("delivery", l.map(x -> ListService.delivery(x, fileName)).orElse(null));
        return m;
    }

    // ------------------------------------------------------------------ mapping

    @GetMapping("/{id}/mapping")
    @PreAuthorize(Roles.VIEW)
    public Map<String, Object> mapping(@PathVariable long id) {
        lists.get(id);
        return mappings.view(id);
    }

    @PostMapping("/{id}/mapping/propose")
    @PreAuthorize(Roles.OPERATE)
    public MappingRules propose(@PathVariable long id, Authentication auth) {
        lists.get(id);
        return mappings.proposeDraft(id, auth.getName());
    }

    @PutMapping("/{id}/mapping/draft")
    @PreAuthorize(Roles.OPERATE)
    public Map<String, Object> saveDraft(@PathVariable long id, @RequestBody MappingRules rules, Authentication auth) {
        lists.get(id);
        mappings.saveDraft(id, rules, auth.getName());
        return mappings.view(id);
    }

    @PostMapping("/{id}/mapping/preview")
    @PreAuthorize(Roles.VIEW)
    public Map<String, Object> preview(@PathVariable long id, @RequestBody(required = false) MappingRules rules) {
        lists.get(id);
        return mappings.preview(id, rules, 200);
    }

    @PostMapping("/{id}/mapping/approve")
    @PreAuthorize(Roles.ADMIN)
    public Map<String, Object> approve(@PathVariable long id, Authentication auth) {
        lists.get(id);
        mappings.approve(id, auth.getName());
        batches.resume();
        return mappings.view(id);
    }
}
