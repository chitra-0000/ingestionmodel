package com.bank.ingestion.service.batch;

import com.bank.ingestion.config.ListHubProperties;
import com.bank.ingestion.util.Texts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

/**
 * Watches the inbound folder (polling: reliable on local disks and network shares, unlike WatchService).
 *
 * A file is taken when its size and time have not changed for listhub.inbound.stable-ms (the copy has
 * finished), or at once when a marker file "name.done" is present. It is claimed in the database
 * (unique name + size + time), moved to work/ and queued. Partial transfer names (.part, .tmp, .filepart,
 * hidden files) are ignored.
 */
@Component
public class InboundPoller {

    private static final Logger LOG = LoggerFactory.getLogger(InboundPoller.class);
    private static final String DONE = ".done";

    private final ListHubProperties props;
    private final BatchService batches;
    /** file name -> {size, modified, first time seen unchanged}. */
    private final Map<String, long[]> watched = new HashMap<>();

    public InboundPoller(ListHubProperties props, BatchService batches) {
        this.props = props;
        this.batches = batches;
    }

    @Scheduled(fixedDelayString = "${listhub.inbound.poll-ms:30000}", initialDelay = 5000)
    public synchronized void poll() {
        if (!props.getInbound().isEnabled()) {
            return;
        }
        Path inbound = props.inboundDir();
        if (!Files.isDirectory(inbound)) {
            return;
        }
        long now = System.currentTimeMillis();
        Map<String, Boolean> present = new HashMap<>();
        try (DirectoryStream<Path> files = Files.newDirectoryStream(inbound)) {
            for (Path f : files) {
                String name = f.getFileName().toString();
                if (ignored(name) || !Files.isRegularFile(f)) {
                    continue;
                }
                present.put(name, Boolean.TRUE);
                BasicFileAttributes a = Files.readAttributes(f, BasicFileAttributes.class);
                long size = a.size();
                long mtime = a.lastModifiedTime().toMillis();
                long[] w = watched.get(name);
                if (w == null || w[0] != size || w[1] != mtime) {
                    watched.put(name, new long[]{size, mtime, now});
                    w = watched.get(name);
                }
                boolean marker = Files.exists(inbound.resolve(name + DONE));
                if (marker || now - w[2] >= props.getInbound().getStableMs()) {
                    take(f, name, size, mtime);
                    watched.remove(name);
                }
            }
        } catch (IOException e) {
            LOG.warn("Inbound folder {} cannot be read: {}", inbound, e.getMessage());
        }
        Iterator<String> it = watched.keySet().iterator();
        while (it.hasNext()) {
            if (!present.containsKey(it.next())) {
                it.remove();
            }
        }
    }

    private void take(Path f, String name, long size, long mtime) {
        String safe = Texts.safeFileName(name);
        Path work = props.workDir().resolve(System.currentTimeMillis() + "_" + safe);
        try {
            Files.createDirectories(props.workDir());
            Files.move(f, work, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            // Another server took it first, or the file is still locked by the transfer: try again next poll.
            LOG.debug("Inbound file {} not taken: {}", Texts.forLog(name), e.getMessage());
            return;
        }
        try {
            Files.deleteIfExists(f.resolveSibling(name + DONE));
            batches.register(work, name, size, mtime, "FOLDER", null, "inbound");
            LOG.info("Inbound file {} ({} bytes) received", Texts.forLog(name), size);
        } catch (DuplicateKeyException e) {
            LOG.info("Inbound file {} was already received (same name, size and time); moved to the error folder",
                    Texts.forLog(name));
            try {
                Files.createDirectories(props.errorDir());
                Files.move(work, props.errorDir().resolve(work.getFileName()), StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException moveError) {
                LOG.warn("Duplicate file {} left in the work folder: {}", work, moveError.getMessage());
            }
        } catch (IOException | RuntimeException e) {
            LOG.error("Inbound file {} could not be registered", Texts.forLog(name), e);
        }
    }

    private static boolean ignored(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return n.startsWith(".") || n.endsWith(".part") || n.endsWith(".tmp") || n.endsWith(".filepart")
                || n.endsWith(".crdownload") || n.endsWith(DONE) || n.startsWith("~");
    }
}
