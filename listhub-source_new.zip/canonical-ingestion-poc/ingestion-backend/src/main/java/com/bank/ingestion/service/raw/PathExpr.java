package com.bank.ingestion.service.raw;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Compiled mapping path (see MappingRules for the syntax). Small and fast on purpose: a 5M-record file runs
 * every path of the mapping on every record, so there is no general XPath engine here.
 * Compiled paths are immutable and cached.
 */
public final class PathExpr {

    private static final Map<String, PathExpr> CACHE = new ConcurrentHashMap<>();
    private static final int MAX_PATH_LENGTH = 1000;

    private final String source;
    private final List<Step> steps;
    /** Last part: ATTR (@x), TEXT (text()), NAME (name()) or VALUE (element value). */
    private final Kind kind;
    private final String attrName;

    private enum Kind { VALUE, ATTR, TEXT, NAME }

    private static final class Step {
        final String name;
        final List<String[]> predicates;

        Step(String name, List<String[]> predicates) {
            this.name = name;
            this.predicates = predicates;
        }

        boolean matches(RNode n, RefTable refs) {
            if (!"*".equals(name) && !name.equalsIgnoreCase(n.name())) {
                return false;
            }
            for (String[] p : predicates) {
                String raw = n.attr(p[0]);
                if (raw == null) {
                    return false;
                }
                if (p[1] != null && !p[1].equalsIgnoreCase(raw.trim())) {
                    String label = refs.decodeAttr(p[0], raw.trim());
                    if (label == null || !p[1].equalsIgnoreCase(label.trim())) {
                        return false;
                    }
                }
            }
            return true;
        }
    }

    private PathExpr(String source, List<Step> steps, Kind kind, String attrName) {
        this.source = source;
        this.steps = steps;
        this.kind = kind;
        this.attrName = attrName;
    }

    public static PathExpr of(String path) {
        if (path == null) {
            throw new IllegalArgumentException("Empty path");
        }
        String p = path.trim();
        PathExpr cached = CACHE.get(p);
        if (cached != null) {
            return cached;
        }
        PathExpr compiled = compile(p);
        if (CACHE.size() < 10000) {
            CACHE.put(p, compiled);
        }
        return compiled;
    }

    public String source() {
        return source;
    }

    /** Every non-blank value the path selects in the record, in document order. */
    public List<String> values(RNode record, RefTable refs) {
        if (kind == Kind.NAME && steps.isEmpty()) {
            return Collections.singletonList(record.name());
        }
        List<RNode> nodes = Collections.singletonList(record);
        for (Step s : steps) {
            List<RNode> next = new ArrayList<>();
            for (RNode n : nodes) {
                for (RNode c : n.children()) {
                    if (s.matches(c, refs)) {
                        next.add(c);
                    }
                }
            }
            if (next.isEmpty()) {
                return Collections.emptyList();
            }
            nodes = next;
        }
        List<String> out = new ArrayList<>(nodes.size());
        for (RNode n : nodes) {
            String v;
            switch (kind) {
                case ATTR:
                    v = n.attr(attrName);
                    break;
                case TEXT:
                    v = n.text();
                    break;
                case NAME:
                    v = n.name();
                    break;
                default:
                    v = n.value();
            }
            if (v != null && !v.trim().isEmpty()) {
                out.add(v.trim());
            }
        }
        return out;
    }

    public String first(RNode record, RefTable refs) {
        List<String> v = values(record, refs);
        return v.isEmpty() ? null : v.get(0);
    }

    // ------------------------------------------------------------------ parsing

    private static PathExpr compile(String p) {
        if (p.isEmpty() || p.length() > MAX_PATH_LENGTH) {
            throw new IllegalArgumentException("Path is empty or too long");
        }
        List<String> parts = split(p);
        List<Step> steps = new ArrayList<>();
        Kind kind = Kind.VALUE;
        String attr = null;
        for (int i = 0; i < parts.size(); i++) {
            String part = parts.get(i).trim();
            boolean last = i == parts.size() - 1;
            if (part.isEmpty() || ".".equals(part)) {
                continue;
            }
            if (part.startsWith("@")) {
                if (!last || part.length() < 2) {
                    throw new IllegalArgumentException("@attribute must be the last part of a path: " + p);
                }
                kind = Kind.ATTR;
                attr = part.substring(1);
            } else if ("text()".equals(part)) {
                requireLast(last, p);
                kind = Kind.TEXT;
            } else if ("name()".equals(part)) {
                requireLast(last, p);
                kind = Kind.NAME;
            } else {
                steps.add(step(part, p));
            }
        }
        return new PathExpr(p, Collections.unmodifiableList(steps), kind, attr);
    }

    private static void requireLast(boolean last, String p) {
        if (!last) {
            throw new IllegalArgumentException("text() and name() must end a path: " + p);
        }
    }

    /** Splits on "/" outside predicates and quotes. */
    private static List<String> split(String p) {
        List<String> parts = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        int depth = 0;
        char quote = 0;
        for (int i = 0; i < p.length(); i++) {
            char c = p.charAt(i);
            if (quote != 0) {
                if (c == quote) {
                    quote = 0;
                }
                cur.append(c);
            } else if (c == '\'' || c == '"') {
                quote = c;
                cur.append(c);
            } else if (c == '[') {
                depth++;
                cur.append(c);
            } else if (c == ']') {
                depth--;
                cur.append(c);
            } else if (c == '/' && depth == 0) {
                parts.add(cur.toString());
                cur.setLength(0);
            } else {
                cur.append(c);
            }
        }
        if (quote != 0 || depth != 0) {
            throw new IllegalArgumentException("Unbalanced quote or bracket in path: " + p);
        }
        parts.add(cur.toString());
        return parts;
    }

    private static Step step(String part, String p) {
        int b = part.indexOf('[');
        String name = (b < 0 ? part : part.substring(0, b)).trim();
        if (name.isEmpty()) {
            throw new IllegalArgumentException("Missing element name in path: " + p);
        }
        List<String[]> preds = new ArrayList<>();
        while (b >= 0) {
            int e = closing(part, b);
            String body = part.substring(b + 1, e).trim();
            if (!body.startsWith("@")) {
                throw new IllegalArgumentException("Only [@attribute] or [@attribute='value'] predicates are allowed: " + p);
            }
            int eq = body.indexOf('=');
            if (eq < 0) {
                preds.add(new String[]{body.substring(1).trim(), null});
            } else {
                String a = body.substring(1, eq).trim();
                String v = body.substring(eq + 1).trim();
                if (v.length() < 2 || (v.charAt(0) != '\'' && v.charAt(0) != '"') || v.charAt(v.length() - 1) != v.charAt(0)) {
                    throw new IllegalArgumentException("Predicate value must be quoted: " + p);
                }
                preds.add(new String[]{a, v.substring(1, v.length() - 1)});
            }
            b = part.indexOf('[', e);
        }
        return new Step(name, Collections.unmodifiableList(preds));
    }

    private static int closing(String part, int open) {
        char quote = 0;
        for (int i = open + 1; i < part.length(); i++) {
            char c = part.charAt(i);
            if (quote != 0) {
                if (c == quote) {
                    quote = 0;
                }
            } else if (c == '\'' || c == '"') {
                quote = c;
            } else if (c == ']') {
                return i;
            }
        }
        throw new IllegalArgumentException("Missing ] in path part: " + part);
    }
}
