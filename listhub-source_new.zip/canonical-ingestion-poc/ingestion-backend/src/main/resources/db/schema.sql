-- ListHub: fixed tables, common to every provider and every file format (XML, CSV, JSON).
-- Runs unchanged on H2 (MODE=Oracle, created at start-up on a developer machine) and on Oracle 19c
-- (run once by the DBA in the application schema: listhub.db.init=never in application-oracle.properties).
-- No table is created or altered at runtime; a new provider is configuration only.

-- Sequences hand out blocks of ids (hi/lo in the application): one round trip per 1000 rows.
CREATE SEQUENCE LH_ID_SEQ START WITH 1000 INCREMENT BY 1000 NOCACHE;
CREATE SEQUENCE LH_SMALL_SEQ START WITH 1 INCREMENT BY 1 NOCACHE;

-- ============================================================== configuration

-- Users of the screens and of the subscriber API. Passwords are BCrypt hashes, never plain text.
CREATE TABLE APP_USER (
    USERNAME            VARCHAR2(60 CHAR)   NOT NULL,
    DISPLAY_NAME        VARCHAR2(120 CHAR)  NOT NULL,
    PASSWORD_HASH       VARCHAR2(100)       NOT NULL,
    ROLES               VARCHAR2(200)       NOT NULL,
    ACTIVE              NUMBER(1)           DEFAULT 1 NOT NULL,
    CREATED_AT          TIMESTAMP           NOT NULL,
    CONSTRAINT PK_APP_USER PRIMARY KEY (USERNAME)
);

-- One row per list. FILE_PATTERN routes a file to the list by its name ("*" = any text).
CREATE TABLE LIST_DEF (
    LIST_ID             NUMBER(19)          NOT NULL,
    LIST_CODE           VARCHAR2(20 CHAR)   NOT NULL,
    NAME                VARCHAR2(200 CHAR)  NOT NULL,
    PROVIDER_CODE       VARCHAR2(30 CHAR)   NOT NULL,
    CATEGORY            VARCHAR2(40 CHAR),
    FILE_FORMAT         VARCHAR2(10)        DEFAULT 'AUTO' NOT NULL,
    FILE_PATTERN        VARCHAR2(200 CHAR),
    DELTA_PATTERN       VARCHAR2(200 CHAR),
    RECORD_ELEMENTS     VARCHAR2(500 CHAR),
    ID_PREFIX           VARCHAR2(10 CHAR)   DEFAULT 'RGL' NOT NULL,
    MATCH_KEY_ATTRS     VARCHAR2(200 CHAR),
    WORKFLOW            VARCHAR2(10)        DEFAULT 'MANUAL' NOT NULL,
    EXPORT_FORMATS      VARCHAR2(100)       DEFAULT 'CSV,XML' NOT NULL,
    MAX_REJECT_PERCENT  NUMBER(5,2)         DEFAULT 5 NOT NULL,
    ACTIVE              NUMBER(1)           DEFAULT 1 NOT NULL,
    DESCRIPTION         VARCHAR2(1000 CHAR),
    CREATED_BY          VARCHAR2(60 CHAR),
    CREATED_AT          TIMESTAMP           NOT NULL,
    CONSTRAINT PK_LIST_DEF PRIMARY KEY (LIST_ID),
    CONSTRAINT UQ_LIST_CODE UNIQUE (LIST_CODE)
);

-- Mapping of a list: path rules from the provider record to the canonical attributes (JSON, no XSLT).
-- One APPROVED version is used at a time; DRAFT versions come from the auto-mapper or from edits.
CREATE TABLE LIST_MAPPING (
    MAPPING_ID          NUMBER(19)          NOT NULL,
    LIST_ID             NUMBER(19)          NOT NULL,
    VERSION_NO          NUMBER(10)          NOT NULL,
    STATUS              VARCHAR2(20)        NOT NULL,
    RULES_JSON          CLOB                NOT NULL,
    LAYOUT_KEY          VARCHAR2(64),
    CREATED_BY          VARCHAR2(60 CHAR),
    CREATED_AT          TIMESTAMP           NOT NULL,
    APPROVED_BY         VARCHAR2(60 CHAR),
    APPROVED_AT         TIMESTAMP,
    CONSTRAINT PK_LIST_MAPPING PRIMARY KEY (MAPPING_ID),
    CONSTRAINT UQ_LIST_MAPPING UNIQUE (LIST_ID, VERSION_NO)
);

-- ============================================================== batches (one file = one batch)

-- FILE_NAME + SIZE + MTIME is unique: when several servers watch the same folder, only one claims a file.
CREATE TABLE LOAD_BATCH (
    BATCH_ID            NUMBER(19)          NOT NULL,
    LIST_ID             NUMBER(19),
    FILE_NAME           VARCHAR2(255 CHAR)  NOT NULL,
    FILE_SIZE           NUMBER(19)          NOT NULL,
    FILE_MTIME          NUMBER(19)          NOT NULL,
    SOURCE              VARCHAR2(10)        NOT NULL,
    FILE_FORMAT         VARCHAR2(10),
    DELIVERY            VARCHAR2(10),
    SHA256              VARCHAR2(64),
    STATUS              VARCHAR2(20)        NOT NULL,
    MESSAGE             VARCHAR2(1000 CHAR),
    VERSION_NO          NUMBER(10),
    RECORD_COUNT        NUMBER(19)          DEFAULT 0,
    REF_COUNT           NUMBER(19)          DEFAULT 0,
    WORK_PATH           VARCHAR2(1000 CHAR),
    LAYOUT_JSON         CLOB,
    SUBMITTED_BY        VARCHAR2(60 CHAR),
    RECEIVED_AT         TIMESTAMP           NOT NULL,
    STARTED_AT          TIMESTAMP,
    FINISHED_AT         TIMESTAMP,
    CONSTRAINT PK_LOAD_BATCH PRIMARY KEY (BATCH_ID),
    CONSTRAINT UQ_LOAD_BATCH_FILE UNIQUE (FILE_NAME, FILE_SIZE, FILE_MTIME)
);
CREATE INDEX IX_LOAD_BATCH_LIST ON LOAD_BATCH (LIST_ID, STATUS);
CREATE INDEX IX_LOAD_BATCH_STATUS ON LOAD_BATCH (STATUS, RECEIVED_AT);

-- Time of every step of a batch (Batches follow-up screen).
CREATE TABLE BATCH_STEP (
    BATCH_ID            NUMBER(19)          NOT NULL,
    STEP_CODE           VARCHAR2(20)        NOT NULL,
    STARTED_AT          TIMESTAMP           NOT NULL,
    FINISHED_AT         TIMESTAMP,
    DURATION_MS         NUMBER(19),
    RESULT              VARCHAR2(500 CHAR),
    CONSTRAINT PK_BATCH_STEP PRIMARY KEY (BATCH_ID, STEP_CODE)
);

-- ============================================================== stage 1: raw, exactly as received

-- One row per provider record. PAYLOAD = the record's original bytes (XML fragment, CSV line or JSON object),
-- gzip-compressed. Nothing is dropped, so any tag can be mapped later and re-processed without the file.
CREATE TABLE RAW_RECORD (
    BATCH_ID            NUMBER(19)          NOT NULL,
    SEQ_NO              NUMBER(19)          NOT NULL,
    ELEMENT             VARCHAR2(100 CHAR),
    RECORD_KEY          VARCHAR2(200 CHAR),
    PAYLOAD             BLOB                NOT NULL,
    CONSTRAINT PK_RAW_RECORD PRIMARY KEY (BATCH_ID, SEQ_NO)
);

-- Reference lists carried inside the file (code -> label), e.g. CountryList, DateTypeList, SanctionsReferencesList.
CREATE TABLE RAW_REF (
    BATCH_ID            NUMBER(19)          NOT NULL,
    LIST_NAME           VARCHAR2(100 CHAR)  NOT NULL,
    CODE                VARCHAR2(200 CHAR)  NOT NULL,
    LABEL               VARCHAR2(1000 CHAR),
    CONSTRAINT PK_RAW_REF PRIMARY KEY (BATCH_ID, LIST_NAME, CODE)
);

-- Every field path found in the file, with counts and sample values (mapping screen, filter rules).
CREATE TABLE RAW_FIELD_PROFILE (
    BATCH_ID            NUMBER(19)          NOT NULL,
    PATH                VARCHAR2(1000 CHAR) NOT NULL,
    LABEL               VARCHAR2(1000 CHAR),
    OCCURS              NUMBER(19)          NOT NULL,
    RECORDS_WITH        NUMBER(19)          NOT NULL,
    SAMPLES             VARCHAR2(1000 CHAR),
    REF_LIST            VARCHAR2(100 CHAR)
);
CREATE INDEX IX_RAW_FIELD_PROFILE ON RAW_FIELD_PROFILE (BATCH_ID);

-- ============================================================== stage 2: canonical, versioned

-- Versions of a list. A version is visible to subscribers only once PUBLISHED.
CREATE TABLE LIST_VERSION (
    LIST_ID             NUMBER(19)          NOT NULL,
    VERSION_NO          NUMBER(10)          NOT NULL,
    BATCH_ID            NUMBER(19)          NOT NULL,
    STATUS              VARCHAR2(20)        NOT NULL,
    DELIVERY            VARCHAR2(10)        NOT NULL,
    MAPPING_VERSION     NUMBER(10),
    FILE_RECORDS        NUMBER(19)          DEFAULT 0,
    TOTAL_RECORDS       NUMBER(19)          DEFAULT 0,
    CREATED_COUNT       NUMBER(19)          DEFAULT 0,
    MODIFIED_COUNT      NUMBER(19)          DEFAULT 0,
    MINOR_COUNT         NUMBER(19)          DEFAULT 0,
    DELETED_COUNT       NUMBER(19)          DEFAULT 0,
    UNCHANGED_COUNT     NUMBER(19)          DEFAULT 0,
    REJECTED_COUNT      NUMBER(19)          DEFAULT 0,
    FLAGGED_COUNT       NUMBER(19)          DEFAULT 0,
    ISSUES_JSON         CLOB,
    CREATED_AT          TIMESTAMP           NOT NULL,
    VALIDATED_BY        VARCHAR2(60 CHAR),
    VALIDATED_AT        TIMESTAMP,
    CERTIFIED_BY        VARCHAR2(60 CHAR),
    CERTIFIED_AT        TIMESTAMP,
    PUBLISHED_BY        VARCHAR2(60 CHAR),
    PUBLISHED_AT        TIMESTAMP,
    REJECTED_BY         VARCHAR2(60 CHAR),
    REJECTED_AT         TIMESTAMP,
    COMMENT_TEXT        VARCHAR2(1000 CHAR),
    CONSTRAINT PK_LIST_VERSION PRIMARY KEY (LIST_ID, VERSION_NO)
);

-- One identity per person / entity per list: the internal id (RGL-001-0000000457) never changes.
-- KEY_VALUE is the provider's external reference, or a match key (hash of chosen attributes) when the
-- provider has none.
CREATE TABLE RECORD_IDENTITY (
    RGL_ID              VARCHAR2(40)        NOT NULL,
    LIST_ID             NUMBER(19)          NOT NULL,
    RGL_NO              NUMBER(19)          NOT NULL,
    KEY_TYPE            VARCHAR2(5)         NOT NULL,
    KEY_VALUE           VARCHAR2(200 CHAR)  NOT NULL,
    FIRST_VERSION       NUMBER(10)          NOT NULL,
    CONSTRAINT PK_RECORD_IDENTITY PRIMARY KEY (RGL_ID),
    CONSTRAINT UQ_RECORD_IDENTITY UNIQUE (LIST_ID, KEY_VALUE)
);

-- The canonical record, one row per (identity, period of validity). A row is valid from VALID_FROM to
-- VALID_TO (inclusive, NULL = still valid). Unchanged records keep their row: nothing is written for them.
-- The search columns hold every value joined with " | "; CONTENT holds the full record as JSON.
CREATE TABLE CANONICAL_RECORD (
    ROW_ID              NUMBER(19)          NOT NULL,
    RGL_ID              VARCHAR2(40)        NOT NULL,
    LIST_ID             NUMBER(19)          NOT NULL,
    VALID_FROM          NUMBER(10)          NOT NULL,
    VALID_TO            NUMBER(10),
    BATCH_ID            NUMBER(19)          NOT NULL,
    RAW_SEQ             NUMBER(19),
    EXTERNAL_REF        VARCHAR2(200 CHAR),
    RECORD_TYPE         VARCHAR2(10)        NOT NULL,
    PRIMARY_NAME        VARCHAR2(500 CHAR)  NOT NULL,
    NAME_SEARCH         VARCHAR2(4000 CHAR),
    GENDER              VARCHAR2(10),
    DOB                 VARCHAR2(500 CHAR),
    NATIONALITIES       VARCHAR2(500 CHAR),
    COUNTRIES           VARCHAR2(1000 CHAR),
    ID_NUMBERS          VARCHAR2(2000 CHAR),
    LIST_REFS           VARCHAR2(2000 CHAR),
    STATUS              VARCHAR2(40 CHAR),
    DQ_FLAGS            VARCHAR2(200),
    CONTENT_HASH        VARCHAR2(32)        NOT NULL,
    MAIN_HASH           VARCHAR2(32)        NOT NULL,
    CONTENT             CLOB                NOT NULL,
    CONSTRAINT PK_CANONICAL_RECORD PRIMARY KEY (ROW_ID)
);
CREATE INDEX IX_CANONICAL_RGL ON CANONICAL_RECORD (RGL_ID, VALID_TO);
CREATE INDEX IX_CANONICAL_LIST ON CANONICAL_RECORD (LIST_ID, VALID_FROM, VALID_TO);

-- What happened to each record in each version: CREATED, MODIFIED, MINOR, DELETED, REJECTED, FLAGGED.
-- DETAIL_JSON keeps the before / after values or the quality issues (version detail and history screens).
CREATE TABLE RECORD_CHANGE (
    LIST_ID             NUMBER(19)          NOT NULL,
    VERSION_NO          NUMBER(10)          NOT NULL,
    CHANGE_TYPE         VARCHAR2(10)        NOT NULL,
    SEQ_NO              NUMBER(19)          NOT NULL,
    RGL_ID              VARCHAR2(40),
    EXTERNAL_REF        VARCHAR2(200 CHAR),
    RECORD_TYPE         VARCHAR2(10),
    PRIMARY_NAME        VARCHAR2(500 CHAR),
    COUNTRY             VARCHAR2(100 CHAR),
    SUMMARY             VARCHAR2(1000 CHAR),
    DETAIL_JSON         CLOB,
    BATCH_ID            NUMBER(19)          NOT NULL,
    RAW_SEQ             NUMBER(19),
    CONSTRAINT PK_RECORD_CHANGE PRIMARY KEY (LIST_ID, VERSION_NO, CHANGE_TYPE, SEQ_NO)
);
CREATE INDEX IX_RECORD_CHANGE_RGL ON RECORD_CHANGE (RGL_ID);

-- Files generated at publication (and on demand), kept in the outbound folder.
CREATE TABLE EXPORT_FILE (
    EXPORT_ID           NUMBER(19)          NOT NULL,
    LIST_ID             NUMBER(19)          NOT NULL,
    VERSION_NO          NUMBER(10)          NOT NULL,
    FORMAT              VARCHAR2(20)        NOT NULL,
    KIND                VARCHAR2(10)        NOT NULL,
    FILE_NAME           VARCHAR2(255 CHAR)  NOT NULL,
    FILE_PATH           VARCHAR2(1000 CHAR) NOT NULL,
    RECORD_COUNT        NUMBER(19)          NOT NULL,
    SIZE_BYTES          NUMBER(19)          NOT NULL,
    SHA256              VARCHAR2(64)        NOT NULL,
    CREATED_AT          TIMESTAMP           NOT NULL,
    CONSTRAINT PK_EXPORT_FILE PRIMARY KEY (EXPORT_ID)
);
CREATE INDEX IX_EXPORT_FILE_LIST ON EXPORT_FILE (LIST_ID, VERSION_NO);

-- ORACLE with the Partitioning option (optional, recommended above a few lists of 5M records):
--   RAW_RECORD        PARTITION BY RANGE (BATCH_ID) INTERVAL (1)  -> housekeeping drops a batch in seconds
--   CANONICAL_RECORD  PARTITION BY LIST (LIST_ID) AUTOMATIC       -> each list in its own segment
-- Without it the application deletes old raw batches in chunks (listhub.raw-retention-days).
