import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { ApproveOutcome, Decision, LoadView, ServerFiles, StructureChange } from './models';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly base = environment.apiBase;

  constructor(private http: HttpClient) {}

  upload(provider: string, file: File): Observable<HttpEvent<LoadView>> {
    const form = new FormData();
    form.append('provider', provider);
    form.append('file', file, file.name);
    return this.http.post<LoadView>(`${this.base}/uploads`, form, { reportProgress: true, observe: 'events' });
  }

  serverFiles(): Observable<ServerFiles> {
    return this.http.get<ServerFiles>(`${this.base}/server-files`);
  }

  loadFromServer(provider: string, path: string): Observable<LoadView> {
    return this.http.post<LoadView>(`${this.base}/server-files/load`, { provider, path });
  }

  loads(limit = 100): Observable<LoadView[]> {
    return this.http.get<LoadView[]>(`${this.base}/loads`, { params: { limit: String(limit) } });
  }

  load(id: number): Observable<LoadView> {
    return this.http.get<LoadView>(`${this.base}/loads/${id}`);
  }

  providers(): Observable<string[]> {
    return this.http.get<string[]>(`${this.base}/providers`);
  }

  structureChanges(loadId: number): Observable<StructureChange[]> {
    return this.http.get<StructureChange[]>(`${this.base}/loads/${loadId}/structure-changes`);
  }

  approve(d: Decision): Observable<ApproveOutcome> {
    return this.http.post<ApproveOutcome>(`${this.base}/structure-changes/approve`, d);
  }

  reject(d: Decision): Observable<StructureChange[]> {
    return this.http.post<StructureChange[]>(`${this.base}/structure-changes/reject`, d);
  }

  originalUrl(id: number): string {
    return `${this.base}/loads/${id}/download/original`;
  }

  reportUrl(id: number): string {
    return `${this.base}/loads/${id}/download/report`;
  }

  static message(err: HttpErrorResponse): string {
    if (err.error && typeof err.error.message === 'string') {
      return err.error.message;
    }
    return err.status === 0 ? 'The server cannot be reached' : `Request failed (${err.status})`;
  }
}
