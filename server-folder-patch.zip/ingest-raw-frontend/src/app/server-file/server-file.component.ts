import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ApiService } from '../shared/api.service';
import { LoadView, ServerFile } from '../shared/models';

/** Load a file that is already on the server (large files, CFT drops): no upload, the file is read in place. */
@Component({
  selector: 'app-server-file',
  templateUrl: './server-file.component.html'
})
export class ServerFileComponent implements OnInit {
  @Output() loaded = new EventEmitter<LoadView>();

  readonly providerPattern = '^[A-Za-z0-9][A-Za-z0-9 _-]{0,39}$';
  provider = '';
  path = '';
  roots: string[] = [];
  files: ServerFile[] = [];
  showFiles = false;
  busy = false;
  error = '';
  info = '';

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.refresh();
  }

  refresh(): void {
    this.api.serverFiles().subscribe(r => {
      this.roots = r.roots;
      this.files = r.files;
    }, (e: HttpErrorResponse) => (this.error = ApiService.message(e)));
  }

  pick(f: ServerFile): void {
    this.path = f.path;
    this.showFiles = false;
  }

  get canLoad(): boolean {
    return !this.busy && this.path.trim().length > 0 && new RegExp(this.providerPattern).test(this.provider.trim());
  }

  load(): void {
    if (!this.canLoad) {
      return;
    }
    this.busy = true;
    this.error = '';
    this.info = '';
    this.api.loadFromServer(this.provider.trim(), this.path.trim()).subscribe(v => {
      this.busy = false;
      this.info = `Load ${v.loadId} queued — ${v.fileName}`;
      this.path = '';
      this.loaded.emit(v);
    }, (e: HttpErrorResponse) => {
      this.busy = false;
      this.error = ApiService.message(e);
    });
  }

  trackPath(_: number, f: ServerFile): string {
    return f.path;
  }
}
