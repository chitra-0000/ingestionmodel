import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { UploadComponent } from './upload/upload.component';
import { ServerFileComponent } from './server-file/server-file.component';
import { LoadListComponent } from './load-list/load-list.component';
import { LoadDetailComponent } from './load-detail/load-detail.component';
import { StatusBadgeComponent } from './shared/status-badge.component';
import { BytesPipe, DurationPipe } from './shared/format.pipes';

const routes: Routes = [
  { path: '', component: LoadListComponent },
  { path: 'loads/:id', component: LoadDetailComponent },
  { path: '**', redirectTo: '' }
];

@NgModule({
  declarations: [
    AppComponent,
    UploadComponent,
    ServerFileComponent,
    LoadListComponent,
    LoadDetailComponent,
    StatusBadgeComponent,
    BytesPipe,
    DurationPipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
