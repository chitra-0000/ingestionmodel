package com.poc.ingest.service;

import com.poc.ingest.config.IngestProperties;
import com.poc.ingest.model.ArchiveStatus;
import com.poc.ingest.repo.LoadLogRepository;
import com.poc.ingest.util.Safe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Keeps the original file (gzip) in INGEST_FILE_ARCHIVE for the retention period: the final guarantee that
 * nothing is lost, and the source of the "Download original" button. Runs in parallel with the load.
 */
@Service
public class ArchiveService {

    private static final Logger LOG = LoggerFactory.getLogger(ArchiveService.class);
    private static final int BUF = 256 * 1024;

    private final JdbcTemplate jdbc;
    private final LoadLogRepository loads;
    private final IngestProperties props;

    public ArchiveService(JdbcTemplate jdbc, LoadLogRepository loads, IngestProperties props) {
        this.jdbc = jdbc;
        this.loads = loads;
        this.props = props;
    }

    /**
     * Compresses the file into the work folder (never next to the source: server files stay untouched), streams it
     * into a BLOB, then removes the .gz. When {@code knownSha256} is null (server-folder loads) the SHA-256 is
     * computed during the same read and written to the load log. Never throws.
     */
    public boolean archive(long loadId, Path file, String fileName, long size, String knownSha256) {
        Path gz;
        try {
            Path dir = Paths.get(props.getStorageDir()).toAbsolutePath().normalize();
            Files.createDirectories(dir);
            gz = dir.resolve(loadId + ".gz");
        } catch (IOException e) {
            LOG.error("Archive work folder not usable for load {}", loadId, e);
            loads.setArchiveStatus(loadId, ArchiveStatus.FAILED);
            return false;
        }
        try {
            String computed;
            try (DigestInputStream in = new DigestInputStream(Files.newInputStream(file), sha256());
                 OutputStream out = new GZIPOutputStream(Files.newOutputStream(gz), BUF)) {
                copy(in, out);
                computed = LayoutService.hex(in.getMessageDigest().digest());
            }
            final String sha256 = knownSha256 != null ? knownSha256 : computed;
            if (knownSha256 == null) {
                loads.setSha256(loadId, computed);
            }
            final long compressed = Files.size(gz);
            try (InputStream blob = Files.newInputStream(gz)) {
                jdbc.update(con -> {
                    PreparedStatement ps = con.prepareStatement("INSERT INTO INGEST_FILE_ARCHIVE (LOAD_ID, "
                            + "ORIGINAL_FILENAME, ORIGINAL_SIZE, COMPRESSED_SIZE, FILE_SHA256, ARCHIVED_AT, FILE_GZ) "
                            + "VALUES (?,?,?,?,?,?,?)");
                    ps.setLong(1, loadId);
                    ps.setString(2, fileName);
                    ps.setLong(3, size);
                    ps.setLong(4, compressed);
                    ps.setString(5, sha256);
                    ps.setTimestamp(6, Timestamp.from(Instant.now()));
                    ps.setBinaryStream(7, blob, compressed);
                    return ps;
                });
            }
            loads.setArchiveStatus(loadId, ArchiveStatus.ARCHIVED);
            return true;
        } catch (IOException | DataAccessException e) {
            LOG.error("Archiving original file of load {} failed", loadId, e);
            loads.setArchiveStatus(loadId, ArchiveStatus.FAILED);
            return false;
        } finally {
            deleteQuietly(gz);
        }
    }

    /** Writes the decompressed original to {@code out}. */
    public void streamOriginal(long loadId, OutputStream out) {
        jdbc.query("SELECT FILE_GZ FROM INGEST_FILE_ARCHIVE WHERE LOAD_ID = ?", rs -> {
            try (InputStream in = new GZIPInputStream(rs.getBinaryStream(1), BUF)) {
                copy(in, out);
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        }, loadId);
    }

    public boolean hasOriginal(long loadId) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM INGEST_FILE_ARCHIVE WHERE LOAD_ID = ?",
                Integer.class, loadId);
        return n != null && n > 0;
    }

    /** Daily: drops originals older than the retention period (default 160 days). */
    @Scheduled(cron = "${ingest.archive-purge-cron:0 30 2 * * *}")
    public int purgeExpired() {
        Timestamp cutoff = Timestamp.from(Instant.now().minus(Duration.ofDays(props.getArchiveRetentionDays())));
        List<Long> ids = jdbc.queryForList("SELECT LOAD_ID FROM INGEST_FILE_ARCHIVE WHERE ARCHIVED_AT < ?",
                Long.class, cutoff);
        for (Long id : ids) {
            jdbc.update("DELETE FROM INGEST_FILE_ARCHIVE WHERE LOAD_ID = ?", id);
            loads.setArchiveStatus(id, ArchiveStatus.PURGED);
        }
        if (!ids.isEmpty()) {
            LOG.info("Purged {} archived files older than {} days", ids.size(), props.getArchiveRetentionDays());
        }
        return ids.size();
    }

    private static MessageDigest sha256() {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[BUF];
        int n;
        while ((n = in.read(buf)) > 0) {
            out.write(buf, 0, n);
        }
    }

    static void deleteQuietly(Path p) {
        try {
            Files.deleteIfExists(p);
        } catch (IOException e) {
            LOG.warn("Could not delete temporary file {}", Safe.log(p.getFileName()));
        }
    }
}
