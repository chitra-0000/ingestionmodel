package com.poc.ingest.repo;

import com.poc.ingest.model.ArchiveStatus;
import com.poc.ingest.model.FormatType;
import com.poc.ingest.model.LoadStatus;
import com.poc.ingest.model.LoadView;
import com.poc.ingest.util.Safe;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

/** INGEST_LOAD_LOG. */
@Repository
public class LoadLogRepository {

    private static final String COLUMNS = "LOAD_ID, PROVIDER, FORMAT_TYPE, LAYOUT_ID, TABLE_NAME, ORIGINAL_FILENAME, "
            + "FILE_SIZE, FILE_SHA256, STATUS, ARCHIVE_STATUS, RECORDS_PARSED, ROWS_INSERTED, REF_ROWS, "
            + "NEW_FIELD_COUNT, UPLOADED_AT, STARTED_AT, FINISHED_AT, DURATION_MS, MESSAGE";

    private static final RowMapper<LoadView> MAPPER = (rs, i) -> {
        LoadView v = new LoadView();
        v.setLoadId(rs.getLong("LOAD_ID"));
        v.setProvider(rs.getString("PROVIDER"));
        String f = rs.getString("FORMAT_TYPE");
        v.setFormat(f == null ? null : FormatType.valueOf(f));
        v.setLayoutId(longOrNull(rs, "LAYOUT_ID"));
        v.setTableName(rs.getString("TABLE_NAME"));
        v.setFileName(rs.getString("ORIGINAL_FILENAME"));
        v.setFileSize(rs.getLong("FILE_SIZE"));
        v.setFileSha256(rs.getString("FILE_SHA256"));
        v.setStatus(LoadStatus.valueOf(rs.getString("STATUS")));
        v.setArchiveStatus(ArchiveStatus.valueOf(rs.getString("ARCHIVE_STATUS")));
        v.setRecordsParsed(longOrNull(rs, "RECORDS_PARSED"));
        v.setRowsInserted(longOrNull(rs, "ROWS_INSERTED"));
        v.setRefRows(longOrNull(rs, "REF_ROWS"));
        Long nf = longOrNull(rs, "NEW_FIELD_COUNT");
        v.setNewFieldCount(nf == null ? null : nf.intValue());
        v.setUploadedAt(instant(rs.getTimestamp("UPLOADED_AT")));
        v.setStartedAt(instant(rs.getTimestamp("STARTED_AT")));
        v.setFinishedAt(instant(rs.getTimestamp("FINISHED_AT")));
        v.setDurationMs(longOrNull(rs, "DURATION_MS"));
        v.setMessage(rs.getString("MESSAGE"));
        return v;
    };

    private final JdbcTemplate jdbc;

    public LoadLogRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public void insertQueued(long loadId, String provider, String fileName, long size, String sha256) {
        jdbc.update("INSERT INTO INGEST_LOAD_LOG (LOAD_ID, PROVIDER, ORIGINAL_FILENAME, FILE_SIZE, FILE_SHA256, "
                        + "STATUS, ARCHIVE_STATUS, UPLOADED_AT) VALUES (?,?,?,?,?,?,?,?)",
                loadId, provider, fileName, size, sha256, LoadStatus.QUEUED.name(), ArchiveStatus.PENDING.name(),
                Timestamp.from(Instant.now()));
    }

    public void markLoading(long loadId) {
        jdbc.update("UPDATE INGEST_LOAD_LOG SET STATUS = ?, STARTED_AT = ? WHERE LOAD_ID = ?",
                LoadStatus.LOADING.name(), Timestamp.from(Instant.now()), loadId);
    }

    public void setLayout(long loadId, FormatType format, long layoutId, String table) {
        jdbc.update("UPDATE INGEST_LOAD_LOG SET FORMAT_TYPE = ?, LAYOUT_ID = ?, TABLE_NAME = ? WHERE LOAD_ID = ?",
                format.name(), layoutId, table, loadId);
    }

    public void setFormat(long loadId, FormatType format) {
        jdbc.update("UPDATE INGEST_LOAD_LOG SET FORMAT_TYPE = ? WHERE LOAD_ID = ?", format.name(), loadId);
    }

    public void finish(long loadId, LoadStatus status, Long parsed, Long inserted, Long refRows, Integer newFields,
                       Instant started, String message, String envelopeJson) {
        Instant now = Instant.now();
        Long duration = started == null ? null : now.toEpochMilli() - started.toEpochMilli();
        jdbc.update("UPDATE INGEST_LOAD_LOG SET STATUS = ?, RECORDS_PARSED = ?, ROWS_INSERTED = ?, REF_ROWS = ?, "
                        + "NEW_FIELD_COUNT = ?, FINISHED_AT = ?, DURATION_MS = ?, MESSAGE = ?, ENVELOPE_JSON = ? "
                        + "WHERE LOAD_ID = ?",
                status.name(), parsed, inserted, refRows, newFields, Timestamp.from(now), duration,
                Safe.truncateBytes(message, 2000), envelopeJson, loadId);
    }

    public void setSha256(long loadId, String sha) {
        jdbc.update("UPDATE INGEST_LOAD_LOG SET FILE_SHA256 = ? WHERE LOAD_ID = ?", sha, loadId);
    }

    public void setArchiveStatus(long loadId, ArchiveStatus s) {
        jdbc.update("UPDATE INGEST_LOAD_LOG SET ARCHIVE_STATUS = ? WHERE LOAD_ID = ?", s.name(), loadId);
    }

    public void setStatus(long loadId, LoadStatus s) {
        jdbc.update("UPDATE INGEST_LOAD_LOG SET STATUS = ? WHERE LOAD_ID = ?", s.name(), loadId);
    }

    /** Once every new field of a table is decided, its NEW_FIELDS loads count as successful. */
    public void markReviewed(long layoutId) {
        jdbc.update("UPDATE INGEST_LOAD_LOG SET STATUS = ? WHERE LAYOUT_ID = ? AND STATUS = ?",
                LoadStatus.SUCCESS.name(), layoutId, LoadStatus.NEW_FIELDS.name());
    }

    public LoadView find(long loadId) {
        List<LoadView> l = jdbc.query("SELECT " + COLUMNS + " FROM INGEST_LOAD_LOG WHERE LOAD_ID = ?", MAPPER, loadId);
        return l.isEmpty() ? null : l.get(0);
    }

    public List<LoadView> recent(int limit) {
        return jdbc.query("SELECT " + COLUMNS + " FROM INGEST_LOAD_LOG ORDER BY LOAD_ID DESC "
                + "FETCH FIRST ? ROWS ONLY", MAPPER, limit);
    }

    public List<LoadView> unfinished() {
        return jdbc.query("SELECT " + COLUMNS + " FROM INGEST_LOAD_LOG WHERE STATUS IN (?, ?)", MAPPER,
                LoadStatus.QUEUED.name(), LoadStatus.LOADING.name());
    }

    /** True if a load other than {@code exceptLoadId} is writing into the layout's table. */
    public boolean isLoadRunning(long layoutId, long exceptLoadId) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM INGEST_LOAD_LOG WHERE LAYOUT_ID = ? AND STATUS = ? "
                + "AND LOAD_ID <> ?", Integer.class, layoutId, LoadStatus.LOADING.name(), exceptLoadId);
        return n != null && n > 0;
    }

    public String envelope(long loadId) {
        List<String> l = jdbc.queryForList("SELECT ENVELOPE_JSON FROM INGEST_LOAD_LOG WHERE LOAD_ID = ?",
                String.class, loadId);
        return l.isEmpty() ? null : l.get(0);
    }

    private static Long longOrNull(ResultSet rs, String col) throws SQLException {
        long v = rs.getLong(col);
        return rs.wasNull() ? null : v;
    }

    private static Instant instant(Timestamp t) {
        return t == null ? null : t.toInstant();
    }
}
