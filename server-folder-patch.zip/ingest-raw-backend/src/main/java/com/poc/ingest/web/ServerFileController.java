package com.poc.ingest.web;

import com.poc.ingest.model.LoadView;
import com.poc.ingest.service.LoadService;
import com.poc.ingest.service.ServerFileService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/** Load files that are already on the server (CFT drop folder or copied by hand), without uploading them. */
@RestController
@RequestMapping("/api/server-files")
public class ServerFileController {

    private final ServerFileService serverFiles;
    private final LoadService loadService;

    public ServerFileController(ServerFileService serverFiles, LoadService loadService) {
        this.serverFiles = serverFiles;
        this.loadService = loadService;
    }

    /** Allowed folders and the files in them. */
    @GetMapping
    public Map<String, Object> list() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("roots", serverFiles.rootNames());
        m.put("files", serverFiles.list());
        return m;
    }

    @PostMapping("/load")
    public ResponseEntity<LoadView> load(@Valid @RequestBody Requests.ServerLoad body) throws IOException {
        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .body(loadService.submitFromServer(body.getProvider(), body.getPath()));
    }
}
