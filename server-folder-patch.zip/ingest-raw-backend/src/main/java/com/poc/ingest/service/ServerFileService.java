package com.poc.ingest.service;

import com.poc.ingest.config.IngestProperties;
import com.poc.ingest.web.ApiException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.LinkOption;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/**
 * Files already on the server (placed by CFT or copied by hand). A typed path is accepted only if, after resolving
 * "..", links and case, it lies inside one of the configured roots (ingest.server-file-roots). This is the
 * path-manipulation control for Fortify: user text never reaches the file system unchecked.
 */
@Service
public class ServerFileService {

    private static final Logger LOG = LoggerFactory.getLogger(ServerFileService.class);
    private static final int MAX_PATH_LENGTH = 1024;
    private static final int MAX_LISTED = 500;
    private static final int LIST_DEPTH = 4;

    private final IngestProperties props;

    public ServerFileService(IngestProperties props) {
        this.props = props;
    }

    /** A file the UI may offer. */
    public static final class ServerFile {
        private final String path;
        private final String name;
        private final long size;
        private final Instant modifiedAt;

        ServerFile(String path, String name, long size, Instant modifiedAt) {
            this.path = path;
            this.name = name;
            this.size = size;
            this.modifiedAt = modifiedAt;
        }

        public String getPath() { return path; }
        public String getName() { return name; }
        public long getSize() { return size; }
        public Instant getModifiedAt() { return modifiedAt; }
    }

    /** Allowed folders that exist, as real (canonical) paths. */
    public List<Path> roots() {
        List<Path> out = new ArrayList<>();
        for (String r : props.getServerFileRoots()) {
            if (r == null || r.trim().isEmpty()) {
                continue;
            }
            try {
                Path p = Paths.get(r.trim()).toRealPath();
                if (Files.isDirectory(p)) {
                    out.add(p);
                }
            } catch (IOException | InvalidPathException e) {
                LOG.warn("Configured server folder is not usable and is ignored");
            }
        }
        return out;
    }

    /** Validates a typed path and returns the real file inside an allowed folder. */
    public Path resolve(String typed) {
        List<Path> roots = roots();
        if (roots.isEmpty()) {
            throw new ApiException(HttpStatus.BAD_REQUEST,
                    "Loading from a server folder is not configured (ingest.server-file-roots)");
        }
        if (typed == null || typed.trim().isEmpty() || typed.length() > MAX_PATH_LENGTH || typed.indexOf('\0') >= 0) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Enter the full path of the file");
        }
        Path real;
        try {
            real = Paths.get(stripQuotes(typed.trim())).toAbsolutePath().normalize().toRealPath();
        } catch (NoSuchFileException e) {
            throw new ApiException(HttpStatus.NOT_FOUND, "File not found: " + typed.trim());
        } catch (IOException | InvalidPathException e) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Not a valid file path: " + typed.trim());
        }
        if (!isInside(real, roots)) {
            throw new ApiException(HttpStatus.FORBIDDEN, "The file must be inside one of the allowed folders: "
                    + describe(roots));
        }
        if (!Files.isRegularFile(real, LinkOption.NOFOLLOW_LINKS) || !Files.isReadable(real)) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Not a readable file: " + typed.trim());
        }
        return real;
    }

    /** Files under the allowed folders (a few levels deep), newest first, so the user can pick instead of typing. */
    public List<ServerFile> list() {
        List<ServerFile> out = new ArrayList<>();
        for (Path root : roots()) {
            try (Stream<Path> s = Files.walk(root, LIST_DEPTH)) {
                s.filter(p -> Files.isRegularFile(p, LinkOption.NOFOLLOW_LINKS))
                        .limit(MAX_LISTED)
                        .forEach(p -> add(out, p));
            } catch (IOException | java.io.UncheckedIOException e) {
                LOG.warn("Could not list a server folder: {}", e.getClass().getSimpleName());
            }
        }
        out.sort(Comparator.comparing(ServerFile::getModifiedAt).reversed());
        return out.size() > MAX_LISTED ? out.subList(0, MAX_LISTED) : out;
    }

    public List<String> rootNames() {
        List<String> names = new ArrayList<>();
        for (Path p : roots()) {
            names.add(p.toString());
        }
        return Collections.unmodifiableList(names);
    }

    private static void add(List<ServerFile> out, Path p) {
        try {
            out.add(new ServerFile(p.toString(), p.getFileName().toString(), Files.size(p),
                    Files.getLastModifiedTime(p).toInstant()));
        } catch (IOException e) {
            // file vanished or is locked while listing: just leave it out
        }
    }

    static boolean isInside(Path real, List<Path> roots) {
        boolean windows = real.getFileSystem().getSeparator().equals("\\");
        for (Path root : roots) {
            if (windows) {
                String f = real.toString().toLowerCase(Locale.ROOT);
                String r = root.toString().toLowerCase(Locale.ROOT);
                String rSlash = r.endsWith("\\") ? r : r + "\\";
                if (f.startsWith(rSlash)) {
                    return true;
                }
            } else if (real.startsWith(root) && !real.equals(root)) {
                return true;
            }
        }
        return false;
    }

    /** Windows "Copy as path" puts quotes around the path. */
    private static String stripQuotes(String s) {
        if (s.length() >= 2 && s.startsWith("\"") && s.endsWith("\"")) {
            return s.substring(1, s.length() - 1);
        }
        return s;
    }

    private static String describe(List<Path> roots) {
        StringBuilder sb = new StringBuilder();
        for (Path r : roots) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(r);
        }
        return sb.toString();
    }
}
