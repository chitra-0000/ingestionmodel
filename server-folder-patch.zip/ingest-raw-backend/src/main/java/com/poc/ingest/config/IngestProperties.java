package com.poc.ingest.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * All tuning knobs for the raw loader. Defaults are sized for the 5M records / 5 minutes target
 * and should be confirmed with the benchmark on the target Oracle instance.
 */
@ConfigurationProperties(prefix = "ingest")
public class IngestProperties {

    /** Folder for uploaded files while they are loaded and archived. Deleted per file afterwards. */
    private String storageDir = System.getProperty("java.io.tmpdir") + "/ingest-raw";

    /**
     * Folders the "Load from server path" screen may read from (comma separated). A typed path must resolve inside
     * one of them; anything else is refused. Empty = feature disabled.
     */
    private java.util.List<String> serverFileRoots = new java.util.ArrayList<>();

    /** Rows per JDBC executeBatch + commit. */
    private int batchSize = 5000;

    /** Parallel insert threads per load, each with its own connection. */
    private int writerThreads = 4;

    /** Batches buffered between the parser and the writers. Bounds heap: capacity x batchSize rows. */
    private int queueCapacity = 16;

    /** Files loaded at the same time. Others wait in the queue. */
    private int maxConcurrentLoads = 2;

    /** Files that may wait for a free loader before uploads are refused. */
    private int maxQueuedLoads = 50;

    /** XML only: elements read from the head of the file to find the record containers. */
    private int containerScanElements = 300_000;

    /** Records read from the head of the file to learn fields, repeating groups and value lengths. */
    private int sampleRecords = 20_000;

    /** XML only: same-name siblings after which an unknown wrapper is treated as a record container. */
    private int autoContainerThreshold = 1000;

    /** Share of a file's fields that must match an existing layout to reuse its table. Below it, a new table is created. */
    private double layoutMatchThreshold = 0.5;

    /** Byte limit of generated VARCHAR2 columns. 4000 unless MAX_STRING_SIZE=EXTENDED (then up to 32767). */
    private int varcharMaxBytes = 4000;

    /** Sampled values longer than this (bytes) make the column a CLOB instead of VARCHAR2. */
    private int clobThresholdBytes = 2000;

    /** Hard cap of generated C/G columns per table (Oracle allows 1000 incl. system columns). */
    private int maxDataColumns = 900;

    /** Appended to CREATE TABLE of runtime data tables. Empty for H2 tests. */
    private String tableOptions = "NOLOGGING";

    /** Optional optimizer hint for the insert, e.g. "APPEND_VALUES" (direct path; serialises writers). */
    private String insertHint = "";

    /** After loading, compare parsed record count with SELECT COUNT(*) of the load. */
    private boolean reconcileWithCount = true;

    /** Days the original file stays in INGEST_FILE_ARCHIVE. */
    private int archiveRetentionDays = 160;

    public String getStorageDir() { return storageDir; }
    public void setStorageDir(String storageDir) { this.storageDir = storageDir; }
    public java.util.List<String> getServerFileRoots() { return serverFileRoots; }
    public void setServerFileRoots(java.util.List<String> serverFileRoots) { this.serverFileRoots = serverFileRoots; }
    public int getBatchSize() { return batchSize; }
    public void setBatchSize(int batchSize) { this.batchSize = batchSize; }
    public int getWriterThreads() { return writerThreads; }
    public void setWriterThreads(int writerThreads) { this.writerThreads = writerThreads; }
    public int getQueueCapacity() { return queueCapacity; }
    public void setQueueCapacity(int queueCapacity) { this.queueCapacity = queueCapacity; }
    public int getMaxConcurrentLoads() { return maxConcurrentLoads; }
    public void setMaxConcurrentLoads(int maxConcurrentLoads) { this.maxConcurrentLoads = maxConcurrentLoads; }
    public int getMaxQueuedLoads() { return maxQueuedLoads; }
    public void setMaxQueuedLoads(int maxQueuedLoads) { this.maxQueuedLoads = maxQueuedLoads; }
    public int getContainerScanElements() { return containerScanElements; }
    public void setContainerScanElements(int containerScanElements) { this.containerScanElements = containerScanElements; }
    public int getSampleRecords() { return sampleRecords; }
    public void setSampleRecords(int sampleRecords) { this.sampleRecords = sampleRecords; }
    public int getAutoContainerThreshold() { return autoContainerThreshold; }
    public void setAutoContainerThreshold(int autoContainerThreshold) { this.autoContainerThreshold = autoContainerThreshold; }
    public double getLayoutMatchThreshold() { return layoutMatchThreshold; }
    public void setLayoutMatchThreshold(double layoutMatchThreshold) { this.layoutMatchThreshold = layoutMatchThreshold; }
    public int getVarcharMaxBytes() { return varcharMaxBytes; }
    public void setVarcharMaxBytes(int varcharMaxBytes) { this.varcharMaxBytes = varcharMaxBytes; }
    public int getClobThresholdBytes() { return clobThresholdBytes; }
    public void setClobThresholdBytes(int clobThresholdBytes) { this.clobThresholdBytes = clobThresholdBytes; }
    public int getMaxDataColumns() { return maxDataColumns; }
    public void setMaxDataColumns(int maxDataColumns) { this.maxDataColumns = maxDataColumns; }
    public String getTableOptions() { return tableOptions; }
    public void setTableOptions(String tableOptions) { this.tableOptions = tableOptions; }
    public String getInsertHint() { return insertHint; }
    public void setInsertHint(String insertHint) { this.insertHint = insertHint; }
    public boolean isReconcileWithCount() { return reconcileWithCount; }
    public void setReconcileWithCount(boolean reconcileWithCount) { this.reconcileWithCount = reconcileWithCount; }
    public int getArchiveRetentionDays() { return archiveRetentionDays; }
    public void setArchiveRetentionDays(int archiveRetentionDays) { this.archiveRetentionDays = archiveRetentionDays; }
}
