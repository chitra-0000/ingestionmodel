package com.poc.ingest.service;

import com.poc.ingest.config.IngestProperties;
import com.poc.ingest.flatten.ChangeStat;
import com.poc.ingest.flatten.RecordFlattener;
import com.poc.ingest.load.LoadPipeline;
import com.poc.ingest.model.FormatType;
import com.poc.ingest.model.Layout;
import com.poc.ingest.model.LoadStatus;
import com.poc.ingest.model.LoadView;
import com.poc.ingest.parse.FormatSniffer;
import com.poc.ingest.parse.NodeJson;
import com.poc.ingest.parse.ParseException;
import com.poc.ingest.repo.LayoutRepository;
import com.poc.ingest.repo.LoadLogRepository;
import com.poc.ingest.repo.StructureChangeRepository;
import com.poc.ingest.util.Safe;
import com.poc.ingest.web.ApiException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.time.Instant;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.locks.Lock;

/**
 * Orchestrates one file: store -> (archive in parallel) -> sample -> resolve table -> stream load -> reconcile
 * -> record new fields -> final status. Any failure removes the load's rows and marks it FAILED (fail-fast,
 * operator re-uploads; no automatic retry).
 */
@Service
public class LoadService {

    private static final Logger LOG = LoggerFactory.getLogger(LoadService.class);
    /** Placeholder until the archive step has read the server file. */
    private static final String SHA_PENDING = "PENDING";

    private final IngestProperties props;
    private final LoadLogRepository loads;
    private final LayoutRepository layouts;
    private final StructureChangeRepository changes;
    private final LayoutService layoutService;
    private final DdlService ddl;
    private final ArchiveService archive;
    private final LayoutLocks locks;
    private final StructureChangeService structureChanges;
    private final ServerFileService serverFiles;
    private final DataSource dataSource;
    private final ExecutorService loadExecutor;
    private final ExecutorService writerExecutor;
    private final ExecutorService archiveExecutor;

    @SuppressWarnings("java:S107") // Spring constructor injection of collaborators
    public LoadService(IngestProperties props, LoadLogRepository loads, LayoutRepository layouts,
                       StructureChangeRepository changes, LayoutService layoutService, DdlService ddl,
                       ArchiveService archive, LayoutLocks locks, StructureChangeService structureChanges,
                       ServerFileService serverFiles, DataSource dataSource,
                       @Qualifier("loadExecutor") ExecutorService loadExecutor,
                       @Qualifier("writerExecutor") ExecutorService writerExecutor,
                       @Qualifier("archiveExecutor") ExecutorService archiveExecutor) {
        this.props = props;
        this.loads = loads;
        this.layouts = layouts;
        this.changes = changes;
        this.layoutService = layoutService;
        this.ddl = ddl;
        this.archive = archive;
        this.locks = locks;
        this.structureChanges = structureChanges;
        this.serverFiles = serverFiles;
        this.dataSource = dataSource;
        this.loadExecutor = loadExecutor;
        this.writerExecutor = writerExecutor;
        this.archiveExecutor = archiveExecutor;
    }

    /** Stores the upload on disk (never in memory), registers it and queues the load. */
    public LoadView submit(String provider, String originalName, InputStream content) throws IOException {
        if (!Safe.isValidProvider(provider)) {
            throw new ApiException(HttpStatus.BAD_REQUEST,
                    "Provider must be 1-40 characters: letters, digits, space, '_' or '-'");
        }
        String fileName = Safe.fileName(originalName);
        Path dir = storageDir();
        long loadId = layouts.nextId();
        Path file = dir.resolve(loadId + ".dat");
        String sha;
        long size;
        try (DigestInputStream in = new DigestInputStream(content, sha256())) {
            size = Files.copy(in, file);
            sha = LayoutService.hex(in.getMessageDigest().digest());
        }
        if (size == 0) {
            ArchiveService.deleteQuietly(file);
            throw new ApiException(HttpStatus.BAD_REQUEST, "The file is empty");
        }
        loads.insertQueued(loadId, provider.trim(), fileName, size, sha);
        try {
            loadExecutor.submit(() -> process(loadId, file, true, provider.trim(), fileName, size, sha));
        } catch (RejectedExecutionException e) {
            loads.finish(loadId, LoadStatus.FAILED, null, null, null, null, null,
                    "Too many files waiting; upload again later", null);
            ArchiveService.deleteQuietly(file);
            throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE, "Too many files are waiting to load; try later");
        }
        LOG.info("Load {} queued: provider={} file={} size={}", loadId, Safe.log(provider), Safe.log(fileName), size);
        return loads.find(loadId);
    }

    /**
     * Loads a file that is already on the server, in place: no upload, no copy. The file is only read; it stays where
     * it is. The SHA-256 is computed while archiving (one extra read, in parallel with the load).
     */
    public LoadView submitFromServer(String provider, String typedPath) throws IOException {
        if (!Safe.isValidProvider(provider)) {
            throw new ApiException(HttpStatus.BAD_REQUEST,
                    "Provider must be 1-40 characters: letters, digits, space, '_' or '-'");
        }
        Path file = serverFiles.resolve(typedPath);
        long size = Files.size(file);
        if (size == 0) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "The file is empty");
        }
        String fileName = Safe.fileName(file.getFileName().toString());
        long loadId = layouts.nextId();
        loads.insertQueued(loadId, provider.trim(), fileName, size, SHA_PENDING);
        try {
            loadExecutor.submit(() -> process(loadId, file, false, provider.trim(), fileName, size, null));
        } catch (RejectedExecutionException e) {
            loads.finish(loadId, LoadStatus.FAILED, null, null, null, null, null,
                    "Too many files waiting; try again later", null);
            throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE, "Too many files are waiting to load; try later");
        }
        LOG.info("Load {} queued from server folder: provider={} file={} size={}", loadId, Safe.log(provider),
                Safe.log(fileName), size);
        return loads.find(loadId);
    }

    /**
     * @param ownsFile true for uploads (temporary copy, deleted afterwards); false for server-folder files, which are
     *                 only read and stay where the user placed them
     * @param sha      null when not known yet (computed by the archive step)
     */
    void process(long loadId, Path file, boolean ownsFile, String provider, String fileName, long size, String sha) {
        Instant started = Instant.now();
        loads.markLoading(loadId);
        Future<Boolean> archived = archiveExecutor.submit(() -> archive.archive(loadId, file, fileName, size, sha));
        Layout layout = null;
        Lock readLock = null;
        try {
            FormatType format = FormatSniffer.detect(file);
            loads.setFormat(loadId, format);
            LayoutService.Sample sample = layoutService.sample(file, format);
            LayoutService.Resolution resolution = layoutService.resolve(provider, format, sample);
            layout = resolution.getLayout();

            readLock = locks.forLayout(layout.getLayoutId()).readLock();
            readLock.lock();
            layout = layouts.findById(layout.getLayoutId()); // columns approved meanwhile are included
            loads.setLayout(loadId, format, layout.getLayoutId(), layout.getTableName());

            RecordFlattener flattener = new RecordFlattener(layout.getDescriptor(), props.getVarcharMaxBytes(),
                    format != FormatType.CSV);
            LoadPipeline.Job job = new LoadPipeline.Job()
                    .loadId(loadId).provider(provider).tableName(layout.getTableName())
                    .insertSql(ddl.insertSql(layout.getTableName(), layout.getDescriptor()))
                    .columns(layout.getDescriptor().getColumns())
                    .containerKinds(LayoutService.containerKinds(layout, sample))
                    .knownContainers(LayoutService.knownContainers(layout, sample))
                    .engine(layoutService.engineFor(format)).flattener(flattener)
                    .batchSize(props.getBatchSize()).writerThreads(props.getWriterThreads())
                    .queueCapacity(props.getQueueCapacity());

            LoadPipeline.Result r;
            try (InputStream in = LayoutService.open(file)) {
                r = new LoadPipeline(dataSource, writerExecutor).run(job, in);
            }
            reconcile(layout.getTableName(), loadId, r);
            readLock.unlock();
            readLock = null;

            int pending = recordChanges(layout.getLayoutId(), loadId, flattener);
            String msg = null;
            if (pending > 0 && resolution.isCreated()) {
                // brand-new table: there is no existing structure to protect, so fields met after sampling
                // become columns straight away instead of waiting for approval
                int added = structureChanges.autoApproveNewLayout(layout.getLayoutId(), loadId);
                pending -= added;
                msg = added + " field(s) found after sampling were added as columns automatically (new table)";
            }
            if (r.getLargeRows() > 0) {
                String large = r.getLargeRows() + " row(s) had a value over 4000 bytes and were inserted one by one";
                msg = msg == null ? large : msg + ". " + large;
            }
            boolean archiveOk = Boolean.TRUE.equals(archived.get());
            LoadStatus status = pending > 0 ? LoadStatus.NEW_FIELDS : LoadStatus.SUCCESS;
            if (!archiveOk) {
                msg = (msg == null ? "" : msg + ". ") + "Data loaded, but the original file could not be archived";
            }
            loads.finish(loadId, status, r.getDataParsed(), r.getDataWritten(), r.getRefWritten(), pending, started,
                    msg, r.getEnvelope() == null ? null : NodeJson.toJson(r.getEnvelope()));
            LOG.info("Load {} {}: {} rows into {}, {} reference rows, {} large rows, {} new fields, {} ms", loadId,
                    status, r.getDataWritten(), layout.getTableName(), r.getRefWritten(), r.getLargeRows(), pending,
                    Instant.now().toEpochMilli() - started.toEpochMilli());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            fail(loadId, layout, started, "Load interrupted", e);
        } catch (ParseException e) {
            fail(loadId, layout, started, e.getMessage(), e);
        } catch (IOException | SQLException | ExecutionException | RuntimeException e) {
            fail(loadId, layout, started, "Load failed: " + e.getClass().getSimpleName() + ": " + e.getMessage(), e);
        } finally {
            if (readLock != null) {
                readLock.unlock();
            }
            waitQuietly(archived);
            if (ownsFile) {
                ArchiveService.deleteQuietly(file);
            }
        }
    }

    private void reconcile(String table, long loadId, LoadPipeline.Result r) {
        if (r.getDataWritten() != r.getDataParsed() || r.getRefWritten() != r.getRefParsed()) {
            throw new IllegalStateException("Reconciliation failed: parsed " + r.getDataParsed() + "/"
                    + r.getRefParsed() + " but wrote " + r.getDataWritten() + "/" + r.getRefWritten());
        }
        if (props.isReconcileWithCount()) {
            long inDb = ddl.countLoadRows(table, loadId);
            long refInDb = ddl.countRefRows(loadId);
            if (inDb != r.getDataParsed() || refInDb != r.getRefParsed()) {
                throw new IllegalStateException("Reconciliation failed: file has " + r.getDataParsed() + " records and "
                        + r.getRefParsed() + " reference rows, table has " + inDb + " and " + refInDb);
            }
        }
    }

    private int recordChanges(long layoutId, long loadId, RecordFlattener flattener) {
        int pending = 0;
        for (ChangeStat s : flattener.changes()) {
            if (s.getPath().length() > StructureChangeRepository.MAX_PATH_LENGTH) {
                continue; // still kept in EXTRA_JSON; too long to become a column name mapping
            }
            if (changes.upsert(layoutId, loadId, s)) {
                pending++;
            }
        }
        return pending;
    }

    private void fail(long loadId, Layout layout, Instant started, String message, Exception e) {
        LOG.error("Load {} failed: {}", loadId, Safe.log(message), e);
        try {
            ddl.deleteLoad(layout == null ? null : layout.getTableName(), loadId);
        } catch (DataAccessException cleanup) {
            LOG.error("Cleanup of load {} failed; delete its rows manually by LOAD_ID", loadId, cleanup);
        }
        loads.finish(loadId, LoadStatus.FAILED, null, null, null, null, started, message, null);
    }

    private static void waitQuietly(Future<?> f) {
        try {
            f.get();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (ExecutionException e) {
            LOG.error("Archive task failed", e.getCause());
        }
    }

    /** Loads interrupted by a restart are marked FAILED and cleaned, so they can be re-uploaded. */
    @EventListener(ApplicationReadyEvent.class)
    public void recoverUnfinished() {
        for (LoadView v : loads.unfinished()) {
            try {
                ddl.deleteLoad(v.getTableName(), v.getLoadId());
            } catch (DataAccessException e) {
                LOG.error("Cleanup of interrupted load {} failed", v.getLoadId(), e);
            }
            loads.finish(v.getLoadId(), LoadStatus.FAILED, null, null, null, null, v.getStartedAt(),
                    "Interrupted by an application restart; upload the file again", null);
        }
    }

    private Path storageDir() throws IOException {
        Path dir = Paths.get(props.getStorageDir()).toAbsolutePath().normalize();
        Files.createDirectories(dir);
        return dir;
    }

    private static MessageDigest sha256() {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }
}
