package com.poc.ingest.web;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.List;

/** Request bodies, validated before they reach the services. */
public final class Requests {

    private Requests() {
    }

    /** Approve or reject selected new fields. */
    public static class Decision {
        @NotEmpty
        @Size(max = 500)
        private List<Long> changeIds;

        @NotBlank
        @Size(max = 100)
        @Pattern(regexp = "^[\\p{L}0-9 ._@'-]+$", message = "contains invalid characters")
        private String decidedBy;

        @Size(max = 1000)
        private String comment;

        private boolean backfill;

        public List<Long> getChangeIds() { return changeIds; }
        public void setChangeIds(List<Long> changeIds) { this.changeIds = changeIds; }
        public String getDecidedBy() { return decidedBy; }
        public void setDecidedBy(String decidedBy) { this.decidedBy = decidedBy; }
        public String getComment() { return comment; }
        public void setComment(String comment) { this.comment = comment; }
        public boolean isBackfill() { return backfill; }
        public void setBackfill(boolean backfill) { this.backfill = backfill; }
    }

    /** Load a file that is already in an allowed server folder. */
    public static class ServerLoad {
        @NotBlank
        @Size(max = 40)
        private String provider;

        @NotBlank
        @Size(max = 1024)
        private String path;

        public String getProvider() { return provider; }
        public void setProvider(String provider) { this.provider = provider; }
        public String getPath() { return path; }
        public void setPath(String path) { this.path = path; }
    }
}
