export type LoadStatus = 'QUEUED' | 'LOADING' | 'SUCCESS' | 'NEW_FIELDS' | 'FAILED';
export type ArchiveStatus = 'PENDING' | 'ARCHIVED' | 'FAILED' | 'PURGED';
export type ChangeStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface LoadView {
  loadId: number;
  provider: string;
  format: 'XML' | 'JSON' | 'CSV' | null;
  layoutId: number | null;
  tableName: string | null;
  fileName: string;
  fileSize: number;
  fileSha256: string;
  status: LoadStatus;
  archiveStatus: ArchiveStatus;
  recordsParsed: number | null;
  rowsInserted: number | null;
  refRows: number | null;
  newFieldCount: number | null;
  uploadedAt: string;
  startedAt: string | null;
  finishedAt: string | null;
  durationMs: number | null;
  message: string | null;
}

export interface StructureChange {
  changeId: number;
  layoutId: number;
  tableName: string;
  firstLoadId: number;
  lastLoadId: number;
  fieldPath: string;
  fieldKind: 'SCALAR' | 'GROUP';
  occurrences: number;
  maxLength: number;
  sampleValue: string | null;
  status: ChangeStatus;
  columnName: string | null;
  backfilledRows: number | null;
  decidedBy: string | null;
  decidedAt: string | null;
  decisionComment: string | null;
  detectedAt: string;
}

export interface ApproveOutcome {
  changes: StructureChange[];
  notes: string[];
}

export interface Decision {
  changeIds: number[];
  decidedBy: string;
  comment: string;
  backfill: boolean;
}
