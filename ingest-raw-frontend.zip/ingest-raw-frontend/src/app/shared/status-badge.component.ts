import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

@Component({
  selector: 'app-status-badge',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<span class="badge" [ngClass]="'badge-' + status.toLowerCase()">{{ label }}</span>`
})
export class StatusBadgeComponent {
  @Input() status = '';

  get label(): string {
    switch (this.status) {
      case 'NEW_FIELDS': return 'New fields';
      case 'SUCCESS': return 'Success';
      case 'FAILED': return 'Failed';
      case 'LOADING': return 'Loading';
      case 'QUEUED': return 'Queued';
      case 'PENDING': return 'Pending';
      case 'APPROVED': return 'Approved';
      case 'REJECTED': return 'Rejected';
      default: return this.status;
    }
  }
}
