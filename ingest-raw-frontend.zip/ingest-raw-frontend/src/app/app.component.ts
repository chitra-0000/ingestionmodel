import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <header class="topbar">
      <div class="brand"><span class="logo"></span>Raw Ingestion</div>
      <span class="tag">Provider files → Oracle, as received</span>
    </header>
    <main class="page"><router-outlet></router-outlet></main>
  `
})
export class AppComponent {}
