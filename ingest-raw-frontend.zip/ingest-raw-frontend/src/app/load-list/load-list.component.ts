import { Component, OnDestroy, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { EMPTY, Subject, Subscription, merge, timer } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';
import { ApiService } from '../shared/api.service';
import { LoadView } from '../shared/models';

/** Upload + history. Polls every 3 s so running loads update by themselves. */
@Component({
  selector: 'app-load-list',
  templateUrl: './load-list.component.html'
})
export class LoadListComponent implements OnInit, OnDestroy {
  loads: LoadView[] = [];
  error = '';
  private readonly refresh$ = new Subject<void>();
  private sub?: Subscription;

  constructor(readonly api: ApiService) {}

  ngOnInit(): void {
    this.sub = merge(timer(0, 3000), this.refresh$)
      .pipe(
        switchMap(() =>
          this.api.loads().pipe(
            catchError((err: HttpErrorResponse) => {
              this.error = ApiService.message(err); // keep polling; the server may come back
              return EMPTY;
            })
          )
        )
      )
      .subscribe(l => {
        this.loads = l;
        this.error = '';
      });
  }

  ngOnDestroy(): void {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }

  onUploaded(): void {
    this.refresh$.next();
  }

  trackById(_: number, l: LoadView): number {
    return l.loadId;
  }

  isRunning(l: LoadView): boolean {
    return l.status === 'QUEUED' || l.status === 'LOADING';
  }
}
