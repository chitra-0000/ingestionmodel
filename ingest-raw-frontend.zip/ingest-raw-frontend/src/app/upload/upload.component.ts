import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { HttpErrorResponse, HttpEventType } from '@angular/common/http';
import { ApiService } from '../shared/api.service';
import { LoadView } from '../shared/models';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html'
})
export class UploadComponent implements OnInit {
  @Output() uploaded = new EventEmitter<LoadView>();

  readonly providerPattern = '^[A-Za-z0-9][A-Za-z0-9 _-]{0,39}$';
  provider = '';
  file: File | null = null;
  providers: string[] = [];
  progress: number | null = null;
  error = '';
  info = '';

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.api.providers().subscribe(p => (this.providers = p), () => (this.providers = []));
  }

  onFile(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.file = input.files && input.files.length ? input.files[0] : null;
    this.error = '';
    this.info = '';
  }

  get canUpload(): boolean {
    return !!this.file && new RegExp(this.providerPattern).test(this.provider.trim()) && this.progress === null;
  }

  upload(fileInput: HTMLInputElement): void {
    if (!this.file || !this.canUpload) {
      return;
    }
    this.error = '';
    this.info = '';
    this.progress = 0;
    const provider = this.provider.trim();
    this.api.upload(provider, this.file).subscribe(
      ev => {
        if (ev.type === HttpEventType.UploadProgress && ev.total) {
          this.progress = Math.round((100 * ev.loaded) / ev.total);
        } else if (ev.type === HttpEventType.Response && ev.body) {
          this.info = `Load ${ev.body.loadId} queued — ${ev.body.fileName}`;
          this.uploaded.emit(ev.body);
          if (!this.providers.includes(provider)) {
            this.providers = [...this.providers, provider].sort();
          }
          this.file = null;
          fileInput.value = '';
          this.progress = null;
        }
      },
      (err: HttpErrorResponse) => {
        this.error = ApiService.message(err);
        this.progress = null;
      }
    );
  }
}
