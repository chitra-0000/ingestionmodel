import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { EMPTY, Subscription, timer } from 'rxjs';
import { catchError, switchMap, takeWhile } from 'rxjs/operators';
import { ApiService } from '../shared/api.service';
import { Decision, LoadView, StructureChange } from '../shared/models';

/** Load details, downloads, and the structure-change review with Approve / Reject. */
@Component({
  selector: 'app-load-detail',
  templateUrl: './load-detail.component.html'
})
export class LoadDetailComponent implements OnInit, OnDestroy {
  load?: LoadView;
  changes: StructureChange[] = [];
  selected = new Set<number>();
  decidedBy = '';
  comment = '';
  backfill = true;
  busy = false;
  error = '';
  notes: string[] = [];
  private id = 0;
  private sub?: Subscription;

  constructor(private route: ActivatedRoute, readonly api: ApiService) {}

  ngOnInit(): void {
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    // poll while the load is still running, then load the field review once
    this.sub = timer(0, 2000)
      .pipe(
        switchMap(() => this.api.load(this.id).pipe(catchError((e: HttpErrorResponse) => this.fail(e)))),
        takeWhile(l => l.status === 'QUEUED' || l.status === 'LOADING', true)
      )
      .subscribe(l => {
        this.load = l;
        if (l.status !== 'QUEUED' && l.status !== 'LOADING') {
          this.loadChanges();
        }
      });
  }

  ngOnDestroy(): void {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }

  get pending(): StructureChange[] {
    return this.changes.filter(c => c.status === 'PENDING');
  }

  get decided(): StructureChange[] {
    return this.changes.filter(c => c.status !== 'PENDING');
  }

  get allSelected(): boolean {
    return this.pending.length > 0 && this.pending.every(c => this.selected.has(c.changeId));
  }

  get canDecide(): boolean {
    return !this.busy && this.selected.size > 0 && this.decidedBy.trim().length > 0;
  }

  toggle(id: number, on: boolean): void {
    if (on) {
      this.selected.add(id);
    } else {
      this.selected.delete(id);
    }
  }

  toggleAll(on: boolean): void {
    this.selected = new Set(on ? this.pending.map(c => c.changeId) : []);
  }

  approve(): void {
    this.decide(true);
  }

  reject(): void {
    this.decide(false);
  }

  private decide(approve: boolean): void {
    if (!this.canDecide) {
      return;
    }
    const d: Decision = {
      changeIds: Array.from(this.selected),
      decidedBy: this.decidedBy.trim(),
      comment: this.comment.trim(),
      backfill: this.backfill
    };
    this.busy = true;
    this.error = '';
    this.notes = [];
    const done = () => {
      this.busy = false;
      this.selected.clear();
      this.comment = '';
      this.loadChanges();
      this.api.load(this.id).subscribe(l => (this.load = l));
    };
    if (approve) {
      this.api.approve(d).subscribe(o => {
        this.notes = o.notes;
        done();
      }, (e: HttpErrorResponse) => this.decisionFailed(e));
    } else {
      this.api.reject(d).subscribe(() => done(), (e: HttpErrorResponse) => this.decisionFailed(e));
    }
  }

  private decisionFailed(e: HttpErrorResponse): void {
    this.busy = false;
    this.error = ApiService.message(e);
  }

  private loadChanges(): void {
    this.api.structureChanges(this.id).subscribe(c => {
      this.changes = c;
      this.selected = new Set(Array.from(this.selected).filter(id => c.some(x => x.changeId === id && x.status === 'PENDING')));
    }, (e: HttpErrorResponse) => (this.error = ApiService.message(e)));
  }

  private fail(e: HttpErrorResponse) {
    this.error = ApiService.message(e);
    return EMPTY;
  }

  trackChange(_: number, c: StructureChange): number {
    return c.changeId;
  }
}
