# Raw Ingestion – frontend

Angular 11.2.4 (same baseline as regliss-ui-js), works with Node 14.17.6.

Screens:

* **Loads** – upload a provider file, then watch the load history (refreshes every 3 s). Each row has
  *Report* (CSV), *Original* (the archived file) and *Details* / *Review*.
* **Load details** – counts, reconciliation, SHA-256, downloads, and the **Structure changes** review:
  tick new fields, enter your name and a comment, then **Approve & add columns** (optionally filling rows already
  loaded) or **Reject**. Decisions are listed underneath.

## Run

```
npm install
npm start            # http://localhost:4200, /api is proxied to http://localhost:8080 (proxy.conf.json)
npm run build        # production build in dist/ingest-raw-frontend
```

On Node 17 or newer the Angular 11 build needs `NODE_OPTIONS=--openssl-legacy-provider`; Node 14 does not.

For deployment, serve `dist/ingest-raw-frontend` behind the same host as the backend (or a reverse proxy that maps
`/api` to it), so no CORS configuration is needed.
