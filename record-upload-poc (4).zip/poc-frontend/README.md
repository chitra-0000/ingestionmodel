# Record upload POC – frontend

Angular 11.2 (same versions as the Regliss UI project), Node 14, npm 6 or 8.

1. Make sure npm is logged in to Artifactory (user `.npmrc` with `registry` and `_auth`).
2. `npm install`
3. `npm start` (backend must run on port 8080; `/api` is forwarded by `proxy.conf.json`)
4. Open http://localhost:4200

`npm test` runs the unit tests in headless Chrome; `npm run test:watch` keeps them running.
