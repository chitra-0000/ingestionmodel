/** One uploaded file and the result of loading it. */
export interface UploadSummary {
  uploadId: number;
  fileName: string;
  format: 'XML' | 'CSV';
  profileName: string | null;
  fileSizeBytes: number;
  status: 'PROCESSING' | 'COMPLETED' | 'FAILED';
  recordsRead: number;
  recordsLoaded: number;
  recordsRejected: number;
  message: string | null;
  startedAt: string;
  endedAt: string | null;
  durationMs: number | null;
}

/** A row with a problem: ERROR (not loaded) or WARNING (loaded). */
export interface RejectRow {
  rowNo: number;
  externalRef: string | null;
  severity: 'ERROR' | 'WARNING';
  reason: string;
}

export interface UploadResult {
  upload: UploadSummary;
  rejects: RejectRow[];
}

/** One line of the records table. */
export interface RecordSummary {
  rowNo: number;
  externalReference: string;
  type: RecordType;
  name: string | null;
  aliases: string[];
  dates: string[];
  countries: string[];
  lists: string[];
  childCount: number;
}

export interface RecordPage {
  items: RecordSummary[];
  total: number;
  page: number;
  size: number;
}

/** The canonical record exactly as stored (every field, null when the file gave none). */
export interface RecordDetail {
  uploadId: number;
  rowNo: number;
  record: { [field: string]: unknown };
}

export type RecordType = 'INDIVIDUAL' | 'ENTITY' | 'VESSEL';
export type FileFormat = 'XML' | 'CSV';
export type RuleKind = 'RECORD' | 'FIELD' | 'COLLECTION' | 'LOOKUP' | 'GROUP_BY';

export interface MappingRule {
  kind: RuleKind;
  target: string | null;
  source: string | null;
  transform: string;
  param: string | null;
}

export interface MappingProfile {
  id: number | null;
  name: string;
  format: FileFormat;
  encoding: string | null;
  delimiter: string | null;
  rules: MappingRule[];
}

export interface ProfileSummary {
  id: number;
  name: string;
  format: FileFormat;
  ruleCount: number;
  updatedAt: string | null;
}

/** A canonical field a mapping can write to. */
export interface TargetField {
  path: string;
  label: string;
  section: string;
  collection: string | null;
  maxLength: number;
  multiValue?: boolean;
}

export interface Targets {
  fields: TargetField[];
  collections: { name: string; label: string }[];
  transforms: { name: string; label: string }[];
  recordTypes: RecordType[];
}

export interface SourceField {
  path: string;
  sample: string | null;
  count: number;
  values: string[];
  suggestedTarget: string | null;
}

export interface InspectResult {
  format: FileFormat;
  encoding: string | null;
  delimiter: string | null;
  sampled: number;
  total: number;
  fields: SourceField[];
  recordElements: { name: string; path: string; count: number; selected: boolean; suggestedType: RecordType }[];
  lookups: { path: string; count: number; attributes: string[]; sample: string | null }[];
  notes: string[];
}

/** Error body returned by the backend. */
export interface ApiError {
  status: number;
  message: string;
  errorId?: string;
}
