import { HttpErrorResponse, HttpEventType } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { messageOf } from './errors';
import { MappingProfile, ProfileSummary, RejectRow, UploadSummary } from './models';
import { UploadApiService } from './upload-api.service';

type Phase = 'idle' | 'uploading' | 'processing' | 'done' | 'error';

const ACCEPTED = ['.xml', '.csv', '.txt', '.tsv'];

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, OnDestroy {
  selectedFile: File | null = null;
  dragOver = false;
  phase: Phase = 'idle';
  progress = 0;
  errorMessage = '';

  current: UploadSummary | null = null;
  rejects: RejectRow[] = [];
  history: UploadSummary[] = [];
  historyError = '';

  profiles: ProfileSummary[] = [];
  profileId: number | null = null;
  profilesError = '';
  /** Mapping editor: open, and the profile it edits (null = new mapping). */
  editorOpen = false;
  editorProfileId: number | null = null;
  savedNotice = '';

  private uploadSub?: Subscription;

  constructor(private readonly api: UploadApiService) {}

  ngOnInit(): void {
    this.loadHistory();
    this.loadProfiles();
  }

  ngOnDestroy(): void {
    this.uploadSub?.unsubscribe();
  }

  get selectedFormat(): 'XML' | 'CSV' | '' {
    const name = this.selectedFile?.name.toLowerCase() ?? '';
    if (!name) {
      return '';
    }
    return name.endsWith('.xml') ? 'XML' : 'CSV';
  }

  /** Profiles usable for the chosen file (all of them before a file is chosen). */
  get usableProfiles(): ProfileSummary[] {
    const format = this.selectedFormat;
    return format ? this.profiles.filter((p) => p.format === format) : this.profiles;
  }

  get busy(): boolean {
    return this.phase === 'uploading' || this.phase === 'processing';
  }

  onFileInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.choose(input.files && input.files.length ? input.files[0] : null);
    input.value = '';
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    this.dragOver = true;
  }

  onDragLeave(): void {
    this.dragOver = false;
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    this.dragOver = false;
    const files = event.dataTransfer?.files;
    this.choose(files && files.length ? files[0] : null);
  }

  choose(file: File | null): void {
    this.errorMessage = '';
    if (!file) {
      return;
    }
    const lower = file.name.toLowerCase();
    if (!ACCEPTED.some((ext) => lower.endsWith(ext))) {
      this.selectedFile = null;
      this.phase = 'error';
      this.errorMessage = `"${file.name}" is not an .xml or .csv file. Choose an XML or a CSV file.`;
      return;
    }
    this.selectedFile = file;
    this.phase = 'idle';
    this.pickProfile();
  }

  /** Keeps the chosen profile when it fits the file's format, otherwise takes the first that does. */
  pickProfile(): void {
    const usable = this.usableProfiles;
    if (!usable.some((p) => p.id === this.profileId)) {
      this.profileId = usable.length ? usable[0].id : null;
    }
  }

  openEditor(profileId: number | null): void {
    this.editorProfileId = profileId;
    this.editorOpen = true;
    this.savedNotice = '';
  }

  onProfileSaved(profile: MappingProfile): void {
    this.editorOpen = false;
    this.savedNotice = `Mapping "${profile.name}" saved.`;
    this.loadProfiles(profile.id);
  }

  loadProfiles(select: number | null = null): void {
    this.api.profiles().subscribe({
      next: (list) => {
        this.profiles = list;
        this.profilesError = '';
        if (select) {
          this.profileId = select;
        }
        this.pickProfile();
      },
      error: (err: HttpErrorResponse) => (this.profilesError = messageOf(err)),
    });
  }

  profileName(id: number | null): string {
    return this.profiles.find((p) => p.id === id)?.name ?? '';
  }

  upload(): void {
    if (!this.selectedFile || this.busy) {
      return;
    }
    if (!this.profileId) {
      this.phase = 'error';
      this.errorMessage = 'Choose a mapping for this file, or create one with "New mapping from this file".';
      return;
    }
    this.phase = 'uploading';
    this.progress = 0;
    this.errorMessage = '';
    this.savedNotice = '';
    this.uploadSub = this.api.upload(this.selectedFile, this.profileId).subscribe({
      next: (event) => {
        if (event.type === HttpEventType.UploadProgress) {
          this.progress = event.total ? Math.round((event.loaded / event.total) * 100) : 0;
          if (this.progress >= 100) {
            this.phase = 'processing';
          }
        } else if (event.type === HttpEventType.Response && event.body) {
          this.current = event.body.upload;
          this.rejects = event.body.rejects;
          this.phase = event.body.upload.status === 'FAILED' ? 'error' : 'done';
          this.errorMessage = event.body.upload.status === 'FAILED' ? event.body.upload.message ?? '' : '';
          if (event.body.upload.status !== 'FAILED') {
            this.selectedFile = null;
          }
          this.loadHistory();
        }
      },
      error: (err: HttpErrorResponse) => {
        this.phase = 'error';
        this.errorMessage = messageOf(err);
        this.current = null;
        this.rejects = [];
      },
    });
  }

  show(upload: UploadSummary): void {
    this.current = upload;
    this.rejects = [];
    this.phase = upload.status === 'FAILED' ? 'error' : 'done';
    this.errorMessage = upload.status === 'FAILED' ? upload.message ?? '' : '';
    this.api.rejects(upload.uploadId, 100).subscribe({ next: (rows) => (this.rejects = rows) });
  }

  loadHistory(): void {
    this.api.recent(20).subscribe({
      next: (rows) => {
        this.history = rows;
        this.historyError = '';
      },
      error: (err: HttpErrorResponse) => (this.historyError = messageOf(err)),
    });
  }

  get errorCount(): number {
    return this.rejects.filter((r) => r.severity !== 'WARNING').length;
  }

  fileSize(bytes: number): string {
    if (bytes < 1024) {
      return `${bytes} B`;
    }
    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }

  duration(ms: number | null): string {
    if (ms === null || ms === undefined) {
      return '–';
    }
    return ms < 1000 ? `${ms} ms` : `${(ms / 1000).toFixed(1)} s`;
  }
}
