import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { MappingEditorComponent } from './mapping/mapping-editor.component';
import { RecordViewComponent } from './record-view/record-view.component';
import { RecordsTableComponent } from './records/records-table.component';

@NgModule({
  declarations: [AppComponent, RecordsTableComponent, RecordViewComponent, MappingEditorComponent],
  imports: [BrowserModule, HttpClientModule, FormsModule],
  bootstrap: [AppComponent],
})
export class AppModule {}
