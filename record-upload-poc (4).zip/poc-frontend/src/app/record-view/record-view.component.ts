import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { messageOf } from '../errors';
import { RecordDetail } from '../models';
import { UploadApiService } from '../upload-api.service';

interface Entry {
  key: string;
  value: unknown;
}

/**
 * One canonical record exactly as stored: every field of the model, child objects as objects,
 * null where the file gave no value. Also shows the JSON for copying.
 */
@Component({
  selector: 'app-record-view',
  templateUrl: './record-view.component.html',
  styleUrls: ['./record-view.component.scss'],
})
export class RecordViewComponent implements OnChanges {
  @Input() uploadId!: number;
  @Input() rowNo!: number;
  @Output() closed = new EventEmitter<void>();

  detail: RecordDetail | null = null;
  error = '';
  showJson = false;
  hideEmpty = false;

  constructor(private readonly api: UploadApiService) {}

  ngOnChanges(): void {
    this.detail = null;
    this.error = '';
    this.api.record(this.uploadId, this.rowNo).subscribe({
      next: (d) => (this.detail = d),
      error: (err: HttpErrorResponse) => (this.error = messageOf(err)),
    });
  }

  get json(): string {
    return this.detail ? JSON.stringify(this.detail.record, null, 2) : '';
  }

  entries(value: unknown): Entry[] {
    if (value === null || typeof value !== 'object' || Array.isArray(value)) {
      return [];
    }
    const object = value as { [key: string]: unknown };
    return Object.keys(object)
      .filter((key) => !this.hideEmpty || !this.isEmpty(object[key]))
      .map((key) => ({ key, value: object[key] }));
  }

  items(value: unknown): unknown[] {
    return Array.isArray(value) ? value : [];
  }

  kind(value: unknown): 'null' | 'array' | 'object' | 'value' {
    if (value === null || value === undefined) {
      return 'null';
    }
    if (Array.isArray(value)) {
      return 'array';
    }
    return typeof value === 'object' ? 'object' : 'value';
  }

  text(value: unknown): string {
    return typeof value === 'string' ? `"${value}"` : String(value);
  }

  private isEmpty(value: unknown): boolean {
    return value === null || value === undefined || (Array.isArray(value) && value.length === 0);
  }
}
