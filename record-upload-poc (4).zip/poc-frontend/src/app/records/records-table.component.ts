import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnChanges, OnDestroy, OnInit } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { messageOf } from '../errors';
import { RecordPage } from '../models';
import { UploadApiService } from '../upload-api.service';

const PAGE_SIZE = 25;

/** Records of one upload as read back from the database, with search and paging. */
@Component({
  selector: 'app-records-table',
  templateUrl: './records-table.component.html',
  styleUrls: ['./records-table.component.scss'],
})
export class RecordsTableComponent implements OnInit, OnChanges, OnDestroy {
  @Input() uploadId!: number;

  search = '';
  page = 0;
  result: RecordPage | null = null;
  loading = false;
  error = '';
  /** Row number of the record open in the canonical record panel. */
  openRow: number | null = null;

  private readonly searchChanges = new Subject<string>();
  private searchSub?: Subscription;
  private loadSub?: Subscription;

  constructor(private readonly api: UploadApiService) {}

  ngOnInit(): void {
    this.searchSub = this.searchChanges.pipe(debounceTime(300), distinctUntilChanged()).subscribe(() => {
      this.page = 0;
      this.load();
    });
  }

  ngOnChanges(): void {
    this.page = 0;
    this.search = '';
    this.openRow = null;
    this.load();
  }

  open(rowNo: number): void {
    this.openRow = this.openRow === rowNo ? null : rowNo;
  }

  ngOnDestroy(): void {
    this.searchSub?.unsubscribe();
    this.loadSub?.unsubscribe();
  }

  onSearch(value: string): void {
    this.search = value;
    this.searchChanges.next(value);
  }

  get rangeText(): string {
    if (!this.result || this.result.total === 0) {
      return '';
    }
    const first = this.result.page * this.result.size + 1;
    const last = Math.min(first + this.result.items.length - 1, this.result.total);
    return `${first}–${last} of ${this.result.total}`;
  }

  get hasNext(): boolean {
    return !!this.result && (this.result.page + 1) * this.result.size < this.result.total;
  }

  previous(): void {
    if (this.page > 0) {
      this.page--;
      this.load();
    }
  }

  next(): void {
    if (this.hasNext) {
      this.page++;
      this.load();
    }
  }

  typeLabel(type: string): string {
    switch (type) {
      case 'INDIVIDUAL':
        return 'Individual';
      case 'ENTITY':
        return 'Entity';
      case 'VESSEL':
        return 'Vessel';
      default:
        return type;
    }
  }

  load(): void {
    if (this.uploadId === undefined || this.uploadId === null) {
      return;
    }
    this.loading = true;
    this.loadSub?.unsubscribe();
    this.loadSub = this.api.records(this.uploadId, this.search, this.page, PAGE_SIZE).subscribe({
      next: (page) => {
        this.result = page;
        this.error = '';
        this.loading = false;
      },
      error: (err: HttpErrorResponse) => {
        this.error = messageOf(err);
        this.loading = false;
      },
    });
  }
}
