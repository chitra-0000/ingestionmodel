import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { RecordPage } from '../models';
import { RecordViewComponent } from '../record-view/record-view.component';
import { RecordsTableComponent } from './records-table.component';

describe('RecordsTableComponent', () => {
  let fixture: ComponentFixture<RecordsTableComponent>;
  let component: RecordsTableComponent;
  let http: HttpTestingController;

  const page: RecordPage = {
    items: [
      {
        rowNo: 1,
        externalReference: '900101',
        type: 'INDIVIDUAL',
        name: 'Viktor Pavel ORLANDO',
        aliases: ['Victor ORLANDOV', 'The Captain'],
        dates: ['1965-03-12 (Date of Birth)'],
        countries: ['ZZ (Citizenship)'],
        lists: ['OFAC - SDN'],
        childCount: 9,
      },
    ],
    total: 1,
    page: 0,
    size: 25,
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule],
      declarations: [RecordsTableComponent, RecordViewComponent],
    }).compileComponents();
    fixture = TestBed.createComponent(RecordsTableComponent);
    component = fixture.componentInstance;
    http = TestBed.inject(HttpTestingController);
    component.uploadId = 7;
    component.ngOnChanges();
    fixture.detectChanges();
  });

  it('shows the records read back from the database with their aliases', () => {
    http.expectOne((r) => r.url === '/api/uploads/7/records').flush(page);
    fixture.detectChanges();
    const text: string = fixture.nativeElement.textContent;
    expect(text).toContain('Viktor Pavel ORLANDO');
    expect(text).toContain('also: Victor ORLANDOV · The Captain');
    expect(text).toContain('1965-03-12 (Date of Birth)');
    expect(component.rangeText).toBe('1–1 of 1');
  });

  it('opens the full canonical record, nulls included', () => {
    http.expectOne((r) => r.url === '/api/uploads/7/records').flush(page);
    fixture.detectChanges();
    component.open(1);
    fixture.detectChanges();
    http.expectOne('/api/uploads/7/records/1').flush({
      uploadId: 7,
      rowNo: 1,
      record: { type: 'INDIVIDUAL', name: 'Viktor', description: null, aliases: [{ name: 'Vic', title: null }] },
    });
    fixture.detectChanges();
    const text: string = fixture.nativeElement.textContent;
    expect(text).toContain('description');
    expect(text).toContain('null');
    expect(text).toContain('"Vic"');
  });

  it('searches after the user stops typing', fakeAsync(() => {
    http.expectOne((r) => r.url === '/api/uploads/7/records').flush(page);
    component.onSearch('orlando');
    tick(300);
    const req = http.expectOne((r) => r.url === '/api/uploads/7/records');
    expect(req.request.params.get('search')).toBe('orlando');
    expect(req.request.params.get('page')).toBe('0');
    req.flush(page);
  }));
});
