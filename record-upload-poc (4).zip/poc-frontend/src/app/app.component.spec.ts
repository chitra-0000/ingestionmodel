import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { MappingEditorComponent } from './mapping/mapping-editor.component';
import { ProfileSummary, UploadResult } from './models';
import { RecordViewComponent } from './record-view/record-view.component';
import { RecordsTableComponent } from './records/records-table.component';

describe('AppComponent', () => {
  let fixture: ComponentFixture<AppComponent>;
  let app: AppComponent;
  let http: HttpTestingController;

  const profiles: ProfileSummary[] = [
    { id: 2, name: 'Sample sanctions CSV', format: 'CSV', ruleCount: 18, updatedAt: null },
    { id: 1, name: 'Dow Jones sanctions XML', format: 'XML', ruleCount: 90, updatedAt: null },
  ];

  const result: UploadResult = {
    upload: {
      uploadId: 7,
      fileName: 'dowjones-sample.xml',
      format: 'XML',
      profileName: 'Dow Jones sanctions XML',
      fileSizeBytes: 5120,
      status: 'COMPLETED',
      recordsRead: 8,
      recordsLoaded: 6,
      recordsRejected: 2,
      message: '6 records loaded, 2 rejected (see the reasons below).',
      startedAt: '2026-11-02T10:00:00Z',
      endedAt: '2026-11-02T10:00:01Z',
      durationMs: 840,
    },
    rejects: [{ rowNo: 7, externalRef: null, severity: 'ERROR', reason: 'externalReference is missing' }],
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule],
      declarations: [AppComponent, RecordsTableComponent, RecordViewComponent, MappingEditorComponent],
    }).compileComponents();
    fixture = TestBed.createComponent(AppComponent);
    app = fixture.componentInstance;
    http = TestBed.inject(HttpTestingController);
    fixture.detectChanges();
    http.expectOne((r) => r.url === '/api/uploads' && r.method === 'GET').flush([]);
    http.expectOne('/api/mapping/profiles').flush(profiles);
  });

  it('refuses files that are not XML or CSV', () => {
    app.choose(new File(['x'], 'list.pdf'));
    fixture.detectChanges();
    expect(app.selectedFile).toBeNull();
    expect(fixture.nativeElement.textContent).toContain('is not an .xml or .csv file');
  });

  it('offers only the mappings for the file format and picks one', () => {
    app.choose(new File(['a;b'], 'list.csv'));
    expect(app.usableProfiles.map((p) => p.id)).toEqual([2]);
    expect(app.profileId).toBe(2);
    app.choose(new File(['<PFA/>'], 'dj.xml'));
    expect(app.profileId).toBe(1);
  });

  it('uploads the file with its mapping and shows the counts and the rejected rows', () => {
    app.choose(new File(['<PFA/>'], 'dowjones-sample.xml'));
    expect(app.selectedFormat).toBe('XML');
    app.upload();

    const post = http.expectOne((r) => r.url === '/api/uploads' && r.method === 'POST');
    const body = post.request.body as FormData;
    expect(body.get('profileId')).toBe('1');
    post.flush(result);
    http.expectOne((r) => r.url === '/api/uploads' && r.method === 'GET').flush([result.upload]);
    fixture.detectChanges();
    http.expectOne((r) => r.url === '/api/uploads/7/records').flush({ items: [], total: 0, page: 0, size: 25 });
    fixture.detectChanges();

    const text: string = fixture.nativeElement.textContent;
    expect(text).toContain('Upload #7 saved.');
    expect(text).toContain('mapping "Dow Jones sanctions XML"');
    expect(text).toContain('externalReference is missing');
  });

  it('shows the server message when the upload is refused', () => {
    app.choose(new File(['<PFA/>'], 'dowjones-sample.xml'));
    app.upload();
    http.expectOne((r) => r.url === '/api/uploads' && r.method === 'POST').flush(
      { status: 409, message: 'This file was already loaded with this profile as upload #3.' },
      { status: 409, statusText: 'Conflict' },
    );
    fixture.detectChanges();
    expect(app.current).toBeNull();
    expect(fixture.nativeElement.textContent).toContain('already loaded with this profile as upload #3');
  });
});
