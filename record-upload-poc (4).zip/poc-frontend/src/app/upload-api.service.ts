import { HttpClient, HttpEvent, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
  InspectResult,
  MappingProfile,
  ProfileSummary,
  RecordDetail,
  RecordPage,
  RejectRow,
  Targets,
  UploadResult,
  UploadSummary,
} from './models';

/** Calls the backend API (proxied to http://localhost:8080 in development). */
@Injectable({ providedIn: 'root' })
export class UploadApiService {
  constructor(private readonly http: HttpClient) {}

  /** Uploads one file with a mapping profile; emits progress events, then the result. */
  upload(file: File, profileId: number): Observable<HttpEvent<UploadResult>> {
    const form = new FormData();
    form.append('file', file, file.name);
    form.append('profileId', String(profileId));
    return this.http.post<UploadResult>('/api/uploads', form, {
      reportProgress: true,
      observe: 'events',
    });
  }

  recent(limit = 20): Observable<UploadSummary[]> {
    return this.http.get<UploadSummary[]>('/api/uploads', { params: new HttpParams().set('limit', String(limit)) });
  }

  records(uploadId: number, search: string, page: number, size: number): Observable<RecordPage> {
    let params = new HttpParams().set('page', String(page)).set('size', String(size));
    const text = search.trim();
    if (text) {
      params = params.set('search', text);
    }
    return this.http.get<RecordPage>(`/api/uploads/${uploadId}/records`, { params });
  }

  record(uploadId: number, rowNo: number): Observable<RecordDetail> {
    return this.http.get<RecordDetail>(`/api/uploads/${uploadId}/records/${rowNo}`);
  }

  rejects(uploadId: number, limit = 200): Observable<RejectRow[]> {
    return this.http.get<RejectRow[]>(`/api/uploads/${uploadId}/rejects`, {
      params: new HttpParams().set('limit', String(limit)),
    });
  }

  profiles(): Observable<ProfileSummary[]> {
    return this.http.get<ProfileSummary[]>('/api/mapping/profiles');
  }

  profile(id: number): Observable<MappingProfile> {
    return this.http.get<MappingProfile>(`/api/mapping/profiles/${id}`);
  }

  saveProfile(profile: MappingProfile): Observable<MappingProfile> {
    return profile.id
      ? this.http.put<MappingProfile>(`/api/mapping/profiles/${profile.id}`, profile)
      : this.http.post<MappingProfile>('/api/mapping/profiles', profile);
  }

  targets(): Observable<Targets> {
    return this.http.get<Targets>('/api/mapping/targets');
  }

  /** Reads the file's structure (columns or XML paths) with samples; nothing is saved. */
  inspect(file: File, recordElements: string[], encoding?: string | null, delimiter?: string | null): Observable<InspectResult> {
    const form = new FormData();
    form.append('file', file, file.name);
    if (recordElements.length) {
      form.append('recordElements', recordElements.join(','));
    }
    if (encoding) {
      form.append('encoding', encoding);
    }
    if (delimiter) {
      form.append('delimiter', delimiter);
    }
    return this.http.post<InspectResult>('/api/mapping/inspect', form);
  }
}
