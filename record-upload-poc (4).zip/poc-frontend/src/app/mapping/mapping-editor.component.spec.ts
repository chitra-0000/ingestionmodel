import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { InspectResult, Targets } from '../models';
import { MappingEditorComponent } from './mapping-editor.component';

describe('MappingEditorComponent', () => {
  let fixture: ComponentFixture<MappingEditorComponent>;
  let editor: MappingEditorComponent;
  let http: HttpTestingController;

  const targets: Targets = {
    fields: [
      { path: 'type', label: 'Record type', section: 'General information', collection: null, maxLength: 10 },
      { path: 'externalReference', label: 'External reference', section: 'General information', collection: null, maxLength: 250 },
      { path: 'name', label: 'Full name', section: 'General information', collection: null, maxLength: 300 },
      { path: 'aliases.name', label: 'Full name', section: 'Aliases', collection: 'aliases', maxLength: 1000 },
    ],
    collections: [{ name: 'aliases', label: 'Aliases' }],
    transforms: [{ name: 'NONE', label: 'As is' }, { name: 'VALUE_MAP', label: 'Value map' }],
    recordTypes: ['INDIVIDUAL', 'ENTITY', 'VESSEL'],
  };

  const found: InspectResult = {
    format: 'CSV',
    encoding: 'UTF-8',
    delimiter: ';',
    sampled: 2,
    total: 2,
    fields: [
      { path: 'Ref', sample: 'R1', count: 2, values: ['R1', 'R2'], suggestedTarget: 'externalReference' },
      { path: 'Kind', sample: 'Person', count: 2, values: ['Person', 'Company'], suggestedTarget: 'type' },
      { path: 'AKA', sample: 'Annie', count: 1, values: ['Annie'], suggestedTarget: 'aliases.name' },
      { path: 'Notes', sample: 'x', count: 1, values: ['x'], suggestedTarget: null },
    ],
    recordElements: [],
    lookups: [],
    notes: [],
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule],
      declarations: [MappingEditorComponent],
    }).compileComponents();
    fixture = TestBed.createComponent(MappingEditorComponent);
    editor = fixture.componentInstance;
    http = TestBed.inject(HttpTestingController);
    editor.file = new File(['Ref;Kind;AKA;Notes'], 'export.csv');
    fixture.detectChanges();
    http.expectOne('/api/mapping/targets').flush(targets);
    http.expectOne('/api/mapping/inspect').flush(found);
    fixture.detectChanges();
  });

  it('suggests lines from the column names, with a value map for the type and the collection line', () => {
    editor.suggest();
    const rules = editor.profile?.rules ?? [];
    expect(rules.map((r) => `${r.kind}:${r.target}:${r.source}`)).toEqual([
      'RECORD:INDIVIDUAL:',
      'FIELD:externalReference:Ref',
      'FIELD:type:Kind',
      'COLLECTION:aliases:',
      'FIELD:aliases.name:AKA',
    ]);
    expect(rules[2].transform).toBe('VALUE_MAP');
    expect(rules[2].param).toBe('Person=INDIVIDUAL;Company=ENTITY');
    expect(editor.sampleFor(rules[1])).toBe('R1');
  });

  it('saves the mapping and reports the server message when it is refused', () => {
    editor.suggest();
    editor.save();
    http.expectOne((r) => r.url === '/api/mapping/profiles' && r.method === 'POST').flush(
      { status: 409, message: "A profile named 'export mapping' already exists. Choose another name." },
      { status: 409, statusText: 'Conflict' },
    );
    expect(editor.error).toContain('already exists');
  });
});
