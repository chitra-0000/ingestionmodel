import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { forkJoin, of } from 'rxjs';
import { messageOf } from '../errors';
import {
  FileFormat,
  InspectResult,
  MappingProfile,
  MappingRule,
  RecordType,
  RuleKind,
  SourceField,
  TargetField,
  Targets,
} from '../models';
import { UploadApiService } from '../upload-api.service';

interface TargetGroup {
  section: string;
  fields: TargetField[];
}

const KIND_LABELS: { [kind in RuleKind]: string } = {
  RECORD: 'Record',
  FIELD: 'Field',
  COLLECTION: 'Collection',
  LOOKUP: 'Lookup',
  GROUP_BY: 'Group rows',
};

/**
 * Maps a file's columns (CSV) or tags (XML) to the canonical record. Shows what the inspector found
 * in the file with sample values, and the mapping lines; saves them as a profile.
 */
@Component({
  selector: 'app-mapping-editor',
  templateUrl: './mapping-editor.component.html',
  styleUrls: ['./mapping-editor.component.scss'],
})
export class MappingEditorComponent implements OnInit {
  /** The file to map (optional when editing a profile without a file). */
  @Input() file: File | null = null;
  /** Profile to edit, or null for a new one. */
  @Input() profileId: number | null = null;
  @Output() saved = new EventEmitter<MappingProfile>();
  @Output() cancelled = new EventEmitter<void>();

  readonly kinds: RuleKind[] = ['RECORD', 'FIELD', 'COLLECTION', 'LOOKUP', 'GROUP_BY'];
  readonly kindLabels = KIND_LABELS;
  readonly encodings = ['UTF-8', 'windows-1252', 'ISO-8859-1'];
  readonly delimiters = [
    { value: '', label: 'Detect' },
    { value: ',', label: 'Comma ,' },
    { value: ';', label: 'Semicolon ;' },
    { value: '|', label: 'Pipe |' },
    { value: '\\t', label: 'Tab' },
  ];

  profile: MappingProfile | null = null;
  targets: Targets | null = null;
  groups: TargetGroup[] = [];
  found: InspectResult | null = null;
  filter = '';
  loading = true;
  inspecting = false;
  saving = false;
  error = '';
  inspectError = '';

  constructor(private readonly api: UploadApiService) {}

  ngOnInit(): void {
    const format: FileFormat = this.file && this.file.name.toLowerCase().endsWith('.xml') ? 'XML' : 'CSV';
    forkJoin({
      targets: this.api.targets(),
      profile: this.profileId ? this.api.profile(this.profileId) : of(this.emptyProfile(format)),
    }).subscribe({
      next: ({ targets, profile }) => {
        this.targets = targets;
        this.groups = this.groupTargets(targets.fields);
        this.profile = profile;
        this.loading = false;
        if (this.file) {
          this.inspect(!this.profileId);
        }
      },
      error: (err: HttpErrorResponse) => {
        this.error = messageOf(err);
        this.loading = false;
      },
    });
  }

  get isXml(): boolean {
    return this.profile?.format === 'XML';
  }

  get visibleFields(): SourceField[] {
    const all = this.found?.fields ?? [];
    const f = this.filter.trim().toLowerCase();
    return f ? all.filter((x) => x.path.toLowerCase().includes(f) || (x.sample ?? '').toLowerCase().includes(f)) : all;
  }

  get fileMismatch(): boolean {
    if (!this.file || !this.profile) {
      return false;
    }
    const isXmlFile = this.file.name.toLowerCase().endsWith('.xml');
    return isXmlFile !== (this.profile.format === 'XML');
  }

  /** Reads the file's structure. For a new profile, also proposes the record lines. */
  inspect(propose: boolean): void {
    if (!this.file || !this.profile) {
      return;
    }
    const elements = this.profile.rules.filter((r) => r.kind === 'RECORD' && r.source).map((r) => (r.source || '').trim());
    this.inspecting = true;
    this.inspectError = '';
    this.api.inspect(this.file, this.isXml ? elements : [], this.isXml ? null : this.profile.encoding,
      this.isXml ? null : this.profile.delimiter).subscribe({
      next: (result) => {
        this.found = result;
        this.inspecting = false;
        if (propose && this.profile) {
          this.proposeRecordLines(result);
          if (!this.isXml) {
            this.profile.encoding = result.encoding;
          }
        }
      },
      error: (err: HttpErrorResponse) => {
        this.inspectError = messageOf(err);
        this.inspecting = false;
      },
    });
  }

  /** Record element chosen or removed in the found panel (XML). */
  toggleRecordElement(name: string, type: RecordType, on: boolean): void {
    if (!this.profile) {
      return;
    }
    const rules = this.profile.rules;
    const index = rules.findIndex((r) => r.kind === 'RECORD' && (r.source || '').toLowerCase() === name.toLowerCase());
    if (on && index < 0) {
      rules.unshift(this.rule('RECORD', type, name));
    } else if (!on && index >= 0) {
      rules.splice(index, 1);
    }
  }

  isRecordElement(name: string): boolean {
    return !!this.profile?.rules.some((r) => r.kind === 'RECORD' && (r.source || '').toLowerCase() === name.toLowerCase());
  }

  /** Adds a FIELD line reading this column or path, with the suggested target when there is one. */
  addFromSource(field: SourceField): void {
    if (!this.profile) {
      return;
    }
    const target = field.suggestedTarget || '';
    const rule = this.rule('FIELD', target, field.path);
    this.applyDefaults(rule, field);
    this.relativise(rule);
    this.ensureCollection(rule.target);
    this.profile.rules.push(rule);
  }

  addLookup(path: string, attributes: string[]): void {
    if (!this.profile) {
      return;
    }
    const name = path.split('/')[0].replace(/List$/i, '').replace(/[^A-Za-z0-9]+/g, '_').toUpperCase() || 'CODES';
    const key = attributes.find((a) => /code|id$/i.test(a)) || attributes[0];
    const value = attributes.find((a) => /name|label|desc/i.test(a));
    this.profile.rules.push(this.rule('LOOKUP', name, path, 'NONE', `key=@${key};value=${value ? '@' + value : '.'}`));
  }

  /** Adds a FIELD line for every column or path with a suggested target that is not mapped yet. */
  suggest(): void {
    if (!this.profile || !this.found) {
      return;
    }
    const mapped = new Set(this.profile.rules.filter((r) => r.kind === 'FIELD').map((r) => r.target));
    let added = 0;
    for (const field of this.found.fields) {
      if (field.suggestedTarget && !mapped.has(field.suggestedTarget)) {
        this.addFromSource(field);
        mapped.add(field.suggestedTarget);
        added++;
      }
    }
    this.error = added ? '' : 'No more columns could be matched by name. Add the remaining lines by hand.';
  }

  addRule(kind: RuleKind): void {
    if (!this.profile) {
      return;
    }
    const rule = this.rule(kind, kind === 'RECORD' ? 'INDIVIDUAL' : '', '');
    this.profile.rules.push(rule);
  }

  remove(index: number): void {
    this.profile?.rules.splice(index, 1);
  }

  move(index: number, delta: number): void {
    if (!this.profile) {
      return;
    }
    const rules = this.profile.rules;
    const to = index + delta;
    if (to < 0 || to >= rules.length) {
      return;
    }
    [rules[index], rules[to]] = [rules[to], rules[index]];
  }

  onTargetChange(rule: MappingRule): void {
    if (rule.kind === 'FIELD') {
      this.ensureCollection(rule.target);
      this.relativise(rule);
    }
  }

  /** A sample value from the file for a line, to check the mapping reads what is expected. */
  sampleFor(rule: MappingRule): string {
    if (!this.found || !rule.source) {
      return '';
    }
    if (rule.transform === 'CONSTANT') {
      return rule.param || '';
    }
    const first = rule.source.split(/\s\+\s/)[0].trim();
    let path = first;
    if (rule.kind === 'FIELD' && this.isXml && rule.target && rule.target.includes('.') && !first.startsWith('/')) {
      const collection = this.collectionRule(rule.target.split('.')[0]);
      const base = collection?.source?.split(/\s\+\s/)[0].trim();
      if (base) {
        path = first === '.' ? base : this.resolve(base, first);
      }
    }
    const key = this.plain(path.replace(/^\//, ''));
    const field = this.found.fields.find((f) => this.plain(f.path) === key);
    return field?.sample ?? '';
  }

  targetLabel(path: string | null): string {
    return this.targets?.fields.find((f) => f.path === path)?.label ?? '';
  }

  trackByIndex(index: number): number {
    return index;
  }

  save(): void {
    if (!this.profile) {
      return;
    }
    this.error = '';
    if (!this.profile.name.trim()) {
      this.error = 'Give the mapping a name.';
      return;
    }
    this.saving = true;
    const toSave: MappingProfile = {
      ...this.profile,
      rules: this.profile.rules.map((r) => ({ ...r, target: r.target || null, source: r.source || null, param: r.param || null })),
    };
    this.api.saveProfile(toSave).subscribe({
      next: (saved) => {
        this.saving = false;
        this.saved.emit(saved);
      },
      error: (err: HttpErrorResponse) => {
        this.saving = false;
        this.error = messageOf(err);
      },
    });
  }

  private emptyProfile(format: FileFormat): MappingProfile {
    const base = this.file ? this.file.name.replace(/\.[^.]+$/, '') : 'New';
    return {
      id: null,
      name: `${base} mapping`,
      format,
      encoding: format === 'CSV' ? 'UTF-8' : null,
      delimiter: '',
      rules: format === 'CSV' ? [this.rule('RECORD', 'INDIVIDUAL', '')] : [],
    };
  }

  private proposeRecordLines(result: InspectResult): void {
    if (!this.profile || !this.isXml) {
      return;
    }
    for (const element of result.recordElements.filter((e) => e.selected)) {
      if (!this.isRecordElement(element.name)) {
        this.profile.rules.push(this.rule('RECORD', element.suggestedType, element.name));
      }
    }
  }

  private applyDefaults(rule: MappingRule, field: SourceField): void {
    const target = rule.target || '';
    if (target === 'type') {
      rule.transform = 'VALUE_MAP';
      rule.param = field.values.map((v) => `${v}=${this.guessType(v)}`).join(';') || null;
    } else if (/date/i.test(target) && !this.isXml && target !== 'recordDJ.lastUpdateDate') {
      rule.transform = 'DATE';
    }
  }

  private guessType(value: string): RecordType {
    const v = value.toLowerCase();
    if (/vessel|ship|^v$/.test(v)) {
      return 'VESSEL';
    }
    if (/entity|company|organi[sz]ation|^e$|^c$/.test(v)) {
      return 'ENTITY';
    }
    return 'INDIVIDUAL';
  }

  /** Item fields read relative to their collection's element (XML), or the split value "." (CSV). */
  private relativise(rule: MappingRule): void {
    if (!rule.target || !rule.target.includes('.') || !rule.source || rule.target.startsWith('recordDJ.')) {
      return;
    }
    const collection = this.collectionRule(rule.target.split('.')[0]);
    const base = collection?.source?.trim();
    if (!base) {
      return;
    }
    if (this.isXml) {
      const plainBase = this.plain(base);
      const plainSource = this.plain(rule.source);
      if (plainSource === plainBase) {
        rule.source = '.';
      } else if (plainSource.startsWith(plainBase + '/')) {
        rule.source = rule.source.split('/').slice(plainBase.split('/').length).join('/');
      }
    } else if (this.plain(base) === this.plain(rule.source)) {
      rule.source = '.';
    }
  }

  /** Item fields need their collection line; CSV gets "whole row" by default. */
  private ensureCollection(target: string | null): void {
    if (!this.profile || !target || !target.includes('.') || target.startsWith('recordDJ.')) {
      return;
    }
    const name = target.split('.')[0];
    if (!this.collectionRule(name)) {
      this.profile.rules.push(this.rule('COLLECTION', name, ''));
    }
  }

  private collectionRule(name: string): MappingRule | undefined {
    return this.profile?.rules.find((r) => r.kind === 'COLLECTION' && r.target === name);
  }

  private resolve(base: string, relative: string): string {
    const parts = base.split('/');
    for (const step of relative.split('/')) {
      if (step === '..') {
        parts.pop();
      } else if (step !== '.') {
        parts.push(step);
      }
    }
    return parts.join('/');
  }

  /** Path without filters and in lower case, for comparing. */
  private plain(path: string): string {
    return path.replace(/\[[^\]]*\]/g, '').trim().toLowerCase();
  }

  private rule(kind: RuleKind, target: string, source: string, transform = 'NONE', param: string | null = null): MappingRule {
    return { kind, target, source, transform, param };
  }

  private groupTargets(fields: TargetField[]): TargetGroup[] {
    const groups: TargetGroup[] = [];
    for (const field of fields) {
      let group = groups.find((g) => g.section === field.section);
      if (!group) {
        group = { section: field.section, fields: [] };
        groups.push(group);
      }
      group.fields.push(field);
    }
    return groups;
  }
}
