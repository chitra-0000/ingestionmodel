# Record upload POC

A page to show the idea: **upload any XML or CSV file, map its tags or columns to one canonical
record model at runtime, and save the records to Oracle.** The canonical record mirrors the bank's
`Record` entity field for field (individual, entity and vessel fields; programs, aliases, sanction
references, sources, relations, associations, addresses, IBANs, dates, countries, identity documents,
Dow Jones data, referential codes), so it is the single source for publication to the downstream systems.
A new provider layout needs a new **mapping profile** (made on screen), not new code.

| Folder | What | Stack | Open with |
| --- | --- | --- | --- |
| `poc-backend` | REST API, file readers, database | Java 8, Spring Boot 2.7.18, Maven 3.8.6 (wrapper), Oracle 19 (ojdbc8), Liquibase | IntelliJ IDEA (open `pom.xml`) |
| `poc-frontend` | Upload page | Angular 11.2 (same versions as the Regliss UI project), Node 14 | VS Code |
| `samples` | Fictional Dow Jones XML and two CSV layouts for the demo | | |
| `docs/oracle-setup.sql` | One-time user creation for the DBA | | |

## Frontend versions

The frontend uses exactly the package versions of the existing Regliss UI project (Angular ~11.2.4,
TypeScript ~4.1.5, rxjs ~6.6.0, zone.js ~0.10.3, Karma ~6.1, Jasmine ~3.6), so the bank's Artifactory
allows every package. No `package-lock.json` is shipped: `npm install` creates it from Artifactory.
npm 6 (bundled with Node 14) works; npm logs in to Artifactory through your user `.npmrc`.

## Run it

**Quickest demo (no Oracle needed):**

```powershell
powershell -ExecutionPolicy Bypass -File .\start-poc.ps1 -Demo
```

**Against Oracle 19:** ask the DBA to run `docs/oracle-setup.sql`, then:

```powershell
powershell -ExecutionPolicy Bypass -File .\start-poc.ps1 -DbUrl "jdbc:oracle:thin:@//host:1521/SERVICE" -DbUser LISTHUB_POC
```

The tables are created automatically at first start (Liquibase). The page opens at http://localhost:4200.

**From the IDEs:**

- **IntelliJ:** open `poc-backend/pom.xml` as a project with a Java 8 SDK. Run **PocApplication (H2 demo, no Oracle)** or **PocApplication (Oracle 19)**; fill in the Oracle values under Run > Edit Configurations.
- **VS Code:** open `poc-frontend`, run `npm install` once, then press **F5**.

## Demo script (5 minutes)

1. Choose `samples/dowjones-sample.xml`; the mapping "Dow Jones sanctions XML" is picked. Load it: 8 read,
   6 saved, 2 rejected with reasons (missing id, impossible month).
2. Click **View record** on Viktor ORLANDO: the full canonical record, every field of the model, child
   objects as objects, `null` where the file has nothing. Codes are turned into names from the file's own
   code lists (sanction lists, countries, Dow Jones descriptions).
3. Choose `samples/generic-export-sample.csv`, a layout the application has never seen. Click
   **New mapping from this file**: the columns are listed with samples. Click **Suggest from names**,
   then **Group rows** on `Designation External Reference` (two rows of the same person become one record
   with two aliases). Save, then load: 3 records.
4. Load the Dow Jones file again: refused, the same content is never loaded twice with the same mapping.
5. Click a row in the upload history to show any earlier upload.

## Mapping profiles

A profile is a list of lines, stored in `poc_mapping_profile` / `poc_mapping_rule`:

| Line | Meaning | Example (XML) | Example (CSV) |
| --- | --- | --- | --- |
| Record | Which element is one record, and its type (CSV: default type) | `Person` → INDIVIDUAL | every row → INDIVIDUAL |
| Field | One canonical field from a path or column | `NameDetails/Name[@NameType='Primary Name']/NameValue/Surname` → `lastName` | `Designation Full Name` → `name` |
| Collection | A list of child objects | `NameDetails/Name[@NameType!='Primary Name']/NameValue` → `aliases` | empty (one per row) or a column split on `\|` |
| Lookup | A code list anywhere in the XML | `SanctionsReferencesList/ReferenceName`, `key=@code;value=@name` | |
| Group rows | CSV: consecutive rows with the same id form one record | | `Designation External Reference` |

Transformations (fixed list, no scripts): upper/lower case, value map (`P=INDIVIDUAL;*=ENTITY`), date
to partial ISO (patterns such as `dd/MM/yyyy`), year + month + day parts, split, lookup, default, fixed value.
Several sources are joined with ` + `. The first value found wins when several lines target the same field.

Built-in profiles (added at start-up if missing): `src/main/resources/profiles/*.json`.

## What it shows (for the approval)

- Any layout into one canonical record model, by configuration: XML and CSV land in the same tables and screen.
- Every field of the model is kept, with child objects in their own tables and nulls where the file has nothing.
- Streaming readers: memory stays at one batch of records (500) whatever the file size.
- Records saved in JDBC batches; a file that fails part-way leaves no records behind.
- Quality checks with reasons (errors reject a record, warnings load it and list it); duplicate files refused by SHA-256 content hash.
- Secure by design: XML external entities and DOCTYPE refused, bind variables only, no passwords in files, file type and size checked, no stack traces to the browser.

## Tests

```bash
cd poc-backend && ./mvnw verify          # 18 tests: paths, dates, XXE, profiles, full flow on H2 (Oracle mode)
cd poc-frontend && npm test              # 9 tests (Chrome headless)
```

## API

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/api/uploads` (multipart `file`, `profileId`) | Upload and load a file with a mapping |
| GET | `/api/uploads` | Recent uploads |
| GET | `/api/uploads/{id}/records?search=&page=&size=` | Records of an upload (summary) |
| GET | `/api/uploads/{id}/records/{rowNo}` | One full canonical record |
| GET | `/api/uploads/{id}/rejects` | Rows with a problem (ERROR or WARNING) |
| GET | `/api/mapping/targets` | Canonical fields and collections a mapping can target |
| GET/POST/PUT | `/api/mapping/profiles[/{id}]` | Mapping profiles |
| POST | `/api/mapping/inspect` (multipart `file`) | Columns or XML paths of a file, with samples and suggestions |

Not in this POC (next steps): login and roles, list versions, validation and certification, publication to downstream systems.
