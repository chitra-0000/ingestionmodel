--liquibase formatted sql

-- Canonical record model (mirrors the bank's Record entity: one RECORD table with the
-- individual, entity and vessel columns, plus one table per child collection) and the
-- mapping profiles that turn any CSV or XML layout into it. Oracle 19; also runs on H2 in
-- Oracle mode. Child rows are keyed by (upload_id, row_no, seq_no): no extra sequence round trip.

--changeset poc:002-drop-fixed-format-tables
DROP TABLE poc_record_alias;
DROP TABLE poc_record;
DROP SEQUENCE poc_alias_seq;
--rollback SELECT 1 FROM dual;

--changeset poc:002-upload-profile
ALTER TABLE poc_upload ADD (profile_id NUMBER(19), profile_name VARCHAR2(100 CHAR));
--rollback ALTER TABLE poc_upload DROP (profile_id, profile_name);

--changeset poc:002-reject-severity
ALTER TABLE poc_reject ADD (severity VARCHAR2(10 CHAR) DEFAULT 'ERROR' NOT NULL);
ALTER TABLE poc_reject MODIFY reason VARCHAR2(1000 CHAR);
ALTER TABLE poc_reject MODIFY external_ref VARCHAR2(250 CHAR);
--rollback ALTER TABLE poc_reject DROP (severity);

--changeset poc:002-record
-- One row per canonical record. RECORD_TYPE is the discriminator (INDIVIDUAL, ENTITY, VESSEL).
CREATE TABLE poc_record (
    id                       NUMBER(19)            NOT NULL,
    upload_id                NUMBER(19)            NOT NULL,
    row_no                   NUMBER(12)            NOT NULL,
    record_type              VARCHAR2(10 CHAR)     NOT NULL,
    name                     VARCHAR2(300 CHAR),
    name_normalized          VARCHAR2(450 CHAR),
    description              VARCHAR2(300 CHAR),
    dow_jones_notes          CLOB,
    keywords                 VARCHAR2(256 CHAR),
    comments                 VARCHAR2(2048 CHAR),
    additional_info          VARCHAR2(2048 CHAR),
    regliss_reference        VARCHAR2(256 CHAR),
    record_id                VARCHAR2(13 CHAR),
    start_date               VARCHAR2(255 CHAR),
    external_reference       VARCHAR2(250 CHAR)    NOT NULL,
    instruction              VARCHAR2(2048 CHAR),
    external_uuid            VARCHAR2(36 CHAR)     NOT NULL,
    last_modification_date   VARCHAR2(255 CHAR),
    inactivity_date_as_pep   VARCHAR2(255 CHAR),
    inactivity_date_as_rca   VARCHAR2(255 CHAR),
    from_version             NUMBER(19),
    to_version               NUMBER(19),
    deleted_in_version       NUMBER(19),
    gender                   VARCHAR2(20 CHAR),
    title                    VARCHAR2(100 CHAR),
    first_name               VARCHAR2(200 CHAR),
    middle_name              VARCHAR2(200 CHAR),
    last_name                VARCHAR2(200 CHAR),
    maiden_name              VARCHAR2(200 CHAR),
    suffix                   VARCHAR2(50 CHAR),
    is_deceased              NUMBER(1),
    vessel_imo               VARCHAR2(50 CHAR),
    vessel_flag              VARCHAR2(100 CHAR),
    vessel_tonnage           VARCHAR2(50 CHAR),
    vessel_owner             VARCHAR2(300 CHAR),
    vessel_type              VARCHAR2(100 CHAR),
    vessel_gross_tonnage     VARCHAR2(50 CHAR),
    vessel_call_sign         VARCHAR2(50 CHAR),
    dj_action                VARCHAR2(20 CHAR),
    dj_last_update_date      VARCHAR2(50 CHAR),
    dj_active_status         VARCHAR2(50 CHAR),
    created_at               TIMESTAMP             NOT NULL,
    CONSTRAINT pk_poc_record PRIMARY KEY (id),
    CONSTRAINT uq_poc_record_upload_row UNIQUE (upload_id, row_no),
    CONSTRAINT fk_poc_record_upload FOREIGN KEY (upload_id) REFERENCES poc_upload (upload_id),
    CONSTRAINT ck_poc_record_type CHECK (record_type IN ('INDIVIDUAL', 'ENTITY', 'VESSEL')),
    CONSTRAINT ck_poc_record_deceased CHECK (is_deceased IN (0, 1))
);
CREATE INDEX ix_poc_record_ext_ref ON poc_record (external_reference);
CREATE INDEX ix_poc_record_name_norm ON poc_record (name_normalized);
--rollback DROP TABLE poc_record;

--changeset poc:002-child-ref-code
-- Referential values: categories, sanction types, Dow Jones description 3, PEP occupation categories.
CREATE TABLE poc_record_ref_code (
    upload_id  NUMBER(19)  NOT NULL,
    row_no     NUMBER(12)  NOT NULL,
    seq_no     NUMBER(6)   NOT NULL,
    ref_kind   VARCHAR2(20 CHAR) NOT NULL,
    code       VARCHAR2(100 CHAR),
    label      VARCHAR2(500 CHAR),
    CONSTRAINT pk_poc_rrc PRIMARY KEY (upload_id, row_no, seq_no),
    CONSTRAINT ck_poc_rrc_kind CHECK (ref_kind IN ('CATEGORY', 'SANCTION_TYPE', 'DESCRIPTION3', 'PEP_OCCUPATION')),
    CONSTRAINT fk_poc_rrc_record FOREIGN KEY (upload_id, row_no) REFERENCES poc_record (upload_id, row_no)
);
--rollback DROP TABLE poc_record_ref_code;

--changeset poc:002-child-code
-- Codes of a record: BIC and ISIN (entities), IBAN.
CREATE TABLE poc_record_code (
    upload_id   NUMBER(19)  NOT NULL,
    row_no      NUMBER(12)  NOT NULL,
    seq_no      NUMBER(6)   NOT NULL,
    code_kind   VARCHAR2(10 CHAR) NOT NULL,
    code_value  VARCHAR2(50 CHAR) NOT NULL,
    CONSTRAINT pk_poc_rco PRIMARY KEY (upload_id, row_no, seq_no),
    CONSTRAINT ck_poc_rco_kind CHECK (code_kind IN ('BIC', 'ISIN', 'IBAN')),
    CONSTRAINT fk_poc_rco_record FOREIGN KEY (upload_id, row_no) REFERENCES poc_record (upload_id, row_no)
);
--rollback DROP TABLE poc_record_code;

--changeset poc:002-child-program
-- Programs.
CREATE TABLE poc_record_program (
    upload_id      NUMBER(19)  NOT NULL,
    row_no         NUMBER(12)  NOT NULL,
    seq_no         NUMBER(6)   NOT NULL,
    label          VARCHAR2(500 CHAR),
    sanction_type  VARCHAR2(200 CHAR),
    CONSTRAINT pk_poc_rpg PRIMARY KEY (upload_id, row_no, seq_no),
    CONSTRAINT fk_poc_rpg_record FOREIGN KEY (upload_id, row_no) REFERENCES poc_record (upload_id, row_no)
);
--rollback DROP TABLE poc_record_program;

--changeset poc:002-child-alias
-- Aliases.
CREATE TABLE poc_record_alias (
    upload_id          NUMBER(19)  NOT NULL,
    row_no             NUMBER(12)  NOT NULL,
    seq_no             NUMBER(6)   NOT NULL,
    regliss_reference  VARCHAR2(256 CHAR),
    alias_type         VARCHAR2(100 CHAR),
    alias_quality      VARCHAR2(20 CHAR),
    title              VARCHAR2(100 CHAR),
    first_name         VARCHAR2(200 CHAR),
    middle_name        VARCHAR2(200 CHAR),
    last_name          VARCHAR2(200 CHAR),
    maiden_name        VARCHAR2(200 CHAR),
    suffix             VARCHAR2(50 CHAR),
    name               VARCHAR2(1000 CHAR),
    CONSTRAINT pk_poc_ral PRIMARY KEY (upload_id, row_no, seq_no),
    CONSTRAINT fk_poc_ral_record FOREIGN KEY (upload_id, row_no) REFERENCES poc_record (upload_id, row_no)
);
--rollback DROP TABLE poc_record_alias;

--changeset poc:002-child-sanction-ref
-- Sanction lists and regulations; dates are partial ISO dates.
CREATE TABLE poc_record_sanction_ref (
    upload_id   NUMBER(19)  NOT NULL,
    row_no      NUMBER(12)  NOT NULL,
    seq_no      NUMBER(6)   NOT NULL,
    code        VARCHAR2(100 CHAR),
    list_name   VARCHAR2(500 CHAR),
    since_date  VARCHAR2(10 CHAR),
    end_date    VARCHAR2(10 CHAR),
    CONSTRAINT pk_poc_rsr PRIMARY KEY (upload_id, row_no, seq_no),
    CONSTRAINT fk_poc_rsr_record FOREIGN KEY (upload_id, row_no) REFERENCES poc_record (upload_id, row_no)
);
--rollback DROP TABLE poc_record_sanction_ref;

--changeset poc:002-child-source
-- Sources.
CREATE TABLE poc_record_source (
    upload_id  NUMBER(19)  NOT NULL,
    row_no     NUMBER(12)  NOT NULL,
    seq_no     NUMBER(6)   NOT NULL,
    source     VARCHAR2(2000 CHAR),
    CONSTRAINT pk_poc_rso PRIMARY KEY (upload_id, row_no, seq_no),
    CONSTRAINT fk_poc_rso_record FOREIGN KEY (upload_id, row_no) REFERENCES poc_record (upload_id, row_no)
);
--rollback DROP TABLE poc_record_source;

--changeset poc:002-child-relation
-- Relations and associations to other records.
CREATE TABLE poc_record_relation (
    upload_id             NUMBER(19)  NOT NULL,
    row_no                NUMBER(12)  NOT NULL,
    seq_no                NUMBER(6)   NOT NULL,
    relation_kind         VARCHAR2(12 CHAR) NOT NULL,
    related_external_ref  VARCHAR2(250 CHAR),
    relation_type         VARCHAR2(200 CHAR),
    category              VARCHAR2(200 CHAR),
    ex                    VARCHAR2(50 CHAR),
    CONSTRAINT pk_poc_rre PRIMARY KEY (upload_id, row_no, seq_no),
    CONSTRAINT ck_poc_rre_kind CHECK (relation_kind IN ('RELATION', 'ASSOCIATION')),
    CONSTRAINT fk_poc_rre_record FOREIGN KEY (upload_id, row_no) REFERENCES poc_record (upload_id, row_no)
);
--rollback DROP TABLE poc_record_relation;

--changeset poc:002-child-address
-- Addresses.
CREATE TABLE poc_record_address (
    upload_id  NUMBER(19)  NOT NULL,
    row_no     NUMBER(12)  NOT NULL,
    seq_no     NUMBER(6)   NOT NULL,
    address    VARCHAR2(1000 CHAR),
    zip_code   VARCHAR2(50 CHAR),
    city       VARCHAR2(200 CHAR),
    state      VARCHAR2(200 CHAR),
    country    VARCHAR2(200 CHAR),
    remarks    VARCHAR2(2048 CHAR),
    CONSTRAINT pk_poc_rad PRIMARY KEY (upload_id, row_no, seq_no),
    CONSTRAINT fk_poc_rad_record FOREIGN KEY (upload_id, row_no) REFERENCES poc_record (upload_id, row_no)
);
--rollback DROP TABLE poc_record_address;

--changeset poc:002-child-date
-- Dates (birth, death, registration...) as parts plus the partial ISO date.
CREATE TABLE poc_record_date (
    upload_id        NUMBER(19)  NOT NULL,
    row_no           NUMBER(12)  NOT NULL,
    seq_no           NUMBER(6)   NOT NULL,
    date_type        VARCHAR2(100 CHAR),
    day_value        NUMBER(2),
    month_value      NUMBER(2),
    year_value       NUMBER(4),
    date_value       VARCHAR2(10 CHAR),
    birth_place      VARCHAR2(500 CHAR),
    birth_country    VARCHAR2(200 CHAR),
    additional_info  VARCHAR2(2048 CHAR),
    CONSTRAINT pk_poc_rda PRIMARY KEY (upload_id, row_no, seq_no),
    CONSTRAINT fk_poc_rda_record FOREIGN KEY (upload_id, row_no) REFERENCES poc_record (upload_id, row_no)
);
--rollback DROP TABLE poc_record_date;

--changeset poc:002-child-country
-- Countries (citizenship, residence, registration...).
CREATE TABLE poc_record_country (
    upload_id        NUMBER(19)  NOT NULL,
    row_no           NUMBER(12)  NOT NULL,
    seq_no           NUMBER(6)   NOT NULL,
    country_type     VARCHAR2(100 CHAR),
    country_code     VARCHAR2(10 CHAR),
    country_name     VARCHAR2(200 CHAR),
    additional_info  VARCHAR2(2048 CHAR),
    CONSTRAINT pk_poc_rcn PRIMARY KEY (upload_id, row_no, seq_no),
    CONSTRAINT fk_poc_rcn_record FOREIGN KEY (upload_id, row_no) REFERENCES poc_record (upload_id, row_no)
);
--rollback DROP TABLE poc_record_country;

--changeset poc:002-child-identity-doc
-- Identity documents.
CREATE TABLE poc_record_identity_doc (
    upload_id        NUMBER(19)  NOT NULL,
    row_no           NUMBER(12)  NOT NULL,
    seq_no           NUMBER(6)   NOT NULL,
    document_type    VARCHAR2(200 CHAR),
    doc_number       VARCHAR2(200 CHAR),
    additional_info  VARCHAR2(2048 CHAR),
    CONSTRAINT pk_poc_rid PRIMARY KEY (upload_id, row_no, seq_no),
    CONSTRAINT fk_poc_rid_record FOREIGN KEY (upload_id, row_no) REFERENCES poc_record (upload_id, row_no)
);
--rollback DROP TABLE poc_record_identity_doc;

--changeset poc:002-mapping-profile
-- A mapping profile: how one provider's file layout maps into the canonical record.
CREATE SEQUENCE poc_profile_seq START WITH 1 INCREMENT BY 1 CACHE 20;
CREATE TABLE poc_mapping_profile (
    profile_id     NUMBER(19)           NOT NULL,
    profile_name   VARCHAR2(100 CHAR)   NOT NULL,
    file_format    VARCHAR2(10 CHAR)    NOT NULL,
    encoding       VARCHAR2(30 CHAR),
    delimiter      VARCHAR2(3 CHAR),
    created_at     TIMESTAMP            NOT NULL,
    updated_at     TIMESTAMP            NOT NULL,
    CONSTRAINT pk_poc_mapping_profile PRIMARY KEY (profile_id),
    CONSTRAINT uq_poc_mapping_profile_name UNIQUE (profile_name),
    CONSTRAINT ck_poc_mapping_profile_fmt CHECK (file_format IN ('XML', 'CSV'))
);
CREATE TABLE poc_mapping_rule (
    profile_id   NUMBER(19)            NOT NULL,
    seq_no       NUMBER(5)             NOT NULL,
    rule_kind    VARCHAR2(12 CHAR)     NOT NULL,
    target       VARCHAR2(200 CHAR),
    source       VARCHAR2(1000 CHAR),
    transform    VARCHAR2(12 CHAR)     NOT NULL,
    param        VARCHAR2(1000 CHAR),
    CONSTRAINT pk_poc_mapping_rule PRIMARY KEY (profile_id, seq_no),
    CONSTRAINT fk_poc_mapping_rule_profile FOREIGN KEY (profile_id) REFERENCES poc_mapping_profile (profile_id),
    CONSTRAINT ck_poc_mapping_rule_kind CHECK (rule_kind IN ('RECORD', 'FIELD', 'COLLECTION', 'LOOKUP', 'GROUP_BY'))
);
--rollback DROP TABLE poc_mapping_rule; DROP TABLE poc_mapping_profile; DROP SEQUENCE poc_profile_seq;
