package com.listhub.poc.record;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Supplier;

/** A list of child objects of the canonical record, for example {@code aliases}. */
public final class CollectionTarget {

    private final String name;
    private final String label;
    private final Class<?> owner;
    private final Supplier<Object> factory;
    private final Function<Record, List<Object>> list;
    private final Map<String, FieldTarget> fields = new LinkedHashMap<>();

    CollectionTarget(String name, String label, Class<?> owner, Supplier<Object> factory,
                     Function<Record, List<Object>> list) {
        this.name = name;
        this.label = label;
        this.owner = owner;
        this.factory = factory;
        this.list = list;
    }

    void add(FieldTarget field) {
        fields.put(field.getPath(), field);
    }

    public String getName() {
        return name;
    }

    public String getLabel() {
        return label;
    }

    public boolean appliesTo(Record record) {
        return owner.isInstance(record);
    }

    public Object newItem() {
        return factory.get();
    }

    public List<Object> itemsOf(Record record) {
        return list.apply(record);
    }

    /** Fields of one item, keyed by full path (for example {@code aliases.lastName}). */
    public Map<String, FieldTarget> getFields() {
        return Collections.unmodifiableMap(fields);
    }
}
