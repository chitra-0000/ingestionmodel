package com.listhub.poc.record;

import java.util.Objects;

/** Identity document of a record (passport, national id, registration number...). */
public class IdentityDocument {

    private String documentType;
    private String number;
    private String additionalInfo;

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        IdentityDocument other = (IdentityDocument) o;
        return Objects.equals(documentType, other.documentType)
            && Objects.equals(number, other.number)
            && Objects.equals(additionalInfo, other.additionalInfo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(documentType, number, additionalInfo);
    }

    @Override
    public String toString() {
        return "IdentityDocument{"
            + "documentType=" + documentType
            + ", number=" + number
            + ", additionalInfo=" + additionalInfo
            + "}";
    }
}
