package com.listhub.poc.record;

import java.util.function.BiConsumer;
import java.util.function.Function;

/**
 * One field of the canonical model a mapping can write to, for example {@code name} or
 * {@code aliases.lastName}. Values arrive as text and are converted by the setter.
 */
public final class FieldTarget {

    private final String path;
    private final String label;
    private final String section;
    private final Class<?> owner;
    private final int maxLength;
    private final boolean multiValue;
    private final Function<Object, Object> getter;
    private final BiConsumer<Object, String> setter;

    FieldTarget(String path, String label, String section, Class<?> owner, int maxLength, boolean multiValue,
                Function<Object, Object> getter, BiConsumer<Object, String> setter) {
        this.path = path;
        this.label = label;
        this.section = section;
        this.owner = owner;
        this.maxLength = maxLength;
        this.multiValue = multiValue;
        this.getter = getter;
        this.setter = setter;
    }

    public String getPath() {
        return path;
    }

    public String getLabel() {
        return label;
    }

    public String getSection() {
        return section;
    }

    /** The class holding the field: a record type, or a child object such as {@link Alias}. */
    public Class<?> getOwner() {
        return owner;
    }

    public int getMaxLength() {
        return maxLength;
    }

    /** True when the field is a list of values (for example BIC codes): every value is added. */
    public boolean isMultiValue() {
        return multiValue;
    }

    /** True when this field exists on the given object (for example firstName only on individuals). */
    public boolean appliesTo(Object target) {
        return owner.isInstance(target);
    }

    public Object get(Object target) {
        return getter.apply(target);
    }

    /** Sets (or, for a multi-value field, adds) one value. Throws {@link MappingException} when it cannot be converted. */
    public void set(Object target, String value) {
        setter.accept(target, value);
    }
}
