package com.listhub.poc.upload;

import com.listhub.poc.parse.FileFormat;
import com.listhub.poc.parse.FileInspector;
import com.listhub.poc.parse.InspectResult;
import com.listhub.poc.parse.MappingProfile;
import com.listhub.poc.parse.ProfileValidator;
import com.listhub.poc.parse.Transform;
import com.listhub.poc.record.CollectionTarget;
import com.listhub.poc.record.FieldTarget;
import com.listhub.poc.record.RecordFields;
import com.listhub.poc.store.ProfileRepository;
import com.listhub.poc.store.ProfileSummary;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.validation.constraints.Size;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/** Mapping profiles, the canonical fields they can target, and file inspection. */
@RestController
@Validated
@RequestMapping("/api/mapping")
public class MappingController {

    private final ProfileRepository profiles;
    private final FileInspector inspector;

    public MappingController(ProfileRepository profiles, FileInspector inspector) {
        this.profiles = profiles;
        this.inspector = inspector;
    }

    /** Every canonical field and collection a mapping can target, with labels and sections. */
    @GetMapping("/targets")
    public Map<String, Object> targets() {
        List<Map<String, Object>> fields = new ArrayList<>();
        Map<String, Object> type = new LinkedHashMap<>();
        type.put("path", RecordFields.TYPE);
        type.put("label", "Record type (INDIVIDUAL, ENTITY, VESSEL)");
        type.put("section", "General information");
        type.put("collection", null);
        type.put("maxLength", 10);
        fields.add(type);
        for (FieldTarget field : RecordFields.fields().values()) {
            fields.add(describe(field, null));
        }
        List<Map<String, Object>> collections = new ArrayList<>();
        for (CollectionTarget collection : RecordFields.collections().values()) {
            Map<String, Object> c = new LinkedHashMap<>();
            c.put("name", collection.getName());
            c.put("label", collection.getLabel());
            collections.add(c);
            for (FieldTarget field : collection.getFields().values()) {
                fields.add(describe(field, collection.getName()));
            }
        }
        List<Map<String, String>> transforms = new ArrayList<>();
        for (Transform t : Transform.values()) {
            Map<String, String> m = new LinkedHashMap<>();
            m.put("name", t.name());
            m.put("label", t.getLabel());
            transforms.add(m);
        }
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("fields", fields);
        body.put("collections", collections);
        body.put("transforms", transforms);
        body.put("recordTypes", Arrays.asList("INDIVIDUAL", "ENTITY", "VESSEL"));
        return body;
    }

    private static Map<String, Object> describe(FieldTarget field, String collection) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("path", field.getPath());
        m.put("label", field.getLabel());
        m.put("section", field.getSection());
        m.put("collection", collection);
        m.put("maxLength", field.getMaxLength());
        m.put("multiValue", field.isMultiValue());
        return m;
    }

    @GetMapping("/profiles")
    public List<ProfileSummary> list() {
        return profiles.findAll();
    }

    @GetMapping("/profiles/{id}")
    public MappingProfile one(@PathVariable long id) {
        MappingProfile profile = profiles.findById(id);
        if (profile == null) {
            throw new UploadException(404, "Mapping profile #" + id + " does not exist.");
        }
        return profile;
    }

    @PostMapping("/profiles")
    @ResponseStatus(HttpStatus.CREATED)
    public MappingProfile create(@RequestBody MappingProfile profile) {
        profile.setId(null);
        return save(profile);
    }

    @PutMapping("/profiles/{id}")
    public MappingProfile update(@PathVariable long id, @RequestBody MappingProfile profile) {
        if (!profiles.exists(id)) {
            throw new UploadException(404, "Mapping profile #" + id + " does not exist.");
        }
        profile.setId(id);
        return save(profile);
    }

    private MappingProfile save(MappingProfile profile) {
        List<String> problems = ProfileValidator.problems(profile);
        if (!problems.isEmpty()) {
            throw new UploadException(400, "The mapping cannot be saved: " + String.join(" ", problems.subList(0, Math.min(5, problems.size()))));
        }
        Long sameName = profiles.findIdByName(profile.getName());
        if (sameName != null && !sameName.equals(profile.getId())) {
            throw new UploadException(409, "A profile named '" + profile.getName().trim() + "' already exists. Choose another name.");
        }
        try {
            return profiles.findById(profiles.save(profile));
        } catch (DuplicateKeyException e) {
            throw new UploadException(409, "A profile named '" + profile.getName().trim() + "' already exists. Choose another name.");
        }
    }

    /**
     * Reads a file's structure: CSV columns, or XML record elements, paths and code lists, with
     * sample values. Nothing is saved.
     */
    @PostMapping(value = "/inspect", consumes = "multipart/form-data")
    public InspectResult inspect(@RequestPart("file") MultipartFile file,
                                 @RequestParam(required = false) @Size(max = 500) String recordElements,
                                 @RequestParam(required = false) @Size(max = 30) String encoding,
                                 @RequestParam(required = false) @Size(max = 3) String delimiter) {
        FileFormat format = FileFormat.fromFileName(UploadService.safeFileName(file.getOriginalFilename()));
        if (format == null) {
            throw new UploadException(400, "Only .xml and .csv (or .txt, .tsv) files can be inspected.");
        }
        if (file.isEmpty()) {
            throw new UploadException(400, "The file is empty.");
        }
        try {
            if (format == FileFormat.XML) {
                List<String> elements = recordElements == null ? new ArrayList<>()
                    : Arrays.asList(recordElements.split(","));
                return inspector.inspectXml(file, elements);
            }
            return inspector.inspectCsv(file, encoding, delimiter);
        } catch (IOException e) {
            throw new UploadException(400, "The file could not be read.");
        }
    }
}
