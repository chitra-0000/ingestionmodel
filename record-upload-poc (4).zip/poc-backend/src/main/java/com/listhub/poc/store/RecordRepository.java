package com.listhub.poc.store;

import com.listhub.poc.record.Address;
import com.listhub.poc.record.Alias;
import com.listhub.poc.record.CodeIban;
import com.listhub.poc.record.CountryDetails;
import com.listhub.poc.record.DateDetails;
import com.listhub.poc.record.EntityRecord;
import com.listhub.poc.record.IdentityDocument;
import com.listhub.poc.record.IndividualRecord;
import com.listhub.poc.record.Program;
import com.listhub.poc.record.Record;
import com.listhub.poc.record.RecordAssociation;
import com.listhub.poc.record.RecordDJ;
import com.listhub.poc.record.RecordRelation;
import com.listhub.poc.record.RecordSource;
import com.listhub.poc.record.RecordType;
import com.listhub.poc.record.ReferenceCode;
import com.listhub.poc.record.SanctionReference;
import com.listhub.poc.record.Values;
import com.listhub.poc.record.VesselRecord;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 * Writes canonical records (RECORD row plus one row per child object) in JDBC batches, and reads
 * them back. Every value is a bind variable; table and column names are fixed in this class.
 */
@Repository
public class RecordRepository {

    private static final String RECORD_COLUMNS = "id, upload_id, row_no, record_type, name, name_normalized, description,"
        + " dow_jones_notes, keywords, comments, additional_info, regliss_reference, record_id, start_date,"
        + " external_reference, instruction, external_uuid, last_modification_date, inactivity_date_as_pep,"
        + " inactivity_date_as_rca, from_version, to_version, deleted_in_version, gender, title, first_name, middle_name,"
        + " last_name, maiden_name, suffix, is_deceased, vessel_imo, vessel_flag, vessel_tonnage, vessel_owner,"
        + " vessel_type, vessel_gross_tonnage, vessel_call_sign, dj_action, dj_last_update_date, dj_active_status";

    private static final String INSERT_RECORD = "INSERT INTO poc_record (" + RECORD_COLUMNS + ", created_at) VALUES ("
        + "poc_record_seq.NEXTVAL, :uploadId, :rowNo, :recordType, :name, :nameNormalized, :description,"
        + " :dowJonesNotes, :keywords, :comments, :additionalInfo, :reglissReference, :recordId, :startDate,"
        + " :externalReference, :instruction, :externalUuid, :lastModificationDate, :inactivityDateAsPep,"
        + " :inactivityDateAsRca, :fromVersion, :toVersion, :deletedInVersion, :gender, :title, :firstName, :middleName,"
        + " :lastName, :maidenName, :suffix, :deceased, :vesselImo, :vesselFlag, :vesselTonnage, :vesselOwner,"
        + " :vesselType, :vesselGrossTonnage, :vesselCallSign, :djAction, :djLastUpdateDate, :djActiveStatus, :createdAt)";

    private static final String INSERT_REJECT = "INSERT INTO poc_reject (upload_id, row_no, external_ref, severity, reason)"
        + " VALUES (:uploadId, :rowNo, :externalRef, :severity, :reason)";

    /** Child tables in delete order; all keyed by (upload_id, row_no, seq_no). */
    private static final List<String> CHILD_TABLES = Collections.unmodifiableList(Arrays.asList(
        "poc_record_ref_code", "poc_record_code", "poc_record_program", "poc_record_alias", "poc_record_sanction_ref",
        "poc_record_source", "poc_record_relation", "poc_record_address", "poc_record_date", "poc_record_country",
        "poc_record_identity_doc"));

    private static final List<ChildTable<?>> CHILDREN = new ArrayList<>();
    private static final java.util.Set<String> INTEGER_COLUMNS = new java.util.HashSet<>(
        Arrays.asList("day_value", "month_value", "year_value"));

    static {
        refCodes("CATEGORY", Record::getCategories);
        refCodes("SANCTION_TYPE", Record::getSanctionTypes);
        refCodes("DESCRIPTION3", Record::getDescriptions3);
        refCodes("PEP_OCCUPATION", Record::getPepOccupationCategories);
        CHILDREN.add(new ChildTable<String>("poc_record_code", "code_kind, code_value",
            r -> r instanceof EntityRecord ? ((EntityRecord) r).getBicCodes() : Collections.<String>emptyList(),
            v -> new Object[] {"BIC", v}));
        CHILDREN.add(new ChildTable<String>("poc_record_code", "code_kind, code_value",
            r -> r instanceof EntityRecord ? ((EntityRecord) r).getIsinCodes() : Collections.<String>emptyList(),
            v -> new Object[] {"ISIN", v}));
        CHILDREN.add(new ChildTable<CodeIban>("poc_record_code", "code_kind, code_value", Record::getIbanCodes,
            c -> new Object[] {"IBAN", c.getCode()}));
        CHILDREN.add(new ChildTable<Program>("poc_record_program", "label, sanction_type", Record::getPrograms,
            p -> new Object[] {p.getLabel(), p.getSanctionType()}));
        CHILDREN.add(new ChildTable<Alias>("poc_record_alias",
            "regliss_reference, alias_type, alias_quality, title, first_name, middle_name, last_name, maiden_name, suffix, name",
            Record::getAliases, a -> new Object[] {a.getReglissReference(), a.getAliasType(), a.getAliasQuality(), a.getTitle(),
                a.getFirstName(), a.getMiddleName(), a.getLastName(), a.getMaidenName(), a.getSuffix(), a.getName()}));
        CHILDREN.add(new ChildTable<SanctionReference>("poc_record_sanction_ref", "code, list_name, since_date, end_date",
            Record::getSanctionReferences, s -> new Object[] {s.getCode(), s.getListName(), s.getSinceDate(), s.getEndDate()}));
        CHILDREN.add(new ChildTable<RecordSource>("poc_record_source", "source", Record::getSources,
            s -> new Object[] {s.getSource()}));
        CHILDREN.add(new ChildTable<RecordRelation>("poc_record_relation",
            "relation_kind, related_external_ref, relation_type, category, ex", Record::getRelations,
            x -> new Object[] {"RELATION", x.getRelatedExternalReference(), x.getRelationType(), x.getCategory(), x.getEx()}));
        CHILDREN.add(new ChildTable<RecordAssociation>("poc_record_relation",
            "relation_kind, related_external_ref, relation_type, category, ex", Record::getAssociations,
            x -> new Object[] {"ASSOCIATION", x.getRelatedExternalReference(), x.getRelationType(), x.getCategory(), x.getEx()}));
        CHILDREN.add(new ChildTable<Address>("poc_record_address", "address, zip_code, city, state, country, remarks",
            Record::getAddresses, a -> new Object[] {a.getAddress(), a.getZipCode(), a.getCity(), a.getState(), a.getCountry(),
                a.getRemarks()}));
        CHILDREN.add(new ChildTable<DateDetails>("poc_record_date",
            "date_type, day_value, month_value, year_value, date_value, birth_place, birth_country, additional_info",
            Record::getDatesDetails, d -> new Object[] {d.getDateType(), d.getDay(), d.getMonth(), d.getYear(), d.getDateValue(),
                d.getBirthPlace(), d.getBirthCountry(), d.getAdditionalInfo()}));
        CHILDREN.add(new ChildTable<CountryDetails>("poc_record_country", "country_type, country_code, country_name, additional_info",
            Record::getCountriesDetails, c -> new Object[] {c.getCountryType(), c.getCountryCode(), c.getCountryName(),
                c.getAdditionalInfo()}));
        CHILDREN.add(new ChildTable<IdentityDocument>("poc_record_identity_doc", "document_type, doc_number, additional_info",
            Record::getIdentityDocuments, d -> new Object[] {d.getDocumentType(), d.getNumber(), d.getAdditionalInfo()}));
    }

    private final NamedParameterJdbcTemplate jdbc;

    public RecordRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** One record of a batch: its position in the file and its canonical content. */
    public static final class Loaded {
        private final long rowNo;
        private final Record record;

        public Loaded(long rowNo, Record record) {
            this.rowNo = rowNo;
            this.record = record;
        }
    }

    // ------------------------------------------------------------------ write

    /** Inserts a chunk of records and all their child objects: one batch statement per table. */
    public void insertBatch(long uploadId, List<Loaded> records) {
        if (records.isEmpty()) {
            return;
        }
        Timestamp now = Timestamp.from(Instant.now());
        SqlParameterSource[] recordParams = new SqlParameterSource[records.size()];
        for (int i = 0; i < records.size(); i++) {
            recordParams[i] = recordParams(uploadId, records.get(i), now);
        }
        jdbc.batchUpdate(INSERT_RECORD, recordParams);

        Map<String, List<SqlParameterSource>> childParams = new LinkedHashMap<>();
        Map<String, String> childSql = new HashMap<>();
        Map<String, Integer> seq = new HashMap<>();
        for (Loaded loaded : records) {
            seq.clear();
            for (ChildTable<?> child : CHILDREN) {
                child.collect(uploadId, loaded, seq, childParams, childSql);
            }
        }
        for (Map.Entry<String, List<SqlParameterSource>> e : childParams.entrySet()) {
            jdbc.batchUpdate(childSql.get(e.getKey()), e.getValue().toArray(new SqlParameterSource[0]));
        }
    }

    private static MapSqlParameterSource recordParams(long uploadId, Loaded loaded, Timestamp now) {
        Record r = loaded.record;
        MapSqlParameterSource p = new MapSqlParameterSource()
            .addValue("uploadId", uploadId)
            .addValue("rowNo", loaded.rowNo)
            .addValue("recordType", r.getType().name(), Types.VARCHAR)
            .addValue("name", r.getName(), Types.VARCHAR)
            .addValue("nameNormalized", r.getNameNormalized(), Types.VARCHAR)
            .addValue("description", r.getDescription(), Types.VARCHAR)
            .addValue("dowJonesNotes", r.getDowJonesNotes(), Types.CLOB)
            .addValue("keywords", r.getKeywords(), Types.VARCHAR)
            .addValue("comments", r.getComments(), Types.VARCHAR)
            .addValue("additionalInfo", r.getAdditionalInfo(), Types.VARCHAR)
            .addValue("reglissReference", r.getReglissReference(), Types.VARCHAR)
            .addValue("recordId", r.getRecordId(), Types.VARCHAR)
            .addValue("startDate", r.getStartDateStr(), Types.VARCHAR)
            .addValue("externalReference", r.getExternalReference(), Types.VARCHAR)
            .addValue("instruction", r.getInstruction(), Types.VARCHAR)
            .addValue("externalUuid", r.getExternalUuid(), Types.VARCHAR)
            .addValue("lastModificationDate", r.getSynthesisModDate(), Types.VARCHAR)
            .addValue("inactivityDateAsPep", r.getInactivityDateAsPep(), Types.VARCHAR)
            .addValue("inactivityDateAsRca", r.getInactivityDateAsRca(), Types.VARCHAR)
            .addValue("fromVersion", r.getVersionLinks().getFromVersion(), Types.BIGINT)
            .addValue("toVersion", r.getVersionLinks().getToVersion(), Types.BIGINT)
            .addValue("deletedInVersion", r.getVersionLinks().getDeletedInVersion(), Types.BIGINT)
            .addValue("createdAt", now, Types.TIMESTAMP);
        IndividualRecord person = r instanceof IndividualRecord ? (IndividualRecord) r : null;
        p.addValue("gender", person == null ? null : person.getGender(), Types.VARCHAR)
            .addValue("title", person == null ? null : person.getTitle(), Types.VARCHAR)
            .addValue("firstName", person == null ? null : person.getFirstName(), Types.VARCHAR)
            .addValue("middleName", person == null ? null : person.getMiddleName(), Types.VARCHAR)
            .addValue("lastName", person == null ? null : person.getLastName(), Types.VARCHAR)
            .addValue("maidenName", person == null ? null : person.getMaidenName(), Types.VARCHAR)
            .addValue("suffix", person == null ? null : person.getSuffix(), Types.VARCHAR)
            .addValue("deceased", person == null || person.getDeceased() == null ? null : (person.getDeceased() ? 1 : 0),
                Types.INTEGER);
        VesselRecord vessel = r instanceof VesselRecord ? (VesselRecord) r : null;
        p.addValue("vesselImo", vessel == null ? null : vessel.getImoCode(), Types.VARCHAR)
            .addValue("vesselFlag", vessel == null ? null : vessel.getFlag(), Types.VARCHAR)
            .addValue("vesselTonnage", vessel == null ? null : vessel.getTonnage(), Types.VARCHAR)
            .addValue("vesselOwner", vessel == null ? null : vessel.getOwner(), Types.VARCHAR)
            .addValue("vesselType", vessel == null ? null : vessel.getVesselType(), Types.VARCHAR)
            .addValue("vesselGrossTonnage", vessel == null ? null : vessel.getGrossTonnage(), Types.VARCHAR)
            .addValue("vesselCallSign", vessel == null ? null : vessel.getCallSign(), Types.VARCHAR);
        RecordDJ dj = r.getRecordDJ();
        p.addValue("djAction", dj == null ? null : dj.getAction(), Types.VARCHAR)
            .addValue("djLastUpdateDate", dj == null ? null : dj.getLastUpdateDate(), Types.VARCHAR)
            .addValue("djActiveStatus", dj == null ? null : dj.getActiveStatus(), Types.VARCHAR);
        return p;
    }

    public void insertRejects(long uploadId, List<RejectRow> rejects) {
        if (rejects.isEmpty()) {
            return;
        }
        SqlParameterSource[] params = new SqlParameterSource[rejects.size()];
        for (int i = 0; i < rejects.size(); i++) {
            RejectRow r = rejects.get(i);
            params[i] = new MapSqlParameterSource()
                .addValue("uploadId", uploadId)
                .addValue("rowNo", r.getRowNo())
                .addValue("externalRef", fit(r.getExternalRef(), 250), Types.VARCHAR)
                .addValue("severity", r.getSeverity(), Types.VARCHAR)
                .addValue("reason", fit(r.getReason(), 1000), Types.VARCHAR);
        }
        jdbc.batchUpdate(INSERT_REJECT, params);
    }

    /** Removes everything one upload wrote (used when a file fails part-way). */
    public void deleteUpload(long uploadId) {
        MapSqlParameterSource p = new MapSqlParameterSource("uploadId", uploadId);
        for (String table : CHILD_TABLES) {
            jdbc.update("DELETE FROM " + table + " WHERE upload_id = :uploadId", p);
        }
        jdbc.update("DELETE FROM poc_record WHERE upload_id = :uploadId", p);
    }

    // ------------------------------------------------------------------ read

    public long countRecords(long uploadId, String search) {
        Long count = jdbc.queryForObject("SELECT COUNT(*) FROM poc_record WHERE upload_id = :uploadId" + searchFilter(search),
            searchParams(uploadId, search), Long.class);
        return count == null ? 0 : count;
    }

    /** One page of records with short lists of aliases, dates, countries and sanction lists. */
    public List<RecordSummary> findRecords(long uploadId, String search, int page, int size) {
        MapSqlParameterSource params = searchParams(uploadId, search)
            .addValue("offset", (long) page * size)
            .addValue("size", size);
        List<RecordSummary> rows = jdbc.query("SELECT row_no, external_reference, record_type, name FROM poc_record"
                + " WHERE upload_id = :uploadId" + searchFilter(search)
                + " ORDER BY row_no OFFSET :offset ROWS FETCH NEXT :size ROWS ONLY", params,
            (rs, n) -> {
                RecordSummary s = new RecordSummary();
                s.setRowNo(rs.getLong("row_no"));
                s.setExternalReference(rs.getString("external_reference"));
                s.setType(rs.getString("record_type"));
                s.setName(rs.getString("name"));
                return s;
            });
        if (rows.isEmpty()) {
            return rows;
        }
        Map<Long, RecordSummary> byRow = new HashMap<>();
        List<Long> rowNos = new ArrayList<>();
        for (RecordSummary s : rows) {
            byRow.put(s.getRowNo(), s);
            rowNos.add(s.getRowNo());
        }
        MapSqlParameterSource childParams = new MapSqlParameterSource("uploadId", uploadId).addValue("rows", rowNos);
        String where = " WHERE upload_id = :uploadId AND row_no IN (:rows) ORDER BY row_no, seq_no";
        jdbc.query("SELECT row_no, name, first_name, middle_name, last_name FROM poc_record_alias" + where, childParams, rs -> {
            String alias = rs.getString("name");
            if (Values.isBlank(alias)) {
                alias = joined(rs.getString("first_name"), rs.getString("middle_name"), rs.getString("last_name"));
            }
            addTo(byRow, rs.getLong("row_no"), RecordSummary::getAliases, alias);
        });
        jdbc.query("SELECT row_no, date_type, date_value FROM poc_record_date" + where, childParams, (RowCallbackHandler) rs ->
            addTo(byRow, rs.getLong("row_no"), RecordSummary::getDates,
                labelled(rs.getString("date_value"), rs.getString("date_type"))));
        jdbc.query("SELECT row_no, country_type, country_code, country_name FROM poc_record_country" + where, childParams, rs -> {
            String country = rs.getString("country_code") != null ? rs.getString("country_code") : rs.getString("country_name");
            addTo(byRow, rs.getLong("row_no"), RecordSummary::getCountries, labelled(country, rs.getString("country_type")));
        });
        jdbc.query("SELECT row_no, code, list_name FROM poc_record_sanction_ref" + where, childParams, (RowCallbackHandler) rs ->
            addTo(byRow, rs.getLong("row_no"), RecordSummary::getLists,
                rs.getString("list_name") != null ? rs.getString("list_name") : rs.getString("code")));
        jdbc.query("SELECT row_no, label FROM poc_record_program" + where, childParams, (RowCallbackHandler) rs ->
            addTo(byRow, rs.getLong("row_no"), RecordSummary::getLists, rs.getString("label")));
        for (String table : CHILD_TABLES) {
            jdbc.query("SELECT row_no, COUNT(*) AS n FROM " + table
                    + " WHERE upload_id = :uploadId AND row_no IN (:rows) GROUP BY row_no", childParams,
                rs -> {
                    RecordSummary s = byRow.get(rs.getLong("row_no"));
                    s.setChildCount(s.getChildCount() + rs.getInt("n"));
                });
        }
        return rows;
    }

    /** The full canonical record at one row of an upload, child objects included, or null. */
    public Record findRecord(long uploadId, long rowNo) {
        MapSqlParameterSource p = new MapSqlParameterSource("uploadId", uploadId).addValue("rowNo", rowNo);
        List<Record> found = jdbc.query("SELECT " + RECORD_COLUMNS + " FROM poc_record"
            + " WHERE upload_id = :uploadId AND row_no = :rowNo", p, RecordRepository::mapRecord);
        if (found.isEmpty()) {
            return null;
        }
        Record r = found.get(0);
        String where = " WHERE upload_id = :uploadId AND row_no = :rowNo ORDER BY seq_no";
        jdbc.query("SELECT ref_kind, code, label FROM poc_record_ref_code" + where, p, rs -> {
            ReferenceCode c = new ReferenceCode();
            c.setCode(rs.getString("code"));
            c.setLabel(rs.getString("label"));
            switch (rs.getString("ref_kind")) {
                case "CATEGORY":
                    r.getCategories().add(c);
                    break;
                case "SANCTION_TYPE":
                    r.getSanctionTypes().add(c);
                    break;
                case "DESCRIPTION3":
                    r.getDescriptions3().add(c);
                    break;
                default:
                    r.getPepOccupationCategories().add(c);
            }
        });
        jdbc.query("SELECT code_kind, code_value FROM poc_record_code" + where, p, rs -> {
            String kind = rs.getString("code_kind");
            String value = rs.getString("code_value");
            if ("IBAN".equals(kind)) {
                CodeIban iban = new CodeIban();
                iban.setCode(value);
                r.getIbanCodes().add(iban);
            } else if (r instanceof EntityRecord) {
                ("BIC".equals(kind) ? ((EntityRecord) r).getBicCodes() : ((EntityRecord) r).getIsinCodes()).add(value);
            }
        });
        jdbc.query("SELECT label, sanction_type FROM poc_record_program" + where, p, rs -> {
            Program x = new Program();
            x.setLabel(rs.getString("label"));
            x.setSanctionType(rs.getString("sanction_type"));
            r.getPrograms().add(x);
        });
        jdbc.query("SELECT regliss_reference, alias_type, alias_quality, title, first_name, middle_name, last_name, maiden_name,"
            + " suffix, name FROM poc_record_alias" + where, p, rs -> {
                Alias a = new Alias();
                a.setReglissReference(rs.getString("regliss_reference"));
                a.setAliasType(rs.getString("alias_type"));
                a.setAliasQuality(rs.getString("alias_quality"));
                a.setTitle(rs.getString("title"));
                a.setFirstName(rs.getString("first_name"));
                a.setMiddleName(rs.getString("middle_name"));
                a.setLastName(rs.getString("last_name"));
                a.setMaidenName(rs.getString("maiden_name"));
                a.setSuffix(rs.getString("suffix"));
                a.setName(rs.getString("name"));
                r.getAliases().add(a);
            });
        jdbc.query("SELECT code, list_name, since_date, end_date FROM poc_record_sanction_ref" + where, p, rs -> {
            SanctionReference s = new SanctionReference();
            s.setCode(rs.getString("code"));
            s.setListName(rs.getString("list_name"));
            s.setSinceDate(rs.getString("since_date"));
            s.setEndDate(rs.getString("end_date"));
            r.getSanctionReferences().add(s);
        });
        jdbc.query("SELECT source FROM poc_record_source" + where, p, rs -> {
            RecordSource s = new RecordSource();
            s.setSource(rs.getString("source"));
            r.getSources().add(s);
        });
        jdbc.query("SELECT relation_kind, related_external_ref, relation_type, category, ex FROM poc_record_relation" + where, p,
            rs -> {
                if ("ASSOCIATION".equals(rs.getString("relation_kind"))) {
                    RecordAssociation a = new RecordAssociation();
                    a.setRelatedExternalReference(rs.getString("related_external_ref"));
                    a.setRelationType(rs.getString("relation_type"));
                    a.setCategory(rs.getString("category"));
                    a.setEx(rs.getString("ex"));
                    r.getAssociations().add(a);
                } else {
                    RecordRelation x = new RecordRelation();
                    x.setRelatedExternalReference(rs.getString("related_external_ref"));
                    x.setRelationType(rs.getString("relation_type"));
                    x.setCategory(rs.getString("category"));
                    x.setEx(rs.getString("ex"));
                    r.getRelations().add(x);
                }
            });
        jdbc.query("SELECT address, zip_code, city, state, country, remarks FROM poc_record_address" + where, p, rs -> {
            Address a = new Address();
            a.setAddress(rs.getString("address"));
            a.setZipCode(rs.getString("zip_code"));
            a.setCity(rs.getString("city"));
            a.setState(rs.getString("state"));
            a.setCountry(rs.getString("country"));
            a.setRemarks(rs.getString("remarks"));
            r.getAddresses().add(a);
        });
        jdbc.query("SELECT date_type, day_value, month_value, year_value, date_value, birth_place, birth_country, additional_info"
            + " FROM poc_record_date" + where, p, rs -> {
                DateDetails d = new DateDetails();
                d.setDateType(rs.getString("date_type"));
                d.setDay(intOrNull(rs, "day_value"));
                d.setMonth(intOrNull(rs, "month_value"));
                d.setYear(intOrNull(rs, "year_value"));
                d.setDateValue(rs.getString("date_value"));
                d.setBirthPlace(rs.getString("birth_place"));
                d.setBirthCountry(rs.getString("birth_country"));
                d.setAdditionalInfo(rs.getString("additional_info"));
                r.getDatesDetails().add(d);
            });
        jdbc.query("SELECT country_type, country_code, country_name, additional_info FROM poc_record_country" + where, p, rs -> {
            CountryDetails c = new CountryDetails();
            c.setCountryType(rs.getString("country_type"));
            c.setCountryCode(rs.getString("country_code"));
            c.setCountryName(rs.getString("country_name"));
            c.setAdditionalInfo(rs.getString("additional_info"));
            r.getCountriesDetails().add(c);
        });
        jdbc.query("SELECT document_type, doc_number, additional_info FROM poc_record_identity_doc" + where, p, rs -> {
            IdentityDocument d = new IdentityDocument();
            d.setDocumentType(rs.getString("document_type"));
            d.setNumber(rs.getString("doc_number"));
            d.setAdditionalInfo(rs.getString("additional_info"));
            r.getIdentityDocuments().add(d);
        });
        return r;
    }

    private static Record mapRecord(ResultSet rs, int rowNum) throws SQLException {
        Record r = Record.of(RecordType.valueOf(rs.getString("record_type")));
        r.setId(rs.getLong("id"));
        r.setName(rs.getString("name"));
        r.setNameNormalized(rs.getString("name_normalized"));
        r.setDescription(rs.getString("description"));
        r.setDowJonesNotes(rs.getString("dow_jones_notes"));
        r.setKeywords(rs.getString("keywords"));
        r.setComments(rs.getString("comments"));
        r.setAdditionalInfo(rs.getString("additional_info"));
        r.setReglissReference(rs.getString("regliss_reference"));
        r.setRecordId(rs.getString("record_id"));
        r.setStartDateStr(rs.getString("start_date"));
        r.setExternalReference(rs.getString("external_reference"));
        r.setInstruction(rs.getString("instruction"));
        r.setExternalUuid(rs.getString("external_uuid"));
        r.setSynthesisModDate(rs.getString("last_modification_date"));
        r.setInactivityDateAsPep(rs.getString("inactivity_date_as_pep"));
        r.setInactivityDateAsRca(rs.getString("inactivity_date_as_rca"));
        r.getVersionLinks().setFromVersion(longOrNull(rs, "from_version"));
        r.getVersionLinks().setToVersion(longOrNull(rs, "to_version"));
        r.getVersionLinks().setDeletedInVersion(longOrNull(rs, "deleted_in_version"));
        if (r instanceof IndividualRecord) {
            IndividualRecord person = (IndividualRecord) r;
            person.setGender(rs.getString("gender"));
            person.setTitle(rs.getString("title"));
            person.setFirstName(rs.getString("first_name"));
            person.setMiddleName(rs.getString("middle_name"));
            person.setLastName(rs.getString("last_name"));
            person.setMaidenName(rs.getString("maiden_name"));
            person.setSuffix(rs.getString("suffix"));
            Integer deceased = intOrNull(rs, "is_deceased");
            person.setDeceased(deceased == null ? null : deceased == 1);
        } else if (r instanceof VesselRecord) {
            VesselRecord vessel = (VesselRecord) r;
            vessel.setImoCode(rs.getString("vessel_imo"));
            vessel.setFlag(rs.getString("vessel_flag"));
            vessel.setTonnage(rs.getString("vessel_tonnage"));
            vessel.setOwner(rs.getString("vessel_owner"));
            vessel.setVesselType(rs.getString("vessel_type"));
            vessel.setGrossTonnage(rs.getString("vessel_gross_tonnage"));
            vessel.setCallSign(rs.getString("vessel_call_sign"));
        }
        if (rs.getString("dj_action") != null || rs.getString("dj_last_update_date") != null
            || rs.getString("dj_active_status") != null) {
            RecordDJ dj = new RecordDJ();
            dj.setAction(rs.getString("dj_action"));
            dj.setLastUpdateDate(rs.getString("dj_last_update_date"));
            dj.setActiveStatus(rs.getString("dj_active_status"));
            r.setRecordDJ(dj);
        }
        return r;
    }

    public List<RejectRow> findRejects(long uploadId, int limit) {
        return jdbc.query("SELECT row_no, external_ref, severity, reason FROM poc_reject WHERE upload_id = :uploadId"
                + " ORDER BY row_no, severity FETCH FIRST :limit ROWS ONLY",
            new MapSqlParameterSource("uploadId", uploadId).addValue("limit", limit),
            (rs, n) -> new RejectRow(rs.getLong("row_no"), rs.getString("external_ref"), rs.getString("severity"),
                rs.getString("reason")));
    }

    // ------------------------------------------------------------------ helpers

    private static String searchFilter(String search) {
        return Values.isBlank(search) ? ""
            : " AND (name_normalized LIKE :pattern ESCAPE '\\' OR UPPER(external_reference) LIKE :refPattern ESCAPE '\\')";
    }

    private static MapSqlParameterSource searchParams(long uploadId, String search) {
        MapSqlParameterSource p = new MapSqlParameterSource("uploadId", uploadId);
        if (!Values.isBlank(search)) {
            String normalized = Values.normalizeName(search);
            p.addValue("pattern", "%" + escapeLike(normalized == null ? "" : normalized) + "%", Types.VARCHAR);
            p.addValue("refPattern", "%" + escapeLike(search.trim().toUpperCase(java.util.Locale.ROOT)) + "%", Types.VARCHAR);
        }
        return p;
    }

    private static String escapeLike(String value) {
        return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
    }

    private static void addTo(Map<Long, RecordSummary> byRow, long rowNo, Function<RecordSummary, List<String>> list,
                                  String value) {
        RecordSummary s = byRow.get(rowNo);
        if (s != null && !Values.isBlank(value) && list.apply(s).size() < 5) {
            list.apply(s).add(value);
        }
    }

    private static String labelled(String value, String label) {
        if (Values.isBlank(value)) {
            return null;
        }
        return Values.isBlank(label) ? value : value + " (" + label + ")";
    }

    private static String joined(String... parts) {
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!Values.isBlank(part)) {
                sb.append(sb.length() == 0 ? "" : " ").append(part.trim());
            }
        }
        return sb.toString();
    }

    private static Integer intOrNull(ResultSet rs, String column) throws SQLException {
        int v = rs.getInt(column);
        return rs.wasNull() ? null : v;
    }

    private static Long longOrNull(ResultSet rs, String column) throws SQLException {
        long v = rs.getLong(column);
        return rs.wasNull() ? null : v;
    }

    private static String fit(String value, int max) {
        return value == null || value.length() <= max ? value : value.substring(0, max);
    }

    private static void refCodes(String kind, Function<Record, List<ReferenceCode>> list) {
        CHILDREN.add(new ChildTable<ReferenceCode>("poc_record_ref_code", "ref_kind, code, label", list,
            c -> new Object[] {kind, c.getCode(), c.getLabel()}));
    }

    /** How one child list of the record is written to its table. */
    private static final class ChildTable<T> {
        private final String table;
        private final String[] columns;
        private final String sql;
        private final Function<Record, List<T>> items;
        private final Function<T, Object[]> values;

        ChildTable(String table, String columns, Function<Record, List<T>> items, Function<T, Object[]> values) {
            this.table = table;
            this.columns = columns.split(",\\s*");
            StringBuilder names = new StringBuilder("upload_id, row_no, seq_no");
            StringBuilder binds = new StringBuilder(":uploadId, :rowNo, :seqNo");
            for (String c : this.columns) {
                names.append(", ").append(c);
                binds.append(", :").append(c);
            }
            this.sql = "INSERT INTO " + table + " (" + names + ") VALUES (" + binds + ")";
            this.items = items;
            this.values = values;
        }

        void collect(long uploadId, Loaded loaded, Map<String, Integer> seq, Map<String, List<SqlParameterSource>> params,
                     Map<String, String> sqlByTable) {
            List<T> list = items.apply(loaded.record);
            if (list == null || list.isEmpty()) {
                return;
            }
            sqlByTable.put(table, sql);
            List<SqlParameterSource> tableParams = params.computeIfAbsent(table, k -> new ArrayList<>());
            for (T item : list) {
                int next = seq.merge(table, 1, Integer::sum);
                Object[] v = values.apply(item);
                MapSqlParameterSource p = new MapSqlParameterSource()
                    .addValue("uploadId", uploadId)
                    .addValue("rowNo", loaded.rowNo)
                    .addValue("seqNo", next);
                for (int i = 0; i < columns.length; i++) {
                    p.addValue(columns[i], v[i], INTEGER_COLUMNS.contains(columns[i]) ? Types.INTEGER : Types.VARCHAR);
                }
                tableParams.add(p);
            }
        }
    }
}
