package com.listhub.poc.record;

import java.util.Objects;

/** Date of a record (birth, death, registration...) kept as parts, so partial dates are not lost. dateValue is the partial ISO date (yyyy, yyyy-MM or yyyy-MM-dd). */
public class DateDetails {

    private String dateType;
    private Integer day;
    private Integer month;
    private Integer year;
    private String dateValue;
    private String birthPlace;
    private String birthCountry;
    private String additionalInfo;

    public String getDateType() {
        return dateType;
    }

    public void setDateType(String dateType) {
        this.dateType = dateType;
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getDateValue() {
        return dateValue;
    }

    public void setDateValue(String dateValue) {
        this.dateValue = dateValue;
    }

    public String getBirthPlace() {
        return birthPlace;
    }

    public void setBirthPlace(String birthPlace) {
        this.birthPlace = birthPlace;
    }

    public String getBirthCountry() {
        return birthCountry;
    }

    public void setBirthCountry(String birthCountry) {
        this.birthCountry = birthCountry;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DateDetails other = (DateDetails) o;
        return Objects.equals(dateType, other.dateType)
            && Objects.equals(day, other.day)
            && Objects.equals(month, other.month)
            && Objects.equals(year, other.year)
            && Objects.equals(dateValue, other.dateValue)
            && Objects.equals(birthPlace, other.birthPlace)
            && Objects.equals(birthCountry, other.birthCountry)
            && Objects.equals(additionalInfo, other.additionalInfo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dateType, day, month, year, dateValue, birthPlace, birthCountry, additionalInfo);
    }

    @Override
    public String toString() {
        return "DateDetails{"
            + "dateType=" + dateType
            + ", day=" + day
            + ", month=" + month
            + ", year=" + year
            + ", dateValue=" + dateValue
            + ", birthPlace=" + birthPlace
            + ", birthCountry=" + birthCountry
            + ", additionalInfo=" + additionalInfo
            + "}";
    }
}
