package com.listhub.poc.store;

/** A row of the file with a problem: ERROR (not loaded) or WARNING (loaded), and why. */
public class RejectRow {

    public static final String ERROR = "ERROR";
    public static final String WARNING = "WARNING";

    private final long rowNo;
    private final String externalRef;
    private final String severity;
    private final String reason;

    public RejectRow(long rowNo, String externalRef, String severity, String reason) {
        this.rowNo = rowNo;
        this.externalRef = externalRef;
        this.severity = severity;
        this.reason = reason;
    }

    public long getRowNo() {
        return rowNo;
    }

    public String getExternalRef() {
        return externalRef;
    }

    public String getSeverity() {
        return severity;
    }

    public String getReason() {
        return reason;
    }
}
