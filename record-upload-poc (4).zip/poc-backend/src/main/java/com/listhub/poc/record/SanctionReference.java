package com.listhub.poc.record;

import java.util.Objects;

/** Sanction list or regulation the record is on. Dates are partial ISO dates (yyyy, yyyy-MM or yyyy-MM-dd). */
public class SanctionReference {

    private String code;
    private String listName;
    private String sinceDate;
    private String endDate;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getListName() {
        return listName;
    }

    public void setListName(String listName) {
        this.listName = listName;
    }

    public String getSinceDate() {
        return sinceDate;
    }

    public void setSinceDate(String sinceDate) {
        this.sinceDate = sinceDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SanctionReference other = (SanctionReference) o;
        return Objects.equals(code, other.code)
            && Objects.equals(listName, other.listName)
            && Objects.equals(sinceDate, other.sinceDate)
            && Objects.equals(endDate, other.endDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, listName, sinceDate, endDate);
    }

    @Override
    public String toString() {
        return "SanctionReference{"
            + "code=" + code
            + ", listName=" + listName
            + ", sinceDate=" + sinceDate
            + ", endDate=" + endDate
            + "}";
    }
}
