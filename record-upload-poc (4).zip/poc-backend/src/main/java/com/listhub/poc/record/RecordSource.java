package com.listhub.poc.record;

import java.util.Objects;

/** Source document or link for a record. */
public class RecordSource {

    private String source;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RecordSource other = (RecordSource) o;
        return Objects.equals(source, other.source);
    }

    @Override
    public int hashCode() {
        return Objects.hash(source);
    }

    @Override
    public String toString() {
        return "RecordSource{"
            + "source=" + source
            + "}";
    }
}
