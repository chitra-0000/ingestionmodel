package com.listhub.poc.parse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

/** Splits a cell on a literal separator; empty parts are dropped. */
final class Splitter {

    private Splitter() {
    }

    static List<String> split(String value, String separator) {
        if (separator == null || separator.isEmpty()) {
            return value.trim().isEmpty() ? Collections.<String>emptyList() : Collections.singletonList(value.trim());
        }
        List<String> parts = new ArrayList<>();
        for (String part : value.split(Pattern.quote(separator), -1)) {
            if (!part.trim().isEmpty()) {
                parts.add(part.trim());
            }
        }
        return parts;
    }
}
