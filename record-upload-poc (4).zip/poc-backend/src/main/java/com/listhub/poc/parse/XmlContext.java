package com.listhub.poc.parse;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Mapping values read from one XML element, with paths relative to it. */
final class XmlContext implements MappingContext {

    private final XmlNode node;
    private final XmlNode record;
    private final Map<String, PathExpr> paths;

    XmlContext(XmlNode node, XmlNode record, Map<String, PathExpr> paths) {
        this.node = node;
        this.record = record;
        this.paths = paths;
    }

    @Override
    public List<String> values(String source) {
        return path(source).values(node, record);
    }

    @Override
    public List<MappingContext> items(String source, String separator) {
        List<MappingContext> items = new ArrayList<>();
        for (String part : RecordMapper.SOURCE_SEPARATOR.split(source.trim())) {
            for (XmlNode item : path(part.trim()).select(node, record)) {
                items.add(new XmlContext(item, record, paths));
            }
        }
        return items;
    }

    private PathExpr path(String source) {
        PathExpr path = paths.get(source);
        if (path == null) {
            path = PathExpr.parse(source);
            paths.put(source, path);
        }
        return path;
    }
}
