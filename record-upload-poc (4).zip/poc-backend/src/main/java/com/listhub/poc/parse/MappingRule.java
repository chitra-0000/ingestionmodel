package com.listhub.poc.parse;

/** One line of a mapping profile. See {@link RuleKind} for the meaning of target, source and param. */
public class MappingRule {

    private RuleKind kind;
    private String target;
    private String source;
    private Transform transform = Transform.NONE;
    private String param;

    public MappingRule() {
    }

    public MappingRule(RuleKind kind, String target, String source, Transform transform, String param) {
        this.kind = kind;
        this.target = target;
        this.source = source;
        this.transform = transform;
        this.param = param;
    }

    public RuleKind getKind() {
        return kind;
    }

    public void setKind(RuleKind kind) {
        this.kind = kind;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public Transform getTransform() {
        return transform;
    }

    public void setTransform(Transform transform) {
        this.transform = transform;
    }

    public String getParam() {
        return param;
    }

    public void setParam(String param) {
        this.param = param;
    }
}
