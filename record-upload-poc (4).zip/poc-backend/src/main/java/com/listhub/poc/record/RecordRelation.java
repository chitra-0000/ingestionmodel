package com.listhub.poc.record;

import java.util.Objects;

/** Link from a record to another record of the same list. */
public class RecordRelation {

    private String relatedExternalReference;
    private String relationType;
    private String category;
    private String ex;

    public String getRelatedExternalReference() {
        return relatedExternalReference;
    }

    public void setRelatedExternalReference(String relatedExternalReference) {
        this.relatedExternalReference = relatedExternalReference;
    }

    public String getRelationType() {
        return relationType;
    }

    public void setRelationType(String relationType) {
        this.relationType = relationType;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getEx() {
        return ex;
    }

    public void setEx(String ex) {
        this.ex = ex;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RecordRelation other = (RecordRelation) o;
        return Objects.equals(relatedExternalReference, other.relatedExternalReference)
            && Objects.equals(relationType, other.relationType)
            && Objects.equals(category, other.category)
            && Objects.equals(ex, other.ex);
    }

    @Override
    public int hashCode() {
        return Objects.hash(relatedExternalReference, relationType, category, ex);
    }

    @Override
    public String toString() {
        return "RecordRelation{"
            + "relatedExternalReference=" + relatedExternalReference
            + ", relationType=" + relationType
            + ", category=" + category
            + ", ex=" + ex
            + "}";
    }
}
