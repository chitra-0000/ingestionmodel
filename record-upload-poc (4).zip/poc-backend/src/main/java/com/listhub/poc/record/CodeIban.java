package com.listhub.poc.record;

import java.util.Objects;

/** IBAN code of a record. */
public class CodeIban {

    private String code;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CodeIban other = (CodeIban) o;
        return Objects.equals(code, other.code);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code);
    }

    @Override
    public String toString() {
        return "CodeIban{"
            + "code=" + code
            + "}";
    }
}
