package com.listhub.poc.upload;

import com.listhub.poc.parse.CsvRecordReader;
import com.listhub.poc.parse.FileFormat;
import com.listhub.poc.parse.FileFormatException;
import com.listhub.poc.parse.MappingProfile;
import com.listhub.poc.parse.ProfileValidator;
import com.listhub.poc.parse.RecordSink;
import com.listhub.poc.parse.RecordValidator;
import com.listhub.poc.parse.XmlRecordReader;
import com.listhub.poc.record.Record;
import com.listhub.poc.store.ProfileRepository;
import com.listhub.poc.store.RecordRepository;
import com.listhub.poc.store.RejectRow;
import com.listhub.poc.store.UploadRepository;
import com.listhub.poc.store.UploadSummary;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.multipart.MultipartFile;

/**
 * Loads one uploaded file with a mapping profile: checks it, refuses the same file loaded twice
 * with the same profile, streams it through the CSV or XML reader, which maps every record into
 * the canonical model, checks each record, and writes them in batches. Memory use stays at one
 * batch of records whatever the file size. A file that fails part-way leaves no records behind.
 */
@Service
public class UploadService {

    private static final Logger LOG = LoggerFactory.getLogger(UploadService.class);
    private static final int MAX_REJECTS_STORED = 10_000;
    private static final int REJECTS_RETURNED = 100;

    private final XmlRecordReader xmlReader;
    private final CsvRecordReader csvReader;
    private final RecordValidator validator;
    private final ProfileRepository profiles;
    private final UploadRepository uploads;
    private final RecordRepository records;
    private final TransactionTemplate transactions;
    private final int batchSize;

    public UploadService(XmlRecordReader xmlReader, CsvRecordReader csvReader, RecordValidator validator,
                         ProfileRepository profiles, UploadRepository uploads, RecordRepository records,
                         TransactionTemplate transactions, @Value("${poc.upload.batch-size:500}") int batchSize) {
        this.xmlReader = xmlReader;
        this.csvReader = csvReader;
        this.validator = validator;
        this.profiles = profiles;
        this.uploads = uploads;
        this.records = records;
        this.transactions = transactions;
        this.batchSize = batchSize;
    }

    public UploadResult upload(MultipartFile file, long profileId) {
        String fileName = safeFileName(file.getOriginalFilename());
        FileFormat format = FileFormat.fromFileName(fileName);
        if (format == null) {
            throw new UploadException(400, "Only .xml and .csv (or .txt, .tsv) files can be uploaded.");
        }
        if (file.isEmpty()) {
            throw new UploadException(400, "The file is empty.");
        }
        MappingProfile profile = profiles.findById(profileId);
        if (profile == null) {
            throw new UploadException(404, "Mapping profile #" + profileId + " does not exist.");
        }
        if (profile.getFormat() != format) {
            throw new UploadException(400, "The profile '" + profile.getName() + "' is for " + profile.getFormat()
                + " files, but this file is " + format + ". Choose a " + format + " profile.");
        }
        List<String> problems = ProfileValidator.problems(profile);
        if (!problems.isEmpty()) {
            throw new UploadException(400, "The profile '" + profile.getName() + "' cannot be used: " + problems.get(0));
        }
        String sha256 = sha256Of(file);
        UploadSummary earlier = uploads.findCompletedBySha256(sha256, profileId);
        if (earlier != null) {
            throw new UploadException(409, "This file was already loaded with this profile as upload #" + earlier.getUploadId()
                + " (" + earlier.getFileName() + "). The same content is never loaded twice.");
        }

        long uploadId = uploads.nextId();
        uploads.insertProcessing(uploadId, fileName, format.name(), sha256, file.getSize(), profileId, profile.getName());
        LoadingSink sink = new LoadingSink(uploadId);
        try {
            if (format == FileFormat.XML) {
                xmlReader.read(file, profile, sink);
            } else {
                csvReader.read(file, profile, sink);
            }
            sink.flush();
            uploads.finish(uploadId, "COMPLETED", sink.read, sink.loaded, sink.rejected, completedMessage(sink));
        } catch (FileFormatException e) {
            fail(uploadId, sink, e.getMessage());
        } catch (IOException | IllegalStateException e) {
            LOG.warn("Upload {} could not be read: {}", uploadId, e.getClass().getSimpleName());
            fail(uploadId, sink, "The file could not be read. Check that it is a complete " + format.name() + " file.");
        } catch (DataAccessException e) {
            LOG.error("Upload {} failed while writing to the database", uploadId, e);
            fail(uploadId, sink, "The records could not be saved to the database. Try again later.");
        }
        return new UploadResult(uploads.findById(uploadId), records.findRejects(uploadId, REJECTS_RETURNED));
    }

    private void fail(long uploadId, LoadingSink sink, String message) {
        transactions.execute(status -> {
            records.deleteUpload(uploadId);
            return null;
        });
        uploads.finish(uploadId, "FAILED", sink.read, 0, sink.rejected, message);
    }

    private static String completedMessage(LoadingSink sink) {
        StringBuilder sb = new StringBuilder();
        if (sink.rejected == 0) {
            sb.append("All ").append(sink.loaded).append(" records were loaded.");
        } else {
            sb.append(sink.loaded).append(" records loaded, ").append(sink.rejected).append(" rejected (see the reasons below).");
        }
        if (sink.warned > 0) {
            sb.append(' ').append(sink.warned).append(" loaded with a warning.");
        }
        return sb.toString();
    }

    /** Keeps the file's own name only: no folders, no control characters, at most 255 characters. */
    static String safeFileName(String original) {
        if (original == null) {
            return "upload";
        }
        String name = original.replace('\\', '/');
        name = name.substring(name.lastIndexOf('/') + 1);
        name = name.replaceAll("[\\p{Cntrl}]", "").trim();
        if (name.isEmpty()) {
            return "upload";
        }
        return name.length() > 255 ? name.substring(name.length() - 255) : name;
    }

    private static String sha256Of(MultipartFile file) {
        try (InputStream in = new DigestInputStream(new BufferedInputStream(file.getInputStream()), sha256())) {
            byte[] buffer = new byte[64 * 1024];
            while (in.read(buffer) != -1) {
                // reading feeds the digest
            }
            byte[] hash = ((DigestInputStream) in).getMessageDigest().digest();
            StringBuilder hex = new StringBuilder(hash.length * 2);
            for (byte b : hash) {
                hex.append(String.format(Locale.ROOT, "%02x", b));
            }
            return hex.toString();
        } catch (IOException e) {
            throw new UploadException(400, "The uploaded file could not be read.");
        }
    }

    private static MessageDigest sha256() {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is not available", e);
        }
    }

    /** Checks each mapped record, collects them into batches and writes each batch in its own transaction. */
    private final class LoadingSink implements RecordSink {
        private final long uploadId;
        private final List<RecordRepository.Loaded> batch = new ArrayList<>(batchSize);
        private final List<RejectRow> rejectBatch = new ArrayList<>();
        private long read;
        private long loaded;
        private long rejected;
        private long warned;
        private long problemsStored;

        LoadingSink(long uploadId) {
            this.uploadId = uploadId;
        }

        @Override
        public void accept(long rowNo, Record record) {
            read++;
            RecordValidator.Result check = validator.check(record);
            if (!check.getErrors().isEmpty()) {
                rejected++;
                addProblem(rowNo, record.getExternalReference(), RejectRow.ERROR, String.join(" ", check.getErrors()));
                return;
            }
            if (!check.getWarnings().isEmpty()) {
                warned++;
                addProblem(rowNo, record.getExternalReference(), RejectRow.WARNING, String.join(" ", check.getWarnings()));
            }
            record.getVersionLinks().setFromVersion(uploadId);
            batch.add(new RecordRepository.Loaded(rowNo, record));
            if (batch.size() >= batchSize) {
                flush();
            }
        }

        @Override
        public void reject(long rowNo, String externalReference, String reason) {
            read++;
            rejected++;
            addProblem(rowNo, externalReference, RejectRow.ERROR, reason);
        }

        private void addProblem(long rowNo, String externalReference, String severity, String reason) {
            problemsStored++;
            if (problemsStored <= MAX_REJECTS_STORED) {
                rejectBatch.add(new RejectRow(rowNo, externalReference, severity, reason));
            }
            if (rejectBatch.size() >= batchSize) {
                flush();
            }
        }

        void flush() {
            if (batch.isEmpty() && rejectBatch.isEmpty()) {
                return;
            }
            final List<RecordRepository.Loaded> toWrite = new ArrayList<>(batch);
            final List<RejectRow> rejectsToWrite = new ArrayList<>(rejectBatch);
            transactions.execute(status -> {
                records.insertBatch(uploadId, toWrite);
                records.insertRejects(uploadId, rejectsToWrite);
                return null;
            });
            loaded += toWrite.size();
            batch.clear();
            rejectBatch.clear();
        }
    }
}
