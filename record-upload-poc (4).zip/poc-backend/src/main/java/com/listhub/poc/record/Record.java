package com.listhub.poc.record;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Canonical record: every provider file, whatever its format, is mapped into this model before
 * it is saved, and the downstream systems are published from it. Mirrors the bank's Record entity
 * field for field; child objects stay objects. Fields the file does not provide stay null.
 * Type-specific fields live in {@link IndividualRecord}, {@link EntityRecord} and
 * {@link VesselRecord} (single table, RECORD_TYPE discriminator).
 */
public abstract class Record {

    private Long id;
    private final RecordType type;

    private List<ReferenceCode> categories = new ArrayList<>();
    private List<ReferenceCode> sanctionTypes = new ArrayList<>();
    private List<ReferenceCode> descriptions3 = new ArrayList<>();
    private List<ReferenceCode> pepOccupationCategories = new ArrayList<>();

    private String name;
    private String nameNormalized;
    private String description;
    private String dowJonesNotes;
    private String keywords;
    private String comments;
    private String additionalInfo;
    private String reglissReference;
    private String recordId;
    private String startDateStr;
    private String externalReference;
    private String instruction;

    private List<Program> programs = new ArrayList<>();
    private List<Alias> aliases = new ArrayList<>();
    private List<SanctionReference> sanctionReferences = new ArrayList<>();
    private List<RecordSource> sources = new ArrayList<>();
    private List<RecordRelation> relations = new ArrayList<>();
    private List<RecordAssociation> associations = new ArrayList<>();
    private List<Address> addresses = new ArrayList<>();
    private List<CodeIban> ibanCodes = new ArrayList<>();

    private RecordDJ recordDJ;
    private String externalUuid;
    private String synthesisModDate;
    private String inactivityDateAsPep;
    private String inactivityDateAsRca;
    private RecordVersionLinks versionLinks = new RecordVersionLinks();

    private List<DateDetails> datesDetails = new ArrayList<>();
    private List<CountryDetails> countriesDetails = new ArrayList<>();
    private List<IdentityDocument> identityDocuments = new ArrayList<>();

    protected Record(RecordType type) {
        this.type = type;
    }

    /** A new, empty record of the given type. */
    public static Record of(RecordType type) {
        switch (type) {
            case ENTITY:
                return new EntityRecord();
            case VESSEL:
                return new VesselRecord();
            default:
                return new IndividualRecord();
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public RecordType getType() {
        return type;
    }

    public List<ReferenceCode> getCategories() {
        return categories;
    }

    public void setCategories(List<ReferenceCode> categories) {
        this.categories = categories;
    }

    public List<ReferenceCode> getSanctionTypes() {
        return sanctionTypes;
    }

    public void setSanctionTypes(List<ReferenceCode> sanctionTypes) {
        this.sanctionTypes = sanctionTypes;
    }

    public List<ReferenceCode> getDescriptions3() {
        return descriptions3;
    }

    public void setDescriptions3(List<ReferenceCode> descriptions3) {
        this.descriptions3 = descriptions3;
    }

    public List<ReferenceCode> getPepOccupationCategories() {
        return pepOccupationCategories;
    }

    public void setPepOccupationCategories(List<ReferenceCode> pepOccupationCategories) {
        this.pepOccupationCategories = pepOccupationCategories;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameNormalized() {
        return nameNormalized;
    }

    public void setNameNormalized(String nameNormalized) {
        this.nameNormalized = nameNormalized;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDowJonesNotes() {
        return dowJonesNotes;
    }

    public void setDowJonesNotes(String dowJonesNotes) {
        this.dowJonesNotes = dowJonesNotes;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getReglissReference() {
        return reglissReference;
    }

    public void setReglissReference(String reglissReference) {
        this.reglissReference = reglissReference;
    }

    public String getRecordId() {
        return recordId;
    }

    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    public String getStartDateStr() {
        return startDateStr;
    }

    public void setStartDateStr(String startDateStr) {
        this.startDateStr = startDateStr;
    }

    public String getExternalReference() {
        return externalReference;
    }

    public void setExternalReference(String externalReference) {
        this.externalReference = externalReference;
    }

    public String getInstruction() {
        return instruction;
    }

    public void setInstruction(String instruction) {
        this.instruction = instruction;
    }

    public List<Program> getPrograms() {
        return programs;
    }

    public void setPrograms(List<Program> programs) {
        this.programs = programs;
    }

    public List<Alias> getAliases() {
        return aliases;
    }

    public void setAliases(List<Alias> aliases) {
        this.aliases = aliases;
    }

    public List<SanctionReference> getSanctionReferences() {
        return sanctionReferences;
    }

    public void setSanctionReferences(List<SanctionReference> sanctionReferences) {
        this.sanctionReferences = sanctionReferences;
    }

    public List<RecordSource> getSources() {
        return sources;
    }

    public void setSources(List<RecordSource> sources) {
        this.sources = sources;
    }

    public List<RecordRelation> getRelations() {
        return relations;
    }

    public void setRelations(List<RecordRelation> relations) {
        this.relations = relations;
    }

    public List<RecordAssociation> getAssociations() {
        return associations;
    }

    public void setAssociations(List<RecordAssociation> associations) {
        this.associations = associations;
    }

    public List<Address> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<Address> addresses) {
        this.addresses = addresses;
    }

    public List<CodeIban> getIbanCodes() {
        return ibanCodes;
    }

    public void setIbanCodes(List<CodeIban> ibanCodes) {
        this.ibanCodes = ibanCodes;
    }

    public RecordDJ getRecordDJ() {
        return recordDJ;
    }

    public void setRecordDJ(RecordDJ recordDJ) {
        this.recordDJ = recordDJ;
    }

    public String getExternalUuid() {
        return externalUuid;
    }

    public void setExternalUuid(String externalUuid) {
        this.externalUuid = externalUuid;
    }

    public String getSynthesisModDate() {
        return synthesisModDate;
    }

    public void setSynthesisModDate(String synthesisModDate) {
        this.synthesisModDate = synthesisModDate;
    }

    public String getInactivityDateAsPep() {
        return inactivityDateAsPep;
    }

    public void setInactivityDateAsPep(String inactivityDateAsPep) {
        this.inactivityDateAsPep = inactivityDateAsPep;
    }

    public String getInactivityDateAsRca() {
        return inactivityDateAsRca;
    }

    public void setInactivityDateAsRca(String inactivityDateAsRca) {
        this.inactivityDateAsRca = inactivityDateAsRca;
    }

    public RecordVersionLinks getVersionLinks() {
        return versionLinks;
    }

    public void setVersionLinks(RecordVersionLinks versionLinks) {
        this.versionLinks = versionLinks;
    }

    public List<DateDetails> getDatesDetails() {
        return datesDetails;
    }

    public void setDatesDetails(List<DateDetails> datesDetails) {
        this.datesDetails = datesDetails;
    }

    public List<CountryDetails> getCountriesDetails() {
        return countriesDetails;
    }

    public void setCountriesDetails(List<CountryDetails> countriesDetails) {
        this.countriesDetails = countriesDetails;
    }

    public List<IdentityDocument> getIdentityDocuments() {
        return identityDocuments;
    }

    public void setIdentityDocuments(List<IdentityDocument> identityDocuments) {
        this.identityDocuments = identityDocuments;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Record other = (Record) o;
        return Objects.equals(id, other.id)
            && Objects.equals(type, other.type)
            && Objects.equals(categories, other.categories)
            && Objects.equals(sanctionTypes, other.sanctionTypes)
            && Objects.equals(descriptions3, other.descriptions3)
            && Objects.equals(pepOccupationCategories, other.pepOccupationCategories)
            && Objects.equals(name, other.name)
            && Objects.equals(nameNormalized, other.nameNormalized)
            && Objects.equals(description, other.description)
            && Objects.equals(dowJonesNotes, other.dowJonesNotes)
            && Objects.equals(keywords, other.keywords)
            && Objects.equals(comments, other.comments)
            && Objects.equals(additionalInfo, other.additionalInfo)
            && Objects.equals(reglissReference, other.reglissReference)
            && Objects.equals(recordId, other.recordId)
            && Objects.equals(startDateStr, other.startDateStr)
            && Objects.equals(externalReference, other.externalReference)
            && Objects.equals(instruction, other.instruction)
            && Objects.equals(programs, other.programs)
            && Objects.equals(aliases, other.aliases)
            && Objects.equals(sanctionReferences, other.sanctionReferences)
            && Objects.equals(sources, other.sources)
            && Objects.equals(relations, other.relations)
            && Objects.equals(associations, other.associations)
            && Objects.equals(addresses, other.addresses)
            && Objects.equals(ibanCodes, other.ibanCodes)
            && Objects.equals(recordDJ, other.recordDJ)
            && Objects.equals(externalUuid, other.externalUuid)
            && Objects.equals(synthesisModDate, other.synthesisModDate)
            && Objects.equals(inactivityDateAsPep, other.inactivityDateAsPep)
            && Objects.equals(inactivityDateAsRca, other.inactivityDateAsRca)
            && Objects.equals(versionLinks, other.versionLinks)
            && Objects.equals(datesDetails, other.datesDetails)
            && Objects.equals(countriesDetails, other.countriesDetails)
            && Objects.equals(identityDocuments, other.identityDocuments);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
            id, type, categories, sanctionTypes, descriptions3, pepOccupationCategories, name,
            nameNormalized, description, dowJonesNotes, keywords, comments, additionalInfo, reglissReference,
            recordId, startDateStr, externalReference, instruction, programs, aliases, sanctionReferences,
            sources, relations, associations, addresses, ibanCodes, recordDJ, externalUuid, synthesisModDate,
            inactivityDateAsPep, inactivityDateAsRca, versionLinks, datesDetails, countriesDetails,
            identityDocuments);
    }

    @Override
    public String toString() {
        return "Record{"
            + "id=" + id
            + ", type=" + type
            + ", categories=" + categories
            + ", sanctionTypes=" + sanctionTypes
            + ", descriptions3=" + descriptions3
            + ", pepOccupationCategories=" + pepOccupationCategories
            + ", name=" + name
            + ", nameNormalized=" + nameNormalized
            + ", description=" + description
            + ", dowJonesNotes=" + dowJonesNotes
            + ", keywords=" + keywords
            + ", comments=" + comments
            + ", additionalInfo=" + additionalInfo
            + ", reglissReference=" + reglissReference
            + ", recordId=" + recordId
            + ", startDateStr=" + startDateStr
            + ", externalReference=" + externalReference
            + ", instruction=" + instruction
            + ", programs=" + programs
            + ", aliases=" + aliases
            + ", sanctionReferences=" + sanctionReferences
            + ", sources=" + sources
            + ", relations=" + relations
            + ", associations=" + associations
            + ", addresses=" + addresses
            + ", ibanCodes=" + ibanCodes
            + ", recordDJ=" + recordDJ
            + ", externalUuid=" + externalUuid
            + ", synthesisModDate=" + synthesisModDate
            + ", inactivityDateAsPep=" + inactivityDateAsPep
            + ", inactivityDateAsRca=" + inactivityDateAsRca
            + ", versionLinks=" + versionLinks
            + ", datesDetails=" + datesDetails
            + ", countriesDetails=" + countriesDetails
            + ", identityDocuments=" + identityDocuments
            + "}";
    }
}
