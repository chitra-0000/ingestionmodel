package com.listhub.poc.parse;

import com.listhub.poc.record.Record;

/** Receives records one by one while a file is read, so the file is never held in memory. */
public interface RecordSink {

    void accept(long rowNo, Record record);

    void reject(long rowNo, String externalReference, String reason);
}
