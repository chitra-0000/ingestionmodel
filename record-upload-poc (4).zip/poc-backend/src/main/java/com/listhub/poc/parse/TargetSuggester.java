package com.listhub.poc.parse;

import com.listhub.poc.record.FieldTarget;
import com.listhub.poc.record.RecordFields;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Guesses the canonical field for a column or tag name ("DOB" to a date, "Surname" to last name...). */
final class TargetSuggester {

    private static final Map<String, String> NAMES = new HashMap<>();

    static {
        add("externalReference", "id", "externalid", "externalref", "externalreference", "ref", "reference", "entnum",
            "uid", "providerid", "sourceid", "listid", "entryid", "logicalid", "profileid");
        add("name", "name", "fullname", "wholename", "nameoriginal", "entityname", "designation", "primaryname");
        add("firstName", "firstname", "givenname", "forename", "firstnames");
        add("middleName", "middlename", "secondname");
        add("lastName", "lastname", "surname", "familyname");
        add("maidenName", "maidenname");
        add("title", "title", "titlehonorific", "honorific");
        add("suffix", "suffix");
        add("gender", "gender", "sex", "gendervalue");
        add("deceased", "deceased", "isdeceased");
        add(RecordFields.TYPE, "type", "recordtype", "entitytype", "subjecttype", "sdntype", "partytype", "category");
        add("datesDetails.dateValue", "dob", "dateofbirth", "birthdate", "datebirth");
        add("datesDetails.birthPlace", "pob", "placeofbirth", "birthplace");
        add("countriesDetails.countryCode", "nationality", "citizenship", "countrycode", "nationalitycode");
        add("programs.label", "program", "programme", "programs", "regime", "sanctionsprogram");
        add("sanctionReferences.listName", "list", "listname", "sanctionslist", "sanctionslists", "sanctionlist");
        add("aliases.name", "alias", "aliases", "aka", "akas", "alsoknownas");
        add("addresses.address", "address", "street", "addressline", "address1");
        add("addresses.city", "city", "addresscity", "town");
        add("addresses.state", "state", "province", "addressstate");
        add("addresses.zipCode", "zip", "zipcode", "postcode", "postalcode");
        add("addresses.country", "addresscountry", "country");
        add("identityDocuments.number", "passport", "passportnumber", "idnumber", "nationalid", "idvalue", "documentnumber");
        add("identityDocuments.documentType", "idtype", "documenttype");
        add("comments", "comments", "comment", "remarks", "remark");
        add("description", "description");
        add("keywords", "keywords", "keyword");
        add("additionalInfo", "additionalinfo", "otherinfo", "information", "furtherinformation");
        add("startDateStr", "listeddate", "listingdate", "designationdate", "startdate", "dateofdesignation", "applicationdate");
        add("synthesisModDate", "lastupdated", "lastmodified", "modificationdate", "updatedate");
        add("reglissReference", "reglissid", "reglissreference", "reglissref");
        add("recordId", "recordid");
        add("imoCode", "imo", "imonumber", "imocode");
        add("flag", "flag", "vesselflag");
        add("callSign", "callsign", "vesselcallsign");
        add("tonnage", "tonnage", "vesseltonnage");
        add("grossTonnage", "grt", "grosstonnage", "vesselgrt");
        add("vesselType", "vesseltype");
        add("owner", "owner", "vesselowner");
        add("bicCodes", "bic", "swift", "biccode", "swiftcode");
        add("isinCodes", "isin", "isincode");
        add("ibanCodes.code", "iban");
        add("sources.source", "source", "url", "link", "sourceurl");
        add("instruction", "instruction", "instructions");
        add("dowJonesNotes", "profilenotes", "notes");
        add("recordDJ.activeStatus", "activestatus");
        add("recordDJ.action", "action");
        // Column names of the bank's generic export format ("Designation Full Name"...).
        add(RecordFields.TYPE, "designationtypeofrecord");
        add("name", "designationfullname");
        add("externalReference", "designationexternalreference");
        add("reglissReference", "designationreglissid");
        add("startDateStr", "designationentrydate");
        add("programs.label", "designationsanctionsprogramname");
        add("aliases.reglissReference", "designationreglissreferenceofalias");
        add("aliases.lastName", "designationlastnameofalias");
        add("aliases.firstName", "designationfirstnameofalias");
        add("aliases.middleName", "designationmiddlenameofalias");
        add("aliases.name", "designationfullnameofalias");
        add("aliases.aliasType", "designationtypeofalias");
        add("aliases.aliasQuality", "designationqualityofalias");
        add("countriesDetails.countryCode", "designationcountryofresidence", "designationcountryofcitizenship");
        add("datesDetails.dateValue", "designatedpersonbirthdate", "designatedpersondeceaseddate");
        add("datesDetails.birthPlace", "designatedpersonbirthplace");
        add("addresses.address", "designationaddress1", "designationaddress");
        add("addresses.zipCode", "designationaddresszipcode1", "designationaddresszipcode");
        add("addresses.city", "designationaddresscity1", "designationaddresscity");
        add("addresses.country", "designationaddresscountry1", "designationaddresscountry");
        add("identityDocuments.documentType", "designationtypeofdocument");
        add("identityDocuments.number", "designationdocumentnumber");
        add("dowJonesNotes", "designationprofilecomplement");
    }

    private static final String[] PREFIXES = {"designatedperson", "designatedentity", "designatedvessels",
        "designatedvessel", "designation"};

    private TargetSuggester() {
    }

    private static void add(String target, String... names) {
        for (String n : names) {
            NAMES.putIfAbsent(n, target);
        }
    }

    /** Suggested target for a CSV column or the last step of an XML path (element or attribute name). */
    static String suggest(String source) {
        String last = source;
        int slash = last.lastIndexOf('/');
        if (slash >= 0) {
            last = last.substring(slash + 1);
        }
        String key = last.replace("@", "").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (key.isEmpty()) {
            return null;
        }
        String known = NAMES.get(key);
        if (known != null) {
            return known;
        }
        for (String prefix : PREFIXES) {
            if (key.startsWith(prefix) && key.length() > prefix.length()) {
                known = NAMES.get(key.substring(prefix.length()));
                if (known != null) {
                    return known;
                }
            }
        }
        for (FieldTarget field : RecordFields.fields().values()) {
            if (field.getPath().toLowerCase(Locale.ROOT).replace(".", "").equals(key)) {
                return field.getPath();
            }
        }
        return null;
    }
}
