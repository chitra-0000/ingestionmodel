package com.listhub.poc.parse;

import java.io.InputStream;
import javax.xml.XMLConstants;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

/**
 * StAX readers hardened against XML external entity (XXE) and entity expansion attacks: no DTD
 * processing, no external entities, no external DTD or schema access. A DOCTYPE line in the file
 * is ignored, never resolved.
 */
final class XmlFactory {

    private static final XMLInputFactory FACTORY = create();

    private XmlFactory() {
    }

    static XMLStreamReader open(InputStream in) throws XMLStreamException {
        return FACTORY.createXMLStreamReader(in);
    }

    private static XMLInputFactory create() {
        XMLInputFactory factory = XMLInputFactory.newInstance();
        factory.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
        factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
        factory.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
        trySet(factory, XMLConstants.ACCESS_EXTERNAL_DTD);
        trySet(factory, XMLConstants.ACCESS_EXTERNAL_SCHEMA);
        return factory;
    }

    private static void trySet(XMLInputFactory factory, String property) {
        try {
            factory.setProperty(property, "");
        } catch (IllegalArgumentException e) {
            // Property not known to this StAX implementation; DTD support is already off.
        }
    }

    /** A readable reason for a parse error, with line and column, without parser internals. */
    static String describe(XMLStreamException e) {
        String message = e.getMessage() == null ? "" : e.getMessage();
        int idx = message.indexOf("Message:");
        String reason = idx >= 0 ? message.substring(idx + "Message:".length()).trim() : message.trim();
        reason = reason.replaceAll("\\s+", " ");
        if (reason.length() > 200) {
            reason = reason.substring(0, 197) + "...";
        }
        if (e.getLocation() != null && e.getLocation().getLineNumber() > 0) {
            return "The XML is not valid at line " + e.getLocation().getLineNumber() + ", column "
                + e.getLocation().getColumnNumber() + ": " + reason;
        }
        return "The XML is not valid: " + reason;
    }
}
