package com.listhub.poc.parse;

import java.util.Locale;

/** Supported upload formats, recognised by file extension (.xml; .csv, .txt or .tsv for delimited text). */
public enum FileFormat {
    XML,
    CSV;

    /** @return the format for the file name, or {@code null} when the extension is not supported */
    public static FileFormat fromFileName(String fileName) {
        if (fileName == null) {
            return null;
        }
        String lower = fileName.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".xml")) {
            return XML;
        }
        if (lower.endsWith(".csv") || lower.endsWith(".txt") || lower.endsWith(".tsv")) {
            return CSV;
        }
        return null;
    }
}
