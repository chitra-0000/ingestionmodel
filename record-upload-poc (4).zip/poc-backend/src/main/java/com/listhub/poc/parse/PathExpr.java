package com.listhub.poc.parse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * A small, safe path language for XML mappings (not XPath: no functions, no expressions).
 * <pre>
 *   NameDetails/Name[@NameType='Primary Name']/NameValue/FirstName   element text
 *   DateDetails/Date/DateValue/@Year                                 attribute
 *   ../@DateType                                                     parent's attribute
 *   /@id                                                             attribute of the record element
 *   .                                                                current element's text
 *   *                                                                any child element
 * </pre>
 * Paths are relative to the record element, or to the collection item for item fields; a
 * leading {@code /} always starts at the record element. Filters compare attribute values with
 * {@code =} or {@code !=}, without regard to case.
 */
public final class PathExpr {

    private static final int MAX_LENGTH = 1000;

    private final String text;
    private final boolean fromRecord;
    private final List<Step> steps;
    private final String attribute;

    private PathExpr(String text, boolean fromRecord, List<Step> steps, String attribute) {
        this.text = text;
        this.fromRecord = fromRecord;
        this.steps = steps;
        this.attribute = attribute;
    }

    /** Parses a path; throws {@link IllegalArgumentException} with a readable reason when it is not valid. */
    public static PathExpr parse(String path) {
        if (path == null || path.trim().isEmpty()) {
            throw new IllegalArgumentException("the path is empty");
        }
        String p = path.trim();
        if (p.length() > MAX_LENGTH) {
            throw new IllegalArgumentException("the path is longer than " + MAX_LENGTH + " characters");
        }
        boolean fromRecord = p.startsWith("/");
        List<String> parts = splitSteps(fromRecord ? p.substring(1) : p);
        List<Step> steps = new ArrayList<>();
        String attribute = null;
        for (int i = 0; i < parts.size(); i++) {
            String part = parts.get(i).trim();
            boolean last = i == parts.size() - 1;
            if (part.startsWith("@")) {
                if (!last) {
                    throw new IllegalArgumentException("an attribute (" + part + ") must be the last step");
                }
                attribute = name(part.substring(1), part);
            } else if ("text()".equals(part)) {
                if (!last) {
                    throw new IllegalArgumentException("text() must be the last step");
                }
            } else if (!(part.isEmpty() && parts.size() == 1 && fromRecord)) {
                steps.add(Step.parse(part));
            }
        }
        return new PathExpr(p, fromRecord, Collections.unmodifiableList(steps), attribute);
    }

    /** Elements this path selects (the attribute step, if any, is ignored). */
    public List<XmlNode> select(XmlNode context, XmlNode record) {
        List<XmlNode> current = Collections.singletonList(fromRecord ? record : context);
        for (Step step : steps) {
            List<XmlNode> next = new ArrayList<>();
            for (XmlNode node : current) {
                step.apply(node, next);
            }
            current = next;
            if (current.isEmpty()) {
                break;
            }
        }
        return current;
    }

    /** Values this path selects: attribute values, or element texts. Empty values are left out. */
    public List<String> values(XmlNode context, XmlNode record) {
        List<String> values = new ArrayList<>();
        for (XmlNode node : select(context, record)) {
            String value = attribute == null ? node.text() : node.attribute(attribute);
            if (value != null && !value.trim().isEmpty()) {
                values.add(value.trim());
            }
        }
        return values;
    }

    @Override
    public String toString() {
        return text;
    }

    private static List<String> splitSteps(String path) {
        List<String> parts = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        char quote = 0;
        for (char c : path.toCharArray()) {
            if (quote != 0) {
                if (c == quote) {
                    quote = 0;
                }
                current.append(c);
            } else if (c == '\'' || c == '"') {
                quote = c;
                current.append(c);
            } else if (c == '/') {
                parts.add(current.toString());
                current.setLength(0);
            } else {
                current.append(c);
            }
        }
        if (quote != 0) {
            throw new IllegalArgumentException("a quote is not closed");
        }
        parts.add(current.toString());
        return parts;
    }

    private static String name(String candidate, String context) {
        String n = candidate.trim();
        if (!n.matches("[\\p{L}_][\\p{L}\\p{N}_.:-]*")) {
            throw new IllegalArgumentException("'" + context + "' is not a valid name");
        }
        int colon = n.indexOf(':');
        return (colon >= 0 ? n.substring(colon + 1) : n).toLowerCase(Locale.ROOT);
    }

    /** One step: an element name (or *, ., ..) with optional attribute filters. */
    private static final class Step {
        private final String name;
        private final List<Filter> filters;

        private Step(String name, List<Filter> filters) {
            this.name = name;
            this.filters = filters;
        }

        static Step parse(String part) {
            if (part.isEmpty()) {
                throw new IllegalArgumentException("the path has an empty step (//)");
            }
            if (".".equals(part) || "..".equals(part) || "*".equals(part)) {
                return new Step(part, Collections.<Filter>emptyList());
            }
            int bracket = part.indexOf('[');
            String elementName = name(bracket < 0 ? part : part.substring(0, bracket), part);
            List<Filter> filters = new ArrayList<>();
            String rest = bracket < 0 ? "" : part.substring(bracket);
            while (!rest.isEmpty()) {
                int end = closingBracket(rest);
                filters.add(Filter.parse(rest.substring(1, end), part));
                rest = rest.substring(end + 1).trim();
                if (!rest.isEmpty() && rest.charAt(0) != '[') {
                    throw new IllegalArgumentException("unexpected text after a filter in '" + part + "'");
                }
            }
            return new Step(elementName, filters);
        }

        private static int closingBracket(String text) {
            char quote = 0;
            for (int i = 1; i < text.length(); i++) {
                char c = text.charAt(i);
                if (quote != 0) {
                    if (c == quote) {
                        quote = 0;
                    }
                } else if (c == '\'' || c == '"') {
                    quote = c;
                } else if (c == ']') {
                    return i;
                }
            }
            throw new IllegalArgumentException("a filter [ is not closed in '" + text + "'");
        }

        void apply(XmlNode node, List<XmlNode> out) {
            if (".".equals(name)) {
                out.add(node);
                return;
            }
            if ("..".equals(name)) {
                if (node.getParent() != null) {
                    out.add(node.getParent());
                }
                return;
            }
            for (XmlNode child : node.getChildren()) {
                if (("*".equals(name) || child.key().equals(name)) && matches(child)) {
                    out.add(child);
                }
            }
        }

        private boolean matches(XmlNode node) {
            for (Filter filter : filters) {
                if (!filter.matches(node)) {
                    return false;
                }
            }
            return true;
        }
    }

    /** [@attr='value'] or [@attr!='value']. */
    private static final class Filter {
        private final String attribute;
        private final String value;
        private final boolean equal;

        private Filter(String attribute, String value, boolean equal) {
            this.attribute = attribute;
            this.value = value;
            this.equal = equal;
        }

        static Filter parse(String body, String part) {
            String b = body.trim();
            boolean notEqual = b.contains("!=");
            int op = notEqual ? b.indexOf("!=") : b.indexOf('=');
            if (!b.startsWith("@") || op < 0) {
                throw new IllegalArgumentException("filter [" + body + "] must look like [@Attribute='value'] in '" + part + "'");
            }
            String attributeName = name(b.substring(1, op), part);
            String quoted = b.substring(op + (notEqual ? 2 : 1)).trim();
            if (quoted.length() < 2 || (quoted.charAt(0) != '\'' && quoted.charAt(0) != '"')
                || quoted.charAt(quoted.length() - 1) != quoted.charAt(0)) {
                throw new IllegalArgumentException("the value in filter [" + body + "] must be in quotes");
            }
            return new Filter(attributeName, quoted.substring(1, quoted.length() - 1), !notEqual);
        }

        boolean matches(XmlNode node) {
            String actual = node.attribute(attribute);
            boolean same = actual != null && actual.trim().equalsIgnoreCase(value.trim());
            return equal == same;
        }
    }
}
