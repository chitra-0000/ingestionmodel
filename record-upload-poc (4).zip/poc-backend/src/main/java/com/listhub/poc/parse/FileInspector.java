package com.listhub.poc.parse;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.core.io.InputStreamSource;
import org.springframework.stereotype.Component;

/**
 * Looks at a file before it is mapped: CSV headers, or the XML structure (which repeating elements
 * are records, which paths and attributes they contain, which code lists exist), with sample
 * values. Streams the file; memory is bounded by the caps below whatever the file size.
 */
@Component
public class FileInspector {

    private static final int SAMPLE_ROWS = 200;
    private static final int MAX_DISTINCT_PATHS = 3000;
    private static final int MAX_VALUES = 6;
    private static final int SHORT_VALUE = 40;
    private static final int ENCODING_PROBE_BYTES = 256 * 1024;

    // ---------------------------------------------------------------- CSV

    public InspectResult inspectCsv(InputStreamSource file, String encoding, String delimiter) throws IOException {
        InspectResult result = new InspectResult();
        result.setFormat(FileFormat.CSV);
        String charset = encoding == null || encoding.trim().isEmpty() ? detectEncoding(file) : encoding.trim();
        result.setEncoding(charset);
        MappingProfile settings = new MappingProfile();
        settings.setEncoding(charset);
        settings.setDelimiter(delimiter);
        Map<String, Column> columns = new LinkedHashMap<>();
        try (BufferedReader reader = CsvRecordReader.open(file.getInputStream(), charset)) {
            char d = CsvRecordReader.delimiterOf(settings, reader);
            result.setDelimiter(d == '\t' ? "\\t" : String.valueOf(d));
            try (CSVParser parser = CsvRecordReader.format(d).parse(reader)) {
                for (Map.Entry<String, String> e : CsvRecordReader.columnNames(parser.getHeaderNames()).entrySet()) {
                    columns.put(e.getKey(), new Column(e.getValue()));
                }
                List<String> keys = CsvRecordReader.keys(parser.getHeaderNames());
                long rows = 0;
                for (CSVRecord csv : parser) {
                    rows++;
                    if (rows <= SAMPLE_ROWS) {
                        for (int i = 0; i < keys.size() && i < csv.size(); i++) {
                            Column column = columns.get(keys.get(i));
                            if (column != null) {
                                column.add(csv.get(i));
                            }
                        }
                    }
                }
                result.setTotal(rows);
                result.setSampled(Math.min(rows, SAMPLE_ROWS));
            }
        } catch (UncheckedIOException e) {
            throw new FileFormatException("The CSV file could not be read near line " + lineOf(e)
                + ". Check the quotes and the delimiter.", e);
        }
        if (columns.isEmpty()) {
            throw new FileFormatException("The file has no header row: the first line must hold the column names.");
        }
        for (Column column : columns.values()) {
            result.getFields().add(column.toField());
        }
        if ("windows-1252".equals(charset)) {
            result.getNotes().add("The file is not UTF-8; it is read as windows-1252 (Western European).");
        }
        return result;
    }

    /** UTF-8 when the start of the file is valid UTF-8 (or has a BOM), otherwise windows-1252. */
    static String detectEncoding(InputStreamSource file) throws IOException {
        byte[] probe = new byte[ENCODING_PROBE_BYTES];
        int length = 0;
        try (InputStream in = file.getInputStream()) {
            int n;
            while (length < probe.length && (n = in.read(probe, length, probe.length - length)) > 0) {
                length += n;
            }
        }
        if (length >= 2 && ((probe[0] & 0xFF) == 0xFE || (probe[0] & 0xFF) == 0xFF)) {
            return "UTF-16";
        }
        int end = length;
        if (length == probe.length) {
            // Do not count a multi-byte character cut by the probe limit as invalid.
            while (end > 0 && (probe[end - 1] & 0xC0) == 0x80) {
                end--;
            }
            if (end > 0 && (probe[end - 1] & 0x80) != 0) {
                end--;
            }
        }
        try {
            StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(probe, 0, end));
            return "UTF-8";
        } catch (CharacterCodingException e) {
            return "windows-1252";
        }
    }

    private static String lineOf(UncheckedIOException e) {
        String m = e.getMessage() == null ? "" : e.getMessage();
        int idx = m.indexOf("(line ");
        if (idx >= 0) {
            int close = m.indexOf(')', idx);
            if (close > idx) {
                return m.substring(idx + 6, close);
            }
        }
        return "?";
    }

    // ---------------------------------------------------------------- XML

    /**
     * @param recordElements element names to use as records; empty means guess them
     */
    public InspectResult inspectXml(InputStreamSource file, Collection<String> recordElements) throws IOException {
        InspectResult result = new InspectResult();
        result.setFormat(FileFormat.XML);
        Map<String, ElementStats> structure;
        try (InputStream in = new BufferedInputStream(file.getInputStream())) {
            structure = scanStructure(in, result);
        } catch (XMLStreamException e) {
            throw new FileFormatException(XmlFactory.describe(e), e);
        }
        List<ElementStats> candidates = recordCandidates(structure);
        Set<String> chosen = new HashSet<>();
        for (String name : recordElements) {
            if (name != null && !name.trim().isEmpty()) {
                chosen.add(name.trim().toLowerCase(Locale.ROOT));
            }
        }
        if (chosen.isEmpty() && !candidates.isEmpty()) {
            String parent = candidates.get(0).parentPath;
            for (ElementStats c : candidates) {
                if (c.parentPath.equals(parent)) {
                    chosen.add(c.name.toLowerCase(Locale.ROOT));
                }
            }
        }
        for (ElementStats c : candidates) {
            InspectResult.RecordElement element = new InspectResult.RecordElement();
            element.setName(c.name);
            element.setPath(c.path);
            element.setCount(c.count);
            element.setSelected(chosen.contains(c.name.toLowerCase(Locale.ROOT)));
            element.setSuggestedType(typeFor(c.name));
            result.getRecordElements().add(element);
        }
        result.setLookups(lookupCandidates(structure, candidates));
        if (chosen.isEmpty()) {
            result.getNotes().add("No repeating element was found that looks like a record.");
            return result;
        }
        try (InputStream in = new BufferedInputStream(file.getInputStream())) {
            samplePaths(in, chosen, result);
        } catch (XMLStreamException e) {
            throw new FileFormatException(XmlFactory.describe(e), e);
        }
        return result;
    }

    private static Map<String, ElementStats> scanStructure(InputStream in, InspectResult result) throws XMLStreamException {
        Map<String, ElementStats> stats = new LinkedHashMap<>();
        XMLStreamReader xml = XmlFactory.open(in);
        List<ElementStats> stack = new ArrayList<>();
        long elements = 0;
        try {
            while (xml.hasNext()) {
                int event = xml.next();
                if (event == XMLStreamConstants.START_ELEMENT) {
                    elements++;
                    ElementStats parent = stack.isEmpty() ? null : stack.get(stack.size() - 1);
                    String name = xml.getLocalName();
                    String parentPath = parent == null ? "" : parent.path;
                    String path = parent == null ? name : parent.path + "/" + name;
                    ElementStats s = stats.get(path);
                    if (s == null && stats.size() < MAX_DISTINCT_PATHS) {
                        s = new ElementStats(name, path, parentPath);
                        stats.put(path, s);
                    }
                    if (s == null) {
                        s = new ElementStats(name, path, parentPath);
                    }
                    s.count++;
                    if (parent != null) {
                        parent.hasChildren = true;
                    }
                    for (int i = 0; i < xml.getAttributeCount() && s.attributes.size() < 20; i++) {
                        s.attributes.add(xml.getAttributeLocalName(i));
                        if (s.sample == null) {
                            s.sample = xml.getAttributeLocalName(i) + "=" + xml.getAttributeValue(i);
                        }
                    }
                    stack.add(s);
                } else if (event == XMLStreamConstants.END_ELEMENT) {
                    stack.remove(stack.size() - 1);
                }
            }
        } finally {
            xml.close();
        }
        result.setTotal(elements);
        return stats;
    }

    /**
     * Elements that look like records: they have child elements and are not inside a repeating
     * element. A container (such as Records) gives way to the repeating elements inside it, and
     * elements inside a record (such as VesselDetails) are left out.
     */
    private static List<ElementStats> recordCandidates(Map<String, ElementStats> structure) {
        List<ElementStats> base = new ArrayList<>();
        for (ElementStats s : structure.values()) {
            if (s.hasChildren && !s.parentPath.isEmpty() && ancestorsAppearOnce(s, structure)) {
                base.add(s);
            }
        }
        List<ElementStats> kept = new ArrayList<>();
        for (ElementStats c : base) {
            boolean containerOfRecords = false;
            boolean onlyCodeList = true;
            for (ElementStats d : base) {
                if (d.parentPath.equals(c.path) && d.count >= 2) {
                    containerOfRecords = true;
                    break;
                }
            }
            for (ElementStats d : structure.values()) {
                if (d.parentPath.equals(c.path) && d.hasChildren) {
                    onlyCodeList = false;
                    break;
                }
            }
            if (!containerOfRecords && !onlyCodeList) {
                kept.add(c);
            }
        }
        List<ElementStats> candidates = new ArrayList<>();
        for (ElementStats c : kept) {
            boolean inside = false;
            for (ElementStats k : kept) {
                if (c.path.startsWith(k.path + "/")) {
                    inside = true;
                    break;
                }
            }
            if (!inside) {
                candidates.add(c);
            }
        }
        candidates.sort((a, b) -> Long.compare(b.count, a.count));
        return candidates.size() > 20 ? candidates.subList(0, 20) : candidates;
    }

    private static boolean insideAny(ElementStats s, List<ElementStats> records) {
        for (ElementStats r : records) {
            if (s.path.startsWith(r.path + "/")) {
                return true;
            }
        }
        return false;
    }

    private static boolean ancestorsAppearOnce(ElementStats s, Map<String, ElementStats> structure) {
        ElementStats parent = structure.get(s.parentPath);
        while (parent != null) {
            if (parent.count != 1) {
                return false;
            }
            parent = parent.parentPath.isEmpty() ? null : structure.get(parent.parentPath);
        }
        return true;
    }

    private static List<InspectResult.LookupCandidate> lookupCandidates(Map<String, ElementStats> structure,
                                                                        List<ElementStats> records) {
        List<InspectResult.LookupCandidate> lookups = new ArrayList<>();
        for (ElementStats s : structure.values()) {
            if (insideAny(s, records)) {
                continue;
            }
            ElementStats parent = structure.get(s.parentPath);
            if (!s.hasChildren && parent != null && !s.attributes.isEmpty() && ancestorsAppearOnce(s, structure)) {
                InspectResult.LookupCandidate c = new InspectResult.LookupCandidate();
                c.setPath(parent.name + "/" + s.name);
                c.setCount(s.count);
                c.setAttributes(new ArrayList<>(s.attributes));
                c.setSample(s.sample);
                lookups.add(c);
            }
        }
        return lookups;
    }

    private static void samplePaths(InputStream in, Set<String> recordElements, InspectResult result) throws XMLStreamException {
        Map<String, Column> paths = new LinkedHashMap<>();
        XMLStreamReader xml = XmlFactory.open(in);
        XmlNode root = null;
        XmlNode current = null;
        int depth = 0;
        int nodes = 0;
        long sampled = 0;
        try {
            while (xml.hasNext() && sampled < SAMPLE_ROWS) {
                int event = xml.next();
                if (event == XMLStreamConstants.START_ELEMENT) {
                    String name = xml.getLocalName();
                    if (root == null) {
                        if (recordElements.contains(name.toLowerCase(Locale.ROOT))) {
                            root = new XmlNode(name, null);
                            current = root;
                            attributes(xml, root);
                            depth = 1;
                            nodes = 1;
                        }
                    } else {
                        depth++;
                        nodes++;
                        if (nodes <= XmlRecordReader.MAX_NODES_PER_RECORD) {
                            current = current.addChild(name);
                            attributes(xml, current);
                        }
                    }
                } else if (root != null && (event == XMLStreamConstants.CHARACTERS || event == XMLStreamConstants.CDATA)) {
                    if (nodes <= XmlRecordReader.MAX_NODES_PER_RECORD) {
                        current.appendText(xml.getText());
                    }
                } else if (root != null && event == XMLStreamConstants.END_ELEMENT) {
                    depth--;
                    if (depth == 0) {
                        sampled++;
                        collectPaths(root, "", paths, new HashSet<>());
                        root = null;
                        current = null;
                    } else if (nodes <= XmlRecordReader.MAX_NODES_PER_RECORD) {
                        current = current.getParent();
                    }
                }
            }
        } finally {
            xml.close();
        }
        result.setSampled(sampled);
        for (Column column : paths.values()) {
            result.getFields().add(column.toField());
        }
    }

    private static void collectPaths(XmlNode node, String prefix, Map<String, Column> paths, Set<String> seenInRecord) {
        for (Map.Entry<String, String> attribute : sortedAttributes(node)) {
            add(paths, prefix + "@" + attribute.getKey(), attribute.getValue(), seenInRecord);
        }
        if (!prefix.isEmpty() && node.getChildren().isEmpty()) {
            add(paths, prefix.substring(0, prefix.length() - 1), node.text(), seenInRecord);
        }
        for (XmlNode child : node.getChildren()) {
            collectPaths(child, prefix + child.getName() + "/", paths, seenInRecord);
        }
    }

    private static List<Map.Entry<String, String>> sortedAttributes(XmlNode node) {
        List<Map.Entry<String, String>> list = new ArrayList<>(node.getAttributes().entrySet());
        list.sort(Map.Entry.comparingByKey());
        return list;
    }

    private static void add(Map<String, Column> paths, String path, String value, Set<String> seenInRecord) {
        Column column = paths.get(path);
        if (column == null) {
            if (paths.size() >= MAX_DISTINCT_PATHS) {
                return;
            }
            column = new Column(path);
            paths.put(path, column);
        }
        if (seenInRecord.add(path)) {
            column.records++;
        }
        column.add(value);
    }

    private static void attributes(XMLStreamReader xml, XmlNode node) {
        for (int i = 0; i < xml.getAttributeCount(); i++) {
            node.setAttribute(xml.getAttributeLocalName(i), xml.getAttributeValue(i));
        }
    }

    private static String typeFor(String elementName) {
        String n = elementName.toLowerCase(Locale.ROOT);
        if (n.contains("vessel") || n.contains("ship")) {
            return "VESSEL";
        }
        if (n.contains("entity") || n.contains("company") || n.contains("organi")) {
            return "ENTITY";
        }
        return "INDIVIDUAL";
    }

    /** Running statistics of one XML element path. */
    private static final class ElementStats {
        private final String name;
        private final String path;
        private final String parentPath;
        private long count;
        private boolean hasChildren;
        private final Set<String> attributes = new java.util.LinkedHashSet<>();
        private String sample;

        ElementStats(String name, String path, String parentPath) {
            this.name = name;
            this.path = path;
            this.parentPath = parentPath;
        }
    }

    /** Samples of one CSV column or XML path. */
    private static final class Column {
        private final String path;
        private String sample;
        private long nonEmpty;
        private long records;
        private final List<String> values = new ArrayList<>();
        private final Map<String, Boolean> distinct = new HashMap<>();

        Column(String path) {
            this.path = path;
        }

        void add(String value) {
            if (value == null || value.trim().isEmpty()) {
                return;
            }
            String v = value.trim();
            nonEmpty++;
            if (sample == null) {
                sample = v.length() > 120 ? v.substring(0, 117) + "..." : v;
            }
            if (v.length() <= SHORT_VALUE && values.size() < MAX_VALUES && distinct.put(v, Boolean.TRUE) == null) {
                values.add(v);
            }
        }

        InspectResult.SourceField toField() {
            InspectResult.SourceField field = new InspectResult.SourceField();
            field.setPath(path);
            field.setSample(sample);
            field.setCount(records > 0 ? records : nonEmpty);
            field.setValues(values);
            field.setSuggestedTarget(TargetSuggester.suggest(path));
            return field;
        }
    }
}
