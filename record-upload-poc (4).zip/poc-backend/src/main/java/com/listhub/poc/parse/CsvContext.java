package com.listhub.poc.parse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Mapping values read from one CSV row. A source is a column name (any case). Inside a
 * collection item made by splitting a cell, the source {@code .} is the item's own value.
 */
final class CsvContext implements MappingContext {

    static final String SELF = ".";

    private final Map<String, String> row;
    private final String itemValue;

    CsvContext(Map<String, String> row, String itemValue) {
        this.row = row;
        this.itemValue = itemValue;
    }

    static String key(String column) {
        return column == null ? "" : column.trim().toLowerCase(Locale.ROOT);
    }

    @Override
    public List<String> values(String source) {
        String value = SELF.equals(source.trim()) ? itemValue : row.get(key(source));
        if (value == null || value.trim().isEmpty()) {
            return Collections.emptyList();
        }
        return Collections.singletonList(value.trim());
    }

    @Override
    public List<MappingContext> items(String source, String separator) {
        if (source == null || source.trim().isEmpty()) {
            return Collections.<MappingContext>singletonList(this);
        }
        List<MappingContext> items = new ArrayList<>();
        for (String column : RecordMapper.SOURCE_SEPARATOR.split(source.trim())) {
            String cell = row.get(key(column));
            if (cell != null && !cell.trim().isEmpty()) {
                for (String value : Splitter.split(cell, separator)) {
                    items.add(new CsvContext(row, value));
                }
            }
        }
        return items;
    }
}
