package com.listhub.poc.parse;

import com.listhub.poc.record.CollectionTarget;
import com.listhub.poc.record.DateDetails;
import com.listhub.poc.record.FieldTarget;
import com.listhub.poc.record.IndividualRecord;
import com.listhub.poc.record.MappingException;
import com.listhub.poc.record.Record;
import com.listhub.poc.record.RecordFields;
import com.listhub.poc.record.RecordType;
import com.listhub.poc.record.Values;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * Applies one mapping profile to one record's worth of file data and produces the canonical
 * record. Built once per upload; holds no per-record state, so memory stays flat.
 *
 * <p>Rules: the first non-empty value wins for a single field (so several rules can target the
 * same field, for example a person's name parts and an entity's name); every value is added for a
 * list field; collection items with no value at all are dropped, and identical items are kept once.
 */
public final class RecordMapper {

    /** Several sources in one rule are separated by " + " (with spaces). */
    static final Pattern SOURCE_SEPARATOR = Pattern.compile("\\s\\+\\s");

    private static final Map<String, RecordType> TYPE_NAMES = new HashMap<>();

    static {
        for (String n : Arrays.asList("INDIVIDUAL", "PERSON", "P", "I", "IND", "INDIV", "NATURAL PERSON", "PEOPLE")) {
            TYPE_NAMES.put(n, RecordType.INDIVIDUAL);
        }
        for (String n : Arrays.asList("ENTITY", "E", "ENT", "COMPANY", "ORGANISATION", "ORGANIZATION", "LEGAL ENTITY")) {
            TYPE_NAMES.put(n, RecordType.ENTITY);
        }
        for (String n : Arrays.asList("VESSEL", "V", "SHIP", "BOAT")) {
            TYPE_NAMES.put(n, RecordType.VESSEL);
        }
    }

    private final MappingRule typeRule;
    private final List<MappingRule> recordRules = new ArrayList<>();
    private final Map<String, MappingRule> collectionRules = new LinkedHashMap<>();
    private final Map<String, List<MappingRule>> itemRules = new LinkedHashMap<>();
    private final Map<MappingRule, Map<String, String>> valueMaps = new IdentityHashMap<>();
    private final Map<String, Map<String, String>> lookups;

    public RecordMapper(MappingProfile profile, Map<String, Map<String, String>> lookups) {
        this.lookups = lookups;
        MappingRule type = null;
        for (MappingRule rule : profile.getRules()) {
            if (rule.getKind() == RuleKind.FIELD) {
                String target = rule.getTarget().trim();
                CollectionTarget collection = RecordFields.collectionOf(target);
                if (RecordFields.TYPE.equals(target)) {
                    type = rule;
                } else if (collection != null && !target.startsWith("recordDJ.")) {
                    itemRules.computeIfAbsent(collection.getName(), k -> new ArrayList<>()).add(rule);
                } else {
                    recordRules.add(rule);
                }
                if (rule.getTransform() == Transform.VALUE_MAP) {
                    valueMaps.put(rule, parseValueMap(rule.getParam()));
                }
            } else if (rule.getKind() == RuleKind.COLLECTION) {
                collectionRules.put(rule.getTarget().trim(), rule);
            }
        }
        this.typeRule = type;
        if (typeRule != null && typeRule.getTransform() == Transform.VALUE_MAP) {
            valueMaps.put(typeRule, parseValueMap(typeRule.getParam()));
        }
    }

    /** A new canonical record from one record's data. */
    public Record map(MappingContext context, RecordType defaultType) {
        Record record = Record.of(typeOf(context, defaultType));
        mapInto(record, context);
        return record;
    }

    /** Adds one more CSV row to a record (rows grouped by id): empty fields are filled, lists grow. */
    public void mapInto(Record record, MappingContext context) {
        for (MappingRule rule : recordRules) {
            FieldTarget field = RecordFields.field(rule.getTarget().trim());
            if (field != null && field.appliesTo(record)) {
                apply(field, record, evaluate(rule, context, field.getPath()));
            }
        }
        for (Map.Entry<String, CollectionTarget> entry : RecordFields.collections().entrySet()) {
            List<MappingRule> rules = itemRules.get(entry.getKey());
            if (rules != null && entry.getValue().appliesTo(record)) {
                mapCollection(record, entry.getValue(), rules, context);
            }
        }
        finish(record);
    }

    /** The external reference of a record that failed, for the reject list (best effort). */
    public String externalReferenceOf(MappingContext context) {
        for (MappingRule rule : recordRules) {
            if ("externalReference".equals(rule.getTarget().trim())) {
                try {
                    List<String> values = evaluate(rule, context, "externalReference");
                    if (!values.isEmpty()) {
                        return Values.shorten(values.get(0));
                    }
                } catch (RuntimeException e) {
                    return null;
                }
            }
        }
        return null;
    }

    private RecordType typeOf(MappingContext context, RecordType defaultType) {
        if (typeRule != null) {
            List<String> values = evaluate(typeRule, context, RecordFields.TYPE);
            if (!values.isEmpty()) {
                RecordType type = TYPE_NAMES.get(values.get(0).trim().toUpperCase(Locale.ROOT));
                if (type == null) {
                    throw new MappingException("type: '" + Values.shorten(values.get(0))
                        + "' is not INDIVIDUAL, ENTITY or VESSEL (map it with a value map).");
                }
                return type;
            }
        }
        if (defaultType == null) {
            throw new MappingException("type: the record type is missing and the profile has no default type.");
        }
        return defaultType;
    }

    private void mapCollection(Record record, CollectionTarget collection, List<MappingRule> rules, MappingContext context) {
        MappingRule collectionRule = collectionRules.get(collection.getName());
        List<MappingContext> items = collectionRule == null
            ? Collections.singletonList(context)
            : context.items(collectionRule.getSource() == null ? "" : collectionRule.getSource().trim(), collectionRule.getParam());
        List<Object> list = collection.itemsOf(record);
        for (MappingContext itemContext : items) {
            Object item = collection.newItem();
            boolean fromFile = false;
            for (MappingRule rule : rules) {
                FieldTarget field = collection.getFields().get(rule.getTarget().trim());
                if (field == null) {
                    continue;
                }
                List<String> values = evaluate(rule, itemContext, field.getPath());
                if (!values.isEmpty() && isEmpty(field.get(item))) {
                    field.set(item, values.get(0));
                    fromFile |= rule.getTransform() != Transform.CONSTANT && !usedDefault(rule, itemContext);
                }
            }
            // An item is kept only when the file gave it at least one value (fixed values alone do not count).
            if (fromFile && !list.contains(item)) {
                list.add(item);
            }
        }
    }

    /** True when a DEFAULT rule found nothing in the file and only its default value was used. */
    private boolean usedDefault(MappingRule rule, MappingContext context) {
        if (rule.getTransform() != Transform.DEFAULT || rule.getSource() == null || rule.getSource().trim().isEmpty()) {
            return rule.getTransform() == Transform.DEFAULT;
        }
        for (String source : SOURCE_SEPARATOR.split(rule.getSource().trim())) {
            if (!context.values(source.trim()).isEmpty()) {
                return false;
            }
        }
        return true;
    }

    private static void apply(FieldTarget field, Record record, List<String> values) {
        if (values.isEmpty()) {
            return;
        }
        if (field.isMultiValue()) {
            for (String value : values) {
                field.set(record, value);
            }
        } else if (isEmpty(field.get(record))) {
            field.set(record, values.get(0));
        }
    }

    private static void finish(Record record) {
        if (Values.isBlank(record.getName()) && record instanceof IndividualRecord) {
            IndividualRecord person = (IndividualRecord) record;
            String joined = join(person.getFirstName(), person.getMiddleName(), person.getLastName());
            record.setName(joined);
        }
        record.setNameNormalized(Values.normalizeName(record.getName()));
        for (DateDetails date : record.getDatesDetails()) {
            if (date.getDateValue() == null) {
                date.setDateValue(Values.partialDate(date.getYear(), date.getMonth(), date.getDay()));
            }
        }
        if (Values.isBlank(record.getExternalUuid())) {
            record.setExternalUuid(UUID.randomUUID().toString());
        }
    }

    /** Values of one rule, after its transformation. */
    List<String> evaluate(MappingRule rule, MappingContext context, String field) {
        Transform transform = rule.getTransform() == null ? Transform.NONE : rule.getTransform();
        if (transform == Transform.CONSTANT) {
            return Values.isBlank(rule.getParam()) ? Collections.<String>emptyList()
                : Collections.singletonList(rule.getParam().trim());
        }
        String source = rule.getSource() == null ? "" : rule.getSource().trim();
        List<String> raw;
        if (source.isEmpty()) {
            raw = Collections.emptyList();
        } else {
            String[] sources = SOURCE_SEPARATOR.split(source);
            if (sources.length == 1) {
                raw = context.values(sources[0].trim());
            } else if (transform == Transform.DATE_PARTS) {
                return single(Values.partialDate(field, first(context, sources, 0), first(context, sources, 1),
                    first(context, sources, 2)));
            } else {
                List<String> parts = new ArrayList<>();
                for (String s : sources) {
                    List<String> v = context.values(s.trim());
                    if (!v.isEmpty()) {
                        parts.add(v.get(0));
                    }
                }
                raw = parts.isEmpty() ? Collections.<String>emptyList() : Collections.singletonList(String.join(" ", parts));
            }
        }
        List<String> out = new ArrayList<>(raw.size());
        for (String value : raw) {
            transformInto(rule, transform, field, value, out);
        }
        if (out.isEmpty() && transform == Transform.DEFAULT && !Values.isBlank(rule.getParam())) {
            out.add(rule.getParam().trim());
        }
        return out;
    }

    private void transformInto(MappingRule rule, Transform transform, String field, String value, List<String> out) {
        String v = value.trim();
        if (v.isEmpty()) {
            return;
        }
        switch (transform) {
            case UPPER:
                out.add(v.toUpperCase(Locale.ROOT));
                break;
            case LOWER:
                out.add(v.toLowerCase(Locale.ROOT));
                break;
            case VALUE_MAP:
                Map<String, String> map = valueMaps.get(rule);
                String mapped = map.get(v.toLowerCase(Locale.ROOT));
                if (mapped == null) {
                    mapped = map.get("*");
                }
                out.add(mapped == null ? v : mapped);
                break;
            case DATE:
                List<String> patterns = Values.isBlank(rule.getParam()) ? Values.DEFAULT_DATE_PATTERNS
                    : Arrays.asList(rule.getParam().split("\\|"));
                out.add(Values.parseDate(field, v, patterns));
                break;
            case DATE_PARTS:
                out.add(Values.partialDate(field, v, null, null));
                break;
            case SPLIT:
                out.addAll(Splitter.split(v, Values.isBlank(rule.getParam()) ? "|" : rule.getParam()));
                break;
            case LOOKUP:
                Map<String, String> lookup = lookups.get(rule.getParam() == null ? "" : rule.getParam().trim().toUpperCase(Locale.ROOT));
                String name = lookup == null ? null : lookup.get(v.toLowerCase(Locale.ROOT));
                out.add(name == null ? v : name);
                break;
            default:
                out.add(v);
        }
    }

    private static String first(MappingContext context, String[] sources, int index) {
        if (index >= sources.length) {
            return null;
        }
        List<String> values = context.values(sources[index].trim());
        return values.isEmpty() ? null : values.get(0);
    }

    private static List<String> single(String value) {
        return value == null ? Collections.<String>emptyList() : Collections.singletonList(value);
    }

    private static boolean isEmpty(Object value) {
        if (value == null) {
            return true;
        }
        if (value instanceof String) {
            return ((String) value).trim().isEmpty();
        }
        return false;
    }

    private static String join(String... parts) {
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!Values.isBlank(part)) {
                if (sb.length() > 0) {
                    sb.append(' ');
                }
                sb.append(part.trim());
            }
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    /** "from=to;from=to" into a map with lower-case keys; the key * is the value for anything not listed. */
    static Map<String, String> parseValueMap(String param) {
        Map<String, String> map = new HashMap<>();
        if (param == null) {
            return map;
        }
        for (String pair : param.split(";")) {
            int eq = pair.indexOf('=');
            if (eq > 0) {
                map.put(pair.substring(0, eq).trim().toLowerCase(Locale.ROOT), pair.substring(eq + 1).trim());
            }
        }
        return map;
    }
}
