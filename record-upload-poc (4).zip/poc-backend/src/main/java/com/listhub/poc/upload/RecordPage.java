package com.listhub.poc.upload;

import com.listhub.poc.store.RecordSummary;
import java.util.ArrayList;
import java.util.List;

/** One page of loaded records. */
public class RecordPage {

    private final List<RecordSummary> items;
    private final long total;
    private final int page;
    private final int size;

    public RecordPage(List<RecordSummary> items, long total, int page, int size) {
        this.items = new ArrayList<>(items);
        this.total = total;
        this.page = page;
        this.size = size;
    }

    public List<RecordSummary> getItems() {
        return items;
    }

    public long getTotal() {
        return total;
    }

    public int getPage() {
        return page;
    }

    public int getSize() {
        return size;
    }
}
