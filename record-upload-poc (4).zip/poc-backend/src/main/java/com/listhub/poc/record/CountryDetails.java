package com.listhub.poc.record;

import java.util.Objects;

/** Country linked to a record (citizenship, residence, registration...). */
public class CountryDetails {

    private String countryType;
    private String countryCode;
    private String countryName;
    private String additionalInfo;

    public String getCountryType() {
        return countryType;
    }

    public void setCountryType(String countryType) {
        this.countryType = countryType;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CountryDetails other = (CountryDetails) o;
        return Objects.equals(countryType, other.countryType)
            && Objects.equals(countryCode, other.countryCode)
            && Objects.equals(countryName, other.countryName)
            && Objects.equals(additionalInfo, other.additionalInfo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(countryType, countryCode, countryName, additionalInfo);
    }

    @Override
    public String toString() {
        return "CountryDetails{"
            + "countryType=" + countryType
            + ", countryCode=" + countryCode
            + ", countryName=" + countryName
            + ", additionalInfo=" + additionalInfo
            + "}";
    }
}
