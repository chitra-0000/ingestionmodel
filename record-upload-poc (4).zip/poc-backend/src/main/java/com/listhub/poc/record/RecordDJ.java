package com.listhub.poc.record;

import java.util.Objects;

/** Dow Jones specific data of a record. */
public class RecordDJ {

    private String action;
    private String lastUpdateDate;
    private String activeStatus;

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(String activeStatus) {
        this.activeStatus = activeStatus;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RecordDJ other = (RecordDJ) o;
        return Objects.equals(action, other.action)
            && Objects.equals(lastUpdateDate, other.lastUpdateDate)
            && Objects.equals(activeStatus, other.activeStatus);
    }

    @Override
    public int hashCode() {
        return Objects.hash(action, lastUpdateDate, activeStatus);
    }

    @Override
    public String toString() {
        return "RecordDJ{"
            + "action=" + action
            + ", lastUpdateDate=" + lastUpdateDate
            + ", activeStatus=" + activeStatus
            + "}";
    }
}
