package com.listhub.poc.parse;

import java.util.ArrayList;
import java.util.List;

/** What the inspector found in a file: the sources a mapping can use, with sample values. */
public class InspectResult {

    private FileFormat format;
    private String encoding;
    private String delimiter;
    /** CSV rows or XML records looked at for samples. */
    private long sampled;
    /** CSV: data rows in the file. XML: elements in the file. */
    private long total;
    /** CSV columns, or XML paths relative to the record element. */
    private List<SourceField> fields = new ArrayList<>();
    /** XML only: repeating elements that look like records. */
    private List<RecordElement> recordElements = new ArrayList<>();
    /** XML only: code lists usable as lookups (element with code and name attributes). */
    private List<LookupCandidate> lookups = new ArrayList<>();
    private List<String> notes = new ArrayList<>();

    public FileFormat getFormat() {
        return format;
    }

    public void setFormat(FileFormat format) {
        this.format = format;
    }

    public String getEncoding() {
        return encoding;
    }

    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    public String getDelimiter() {
        return delimiter;
    }

    public void setDelimiter(String delimiter) {
        this.delimiter = delimiter;
    }

    public long getSampled() {
        return sampled;
    }

    public void setSampled(long sampled) {
        this.sampled = sampled;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    public List<SourceField> getFields() {
        return fields;
    }

    public List<RecordElement> getRecordElements() {
        return recordElements;
    }

    public List<LookupCandidate> getLookups() {
        return lookups;
    }

    public void setLookups(List<LookupCandidate> lookups) {
        this.lookups = lookups;
    }

    public List<String> getNotes() {
        return notes;
    }

    /** One column or path, with a sample and up to six distinct short values. */
    public static class SourceField {
        private String path;
        private String sample;
        private long count;
        private List<String> values = new ArrayList<>();
        /** A canonical field this source probably maps to (from its name), or null. */
        private String suggestedTarget;

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public String getSample() {
            return sample;
        }

        public void setSample(String sample) {
            this.sample = sample;
        }

        public long getCount() {
            return count;
        }

        public void setCount(long count) {
            this.count = count;
        }

        public List<String> getValues() {
            return values;
        }

        public void setValues(List<String> values) {
            this.values = values;
        }

        public String getSuggestedTarget() {
            return suggestedTarget;
        }

        public void setSuggestedTarget(String suggestedTarget) {
            this.suggestedTarget = suggestedTarget;
        }
    }

    /** A repeating XML element that looks like a record. */
    public static class RecordElement {
        private String name;
        private String path;
        private long count;
        private boolean selected;
        private String suggestedType;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public long getCount() {
            return count;
        }

        public void setCount(long count) {
            this.count = count;
        }

        public boolean isSelected() {
            return selected;
        }

        public void setSelected(boolean selected) {
            this.selected = selected;
        }

        public String getSuggestedType() {
            return suggestedType;
        }

        public void setSuggestedType(String suggestedType) {
            this.suggestedType = suggestedType;
        }
    }

    /** An XML code list usable as a lookup. */
    public static class LookupCandidate {
        private String path;
        private long count;
        private List<String> attributes = new ArrayList<>();
        private String sample;

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public long getCount() {
            return count;
        }

        public void setCount(long count) {
            this.count = count;
        }

        public List<String> getAttributes() {
            return attributes;
        }

        public void setAttributes(List<String> attributes) {
            this.attributes = attributes;
        }

        public String getSample() {
            return sample;
        }

        public void setSample(String sample) {
            this.sample = sample;
        }
    }
}
