package com.listhub.poc.record;

import java.util.Objects;

/** Record of a ship. */
public class VesselRecord extends Record {

    private String imoCode;
    private String flag;
    private String tonnage;
    private String owner;
    private String vesselType;
    private String grossTonnage;
    private String callSign;

    public VesselRecord() {
        super(RecordType.VESSEL);
    }

    public String getImoCode() {
        return imoCode;
    }

    public void setImoCode(String imoCode) {
        this.imoCode = imoCode;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getTonnage() {
        return tonnage;
    }

    public void setTonnage(String tonnage) {
        this.tonnage = tonnage;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getVesselType() {
        return vesselType;
    }

    public void setVesselType(String vesselType) {
        this.vesselType = vesselType;
    }

    public String getGrossTonnage() {
        return grossTonnage;
    }

    public void setGrossTonnage(String grossTonnage) {
        this.grossTonnage = grossTonnage;
    }

    public String getCallSign() {
        return callSign;
    }

    public void setCallSign(String callSign) {
        this.callSign = callSign;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        VesselRecord other = (VesselRecord) o;
        return super.equals(o) && Objects.equals(imoCode, other.imoCode)
            && Objects.equals(flag, other.flag)
            && Objects.equals(tonnage, other.tonnage)
            && Objects.equals(owner, other.owner)
            && Objects.equals(vesselType, other.vesselType)
            && Objects.equals(grossTonnage, other.grossTonnage)
            && Objects.equals(callSign, other.callSign);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), imoCode, flag, tonnage, owner, vesselType, grossTonnage, callSign);
    }

    @Override
    public String toString() {
        return "VesselRecord{"
            + "imoCode=" + imoCode
            + ", flag=" + flag
            + ", tonnage=" + tonnage
            + ", owner=" + owner
            + ", vesselType=" + vesselType
            + ", grossTonnage=" + grossTonnage
            + ", callSign=" + callSign
            + ", " + super.toString()
            + "}";
    }
}
