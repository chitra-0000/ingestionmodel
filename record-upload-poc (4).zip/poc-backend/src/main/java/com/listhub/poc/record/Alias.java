package com.listhub.poc.record;

import java.util.Objects;

/** Alias of a record. Individuals use the name parts; entities and vessels use name. */
public class Alias {

    private String reglissReference;
    private String aliasType;
    private String aliasQuality;
    private String title;
    private String firstName;
    private String middleName;
    private String lastName;
    private String maidenName;
    private String suffix;
    private String name;

    public String getReglissReference() {
        return reglissReference;
    }

    public void setReglissReference(String reglissReference) {
        this.reglissReference = reglissReference;
    }

    public String getAliasType() {
        return aliasType;
    }

    public void setAliasType(String aliasType) {
        this.aliasType = aliasType;
    }

    public String getAliasQuality() {
        return aliasQuality;
    }

    public void setAliasQuality(String aliasQuality) {
        this.aliasQuality = aliasQuality;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMaidenName() {
        return maidenName;
    }

    public void setMaidenName(String maidenName) {
        this.maidenName = maidenName;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Alias other = (Alias) o;
        return Objects.equals(reglissReference, other.reglissReference)
            && Objects.equals(aliasType, other.aliasType)
            && Objects.equals(aliasQuality, other.aliasQuality)
            && Objects.equals(title, other.title)
            && Objects.equals(firstName, other.firstName)
            && Objects.equals(middleName, other.middleName)
            && Objects.equals(lastName, other.lastName)
            && Objects.equals(maidenName, other.maidenName)
            && Objects.equals(suffix, other.suffix)
            && Objects.equals(name, other.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
            reglissReference, aliasType, aliasQuality, title, firstName, middleName, lastName, maidenName,
            suffix, name);
    }

    @Override
    public String toString() {
        return "Alias{"
            + "reglissReference=" + reglissReference
            + ", aliasType=" + aliasType
            + ", aliasQuality=" + aliasQuality
            + ", title=" + title
            + ", firstName=" + firstName
            + ", middleName=" + middleName
            + ", lastName=" + lastName
            + ", maidenName=" + maidenName
            + ", suffix=" + suffix
            + ", name=" + name
            + "}";
    }
}
