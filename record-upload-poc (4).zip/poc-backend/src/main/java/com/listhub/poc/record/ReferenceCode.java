package com.listhub.poc.record;

import java.util.Objects;

/** A referential value attached to a record (category, sanction type, Dow Jones description 3, PEP occupation category). */
public class ReferenceCode {

    private String code;
    private String label;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ReferenceCode other = (ReferenceCode) o;
        return Objects.equals(code, other.code) && Objects.equals(label, other.label);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, label);
    }

    @Override
    public String toString() {
        return "ReferenceCode{"
            + "code=" + code
            + ", label=" + label
            + "}";
    }
}
