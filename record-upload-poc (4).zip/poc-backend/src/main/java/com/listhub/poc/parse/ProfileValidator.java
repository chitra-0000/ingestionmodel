package com.listhub.poc.parse;

import com.listhub.poc.record.RecordFields;
import com.listhub.poc.record.RecordType;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/** Checks a mapping profile before it is saved or used; every problem is described in plain words. */
public final class ProfileValidator {

    public static final int MAX_RULES = 500;
    public static final int MAX_TEXT = 1000;
    private static final Pattern LOOKUP_NAME = Pattern.compile("[A-Za-z0-9_]{1,50}");

    private ProfileValidator() {
    }

    /** @return the problems found; empty when the profile can be used */
    public static List<String> problems(MappingProfile profile) {
        List<String> problems = new ArrayList<>();
        if (profile.getName() == null || profile.getName().trim().isEmpty() || profile.getName().trim().length() > 100) {
            problems.add("Give the profile a name of 1 to 100 characters.");
        }
        if (profile.getFormat() == null) {
            problems.add("Choose the file format (XML or CSV).");
            return problems;
        }
        if (profile.getEncoding() != null && !profile.getEncoding().trim().isEmpty()
            && !isCharset(profile.getEncoding().trim())) {
            problems.add("The character set '" + profile.getEncoding() + "' is not known. Use UTF-8 or windows-1252.");
        }
        if (profile.getDelimiter() != null && profile.getDelimiter().length() > 3) {
            problems.add("The delimiter must be one character (or \\t for tab).");
        }
        List<MappingRule> rules = profile.getRules();
        if (rules == null || rules.isEmpty()) {
            problems.add("The profile has no mapping lines.");
            return problems;
        }
        if (rules.size() > MAX_RULES) {
            problems.add("A profile can have at most " + MAX_RULES + " mapping lines.");
            return problems;
        }
        Set<String> lookups = new HashSet<>();
        Set<String> collections = new HashSet<>();
        boolean hasRecord = false;
        boolean hasTypeField = false;
        for (MappingRule rule : rules) {
            if (rule.getKind() == RuleKind.LOOKUP && rule.getTarget() != null) {
                lookups.add(rule.getTarget().trim().toUpperCase(Locale.ROOT));
            }
            if (rule.getKind() == RuleKind.COLLECTION && rule.getTarget() != null) {
                if (!collections.add(rule.getTarget().trim())) {
                    problems.add("The collection " + rule.getTarget().trim() + " has more than one COLLECTION line;"
                        + " combine the paths with ' + '.");
                }
            }
        }
        int line = 0;
        for (MappingRule rule : rules) {
            line++;
            String where = "Line " + line + " (" + (rule.getTarget() == null ? "no target" : rule.getTarget()) + "): ";
            if (rule.getKind() == null) {
                problems.add(where + "choose what the line does.");
                continue;
            }
            if (tooLong(rule.getSource()) || tooLong(rule.getParam()) || tooLong(rule.getTarget())) {
                problems.add(where + "texts are limited to " + MAX_TEXT + " characters.");
                continue;
            }
            if (rule.getTransform() == null) {
                rule.setTransform(Transform.NONE);
            }
            switch (rule.getKind()) {
                case RECORD:
                    hasRecord = true;
                    checkRecord(profile, rule, where, problems);
                    break;
                case FIELD:
                    if (RecordFields.TYPE.equals(trim(rule.getTarget()))) {
                        hasTypeField = true;
                    }
                    checkField(profile, rule, where, lookups, problems);
                    break;
                case COLLECTION:
                    checkCollection(profile, rule, where, problems);
                    break;
                case LOOKUP:
                    checkLookup(profile, rule, where, problems);
                    break;
                case GROUP_BY:
                    if (profile.getFormat() != FileFormat.CSV || isBlank(rule.getSource())) {
                        problems.add(where + "GROUP_BY is for CSV files and needs the id column as source.");
                    }
                    break;
                default:
                    break;
            }
        }
        if (profile.getFormat() == FileFormat.XML && !hasRecord) {
            problems.add("Add at least one RECORD line: which XML element is one record (for example Person).");
        }
        if (profile.getFormat() == FileFormat.CSV && !hasRecord && !hasTypeField) {
            problems.add("Set a default record type (RECORD line) or map the type from a column.");
        }
        return problems;
    }

    private static void checkRecord(MappingProfile profile, MappingRule rule, String where, List<String> problems) {
        if (!isType(rule.getTarget())) {
            problems.add(where + "the record type must be INDIVIDUAL, ENTITY or VESSEL.");
        }
        if (profile.getFormat() == FileFormat.XML) {
            String source = trim(rule.getSource());
            if (source.isEmpty() || !source.matches("[\\p{L}_][\\p{L}\\p{N}_.:-]*")) {
                problems.add(where + "give the record element name, for example Person.");
            }
        }
    }

    private static void checkField(MappingProfile profile, MappingRule rule, String where, Set<String> lookups,
                                   List<String> problems) {
        String target = trim(rule.getTarget());
        if (!RecordFields.TYPE.equals(target) && RecordFields.field(target) == null) {
            problems.add(where + "'" + target + "' is not a field of the canonical record.");
            return;
        }
        Transform transform = rule.getTransform();
        if (transform != Transform.CONSTANT && isBlank(rule.getSource())) {
            problems.add(where + "give the " + (profile.getFormat() == FileFormat.CSV ? "column name" : "XML path")
                + " to read, or use a fixed value (CONSTANT).");
            return;
        }
        if ((transform == Transform.CONSTANT || transform == Transform.VALUE_MAP || transform == Transform.LOOKUP
            || transform == Transform.DEFAULT) && isBlank(rule.getParam())) {
            problems.add(where + "the " + transform.name() + " transformation needs a parameter.");
        }
        if (transform == Transform.LOOKUP && !isBlank(rule.getParam())
            && !lookups.contains(rule.getParam().trim().toUpperCase(Locale.ROOT))) {
            problems.add(where + "there is no LOOKUP line named " + rule.getParam().trim() + ".");
        }
        if (transform == Transform.DATE_PARTS && !isBlank(rule.getSource())
            && RecordMapper.SOURCE_SEPARATOR.split(rule.getSource().trim()).length != 3) {
            problems.add(where + "DATE_PARTS needs three sources: year + month + day.");
        }
        if (profile.getFormat() == FileFormat.XML && transform != Transform.CONSTANT) {
            checkPaths(rule.getSource(), where, problems);
        }
    }

    private static void checkCollection(MappingProfile profile, MappingRule rule, String where, List<String> problems) {
        String target = trim(rule.getTarget());
        if (!RecordFields.collections().containsKey(target)) {
            problems.add(where + "'" + target + "' is not a collection of the canonical record.");
            return;
        }
        if (profile.getFormat() == FileFormat.XML) {
            if (isBlank(rule.getSource())) {
                problems.add(where + "give the path of the repeating element, for example NameDetails/Name.");
            } else {
                checkPaths(rule.getSource(), where, problems);
            }
        }
    }

    private static void checkLookup(MappingProfile profile, MappingRule rule, String where, List<String> problems) {
        if (profile.getFormat() != FileFormat.XML) {
            problems.add(where + "lookups are read from XML files only.");
            return;
        }
        if (!LOOKUP_NAME.matcher(trim(rule.getTarget())).matches()) {
            problems.add(where + "name the lookup with letters, digits or _ (for example SANCTION_LISTS).");
        }
        if (isBlank(rule.getSource())) {
            problems.add(where + "give the code list element, for example SanctionsReferencesList/ReferenceName.");
        }
        java.util.Map<String, String> param = RecordMapper.parseValueMap(rule.getParam());
        for (String key : new String[] {"key", "value"}) {
            if (param.containsKey(key)) {
                checkPaths(param.get(key), where, problems);
            }
        }
    }

    private static void checkPaths(String source, String where, List<String> problems) {
        for (String path : RecordMapper.SOURCE_SEPARATOR.split(source.trim())) {
            try {
                PathExpr.parse(path);
            } catch (IllegalArgumentException e) {
                problems.add(where + "the path '" + path.trim() + "' is not valid: " + e.getMessage() + ".");
            }
        }
    }

    private static boolean isType(String value) {
        if (isBlank(value)) {
            return false;
        }
        try {
            RecordType.valueOf(value.trim().toUpperCase(Locale.ROOT));
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private static boolean isCharset(String name) {
        try {
            return Charset.isSupported(name);
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private static boolean tooLong(String value) {
        return value != null && value.length() > MAX_TEXT;
    }

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private static String trim(String value) {
        return value == null ? "" : value.trim();
    }
}
