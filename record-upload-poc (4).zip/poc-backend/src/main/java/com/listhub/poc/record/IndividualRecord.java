package com.listhub.poc.record;

import java.util.Objects;

/** Record of a person. */
public class IndividualRecord extends Record {

    private String gender;
    private String title;
    private String firstName;
    private String middleName;
    private String lastName;
    private String maidenName;
    private String suffix;
    private Boolean deceased;

    public IndividualRecord() {
        super(RecordType.INDIVIDUAL);
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMaidenName() {
        return maidenName;
    }

    public void setMaidenName(String maidenName) {
        this.maidenName = maidenName;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public Boolean getDeceased() {
        return deceased;
    }

    public void setDeceased(Boolean deceased) {
        this.deceased = deceased;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        IndividualRecord other = (IndividualRecord) o;
        return super.equals(o) && Objects.equals(gender, other.gender)
            && Objects.equals(title, other.title)
            && Objects.equals(firstName, other.firstName)
            && Objects.equals(middleName, other.middleName)
            && Objects.equals(lastName, other.lastName)
            && Objects.equals(maidenName, other.maidenName)
            && Objects.equals(suffix, other.suffix)
            && Objects.equals(deceased, other.deceased);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
            super.hashCode(), gender, title, firstName, middleName, lastName, maidenName, suffix, deceased);
    }

    @Override
    public String toString() {
        return "IndividualRecord{"
            + "gender=" + gender
            + ", title=" + title
            + ", firstName=" + firstName
            + ", middleName=" + middleName
            + ", lastName=" + lastName
            + ", maidenName=" + maidenName
            + ", suffix=" + suffix
            + ", deceased=" + deceased
            + ", " + super.toString()
            + "}";
    }
}
