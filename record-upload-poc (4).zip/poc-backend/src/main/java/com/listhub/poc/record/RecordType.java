package com.listhub.poc.record;

/** Discriminator of the canonical record (RECORD_TYPE column). */
public enum RecordType {
    INDIVIDUAL,
    ENTITY,
    VESSEL
}
