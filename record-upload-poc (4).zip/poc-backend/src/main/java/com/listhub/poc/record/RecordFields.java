package com.listhub.poc.record;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Catalogue of everything a mapping can write to in the canonical record. Plain getters and
 * setters, no reflection: a mapping can only reach the fields listed here. The maximum lengths
 * are the Oracle column sizes; longer values are rejected with a reason.
 */
public final class RecordFields {

    /** The record type: handled by the mapper before the record object exists. */
    public static final String TYPE = "type";

    private static final String GENERAL = "General information";
    private static final String INDIVIDUAL = "Individual only";
    private static final String ENTITY = "Entity only";
    private static final String VESSEL = "Vessel only";
    private static final String DOW_JONES = "Dow Jones";

    private static final Map<String, FieldTarget> FIELDS = new LinkedHashMap<>();
    private static final Map<String, CollectionTarget> COLLECTIONS = new LinkedHashMap<>();

    static {
        text(GENERAL, "name", "Full name", Record.class, 300, Record::getName, Record::setName);
        text(GENERAL, "externalReference", "External reference (provider id)", Record.class, 250,
            Record::getExternalReference, Record::setExternalReference);
        text(GENERAL, "reglissReference", "REGLISS reference", Record.class, 256, Record::getReglissReference, Record::setReglissReference);
        text(GENERAL, "recordId", "Record ID", Record.class, 13, Record::getRecordId, Record::setRecordId);
        text(GENERAL, "description", "Description", Record.class, 300, Record::getDescription, Record::setDescription);
        text(GENERAL, "keywords", "Keywords", Record.class, 256, Record::getKeywords, Record::setKeywords);
        text(GENERAL, "comments", "Comments", Record.class, 2048, Record::getComments, Record::setComments);
        text(GENERAL, "additionalInfo", "Additional information", Record.class, 2048, Record::getAdditionalInfo, Record::setAdditionalInfo);
        text(GENERAL, "startDateStr", "Application (start) date", Record.class, 255, Record::getStartDateStr, Record::setStartDateStr);
        text(GENERAL, "instruction", "Instruction", Record.class, 2048, Record::getInstruction, Record::setInstruction);
        text(GENERAL, "dowJonesNotes", "Dow Jones notes", Record.class, 40000, Record::getDowJonesNotes, Record::setDowJonesNotes);
        text(GENERAL, "externalUuid", "External UUID (generated when empty)", Record.class, 36, Record::getExternalUuid, Record::setExternalUuid);
        text(GENERAL, "synthesisModDate", "Last modification date", Record.class, 255, Record::getSynthesisModDate, Record::setSynthesisModDate);
        text(GENERAL, "inactivityDateAsPep", "Inactivity date as PEP", Record.class, 255,
            Record::getInactivityDateAsPep, Record::setInactivityDateAsPep);
        text(GENERAL, "inactivityDateAsRca", "Inactivity date as RCA", Record.class, 255,
            Record::getInactivityDateAsRca, Record::setInactivityDateAsRca);

        text(INDIVIDUAL, "gender", "Gender", IndividualRecord.class, 20, IndividualRecord::getGender, IndividualRecord::setGender);
        text(INDIVIDUAL, "title", "Title", IndividualRecord.class, 100, IndividualRecord::getTitle, IndividualRecord::setTitle);
        text(INDIVIDUAL, "firstName", "First name", IndividualRecord.class, 200, IndividualRecord::getFirstName, IndividualRecord::setFirstName);
        text(INDIVIDUAL, "middleName", "Middle name", IndividualRecord.class, 200, IndividualRecord::getMiddleName, IndividualRecord::setMiddleName);
        text(INDIVIDUAL, "lastName", "Last name", IndividualRecord.class, 200, IndividualRecord::getLastName, IndividualRecord::setLastName);
        text(INDIVIDUAL, "maidenName", "Maiden name", IndividualRecord.class, 200, IndividualRecord::getMaidenName, IndividualRecord::setMaidenName);
        text(INDIVIDUAL, "suffix", "Suffix", IndividualRecord.class, 50, IndividualRecord::getSuffix, IndividualRecord::setSuffix);
        put(new FieldTarget("deceased", "Is deceased (yes/no)", INDIVIDUAL, IndividualRecord.class, 0, false,
            o -> ((IndividualRecord) o).getDeceased(),
            (o, v) -> ((IndividualRecord) o).setDeceased(Values.toBoolean("deceased", v))));

        multi(ENTITY, "bicCodes", "BIC codes", EntityRecord.class, 50, EntityRecord::getBicCodes);
        multi(ENTITY, "isinCodes", "ISIN codes", EntityRecord.class, 50, EntityRecord::getIsinCodes);

        text(VESSEL, "imoCode", "IMO code", VesselRecord.class, 50, VesselRecord::getImoCode, VesselRecord::setImoCode);
        text(VESSEL, "flag", "Flag", VesselRecord.class, 100, VesselRecord::getFlag, VesselRecord::setFlag);
        text(VESSEL, "tonnage", "Tonnage", VesselRecord.class, 50, VesselRecord::getTonnage, VesselRecord::setTonnage);
        text(VESSEL, "owner", "Owner", VesselRecord.class, 300, VesselRecord::getOwner, VesselRecord::setOwner);
        text(VESSEL, "vesselType", "Vessel type", VesselRecord.class, 100, VesselRecord::getVesselType, VesselRecord::setVesselType);
        text(VESSEL, "grossTonnage", "Gross tonnage", VesselRecord.class, 50, VesselRecord::getGrossTonnage, VesselRecord::setGrossTonnage);
        text(VESSEL, "callSign", "Call sign", VesselRecord.class, 50, VesselRecord::getCallSign, VesselRecord::setCallSign);

        text(DOW_JONES, "recordDJ.action", "Dow Jones action (add, chg, del)", Record.class, 20,
            r -> r.getRecordDJ() == null ? null : r.getRecordDJ().getAction(), (r, v) -> dj(r).setAction(v));
        text(DOW_JONES, "recordDJ.lastUpdateDate", "Dow Jones last update date", Record.class, 50,
            r -> r.getRecordDJ() == null ? null : r.getRecordDJ().getLastUpdateDate(), (r, v) -> dj(r).setLastUpdateDate(v));
        text(DOW_JONES, "recordDJ.activeStatus", "Dow Jones active status", Record.class, 50,
            r -> r.getRecordDJ() == null ? null : r.getRecordDJ().getActiveStatus(), (r, v) -> dj(r).setActiveStatus(v));

        referenceCodes("categories", "Categories (Dow Jones description 1)", Record::getCategories);
        referenceCodes("sanctionTypes", "Sanction types (Dow Jones description 2)", Record::getSanctionTypes);
        referenceCodes("descriptions3", "Dow Jones description 3", Record::getDescriptions3);
        referenceCodes("pepOccupationCategories", "PEP occupation categories", Record::getPepOccupationCategories);

        CollectionTarget programs = collection("programs", "Programs", Record.class, Program::new, Record::getPrograms);
        itemText(programs, "label", "Label", Program.class, 500, Program::getLabel, Program::setLabel);
        itemText(programs, "sanctionType", "Sanction type", Program.class, 200, Program::getSanctionType, Program::setSanctionType);

        CollectionTarget aliases = collection("aliases", "Aliases", Record.class, Alias::new, Record::getAliases);
        itemText(aliases, "name", "Full name (entity, vessel)", Alias.class, 1000, Alias::getName, Alias::setName);
        itemText(aliases, "firstName", "First name", Alias.class, 200, Alias::getFirstName, Alias::setFirstName);
        itemText(aliases, "middleName", "Middle name", Alias.class, 200, Alias::getMiddleName, Alias::setMiddleName);
        itemText(aliases, "lastName", "Last name", Alias.class, 200, Alias::getLastName, Alias::setLastName);
        itemText(aliases, "maidenName", "Maiden name", Alias.class, 200, Alias::getMaidenName, Alias::setMaidenName);
        itemText(aliases, "title", "Title", Alias.class, 100, Alias::getTitle, Alias::setTitle);
        itemText(aliases, "suffix", "Suffix", Alias.class, 50, Alias::getSuffix, Alias::setSuffix);
        itemText(aliases, "aliasType", "Alias type", Alias.class, 100, Alias::getAliasType, Alias::setAliasType);
        itemText(aliases, "aliasQuality", "Alias quality (H or L)", Alias.class, 20, Alias::getAliasQuality, Alias::setAliasQuality);
        itemText(aliases, "reglissReference", "REGLISS aka reference", Alias.class, 256, Alias::getReglissReference, Alias::setReglissReference);

        CollectionTarget refs = collection("sanctionReferences", "Sanction references (lists, regulations)", Record.class,
            SanctionReference::new, Record::getSanctionReferences);
        itemText(refs, "code", "Code", SanctionReference.class, 100, SanctionReference::getCode, SanctionReference::setCode);
        itemText(refs, "listName", "List name", SanctionReference.class, 500, SanctionReference::getListName, SanctionReference::setListName);
        itemText(refs, "sinceDate", "Since date", SanctionReference.class, 10, SanctionReference::getSinceDate, SanctionReference::setSinceDate);
        itemText(refs, "endDate", "End date", SanctionReference.class, 10, SanctionReference::getEndDate, SanctionReference::setEndDate);

        CollectionTarget sources = collection("sources", "Sources", Record.class, RecordSource::new, Record::getSources);
        itemText(sources, "source", "Source", RecordSource.class, 2000, RecordSource::getSource, RecordSource::setSource);

        CollectionTarget relations = collection("relations", "Relations", Record.class, RecordRelation::new, Record::getRelations);
        itemText(relations, "relatedExternalReference", "Related record (external reference)", RecordRelation.class, 250,
            RecordRelation::getRelatedExternalReference, RecordRelation::setRelatedExternalReference);
        itemText(relations, "relationType", "Relation", RecordRelation.class, 200, RecordRelation::getRelationType, RecordRelation::setRelationType);
        itemText(relations, "category", "Category", RecordRelation.class, 200, RecordRelation::getCategory, RecordRelation::setCategory);
        itemText(relations, "ex", "Ex (former relation)", RecordRelation.class, 50, RecordRelation::getEx, RecordRelation::setEx);

        CollectionTarget associations = collection("associations", "Associations", Record.class, RecordAssociation::new,
            Record::getAssociations);
        itemText(associations, "relatedExternalReference", "Associated record (external reference)", RecordAssociation.class, 250,
            RecordAssociation::getRelatedExternalReference, RecordAssociation::setRelatedExternalReference);
        itemText(associations, "relationType", "Relation", RecordAssociation.class, 200,
            RecordAssociation::getRelationType, RecordAssociation::setRelationType);
        itemText(associations, "category", "Category", RecordAssociation.class, 200, RecordAssociation::getCategory, RecordAssociation::setCategory);
        itemText(associations, "ex", "Ex (former association)", RecordAssociation.class, 50, RecordAssociation::getEx, RecordAssociation::setEx);

        CollectionTarget addresses = collection("addresses", "Addresses", Record.class, Address::new, Record::getAddresses);
        itemText(addresses, "address", "Address", Address.class, 1000, Address::getAddress, Address::setAddress);
        itemText(addresses, "zipCode", "Zip code", Address.class, 50, Address::getZipCode, Address::setZipCode);
        itemText(addresses, "city", "City", Address.class, 200, Address::getCity, Address::setCity);
        itemText(addresses, "state", "State", Address.class, 200, Address::getState, Address::setState);
        itemText(addresses, "country", "Country", Address.class, 200, Address::getCountry, Address::setCountry);
        itemText(addresses, "remarks", "Additional information", Address.class, 2048, Address::getRemarks, Address::setRemarks);

        CollectionTarget ibans = collection("ibanCodes", "IBAN codes", Record.class, CodeIban::new, Record::getIbanCodes);
        itemText(ibans, "code", "IBAN", CodeIban.class, 50, CodeIban::getCode, CodeIban::setCode);

        CollectionTarget dates = collection("datesDetails", "Dates (birth, death, registration...)", Record.class,
            DateDetails::new, Record::getDatesDetails);
        itemText(dates, "dateType", "Date type", DateDetails.class, 100, DateDetails::getDateType, DateDetails::setDateType);
        itemText(dates, "dateValue", "Date (partial ISO: yyyy, yyyy-MM, yyyy-MM-dd)", DateDetails.class, 10,
            DateDetails::getDateValue, DateDetails::setDateValue);
        itemInt(dates, "day", "Day", (d, v) -> d.setDay(Values.toDay("datesDetails.day", v)), DateDetails::getDay);
        itemInt(dates, "month", "Month (number or name)", (d, v) -> d.setMonth(Values.toMonth("datesDetails.month", v)), DateDetails::getMonth);
        itemInt(dates, "year", "Year", (d, v) -> d.setYear(Values.toInteger("datesDetails.year", v)), DateDetails::getYear);
        itemText(dates, "birthPlace", "Birth place", DateDetails.class, 500, DateDetails::getBirthPlace, DateDetails::setBirthPlace);
        itemText(dates, "birthCountry", "Birth country", DateDetails.class, 200, DateDetails::getBirthCountry, DateDetails::setBirthCountry);
        itemText(dates, "additionalInfo", "Additional information", DateDetails.class, 2048,
            DateDetails::getAdditionalInfo, DateDetails::setAdditionalInfo);

        CollectionTarget countries = collection("countriesDetails", "Countries (citizenship, residence...)", Record.class,
            CountryDetails::new, Record::getCountriesDetails);
        itemText(countries, "countryType", "Country type", CountryDetails.class, 100, CountryDetails::getCountryType, CountryDetails::setCountryType);
        itemText(countries, "countryCode", "Country code", CountryDetails.class, 10, CountryDetails::getCountryCode, CountryDetails::setCountryCode);
        itemText(countries, "countryName", "Country name", CountryDetails.class, 200, CountryDetails::getCountryName, CountryDetails::setCountryName);
        itemText(countries, "additionalInfo", "Additional information", CountryDetails.class, 2048,
            CountryDetails::getAdditionalInfo, CountryDetails::setAdditionalInfo);

        CollectionTarget documents = collection("identityDocuments", "Identity documents", Record.class,
            IdentityDocument::new, Record::getIdentityDocuments);
        itemText(documents, "documentType", "Document type", IdentityDocument.class, 200,
            IdentityDocument::getDocumentType, IdentityDocument::setDocumentType);
        itemText(documents, "number", "Number", IdentityDocument.class, 200, IdentityDocument::getNumber, IdentityDocument::setNumber);
        itemText(documents, "additionalInfo", "Additional information", IdentityDocument.class, 2048,
            IdentityDocument::getAdditionalInfo, IdentityDocument::setAdditionalInfo);
    }

    private RecordFields() {
    }

    /** Record-level fields (not the type and not collection items), by path. */
    public static Map<String, FieldTarget> fields() {
        return Collections.unmodifiableMap(FIELDS);
    }

    /** Collections of child objects, by name. */
    public static Map<String, CollectionTarget> collections() {
        return Collections.unmodifiableMap(COLLECTIONS);
    }

    /** The field for a path such as {@code name} or {@code aliases.lastName}, or null. */
    public static FieldTarget field(String path) {
        FieldTarget field = FIELDS.get(path);
        if (field != null) {
            return field;
        }
        int dot = path.indexOf('.');
        if (dot < 0) {
            return null;
        }
        CollectionTarget collection = COLLECTIONS.get(path.substring(0, dot));
        return collection == null ? null : collection.getFields().get(path);
    }

    /** The collection a path such as {@code aliases.lastName} belongs to, or null for a record-level field. */
    public static CollectionTarget collectionOf(String path) {
        int dot = path.indexOf('.');
        return dot < 0 ? null : COLLECTIONS.get(path.substring(0, dot));
    }

    /** Every field of every collection, in catalogue order. */
    public static List<FieldTarget> allItemFields() {
        List<FieldTarget> all = new ArrayList<>();
        for (CollectionTarget c : COLLECTIONS.values()) {
            all.addAll(c.getFields().values());
        }
        return all;
    }

    private static RecordDJ dj(Record record) {
        if (record.getRecordDJ() == null) {
            record.setRecordDJ(new RecordDJ());
        }
        return record.getRecordDJ();
    }

    private static void put(FieldTarget field) {
        FIELDS.put(field.getPath(), field);
    }

    private static <T> void text(String section, String path, String label, Class<T> owner, int max,
                                 Function<T, String> get, BiConsumer<T, String> set) {
        put(new FieldTarget(path, label, section, owner, max, false,
            o -> get.apply(owner.cast(o)), (o, v) -> set.accept(owner.cast(o), v)));
    }

    private static <T> void multi(String section, String path, String label, Class<T> owner, int max,
                                  Function<T, List<String>> list) {
        put(new FieldTarget(path, label, section, owner, max, true,
            o -> list.apply(owner.cast(o)),
            (o, v) -> {
                List<String> values = list.apply(owner.cast(o));
                if (!values.contains(v)) {
                    values.add(v);
                }
            }));
    }

    @SuppressWarnings("unchecked")
    private static <T> CollectionTarget collection(String name, String label, Class<?> owner, Supplier<T> factory,
                                                   Function<Record, List<T>> list) {
        CollectionTarget target = new CollectionTarget(name, label, owner, (Supplier<Object>) factory,
            r -> (List<Object>) list.apply(r));
        COLLECTIONS.put(name, target);
        return target;
    }

    private static <T> void itemText(CollectionTarget collection, String field, String label, Class<T> owner, int max,
                                     Function<T, String> get, BiConsumer<T, String> set) {
        collection.add(new FieldTarget(collection.getName() + "." + field, label, collection.getLabel(), owner, max, false,
            o -> get.apply(owner.cast(o)), (o, v) -> set.accept(owner.cast(o), v)));
    }

    private static void itemInt(CollectionTarget collection, String field, String label,
                                BiConsumer<DateDetails, String> set, Function<DateDetails, Integer> get) {
        collection.add(new FieldTarget(collection.getName() + "." + field, label, collection.getLabel(), DateDetails.class, 0,
            false, o -> get.apply((DateDetails) o), (o, v) -> set.accept((DateDetails) o, v)));
    }

    private static void referenceCodes(String name, String label, Function<Record, List<ReferenceCode>> list) {
        CollectionTarget target = collection(name, label, Record.class, ReferenceCode::new, list);
        itemText(target, "code", "Code", ReferenceCode.class, 100, ReferenceCode::getCode, ReferenceCode::setCode);
        itemText(target, "label", "Label", ReferenceCode.class, 500, ReferenceCode::getLabel, ReferenceCode::setLabel);
    }
}
