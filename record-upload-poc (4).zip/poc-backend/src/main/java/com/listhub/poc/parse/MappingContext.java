package com.listhub.poc.parse;

import java.util.List;

/** Where mapping values come from: one CSV row, or one XML record element (or one item inside it). */
public interface MappingContext {

    /** Values found at a source (CSV column name, or XML path); never null, empty values left out. */
    List<String> values(String source);

    /**
     * Items of a collection. XML: the elements the path selects. CSV: the cell split on the
     * separator (one item per value), or the whole row when the source is empty. Several sources
     * joined with " + " give the items of each, in order.
     */
    List<MappingContext> items(String source, String separator);
}
