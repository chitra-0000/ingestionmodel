package com.listhub.poc.record;

import java.util.Objects;

/** Address of a record. */
public class Address {

    private String address;
    private String zipCode;
    private String city;
    private String state;
    private String country;
    private String remarks;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Address other = (Address) o;
        return Objects.equals(address, other.address)
            && Objects.equals(zipCode, other.zipCode)
            && Objects.equals(city, other.city)
            && Objects.equals(state, other.state)
            && Objects.equals(country, other.country)
            && Objects.equals(remarks, other.remarks);
    }

    @Override
    public int hashCode() {
        return Objects.hash(address, zipCode, city, state, country, remarks);
    }

    @Override
    public String toString() {
        return "Address{"
            + "address=" + address
            + ", zipCode=" + zipCode
            + ", city=" + city
            + ", state=" + state
            + ", country=" + country
            + ", remarks=" + remarks
            + "}";
    }
}
