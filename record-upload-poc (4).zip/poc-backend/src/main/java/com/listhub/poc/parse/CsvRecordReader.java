package com.listhub.poc.parse;

import com.listhub.poc.record.MappingException;
import com.listhub.poc.record.Record;
import com.listhub.poc.record.RecordType;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PushbackInputStream;
import java.io.UncheckedIOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.csv.DuplicateHeaderMode;
import org.springframework.core.io.InputStreamSource;
import org.springframework.stereotype.Component;

/**
 * Reads any delimited text file with a mapping profile. The header row gives the column names the
 * mapping refers to; the delimiter is detected when the profile does not set one. Rows are
 * streamed one by one. Consecutive rows with the same value in the GROUP_BY column form one record
 * (files with one row per alias or per address).
 */
@Component
public class CsvRecordReader {

    private static final char[] CANDIDATE_DELIMITERS = {',', ';', '|', '\t'};
    private static final Pattern CSV_LINE = Pattern.compile("\\(line (\\d+)\\)\\s*(.*)");
    private static final int MAX_LINE_FOR_DETECTION = 1_000_000;

    public void read(InputStreamSource file, MappingProfile profile, RecordSink sink) throws IOException {
        RecordType defaultType = defaultType(profile);
        String groupBy = groupBy(profile);
        RecordMapper mapper = new RecordMapper(profile, new HashMap<>());
        try (BufferedReader reader = open(file.getInputStream(), profile.getEncoding());
             CSVParser parser = format(delimiterOf(profile, reader)).parse(reader)) {
            List<String> headers = keys(parser.getHeaderNames());
            if (headers.isEmpty()) {
                throw new FileFormatException("The file has no header row: the first line must hold the column names.");
            }
            checkColumns(profile, headers, parser.getHeaderNames());
            long rows = readRows(parser, headers, groupBy, defaultType, mapper, sink);
            if (rows == 0) {
                throw new FileFormatException("The file has a header row but no data rows.");
            }
        } catch (UncheckedIOException e) {
            throw new FileFormatException(describe(e), e);
        }
    }

    private static long readRows(CSVParser parser, List<String> headers, String groupBy, RecordType defaultType,
                                 RecordMapper mapper, RecordSink sink) {
        long rowNo = 0;
        Record current = null;
        long currentRow = 0;
        String currentKey = null;
        String failure = null;
        String failureRef = null;
        for (CSVRecord csv : parser) {
            rowNo++;
            Map<String, String> row = rowOf(headers, csv);
            CsvContext context = new CsvContext(row, null);
            String key = groupBy == null ? null : row.get(groupBy);
            if (current != null || failure != null) {
                boolean sameRecord = groupBy != null && key != null && Objects.equals(key, currentKey);
                if (sameRecord) {
                    if (failure == null) {
                        try {
                            mapper.mapInto(current, context);
                        } catch (MappingException e) {
                            failure = "row " + rowNo + ": " + e.getMessage();
                            failureRef = mapper.externalReferenceOf(context);
                        }
                    }
                    continue;
                }
                emit(currentRow, current, failure, failureRef, sink);
                current = null;
                failure = null;
                failureRef = null;
            }
            currentRow = rowNo;
            currentKey = key;
            try {
                current = mapper.map(context, defaultType);
            } catch (MappingException e) {
                failure = e.getMessage();
                failureRef = mapper.externalReferenceOf(context);
            }
        }
        if (current != null || failure != null) {
            emit(currentRow, current, failure, failureRef, sink);
        }
        return rowNo;
    }

    private static void emit(long rowNo, Record record, String failure, String failureRef, RecordSink sink) {
        if (failure != null) {
            sink.reject(rowNo, failureRef, failure);
        } else {
            sink.accept(rowNo, record);
        }
    }

    private static Map<String, String> rowOf(List<String> headers, CSVRecord csv) {
        Map<String, String> row = new HashMap<>(headers.size() * 2);
        for (int i = 0; i < headers.size() && i < csv.size(); i++) {
            row.putIfAbsent(headers.get(i), csv.get(i));
        }
        return row;
    }

    /** Every column the mapping uses must be in the header; otherwise the whole file is refused with the list. */
    static void checkColumns(MappingProfile profile, List<String> headerKeys, List<String> headerNames) {
        Set<String> present = new LinkedHashSet<>(headerKeys);
        List<String> missing = new ArrayList<>();
        for (MappingRule rule : profile.getRules()) {
            if (rule.getKind() == RuleKind.RECORD || rule.getKind() == RuleKind.LOOKUP
                || rule.getTransform() == Transform.CONSTANT || rule.getSource() == null) {
                continue;
            }
            for (String source : RecordMapper.SOURCE_SEPARATOR.split(rule.getSource().trim())) {
                String s = source.trim();
                if (!s.isEmpty() && !CsvContext.SELF.equals(s) && !present.contains(CsvContext.key(s))) {
                    missing.add("'" + s + "' (for " + rule.getTarget() + ")");
                }
            }
        }
        if (!missing.isEmpty()) {
            List<String> shown = headerNames.size() > 40 ? headerNames.subList(0, 40) : headerNames;
            throw new FileFormatException("The file does not have these columns used by the mapping: "
                + String.join(", ", missing) + ". Columns in the file: " + String.join(", ", shown)
                + ". Choose another profile or edit the mapping.");
        }
    }

    static List<String> keys(List<String> headerNames) {
        List<String> keys = new ArrayList<>(headerNames.size());
        for (String name : headerNames) {
            keys.add(CsvContext.key(name));
        }
        return keys;
    }

    static CSVFormat format(char delimiter) {
        return CSVFormat.DEFAULT.builder()
            .setDelimiter(delimiter)
            .setHeader()
            .setSkipHeaderRecord(true)
            .setIgnoreEmptyLines(true)
            .setIgnoreSurroundingSpaces(true)
            .setAllowMissingColumnNames(true)
            .setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL)
            .build();
    }

    /** Opens the file in the profile's character set; a byte order mark, if any, wins and is skipped. */
    static BufferedReader open(InputStream raw, String encoding) throws IOException {
        PushbackInputStream in = new PushbackInputStream(raw, 3);
        byte[] bom = new byte[3];
        int read = in.read(bom, 0, 3);
        Charset charset = charset(encoding);
        int skip = 0;
        if (read >= 3 && (bom[0] & 0xFF) == 0xEF && (bom[1] & 0xFF) == 0xBB && (bom[2] & 0xFF) == 0xBF) {
            charset = StandardCharsets.UTF_8;
            skip = 3;
        } else if (read >= 2 && (bom[0] & 0xFF) == 0xFE && (bom[1] & 0xFF) == 0xFF) {
            charset = StandardCharsets.UTF_16BE;
            skip = 2;
        } else if (read >= 2 && (bom[0] & 0xFF) == 0xFF && (bom[1] & 0xFF) == 0xFE) {
            charset = StandardCharsets.UTF_16LE;
            skip = 2;
        }
        if (read > skip) {
            in.unread(bom, skip, read - skip);
        }
        return new BufferedReader(new InputStreamReader(in, charset), 64 * 1024);
    }

    static Charset charset(String encoding) {
        if (encoding == null || encoding.trim().isEmpty()) {
            return StandardCharsets.UTF_8;
        }
        try {
            return Charset.forName(encoding.trim());
        } catch (IllegalArgumentException e) {
            throw new FileFormatException("The character set '" + encoding + "' is not known. Use UTF-8 or windows-1252.");
        }
    }

    /** The profile's delimiter, or the most frequent of , ; | and tab in the header line. */
    static char delimiterOf(MappingProfile profile, BufferedReader reader) throws IOException {
        String configured = profile.getDelimiter();
        if (configured != null && !configured.isEmpty()) {
            if ("\\t".equals(configured) || "TAB".equalsIgnoreCase(configured.trim())) {
                return '\t';
            }
            return configured.charAt(0);
        }
        reader.mark(MAX_LINE_FOR_DETECTION);
        String header = reader.readLine();
        reader.reset();
        return detectDelimiter(header);
    }

    static char detectDelimiter(String header) {
        if (header == null) {
            return ',';
        }
        char best = ',';
        int bestCount = 0;
        for (char candidate : CANDIDATE_DELIMITERS) {
            int count = 0;
            boolean quoted = false;
            for (char c : header.toCharArray()) {
                if (c == '"') {
                    quoted = !quoted;
                } else if (c == candidate && !quoted) {
                    count++;
                }
            }
            if (count > bestCount) {
                best = candidate;
                bestCount = count;
            }
        }
        return best;
    }

    private static RecordType defaultType(MappingProfile profile) {
        for (MappingRule rule : profile.getRules()) {
            if (rule.getKind() == RuleKind.RECORD && rule.getTarget() != null && !rule.getTarget().trim().isEmpty()) {
                return RecordType.valueOf(rule.getTarget().trim().toUpperCase(Locale.ROOT));
            }
        }
        return null;
    }

    private static String groupBy(MappingProfile profile) {
        for (MappingRule rule : profile.getRules()) {
            if (rule.getKind() == RuleKind.GROUP_BY && rule.getSource() != null && !rule.getSource().trim().isEmpty()) {
                return CsvContext.key(rule.getSource());
            }
        }
        return null;
    }

    private static String describe(UncheckedIOException e) {
        String message = e.getMessage() == null ? "" : e.getMessage();
        Matcher m = CSV_LINE.matcher(message);
        if (m.find()) {
            return "The CSV file is not valid at line " + m.group(1) + ": " + m.group(2)
                + ". Check the quotes and the delimiter on that line.";
        }
        return "The CSV file could not be read. Check the quotes and the delimiter.";
    }

    /** Column names of a header, keeping file order, for the inspector. */
    static Map<String, String> columnNames(List<String> headerNames) {
        Map<String, String> names = new LinkedHashMap<>();
        for (String name : headerNames) {
            names.putIfAbsent(CsvContext.key(name), name == null ? "" : name.trim());
        }
        names.remove("");
        return names;
    }

    static String lower(String value) {
        return value.toLowerCase(Locale.ROOT);
    }
}
