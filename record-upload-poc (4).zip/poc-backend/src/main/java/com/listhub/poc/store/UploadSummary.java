package com.listhub.poc.store;

import java.time.Instant;

/** One upload in the history: file, mapping profile used, counts and outcome. */
public class UploadSummary {

    private long uploadId;
    private String fileName;
    private String format;
    private String profileName;
    private long fileSizeBytes;
    private String status;
    private long recordsRead;
    private long recordsLoaded;
    private long recordsRejected;
    private String message;
    private Instant startedAt;
    private Instant endedAt;
    private Long durationMs;

    public long getUploadId() {
        return uploadId;
    }

    public void setUploadId(long uploadId) {
        this.uploadId = uploadId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getProfileName() {
        return profileName;
    }

    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    public long getFileSizeBytes() {
        return fileSizeBytes;
    }

    public void setFileSizeBytes(long fileSizeBytes) {
        this.fileSizeBytes = fileSizeBytes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getRecordsRead() {
        return recordsRead;
    }

    public void setRecordsRead(long recordsRead) {
        this.recordsRead = recordsRead;
    }

    public long getRecordsLoaded() {
        return recordsLoaded;
    }

    public void setRecordsLoaded(long recordsLoaded) {
        this.recordsLoaded = recordsLoaded;
    }

    public long getRecordsRejected() {
        return recordsRejected;
    }

    public void setRecordsRejected(long recordsRejected) {
        this.recordsRejected = recordsRejected;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Instant getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(Instant startedAt) {
        this.startedAt = startedAt;
    }

    public Instant getEndedAt() {
        return endedAt;
    }

    public void setEndedAt(Instant endedAt) {
        this.endedAt = endedAt;
    }

    public Long getDurationMs() {
        return durationMs;
    }

    public void setDurationMs(Long durationMs) {
        this.durationMs = durationMs;
    }
}
