package com.listhub.poc.record;

import java.util.Objects;

/** Version range of a record: the version that added it, the version that ended it, and the version that deleted it. */
public class RecordVersionLinks {

    private Long fromVersion;
    private Long toVersion;
    private Long deletedInVersion;

    public Long getFromVersion() {
        return fromVersion;
    }

    public void setFromVersion(Long fromVersion) {
        this.fromVersion = fromVersion;
    }

    public Long getToVersion() {
        return toVersion;
    }

    public void setToVersion(Long toVersion) {
        this.toVersion = toVersion;
    }

    public Long getDeletedInVersion() {
        return deletedInVersion;
    }

    public void setDeletedInVersion(Long deletedInVersion) {
        this.deletedInVersion = deletedInVersion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RecordVersionLinks other = (RecordVersionLinks) o;
        return Objects.equals(fromVersion, other.fromVersion)
            && Objects.equals(toVersion, other.toVersion)
            && Objects.equals(deletedInVersion, other.deletedInVersion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(fromVersion, toVersion, deletedInVersion);
    }

    @Override
    public String toString() {
        return "RecordVersionLinks{"
            + "fromVersion=" + fromVersion
            + ", toVersion=" + toVersion
            + ", deletedInVersion=" + deletedInVersion
            + "}";
    }
}
