package com.listhub.poc.record;

/** A value of one record could not be mapped; the record is rejected with this message. */
public class MappingException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public MappingException(String message) {
        super(message);
    }
}
