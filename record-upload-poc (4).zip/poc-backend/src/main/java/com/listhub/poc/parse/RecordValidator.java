package com.listhub.poc.parse;

import com.listhub.poc.record.CollectionTarget;
import com.listhub.poc.record.FieldTarget;
import com.listhub.poc.record.Record;
import com.listhub.poc.record.RecordFields;
import com.listhub.poc.record.Values;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;

/**
 * Checks a mapped record before it is saved, like the bank model's constraint groups:
 * errors (the record is not saved) and warnings (saved, and listed with the reason).
 */
@Component
public class RecordValidator {

    /** Result of the checks of one record. */
    public static final class Result {
        private final List<String> errors = new ArrayList<>();
        private final List<String> warnings = new ArrayList<>();

        public List<String> getErrors() {
            return errors;
        }

        public List<String> getWarnings() {
            return warnings;
        }
    }

    public Result check(Record record) {
        Result result = new Result();
        if (Values.isBlank(record.getExternalReference())) {
            result.errors.add("externalReference is missing (record.externalReference.mandatory).");
        }
        if (Values.isBlank(record.getName())) {
            result.warnings.add("name is empty (record.name.mandatory).");
        }
        for (FieldTarget field : RecordFields.fields().values()) {
            if (field.appliesTo(record)) {
                checkLength(field, field.getPath(), field.get(record), result);
            }
        }
        if (record.getNameNormalized() != null && record.getNameNormalized().length() > 450) {
            result.errors.add("nameNormalized is longer than 450 characters.");
        }
        for (CollectionTarget collection : RecordFields.collections().values()) {
            if (!collection.appliesTo(record)) {
                continue;
            }
            List<Object> items = collection.itemsOf(record);
            if (items.size() > 10_000) {
                result.errors.add(collection.getName() + " has more than 10000 items.");
                continue;
            }
            for (int i = 0; i < items.size(); i++) {
                for (FieldTarget field : collection.getFields().values()) {
                    String path = collection.getName() + "[" + (i + 1) + "]" + field.getPath().substring(collection.getName().length());
                    checkLength(field, path, field.get(items.get(i)), result);
                }
            }
        }
        return result;
    }

    private static void checkLength(FieldTarget field, String path, Object value, Result result) {
        if (field.getMaxLength() <= 0 || value == null) {
            return;
        }
        if (value instanceof String) {
            if (((String) value).length() > field.getMaxLength()) {
                result.errors.add(path + " is longer than " + field.getMaxLength() + " characters.");
            }
        } else if (value instanceof List) {
            for (Object v : (List<?>) value) {
                if (v instanceof String && ((String) v).length() > field.getMaxLength()) {
                    result.errors.add(path + " has a value longer than " + field.getMaxLength() + " characters.");
                    return;
                }
            }
        }
    }
}
