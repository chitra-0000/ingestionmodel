package com.listhub.poc.record;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Record of a company or organisation. */
public class EntityRecord extends Record {

    private List<String> bicCodes = new ArrayList<>();
    private List<String> isinCodes = new ArrayList<>();

    public EntityRecord() {
        super(RecordType.ENTITY);
    }

    public List<String> getBicCodes() {
        return bicCodes;
    }

    public void setBicCodes(List<String> bicCodes) {
        this.bicCodes = bicCodes;
    }

    public List<String> getIsinCodes() {
        return isinCodes;
    }

    public void setIsinCodes(List<String> isinCodes) {
        this.isinCodes = isinCodes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EntityRecord other = (EntityRecord) o;
        return super.equals(o) && Objects.equals(bicCodes, other.bicCodes)
            && Objects.equals(isinCodes, other.isinCodes);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), bicCodes, isinCodes);
    }

    @Override
    public String toString() {
        return "EntityRecord{"
            + "bicCodes=" + bicCodes
            + ", isinCodes=" + isinCodes
            + ", " + super.toString()
            + "}";
    }
}
