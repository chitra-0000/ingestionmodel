package com.listhub.poc.record;

import java.util.Objects;

/** Sanction program of a record. */
public class Program {

    private String label;
    private String sanctionType;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getSanctionType() {
        return sanctionType;
    }

    public void setSanctionType(String sanctionType) {
        this.sanctionType = sanctionType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Program other = (Program) o;
        return Objects.equals(label, other.label) && Objects.equals(sanctionType, other.sanctionType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(label, sanctionType);
    }

    @Override
    public String toString() {
        return "Program{"
            + "label=" + label
            + ", sanctionType=" + sanctionType
            + "}";
    }
}
