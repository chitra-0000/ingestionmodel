package com.listhub.poc.record;

import java.text.Normalizer;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.ResolverStyle;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalAccessor;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Conversions of file text into canonical values: numbers, months, yes/no, partial dates, normalised names. */
public final class Values {

    /** Date formats tried when a DATE mapping gives no pattern. */
    public static final List<String> DEFAULT_DATE_PATTERNS = Collections.unmodifiableList(Arrays.asList(
        "yyyy-MM-dd", "dd/MM/yyyy", "yyyy/MM/dd", "dd-MM-yyyy", "dd.MM.yyyy", "yyyyMMdd", "dd-MMM-yyyy",
        "dd MMM yyyy", "yyyy-MM", "MM/yyyy", "yyyy"));

    private static final String[] MONTHS = {"jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"};
    private static final Pattern MARKS = Pattern.compile("\\p{M}+");
    private static final Pattern NOT_NAME = Pattern.compile("[^\\p{L}\\p{N}]+");

    private Values() {
    }

    public static Integer toInteger(String field, String value) {
        try {
            return Integer.valueOf(value.trim());
        } catch (NumberFormatException e) {
            throw new MappingException(field + ": '" + shorten(value) + "' is not a number.");
        }
    }

    /** A month as 1 to 12, from a number or an English month name ("Mar", "March"). */
    public static Integer toMonth(String field, String value) {
        String v = value.trim().toLowerCase(Locale.ROOT);
        if (v.length() >= 3) {
            for (int i = 0; i < MONTHS.length; i++) {
                if (v.startsWith(MONTHS[i])) {
                    return i + 1;
                }
            }
        }
        Integer month = toInteger(field, v);
        if (month < 1 || month > 12) {
            throw new MappingException(field + ": '" + shorten(value) + "' is not a month (1 to 12).");
        }
        return month;
    }

    public static Integer toDay(String field, String value) {
        Integer day = toInteger(field, value);
        if (day < 1 || day > 31) {
            throw new MappingException(field + ": '" + shorten(value) + "' is not a day of the month.");
        }
        return day;
    }

    /** True for yes/true/y/1/x/deceased, false for no/false/n/0; anything else is an error. */
    public static Boolean toBoolean(String field, String value) {
        String v = value.trim().toLowerCase(Locale.ROOT);
        switch (v) {
            case "yes": case "y": case "true": case "1": case "x": case "deceased": case "oui": case "o":
                return Boolean.TRUE;
            case "no": case "n": case "false": case "0": case "non":
                return Boolean.FALSE;
            default:
                throw new MappingException(field + ": '" + shorten(value) + "' is not yes or no.");
        }
    }

    /**
     * Partial ISO date (yyyy, yyyy-MM or yyyy-MM-dd) from separate parts. Returns null when every
     * part is empty. Rejects impossible dates such as 31 February.
     */
    public static String partialDate(String field, String year, String month, String day) {
        boolean hasYear = !isBlank(year);
        boolean hasMonth = !isBlank(month);
        boolean hasDay = !isBlank(day);
        if (!hasYear && !hasMonth && !hasDay) {
            return null;
        }
        if (!hasYear) {
            throw new MappingException(field + ": a date without a year cannot be stored.");
        }
        int y = toInteger(field, year);
        if (!hasMonth) {
            return String.format(Locale.ROOT, "%04d", y);
        }
        int m = toMonth(field, month);
        if (!hasDay) {
            return YearMonth.of(y, m).toString();
        }
        int d = toDay(field, day);
        try {
            return LocalDate.of(y, m, d).toString();
        } catch (DateTimeException e) {
            throw new MappingException(field + ": " + y + "-" + m + "-" + d + " is not a real date.");
        }
    }

    /**
     * Partial ISO date from text, trying each pattern in turn (Java date patterns, for example
     * dd/MM/yyyy). A pattern without a day gives yyyy-MM, without a month gives yyyy.
     */
    public static String parseDate(String field, String value, List<String> patterns) {
        String v = value.trim();
        for (String pattern : patterns) {
            String result = tryPattern(v, pattern.trim());
            if (result != null) {
                return result;
            }
        }
        throw new MappingException(field + ": '" + shorten(value) + "' is not a date in the expected format ("
            + String.join(" or ", patterns) + ").");
    }

    private static String tryPattern(String value, String pattern) {
        if (pattern.isEmpty()) {
            return null;
        }
        DateTimeFormatter formatter;
        try {
            formatter = new DateTimeFormatterBuilder().parseCaseInsensitive()
                .appendPattern(pattern.replace("yyyy", "uuuu"))
                .toFormatter(Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT);
        } catch (IllegalArgumentException e) {
            return null;
        }
        try {
            TemporalAccessor parsed = formatter.parse(value);
            int year = parsed.get(ChronoField.YEAR);
            if (!parsed.isSupported(ChronoField.MONTH_OF_YEAR)) {
                return String.format(Locale.ROOT, "%04d", year);
            }
            int month = parsed.get(ChronoField.MONTH_OF_YEAR);
            if (!parsed.isSupported(ChronoField.DAY_OF_MONTH)) {
                return YearMonth.of(year, month).toString();
            }
            return LocalDate.of(year, month, parsed.get(ChronoField.DAY_OF_MONTH)).toString();
        } catch (DateTimeException e) {
            return null;
        }
    }

    /** Partial ISO date built from parts already converted (used for DateDetails.dateValue). */
    public static String partialDate(Integer year, Integer month, Integer day) {
        if (year == null) {
            return null;
        }
        if (month == null) {
            return String.format(Locale.ROOT, "%04d", year);
        }
        if (day == null) {
            return YearMonth.of(year, month).toString();
        }
        try {
            return LocalDate.of(year, month, day).toString();
        } catch (DateTimeException e) {
            throw new MappingException("datesDetails: " + year + "-" + month + "-" + day + " is not a real date.");
        }
    }

    /** Upper case, no accents, single spaces: used for name matching (NAME_NORMALIZED). */
    public static String normalizeName(String name) {
        if (name == null) {
            return null;
        }
        String noAccents = MARKS.matcher(Normalizer.normalize(name, Normalizer.Form.NFD)).replaceAll("");
        String cleaned = NOT_NAME.matcher(noAccents).replaceAll(" ").trim().toUpperCase(Locale.ROOT);
        return cleaned.isEmpty() ? null : cleaned;
    }

    public static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    /** At most 60 characters of a file value, for messages. */
    public static String shorten(String value) {
        if (value == null) {
            return "";
        }
        String v = value.replaceAll("\\p{Cntrl}", " ");
        return v.length() > 60 ? v.substring(0, 57) + "..." : v;
    }
}
