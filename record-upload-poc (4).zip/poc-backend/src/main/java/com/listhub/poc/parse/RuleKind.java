package com.listhub.poc.parse;

/** What one line of a mapping profile does. */
public enum RuleKind {
    /**
     * Which file items are records. XML: source = record element name (for example Person),
     * target = its record type. CSV: source empty (every row), target = default record type.
     */
    RECORD,
    /** One canonical field: target = field path (name, aliases.lastName...), source = CSV column or XML path. */
    FIELD,
    /** One list of child objects: target = collection (aliases...), source = repeating XML path or CSV column. */
    COLLECTION,
    /** XML code list read from anywhere in the file: target = lookup name, source = element path, param = key/value paths. */
    LOOKUP,
    /** CSV only: consecutive rows with the same value in the source column form one record. */
    GROUP_BY
}
