package com.listhub.poc.parse;

import com.listhub.poc.record.MappingException;
import com.listhub.poc.record.Record;
import com.listhub.poc.record.RecordType;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.InputStreamSource;
import org.springframework.stereotype.Component;

/**
 * Reads any XML file with a mapping profile. The file is streamed (StAX): only the record being
 * read is held in memory, whatever the file size. When the profile has lookups (code lists such as
 * Dow Jones' SanctionsReferencesList, which can sit anywhere in the file), a first quick pass
 * collects them, then a second pass maps the records.
 */
@Component
public class XmlRecordReader {

    private static final Logger LOG = LoggerFactory.getLogger(XmlRecordReader.class);
    static final int MAX_NODES_PER_RECORD = 100_000;
    static final int MAX_TEXT_PER_RECORD = 5_000_000;
    private static final int MAX_LOOKUP_ENTRIES = 1_000_000;

    public void read(InputStreamSource file, MappingProfile profile, RecordSink sink) throws IOException {
        Map<String, RecordType> recordElements = recordElements(profile);
        Map<String, Map<String, String>> lookups = collectLookups(file, profile);
        RecordMapper mapper = new RecordMapper(profile, lookups);
        long records;
        try (InputStream in = new BufferedInputStream(file.getInputStream())) {
            records = readRecords(in, recordElements, mapper, sink);
        } catch (XMLStreamException e) {
            throw new FileFormatException(XmlFactory.describe(e), e);
        }
        if (records == 0) {
            throw new FileFormatException("No records found: the file has no " + elementList(recordElements)
                + " elements. Open the mapping and choose the record elements of this file.");
        }
    }

    static Map<String, RecordType> recordElements(MappingProfile profile) {
        Map<String, RecordType> elements = new LinkedHashMap<>();
        for (MappingRule rule : profile.getRules()) {
            if (rule.getKind() == RuleKind.RECORD && rule.getSource() != null && !rule.getSource().trim().isEmpty()) {
                elements.put(localName(rule.getSource()), RecordType.valueOf(rule.getTarget().trim().toUpperCase(Locale.ROOT)));
            }
        }
        if (elements.isEmpty()) {
            throw new FileFormatException("The mapping has no record element. Add a RECORD line, for example Person.");
        }
        return elements;
    }

    private static long readRecords(InputStream in, Map<String, RecordType> recordElements, RecordMapper mapper,
                                    RecordSink sink) throws XMLStreamException {
        XMLStreamReader xml = XmlFactory.open(in);
        Map<String, PathExpr> paths = new HashMap<>();
        long rowNo = 0;
        XmlNode root = null;
        XmlNode current = null;
        RecordType type = null;
        int depth = 0;
        int nodes = 0;
        long textSize = 0;
        boolean tooBig = false;
        try {
            while (xml.hasNext()) {
                int event = xml.next();
                if (event == XMLStreamConstants.START_ELEMENT) {
                    String name = xml.getLocalName();
                    if (root == null) {
                        type = recordElements.get(name.toLowerCase(Locale.ROOT));
                        if (type != null) {
                            root = new XmlNode(name, null);
                            current = root;
                            copyAttributes(xml, root);
                            depth = 1;
                            nodes = 1;
                            textSize = 0;
                            tooBig = false;
                        }
                    } else {
                        depth++;
                        nodes++;
                        if (nodes > MAX_NODES_PER_RECORD) {
                            tooBig = true;
                        }
                        if (!tooBig) {
                            current = current.addChild(name);
                            copyAttributes(xml, current);
                        }
                    }
                } else if (root != null && (event == XMLStreamConstants.CHARACTERS || event == XMLStreamConstants.CDATA)) {
                    if (!tooBig) {
                        String text = xml.getText();
                        textSize += text.length();
                        if (textSize > MAX_TEXT_PER_RECORD) {
                            tooBig = true;
                        } else {
                            current.appendText(text);
                        }
                    }
                } else if (root != null && event == XMLStreamConstants.END_ELEMENT) {
                    depth--;
                    if (depth == 0) {
                        rowNo++;
                        emit(rowNo, root, type, tooBig, mapper, paths, sink);
                        root = null;
                        current = null;
                    } else if (!tooBig) {
                        current = current.getParent();
                    }
                }
            }
        } finally {
            xml.close();
        }
        return rowNo;
    }

    private static void emit(long rowNo, XmlNode root, RecordType type, boolean tooBig, RecordMapper mapper,
                             Map<String, PathExpr> paths, RecordSink sink) {
        XmlContext context = new XmlContext(root, root, paths);
        if (tooBig) {
            sink.reject(rowNo, mapper.externalReferenceOf(context),
                "The <" + root.getName() + "> element is too large to be one record (more than "
                    + MAX_NODES_PER_RECORD + " elements or 5 million characters).");
            return;
        }
        Record record;
        try {
            record = mapper.map(context, type);
        } catch (MappingException e) {
            sink.reject(rowNo, mapper.externalReferenceOf(context), e.getMessage());
            return;
        }
        sink.accept(rowNo, record);
    }

    private static void copyAttributes(XMLStreamReader xml, XmlNode node) {
        for (int i = 0; i < xml.getAttributeCount(); i++) {
            node.setAttribute(xml.getAttributeLocalName(i), xml.getAttributeValue(i));
        }
    }

    /** First pass: reads the code lists named in LOOKUP rules into small maps (code to name). */
    static Map<String, Map<String, String>> collectLookups(InputStreamSource file, MappingProfile profile) throws IOException {
        List<LookupRule> rules = new ArrayList<>();
        for (MappingRule rule : profile.getRules()) {
            if (rule.getKind() == RuleKind.LOOKUP) {
                rules.add(new LookupRule(rule));
            }
        }
        Map<String, Map<String, String>> lookups = new HashMap<>();
        if (rules.isEmpty()) {
            return lookups;
        }
        for (LookupRule rule : rules) {
            lookups.put(rule.name, new HashMap<>());
        }
        try (InputStream in = new BufferedInputStream(file.getInputStream())) {
            XMLStreamReader xml = XmlFactory.open(in);
            try {
                collect(xml, rules, lookups);
            } finally {
                xml.close();
            }
        } catch (XMLStreamException e) {
            throw new FileFormatException(XmlFactory.describe(e), e);
        }
        return lookups;
    }

    private static void collect(XMLStreamReader xml, List<LookupRule> rules, Map<String, Map<String, String>> lookups)
        throws XMLStreamException {
        List<String> stack = new ArrayList<>();
        XmlNode root = null;
        XmlNode current = null;
        LookupRule active = null;
        int depth = 0;
        Map<String, PathExpr> paths = new HashMap<>();
        while (xml.hasNext()) {
            int event = xml.next();
            if (event == XMLStreamConstants.START_ELEMENT) {
                String name = xml.getLocalName();
                stack.add(name.toLowerCase(Locale.ROOT));
                if (root == null) {
                    for (LookupRule rule : rules) {
                        if (rule.matches(stack)) {
                            active = rule;
                            root = new XmlNode(name, null);
                            current = root;
                            copyAttributes(xml, root);
                            depth = 1;
                            break;
                        }
                    }
                } else if (depth < 50) {
                    depth++;
                    current = current.addChild(name);
                    copyAttributes(xml, current);
                } else {
                    depth++;
                }
            } else if (root != null && (event == XMLStreamConstants.CHARACTERS || event == XMLStreamConstants.CDATA)) {
                current.appendText(xml.getText());
            } else if (event == XMLStreamConstants.END_ELEMENT) {
                stack.remove(stack.size() - 1);
                if (root != null) {
                    depth--;
                    if (depth == 0) {
                        active.store(root, paths, lookups.get(active.name));
                        root = null;
                        current = null;
                        active = null;
                    } else if (depth < 50) {
                        current = current.getParent();
                    }
                }
            }
        }
    }

    private static String localName(String name) {
        String n = name.trim();
        int colon = n.indexOf(':');
        return (colon >= 0 ? n.substring(colon + 1) : n).toLowerCase(Locale.ROOT);
    }

    private static String elementList(Map<String, RecordType> elements) {
        StringBuilder sb = new StringBuilder();
        for (String element : elements.keySet()) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append('<').append(element).append('>');
        }
        return sb.toString();
    }

    /** One LOOKUP rule: element path suffix, key and value paths. */
    private static final class LookupRule {
        private final String name;
        private final List<String> suffix;
        private final String keyPath;
        private final String valuePath;

        LookupRule(MappingRule rule) {
            this.name = rule.getTarget().trim().toUpperCase(Locale.ROOT);
            List<String> steps = new ArrayList<>();
            for (String step : Arrays.asList(rule.getSource().trim().split("/"))) {
                if (!step.trim().isEmpty()) {
                    steps.add(localName(step));
                }
            }
            this.suffix = steps;
            Map<String, String> param = RecordMapper.parseValueMap(rule.getParam());
            this.keyPath = param.containsKey("key") ? param.get("key") : "@code";
            this.valuePath = param.containsKey("value") ? param.get("value") : "@name";
        }

        boolean matches(List<String> stack) {
            if (suffix.isEmpty() || stack.size() < suffix.size()) {
                return false;
            }
            int offset = stack.size() - suffix.size();
            for (int i = 0; i < suffix.size(); i++) {
                if (!suffix.get(i).equals(stack.get(offset + i))) {
                    return false;
                }
            }
            return true;
        }

        void store(XmlNode node, Map<String, PathExpr> paths, Map<String, String> into) {
            List<String> keys = path(paths, keyPath).values(node, node);
            List<String> values = path(paths, valuePath).values(node, node);
            if (keys.isEmpty() || values.isEmpty()) {
                return;
            }
            if (into.size() >= MAX_LOOKUP_ENTRIES) {
                LOG.warn("Lookup {} has more than {} entries; the rest is ignored", name, MAX_LOOKUP_ENTRIES);
                return;
            }
            into.put(keys.get(0).toLowerCase(Locale.ROOT), values.get(0));
        }

        private static PathExpr path(Map<String, PathExpr> paths, String text) {
            return paths.computeIfAbsent(text, PathExpr::parse);
        }
    }
}
