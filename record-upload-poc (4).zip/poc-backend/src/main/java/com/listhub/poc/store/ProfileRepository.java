package com.listhub.poc.store;

import com.listhub.poc.parse.FileFormat;
import com.listhub.poc.parse.MappingProfile;
import com.listhub.poc.parse.MappingRule;
import com.listhub.poc.parse.RuleKind;
import com.listhub.poc.parse.Transform;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.Instant;
import java.util.List;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

/** Mapping profiles and their lines. */
@Repository
public class ProfileRepository {

    private final NamedParameterJdbcTemplate jdbc;

    public ProfileRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<ProfileSummary> findAll() {
        return jdbc.query("SELECT p.profile_id, p.profile_name, p.file_format, p.updated_at,"
                + " (SELECT COUNT(*) FROM poc_mapping_rule r WHERE r.profile_id = p.profile_id) AS rule_count"
                + " FROM poc_mapping_profile p ORDER BY p.file_format, p.profile_name",
            (rs, n) -> {
                ProfileSummary s = new ProfileSummary();
                s.setId(rs.getLong("profile_id"));
                s.setName(rs.getString("profile_name"));
                s.setFormat(rs.getString("file_format"));
                s.setRuleCount(rs.getInt("rule_count"));
                Timestamp updated = rs.getTimestamp("updated_at");
                s.setUpdatedAt(updated == null ? null : updated.toInstant());
                return s;
            });
    }

    public MappingProfile findById(long id) {
        MapSqlParameterSource p = new MapSqlParameterSource("id", id);
        List<MappingProfile> found = jdbc.query("SELECT profile_id, profile_name, file_format, encoding, delimiter"
                + " FROM poc_mapping_profile WHERE profile_id = :id", p,
            (rs, n) -> {
                MappingProfile profile = new MappingProfile();
                profile.setId(rs.getLong("profile_id"));
                profile.setName(rs.getString("profile_name"));
                profile.setFormat(FileFormat.valueOf(rs.getString("file_format")));
                profile.setEncoding(rs.getString("encoding"));
                profile.setDelimiter(rs.getString("delimiter"));
                return profile;
            });
        if (found.isEmpty()) {
            return null;
        }
        MappingProfile profile = found.get(0);
        profile.setRules(jdbc.query("SELECT rule_kind, target, source, transform, param FROM poc_mapping_rule"
                + " WHERE profile_id = :id ORDER BY seq_no", p,
            (rs, n) -> new MappingRule(RuleKind.valueOf(rs.getString("rule_kind")), rs.getString("target"),
                rs.getString("source"), Transform.valueOf(rs.getString("transform")), rs.getString("param"))));
        return profile;
    }

    public Long findIdByName(String name) {
        List<Long> ids = jdbc.queryForList("SELECT profile_id FROM poc_mapping_profile WHERE UPPER(profile_name) = UPPER(:name)",
            new MapSqlParameterSource("name", name.trim()), Long.class);
        return ids.isEmpty() ? null : ids.get(0);
    }

    /** Creates the profile, or replaces it (header and every line) when it has an id. */
    public long save(MappingProfile profile) {
        Timestamp now = Timestamp.from(Instant.now());
        long id;
        MapSqlParameterSource header = new MapSqlParameterSource()
            .addValue("name", profile.getName().trim(), Types.VARCHAR)
            .addValue("format", profile.getFormat().name(), Types.VARCHAR)
            .addValue("encoding", blankToNull(profile.getEncoding()), Types.VARCHAR)
            .addValue("delimiter", profile.getDelimiter() == null || profile.getDelimiter().isEmpty()
                ? null : profile.getDelimiter(), Types.VARCHAR)
            .addValue("now", now, Types.TIMESTAMP);
        if (profile.getId() == null) {
            Long next = jdbc.getJdbcTemplate().queryForObject("SELECT poc_profile_seq.NEXTVAL FROM dual", Long.class);
            if (next == null) {
                throw new IllegalStateException("Sequence poc_profile_seq returned no value");
            }
            id = next;
            jdbc.update("INSERT INTO poc_mapping_profile (profile_id, profile_name, file_format, encoding, delimiter,"
                + " created_at, updated_at) VALUES (:id, :name, :format, :encoding, :delimiter, :now, :now)", header.addValue("id", id));
        } else {
            id = profile.getId();
            jdbc.update("UPDATE poc_mapping_profile SET profile_name = :name, file_format = :format, encoding = :encoding,"
                + " delimiter = :delimiter, updated_at = :now WHERE profile_id = :id", header.addValue("id", id));
            jdbc.update("DELETE FROM poc_mapping_rule WHERE profile_id = :id", new MapSqlParameterSource("id", id));
        }
        List<MappingRule> rules = profile.getRules();
        SqlParameterSource[] params = new SqlParameterSource[rules.size()];
        for (int i = 0; i < rules.size(); i++) {
            MappingRule r = rules.get(i);
            params[i] = new MapSqlParameterSource()
                .addValue("id", id)
                .addValue("seq", i + 1)
                .addValue("kind", r.getKind().name(), Types.VARCHAR)
                .addValue("target", blankToNull(r.getTarget()), Types.VARCHAR)
                .addValue("source", blankToNull(r.getSource()), Types.VARCHAR)
                .addValue("transform", (r.getTransform() == null ? Transform.NONE : r.getTransform()).name(), Types.VARCHAR)
                .addValue("param", r.getParam() == null || r.getParam().isEmpty() ? null : r.getParam(), Types.VARCHAR);
        }
        jdbc.batchUpdate("INSERT INTO poc_mapping_rule (profile_id, seq_no, rule_kind, target, source, transform, param)"
            + " VALUES (:id, :seq, :kind, :target, :source, :transform, :param)", params);
        return id;
    }

    public boolean exists(long id) {
        Long n = jdbc.queryForObject("SELECT COUNT(*) FROM poc_mapping_profile WHERE profile_id = :id",
            new MapSqlParameterSource("id", id), Long.class);
        return n != null && n > 0;
    }

    private static String blankToNull(String value) {
        return value == null || value.trim().isEmpty() ? null : value.trim();
    }
}
