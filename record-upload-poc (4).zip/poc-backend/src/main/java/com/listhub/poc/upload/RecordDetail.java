package com.listhub.poc.upload;

import com.listhub.poc.record.Record;

/** One canonical record exactly as stored, with every field (null when the file gave no value). */
public class RecordDetail {

    private final long uploadId;
    private final long rowNo;
    private final Record record;

    public RecordDetail(long uploadId, long rowNo, Record record) {
        this.uploadId = uploadId;
        this.rowNo = rowNo;
        this.record = record;
    }

    public long getUploadId() {
        return uploadId;
    }

    public long getRowNo() {
        return rowNo;
    }

    public Record getRecord() {
        return record;
    }
}
