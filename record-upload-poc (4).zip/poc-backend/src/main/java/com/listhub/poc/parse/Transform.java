package com.listhub.poc.parse;

/** Fixed list of value transformations a mapping can apply. No scripts or expressions from users. */
public enum Transform {
    NONE("As is"),
    UPPER("Upper case"),
    LOWER("Lower case"),
    VALUE_MAP("Value map (param: from=to;from=to;*=other)"),
    DATE("Date to partial ISO (param: patterns, e.g. dd/MM/yyyy|yyyy)"),
    DATE_PARTS("Year + month + day to partial ISO"),
    SPLIT("Split into several values (param: separator)"),
    LOOKUP("Code to name from a lookup (param: lookup name)"),
    DEFAULT("Default when empty (param: value)"),
    CONSTANT("Fixed value (param: value)");

    private final String label;

    Transform(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
