package com.listhub.poc.parse;

import java.util.ArrayList;
import java.util.List;

/**
 * How one provider's files map into the canonical record. Saved in the database and chosen at
 * upload time, so a new file layout needs a new profile, not new code.
 */
public class MappingProfile {

    private Long id;
    private String name;
    private FileFormat format;
    /** Character set of CSV files (UTF-8, windows-1252, ISO-8859-1). XML files declare their own. */
    private String encoding = "UTF-8";
    /** CSV delimiter; empty means detect it from the header line. */
    private String delimiter;
    private List<MappingRule> rules = new ArrayList<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public FileFormat getFormat() {
        return format;
    }

    public void setFormat(FileFormat format) {
        this.format = format;
    }

    public String getEncoding() {
        return encoding;
    }

    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    public String getDelimiter() {
        return delimiter;
    }

    public void setDelimiter(String delimiter) {
        this.delimiter = delimiter;
    }

    public List<MappingRule> getRules() {
        return rules;
    }

    public void setRules(List<MappingRule> rules) {
        this.rules = rules;
    }
}
