package com.listhub.poc.store;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.listhub.poc.parse.MappingProfile;
import com.listhub.poc.parse.ProfileValidator;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

/**
 * Adds the ready-made mapping profiles (Dow Jones XML, sample CSV) at start-up when no profile of
 * that name exists yet. Profiles already in the database, including edited ones, are never changed.
 */
@Component
public class ProfileSeeder implements ApplicationRunner {

    private static final Logger LOG = LoggerFactory.getLogger(ProfileSeeder.class);
    private static final List<String> BUILT_IN = Arrays.asList(
        "profiles/dowjones-sanctions-xml.json", "profiles/sample-csv.json");

    private final ProfileRepository profiles;
    private final ObjectMapper json;

    public ProfileSeeder(ProfileRepository profiles, ObjectMapper json) {
        this.profiles = profiles;
        this.json = json;
    }

    @Override
    public void run(ApplicationArguments args) throws IOException {
        for (String resource : BUILT_IN) {
            MappingProfile profile;
            try (InputStream in = new ClassPathResource(resource).getInputStream()) {
                profile = json.readValue(in, MappingProfile.class);
            }
            List<String> problems = ProfileValidator.problems(profile);
            if (!problems.isEmpty()) {
                LOG.error("Built-in profile {} is not valid: {}", resource, problems);
                continue;
            }
            if (profiles.findIdByName(profile.getName()) == null) {
                profile.setId(null);
                profiles.save(profile);
                LOG.info("Added built-in mapping profile '{}'", profile.getName());
            }
        }
    }
}
