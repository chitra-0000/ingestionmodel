package com.listhub.poc.parse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * One XML element of the record being read. Only one record's elements are held in memory at a
 * time; names are compared without regard to case or namespace prefix.
 */
public final class XmlNode {

    private final String name;
    private final String key;
    private final XmlNode parent;
    private final Map<String, String> attributes = new HashMap<>();
    private final Map<String, String> originalNames = new java.util.LinkedHashMap<>();
    private final StringBuilder text = new StringBuilder();
    private List<XmlNode> children = Collections.emptyList();

    public XmlNode(String name, XmlNode parent) {
        this.name = name;
        this.key = name.toLowerCase(Locale.ROOT);
        this.parent = parent;
    }

    public XmlNode addChild(String childName) {
        if (children.isEmpty()) {
            children = new ArrayList<>(4);
        }
        XmlNode child = new XmlNode(childName, this);
        children.add(child);
        return child;
    }

    public void setAttribute(String attributeName, String value) {
        String lower = attributeName.toLowerCase(Locale.ROOT);
        attributes.put(lower, value);
        originalNames.put(lower, attributeName);
    }

    public void appendText(String chunk) {
        text.append(chunk);
    }

    public String getName() {
        return name;
    }

    /** Name in lower case, for matching. */
    String key() {
        return key;
    }

    public XmlNode getParent() {
        return parent;
    }

    public List<XmlNode> getChildren() {
        return children;
    }

    public String attribute(String attributeName) {
        return attributes.get(attributeName.toLowerCase(Locale.ROOT));
    }

    /** Attributes with their names as written in the file. */
    public Map<String, String> getAttributes() {
        Map<String, String> byName = new java.util.LinkedHashMap<>();
        for (Map.Entry<String, String> e : originalNames.entrySet()) {
            byName.put(e.getValue(), attributes.get(e.getKey()));
        }
        return byName;
    }

    /** The element's own text, trimmed. */
    public String text() {
        return text.toString().trim();
    }
}
