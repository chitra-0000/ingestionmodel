package com.listhub.poc.parse;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.listhub.poc.record.Record;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.ByteArrayResource;

/** External entities and entity expansion are never processed. */
class XmlSecurityTest {

    private static MappingProfile profile() {
        MappingProfile profile = new MappingProfile();
        profile.setName("t");
        profile.setFormat(FileFormat.XML);
        profile.getRules().add(new MappingRule(RuleKind.RECORD, "INDIVIDUAL", "Person", Transform.NONE, null));
        profile.getRules().add(new MappingRule(RuleKind.FIELD, "externalReference", "@id", Transform.NONE, null));
        profile.getRules().add(new MappingRule(RuleKind.FIELD, "name", "Name", Transform.NONE, null));
        return profile;
    }

    @Test
    void doesNotResolveExternalEntities() {
        String xml = "<?xml version=\"1.0\"?><!DOCTYPE r [<!ENTITY x SYSTEM \"file:///etc/passwd\">]>"
            + "<r><Person id=\"1\"><Name>&x;</Name></Person></r>";
        List<Record> loaded = new ArrayList<>();
        try {
            new XmlRecordReader().read(new ByteArrayResource(xml.getBytes(StandardCharsets.UTF_8)), profile(), sink(loaded));
        } catch (FileFormatException | java.io.IOException e) {
            assertThat(loaded).isEmpty();
            return;
        }
        assertThat(loaded).allSatisfy(r -> assertThat(String.valueOf(r.getName())).doesNotContain("root:"));
    }

    @Test
    void reportsBrokenXmlWithTheLine() {
        String xml = "<r>\n<Person id=\"1\"><Name>A</Person></r>";
        assertThatThrownBy(() -> new XmlRecordReader().read(new ByteArrayResource(xml.getBytes(StandardCharsets.UTF_8)),
            profile(), sink(new ArrayList<>())))
            .isInstanceOf(FileFormatException.class).hasMessageContaining("line 2");
    }

    private static RecordSink sink(List<Record> loaded) {
        return new RecordSink() {
            @Override
            public void accept(long rowNo, Record record) {
                loaded.add(record);
            }

            @Override
            public void reject(long rowNo, String externalReference, String reason) {
                // not needed
            }
        };
    }
}
