package com.listhub.poc.parse;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.Arrays;
import org.junit.jupiter.api.Test;

class PathExprTest {

    private static XmlNode person() {
        XmlNode person = new XmlNode("Person", null);
        person.setAttribute("id", "42");
        XmlNode names = person.addChild("NameDetails");
        XmlNode primary = names.addChild("Name");
        primary.setAttribute("NameType", "Primary Name");
        primary.addChild("NameValue").addChild("Surname").appendText(" DOE ");
        XmlNode aka = names.addChild("Name");
        aka.setAttribute("NameType", "Also Known As");
        aka.addChild("NameValue").addChild("Surname").appendText("DOH");
        return person;
    }

    @Test
    void readsElementTextAttributesAndFilters() {
        XmlNode p = person();
        assertThat(PathExpr.parse("@ID").values(p, p)).containsExactly("42");
        assertThat(PathExpr.parse("NameDetails/Name/NameValue/Surname").values(p, p)).containsExactly("DOE", "DOH");
        assertThat(PathExpr.parse("namedetails/name[@nametype='primary name']/NameValue/Surname").values(p, p))
            .containsExactly("DOE");
        assertThat(PathExpr.parse("NameDetails/Name[@NameType!='Primary Name']/NameValue/Surname").values(p, p))
            .containsExactly("DOH");
    }

    @Test
    void navigatesFromAnItemToItsParentAndToTheRecord() {
        XmlNode p = person();
        XmlNode value = PathExpr.parse("NameDetails/Name/NameValue").select(p, p).get(1);
        assertThat(PathExpr.parse("../@NameType").values(value, p)).containsExactly("Also Known As");
        assertThat(PathExpr.parse("/@id").values(value, p)).containsExactly("42");
        assertThat(PathExpr.parse("Surname").values(value, p)).containsExactly("DOH");
    }

    @Test
    void explainsWhyAPathIsNotValid() {
        for (String bad : Arrays.asList("A//B", "@x/B", "A[@x='1'", "A[x='1']", "A[@x=1]", "1A")) {
            assertThatThrownBy(() -> PathExpr.parse(bad)).isInstanceOf(IllegalArgumentException.class);
        }
    }
}
