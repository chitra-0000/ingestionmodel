package com.listhub.poc.parse;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class ProfileValidatorTest {

    @Test
    void describesEveryProblem() {
        MappingProfile p = new MappingProfile();
        p.setName("x");
        p.setFormat(FileFormat.XML);
        p.getRules().add(new MappingRule(RuleKind.FIELD, "aliases.nickname", "A", Transform.NONE, null));
        p.getRules().add(new MappingRule(RuleKind.FIELD, "name", "A[@b=1]", Transform.NONE, null));
        p.getRules().add(new MappingRule(RuleKind.FIELD, "sanctionReferences.listName", ".", Transform.LOOKUP, "LISTS"));
        assertThat(ProfileValidator.problems(p))
            .anySatisfy(m -> assertThat(m).contains("'aliases.nickname' is not a field"))
            .anySatisfy(m -> assertThat(m).contains("must be in quotes"))
            .anySatisfy(m -> assertThat(m).contains("no LOOKUP line named LISTS"))
            .anySatisfy(m -> assertThat(m).contains("Add at least one RECORD line"));
    }
}
