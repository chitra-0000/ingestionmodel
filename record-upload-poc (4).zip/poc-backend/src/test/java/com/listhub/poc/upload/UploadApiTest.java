package com.listhub.poc.upload;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.nullValue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.util.StreamUtils;

/**
 * Whole flow on H2 in Oracle mode: Liquibase schema, built-in profiles, mapping into the
 * canonical record, child tables, read-back, rejects, duplicates, profile creation, inspection.
 */
@SpringBootTest(properties = {
    "spring.datasource.url=jdbc:h2:mem:poc;MODE=Oracle;DEFAULT_NULL_ORDERING=HIGH;DB_CLOSE_DELAY=-1",
    "spring.datasource.username=sa",
    "spring.datasource.password=",
    "poc.upload.batch-size=2"})
@AutoConfigureMockMvc
@DirtiesContext
class UploadApiTest {

    @Autowired
    private MockMvc mvc;

    @Test
    void mapsTheDowJonesSampleIntoTheCanonicalRecordAndRefusesItTheSecondTime() throws Exception {
        long profileId = profileId("Dow Jones sanctions XML");
        String body = mvc.perform(multipart("/api/uploads").file(sample("dowjones-sample.xml", "application/xml"))
                .param("profileId", String.valueOf(profileId)))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.upload.status").value("COMPLETED"))
            .andExpect(jsonPath("$.upload.profileName").value("Dow Jones sanctions XML"))
            .andExpect(jsonPath("$.upload.recordsRead").value(8))
            .andExpect(jsonPath("$.upload.recordsLoaded").value(6))
            .andExpect(jsonPath("$.upload.recordsRejected").value(2))
            .andExpect(jsonPath("$.rejects[0].reason", containsString("externalReference is missing")))
            .andExpect(jsonPath("$.rejects[1].reason").value("datesDetails.month: '13' is not a month (1 to 12)."))
            .andReturn().getResponse().getContentAsString();
        long uploadId = Long.parseLong(body.replaceAll("(?s).*\"uploadId\":(\\d+).*", "$1"));

        mvc.perform(get("/api/uploads/" + uploadId + "/records"))
            .andExpect(jsonPath("$.total").value(6))
            .andExpect(jsonPath("$.items[0].name").value("Viktor Pavel ORLANDO"))
            .andExpect(jsonPath("$.items[0].aliases[0]").value("Victor ORLANDOV"))
            .andExpect(jsonPath("$.items[1].dates[0]").value("1978 (Date of Birth)"));

        mvc.perform(get("/api/uploads/" + uploadId + "/records/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.record.type").value("INDIVIDUAL"))
            .andExpect(jsonPath("$.record.externalReference").value("900101"))
            .andExpect(jsonPath("$.record.title").value("Mr"))
            .andExpect(jsonPath("$.record.deceased").value(false))
            .andExpect(jsonPath("$.record.description").value(nullValue()))
            .andExpect(jsonPath("$.record.categories[0].label").value("Sanctions Lists"))
            .andExpect(jsonPath("$.record.sanctionTypes[0].label").value("Asset freeze"))
            .andExpect(jsonPath("$.record.pepOccupationCategories[0].label").value("State-Owned Enterprises"))
            .andExpect(jsonPath("$.record.aliases[1].aliasQuality").value("L"))
            .andExpect(jsonPath("$.record.sanctionReferences[0].listName").value("OFAC - Specially Designated Nationals (SDN)"))
            .andExpect(jsonPath("$.record.sanctionReferences[0].sinceDate").value("2022-02-02"))
            .andExpect(jsonPath("$.record.datesDetails[0].dateValue").value("1965-03-12"))
            .andExpect(jsonPath("$.record.datesDetails[1].birthPlace").value("Port Elara"))
            .andExpect(jsonPath("$.record.countriesDetails[0].countryName").value("Zedland (fictional)"))
            .andExpect(jsonPath("$.record.identityDocuments[0].number").value("ZZ1234567"))
            .andExpect(jsonPath("$.record.addresses[0].country").value("Zedland (fictional)"))
            .andExpect(jsonPath("$.record.recordDJ.activeStatus").value("Active"))
            .andExpect(jsonPath("$.record.versionLinks.fromVersion").value(uploadId));

        mvc.perform(get("/api/uploads/" + uploadId + "/records/4"))
            .andExpect(jsonPath("$.record.type").value("ENTITY"))
            .andExpect(jsonPath("$.record.bicCodes[0]").value("NWMTZZ22"))
            .andExpect(jsonPath("$.record.addresses.length()").value(2));

        mvc.perform(get("/api/uploads/" + uploadId + "/records/6"))
            .andExpect(jsonPath("$.record.type").value("VESSEL"))
            .andExpect(jsonPath("$.record.imoCode").value("9912345"))
            .andExpect(jsonPath("$.record.callSign").value("ZZSF7"));

        mvc.perform(get("/api/uploads/" + uploadId + "/records").param("search", "harbour"))
            .andExpect(jsonPath("$.total").value(1))
            .andExpect(jsonPath("$.items[0].type").value("ENTITY"));

        mvc.perform(multipart("/api/uploads").file(sample("dowjones-sample.xml", "application/xml"))
                .param("profileId", String.valueOf(profileId)))
            .andExpect(status().isConflict())
            .andExpect(jsonPath("$.message", containsString("already loaded with this profile as upload #" + uploadId)));
    }

    @Test
    void loadsTheCsvSampleWithItsProfile() throws Exception {
        mvc.perform(multipart("/api/uploads").file(sample("sanctions-sample.csv", "text/csv"))
                .param("profileId", String.valueOf(profileId("Sample sanctions CSV"))))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.upload.recordsLoaded").value(5))
            .andExpect(jsonPath("$.upload.recordsRejected").value(2));
    }

    @Test
    void createsAProfileForANewCsvLayoutAndGroupsRowsOfTheSameRecord() throws Exception {
        String profile = "{\"name\":\"Generic export test\",\"format\":\"CSV\",\"rules\":["
            + "{\"kind\":\"RECORD\",\"target\":\"INDIVIDUAL\"},"
            + "{\"kind\":\"GROUP_BY\",\"source\":\"Ref\"},"
            + "{\"kind\":\"FIELD\",\"target\":\"type\",\"source\":\"Kind\",\"transform\":\"VALUE_MAP\",\"param\":\"P=INDIVIDUAL;C=ENTITY\"},"
            + "{\"kind\":\"FIELD\",\"target\":\"externalReference\",\"source\":\"Ref\"},"
            + "{\"kind\":\"FIELD\",\"target\":\"name\",\"source\":\"Full Name\"},"
            + "{\"kind\":\"FIELD\",\"target\":\"aliases.name\",\"source\":\"AKA\"}]}";
        String saved = mvc.perform(post("/api/mapping/profiles").contentType(MediaType.APPLICATION_JSON).content(profile))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.rules.length()").value(6))
            .andReturn().getResponse().getContentAsString();
        long id = Long.parseLong(saved.replaceAll("(?s)^\\{\"id\":(\\d+).*", "$1"));

        MockMultipartFile csv = new MockMultipartFile("file", "export.csv", "text/csv",
            ("Ref;Kind;Full Name;AKA\nR1;P;Ann SMITH;Annie Smith\nR1;P;Ann SMITH;A. Smith\nR2;C;Acme Ltd;\n")
                .getBytes(StandardCharsets.UTF_8));
        String body = mvc.perform(multipart("/api/uploads").file(csv).param("profileId", String.valueOf(id)))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.upload.recordsLoaded").value(2))
            .andReturn().getResponse().getContentAsString();
        long uploadId = Long.parseLong(body.replaceAll("(?s).*\"uploadId\":(\\d+).*", "$1"));
        mvc.perform(get("/api/uploads/" + uploadId + "/records/1"))
            .andExpect(jsonPath("$.record.aliases.length()").value(2))
            .andExpect(jsonPath("$.record.aliases[1].name").value("A. Smith"));
        mvc.perform(get("/api/uploads/" + uploadId + "/records/3"))
            .andExpect(jsonPath("$.record.type").value("ENTITY"));

        mvc.perform(post("/api/mapping/profiles").contentType(MediaType.APPLICATION_JSON).content(profile))
            .andExpect(status().isConflict());
    }

    @Test
    void refusesAProfileWithAnUnknownField() throws Exception {
        mvc.perform(post("/api/mapping/profiles").contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Bad\",\"format\":\"CSV\",\"rules\":[{\"kind\":\"RECORD\",\"target\":\"INDIVIDUAL\"},"
                    + "{\"kind\":\"FIELD\",\"target\":\"salary\",\"source\":\"x\"}]}"))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.message", containsString("'salary' is not a field of the canonical record")));
    }

    @Test
    void tellsWhichColumnsAreMissingWhenTheProfileDoesNotFitTheFile() throws Exception {
        MockMultipartFile csv = new MockMultipartFile("file", "other.csv", "text/csv",
            "id;label\n1;x\n".getBytes(StandardCharsets.UTF_8));
        mvc.perform(multipart("/api/uploads").file(csv).param("profileId", String.valueOf(profileId("Sample sanctions CSV"))))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.upload.status").value("FAILED"))
            .andExpect(jsonPath("$.upload.message", containsString("'external_id' (for externalReference)")))
            .andExpect(jsonPath("$.upload.message", containsString("Columns in the file: id, label")));
    }

    @Test
    void inspectsAnXmlFile() throws Exception {
        mvc.perform(multipart("/api/mapping/inspect").file(sample("dowjones-sample.xml", "application/xml")))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.recordElements[0].name").value("Person"))
            .andExpect(jsonPath("$.recordElements[0].selected").value(true))
            .andExpect(jsonPath("$.fields[?(@.path == 'NameDetails/Name/@NameType')]").exists());
    }

    @Test
    void refusesAFileOfAnotherFormatThanTheProfile() throws Exception {
        mvc.perform(multipart("/api/uploads").file(sample("sanctions-sample.csv", "text/csv"))
                .param("profileId", String.valueOf(profileId("Dow Jones sanctions XML"))))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.message", containsString("is for XML files")));
    }

    @Test
    void refusesOtherFileTypes() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "list.pdf", "application/pdf", new byte[] {1, 2, 3});
        mvc.perform(multipart("/api/uploads").file(file).param("profileId", "1"))
            .andExpect(status().isBadRequest());
    }

    @Test
    void answersNotFoundForAnUnknownUpload() throws Exception {
        mvc.perform(get("/api/uploads/999999/records"))
            .andExpect(status().isNotFound())
            .andExpect(jsonPath("$.message").value("Upload #999999 does not exist."));
    }

    private long profileId(String name) throws Exception {
        String list = mvc.perform(get("/api/mapping/profiles")).andReturn().getResponse().getContentAsString();
        int at = list.indexOf("\"name\":\"" + name + "\"");
        String before = list.substring(0, at);
        return Long.parseLong(before.substring(before.lastIndexOf("\"id\":") + 5, before.lastIndexOf(',')));
    }

    private static MockMultipartFile sample(String name, String contentType) throws IOException {
        try (InputStream in = UploadApiTest.class.getResourceAsStream("/samples/" + name)) {
            return new MockMultipartFile("file", name, contentType, StreamUtils.copyToByteArray(in));
        }
    }
}
