package com.listhub.poc.parse;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.listhub.poc.record.MappingException;
import com.listhub.poc.record.Values;
import java.util.Arrays;
import org.junit.jupiter.api.Test;

class ValuesTest {

    @Test
    void buildsPartialDatesFromParts() {
        assertThat(Values.partialDate("d", "1965", "Mar", "12")).isEqualTo("1965-03-12");
        assertThat(Values.partialDate("d", "1981", "7", "")).isEqualTo("1981-07");
        assertThat(Values.partialDate("d", "1978", null, null)).isEqualTo("1978");
        assertThat(Values.partialDate("d", "", "", "")).isNull();
        assertThatThrownBy(() -> Values.partialDate("d", "2023", "Feb", "30")).isInstanceOf(MappingException.class)
            .hasMessageContaining("not a real date");
    }

    @Test
    void parsesDatesWithTheGivenPatternsOnly() {
        assertThat(Values.parseDate("d", "03/11/1958", Values.DEFAULT_DATE_PATTERNS)).isEqualTo("1958-11-03");
        assertThat(Values.parseDate("d", "12-Mar-1965", Values.DEFAULT_DATE_PATTERNS)).isEqualTo("1965-03-12");
        assertThat(Values.parseDate("d", "1969", Values.DEFAULT_DATE_PATTERNS)).isEqualTo("1969");
        assertThatThrownBy(() -> Values.parseDate("d", "1985-02-31", Arrays.asList("yyyy-MM-dd")))
            .isInstanceOf(MappingException.class);
    }

    @Test
    void normalisesNamesForMatching() {
        assertThat(Values.normalizeName("  José-María  O'Neill ")).isEqualTo("JOSE MARIA O NEILL");
    }
}
