# Record upload POC

A simple page to show the idea: **upload a Dow Jones XML or CSV file, and its records are read,
checked and saved to Oracle.** The page then shows the counts, the rejected rows with the reason,
the records read back from the database, and the upload history.

| Folder | What | Stack | Open with |
| --- | --- | --- | --- |
| `poc-backend` | REST API, file readers, database | Java 8, Spring Boot 2.7.18, Maven 3.8.6 (wrapper), Oracle 19 (ojdbc8), Liquibase | IntelliJ IDEA (open `pom.xml`) |
| `poc-frontend` | Upload page | Angular 11.2 (same versions as the Regliss UI project), Node 14 | VS Code |
| `samples` | Fictional Dow Jones XML and CSV files for the demo | | |
| `docs/oracle-setup.sql` | One-time user creation for the DBA | | |

## Frontend versions

The frontend uses exactly the package versions of the existing Regliss UI project (Angular ~11.2.4,
TypeScript ~4.1.5, rxjs ~6.6.0, zone.js ~0.10.3, Karma ~6.1, Jasmine ~3.6), so the bank's Artifactory
allows every package. No `package-lock.json` is shipped: `npm install` creates it from Artifactory.
npm 6 (bundled with Node 14) works; npm logs in to Artifactory through your user `.npmrc`.

## Run it

**Quickest demo (no Oracle needed):**

```powershell
powershell -ExecutionPolicy Bypass -File .\start-poc.ps1 -Demo
```

**Against Oracle 19:** ask the DBA to run `docs/oracle-setup.sql`, then:

```powershell
powershell -ExecutionPolicy Bypass -File .\start-poc.ps1 -DbUrl "jdbc:oracle:thin:@//host:1521/SERVICE" -DbUser LISTHUB_POC
```

The tables are created automatically at first start (Liquibase). The page opens at http://localhost:4200.

**From the IDEs:**

- **IntelliJ:** open `poc-backend/pom.xml` as a project with a Java 8 SDK. Run **PocApplication (H2 demo, no Oracle)** or **PocApplication (Oracle 19)**; fill in the Oracle values under Run > Edit Configurations.
- **VS Code:** open `poc-frontend`, run `npm install` once, then press **F5**.

## Demo script (3 minutes)

1. Upload `samples/dowjones-sample.xml`. Result: 8 read, 6 saved, 2 rejected with reasons (missing id, impossible month).
2. Show the records table: names, aliases, partial dates of birth (1978, 1981-07), nationality, sanctions list names from the file's reference list. Search for "harbour".
3. Upload `samples/sanctions-sample.csv`. Same table, different format: 5 saved, 2 rejected.
4. Upload the Dow Jones file again. It is refused: the same file content is never loaded twice.
5. Click a row in the upload history to show any earlier upload.

## What it shows (for the approval)

- Any format into one record model: XML and CSV land in the same tables and screen.
- Streaming readers: memory stays at one batch of records (500) whatever the file size.
- Records saved in JDBC batches; a file that fails part-way leaves no records behind.
- Quality checks with reasons; duplicate files refused by SHA-256 content hash.
- Secure by design: XML external entities and DOCTYPE refused, bind variables only, no passwords in files, file type and size checked, no stack traces to the browser.
- CSV column names are configuration (`poc.csv.columns.*` in `application.yml`), not code.

## Tests

```bash
cd poc-backend && ./mvnw verify          # 14 tests: readers, XXE refusal, full upload flow on H2 (Oracle mode)
cd poc-frontend && npm test              # 5 tests (Chrome headless)
```

## CSV format

Header row required; comma or semicolon. Columns (any order, any case):
`external_id` (required), `full_name` or `last_name` (required), `record_type` (PERSON/ENTITY/VESSEL),
`first_name`, `middle_name`, `gender`, `date_of_birth` (yyyy, yyyy-MM, yyyy-MM-dd or dd/MM/yyyy),
`nationality`, `sanctions_lists` and `aliases` (several values separated by `|`).

## API

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/api/uploads` (multipart `file`) | Upload and load a file |
| GET | `/api/uploads` | Recent uploads |
| GET | `/api/uploads/{id}/records?search=&page=&size=` | Records of an upload |
| GET | `/api/uploads/{id}/rejects` | Rejected rows |

Not in this POC (next steps): login and roles, list versions, validation and certification, publication to downstream systems.
