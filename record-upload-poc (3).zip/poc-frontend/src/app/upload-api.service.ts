import { HttpClient, HttpEvent, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RecordPage, RejectRow, UploadResult, UploadSummary } from './models';

/** Calls the backend upload API (proxied to http://localhost:8080 in development). */
@Injectable({ providedIn: 'root' })
export class UploadApiService {
  constructor(private readonly http: HttpClient) {}

  /** Uploads one file; emits progress events, then the result. */
  upload(file: File): Observable<HttpEvent<UploadResult>> {
    const form = new FormData();
    form.append('file', file, file.name);
    return this.http.post<UploadResult>('/api/uploads', form, {
      reportProgress: true,
      observe: 'events',
    });
  }

  recent(limit = 20): Observable<UploadSummary[]> {
    return this.http.get<UploadSummary[]>('/api/uploads', { params: new HttpParams().set('limit', String(limit)) });
  }

  records(uploadId: number, search: string, page: number, size: number): Observable<RecordPage> {
    let params = new HttpParams().set('page', String(page)).set('size', String(size));
    const text = search.trim();
    if (text) {
      params = params.set('search', text);
    }
    return this.http.get<RecordPage>(`/api/uploads/${uploadId}/records`, { params });
  }

  rejects(uploadId: number, limit = 200): Observable<RejectRow[]> {
    return this.http.get<RejectRow[]>(`/api/uploads/${uploadId}/rejects`, {
      params: new HttpParams().set('limit', String(limit)),
    });
  }
}
