export const environment = {
  production: true,
  /** Serve the built app behind the same reverse proxy as the backend. */
  apiBase: '/api'
};
