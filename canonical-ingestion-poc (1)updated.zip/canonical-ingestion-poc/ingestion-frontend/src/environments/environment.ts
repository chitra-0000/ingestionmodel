export const environment = {
  production: false,
  /** Same-origin through proxy.conf.json in development. */
  apiBase: '/api'
};
