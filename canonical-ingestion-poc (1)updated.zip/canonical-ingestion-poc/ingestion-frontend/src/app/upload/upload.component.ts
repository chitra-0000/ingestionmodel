import { Component, OnDestroy } from '@angular/core';
import { HttpErrorResponse, HttpEventType } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { ApiService } from '../core/api.service';
import { LoadRun } from '../core/models';

interface UploadItem {
  file: File;
  progress: number;
  state: 'waiting' | 'sending' | 'stored' | 'failed';
  load?: LoadRun;
  error?: string;
}

const MAX_FILES = 20;

/** One list per file; up to 20 files at once, sent one after another so progress stays readable. */
@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnDestroy {

  providerCode = '';
  uploadedBy = '';
  items: UploadItem[] = [];
  dragging = false;
  busy = false;
  formError = '';
  private sub?: Subscription;

  constructor(private api: ApiService) { }

  get providerValid(): boolean {
    return /^[A-Za-z][A-Za-z0-9_]{1,19}$/.test(this.providerCode.trim());
  }

  onPick(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.addFiles(input.files);
    input.value = '';
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    this.dragging = false;
    this.addFiles(event.dataTransfer ? event.dataTransfer.files : null);
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    this.dragging = true;
  }

  remove(item: UploadItem): void {
    this.items = this.items.filter(i => i !== item);
  }

  private addFiles(list: FileList | null): void {
    this.formError = '';
    if (!list) {
      return;
    }
    for (let i = 0; i < list.length; i++) {
      const f = list[i];
      if (!/\.(xml|csv|txt)$/i.test(f.name)) {
        this.formError = `${f.name} was skipped: only .xml, .csv and .txt files are accepted.`;
        continue;
      }
      if (this.items.length >= MAX_FILES) {
        this.formError = `Up to ${MAX_FILES} files can be uploaded at once.`;
        break;
      }
      this.items.push({ file: f, progress: 0, state: 'waiting' });
    }
  }

  start(): void {
    if (!this.providerValid) {
      this.formError = 'Enter a provider code: 2–20 letters, digits or underscores, starting with a letter.';
      return;
    }
    this.formError = '';
    this.busy = true;
    this.next();
  }

  private next(): void {
    const item = this.items.find(i => i.state === 'waiting');
    if (!item) {
      this.busy = false;
      return;
    }
    item.state = 'sending';
    this.sub = this.api.upload(item.file, this.providerCode.trim().toUpperCase(), this.uploadedBy.trim()).subscribe(
      ev => {
        if (ev.type === HttpEventType.UploadProgress && ev.total) {
          item.progress = Math.round(ev.loaded * 100 / ev.total);
        } else if (ev.type === HttpEventType.Response && ev.body) {
          item.state = 'stored';
          item.progress = 100;
          item.load = ev.body;
        }
      },
      (err: HttpErrorResponse) => {
        item.state = 'failed';
        item.error = ApiService.message(err);
        this.next();
      },
      () => this.next()
    );
  }

  get waiting(): number {
    return this.items.filter(i => i.state === 'waiting').length;
  }

  ngOnDestroy(): void {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }
}
