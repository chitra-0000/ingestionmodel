import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../core/api.service';
import { CanonicalField, FieldMapping, MappingDraft, MappingRequest, PathInfo, ValidationResult } from '../core/models';

interface Row {
  field: CanonicalField;
  mapping: FieldMapping;
}

/**
 * "Approved mapping exists? No" branch: review the suggested mapping, validate it against the stored
 * sample (compile + preview + DQ), then approve it as a new version.
 */
@Component({
  selector: 'app-mapping-review',
  templateUrl: './mapping-review.component.html',
  styleUrls: ['./mapping-review.component.css']
})
export class MappingReviewComponent implements OnInit {

  loadId = 0;
  draft?: MappingDraft;
  rows: Row[] = [];
  recordPath = '';
  customXslt = false;
  xslt = '';
  approvedBy = '';
  result?: ValidationResult;
  validatedSignature = '';
  busy = '';
  error = '';
  private paths: { [p: string]: PathInfo } = {};

  constructor(private route: ActivatedRoute, private router: Router, private api: ApiService) { }

  ngOnInit(): void {
    this.loadId = Number(this.route.snapshot.paramMap.get('id'));
    this.fetch();
  }

  fetch(recordPath?: string): void {
    this.busy = 'Reading the file structure…';
    this.error = '';
    this.result = undefined;
    this.api.draft(this.loadId, recordPath).subscribe(
      d => {
        this.draft = d;
        this.recordPath = d.recordPath;
        this.xslt = d.xslt;
        this.customXslt = false;
        this.paths = {};
        d.sourcePaths.forEach(p => this.paths[p.path] = p);
        this.rows = d.canonicalFields.map(f => ({
          field: f,
          mapping: Object.assign({}, d.fieldMappings.find(m => m.field === f.name)
            || { field: f.name, expression: '', multiValued: false, confidence: 0, matchedBy: 'NONE' })
        }));
        this.busy = '';
      },
      (err: HttpErrorResponse) => {
        this.busy = '';
        this.error = ApiService.message(err);
      }
    );
  }

  changeRecordPath(): void {
    if (this.draft && this.recordPath && this.recordPath !== this.draft.recordPath) {
      this.fetch(this.recordPath);
    }
  }

  /** Example values of the path the expression points at (when it is a plain path). */
  samples(expr: string): string[] {
    const parts = (expr || '').split('|').map(s => s.trim()).filter(s => !!s);
    const values: string[] = [];
    parts.forEach(p => {
      const info = this.paths[p];
      if (info) {
        info.samples.slice(0, 3).forEach(v => values.push(v));
      }
    });
    return values;
  }

  isRepeating(expr: string): boolean {
    const info = this.paths[(expr || '').trim()];
    return !!info && info.maxPerRecord > 1;
  }

  edited(row: Row): void {
    row.mapping.matchedBy = 'MANUAL';
    row.mapping.confidence = 100;
    this.result = undefined;
  }

  /** Advanced mode starts from the XSLT generated for the current field table. */
  toggleCustom(): void {
    this.customXslt = !this.customXslt;
    this.result = undefined;
  }

  confidenceTone(m: FieldMapping): string {
    if (!m.expression) {
      return '';
    }
    if (m.matchedBy === 'MANUAL' || m.matchedBy === 'PREVIOUS_VERSION' || m.confidence >= 85) {
      return 'ok';
    }
    return m.confidence >= 60 ? 'warn' : 'bad';
  }

  matchLabel(m: FieldMapping): string {
    if (!m.expression) {
      return 'Not mapped';
    }
    switch (m.matchedBy) {
      case 'MANUAL': return 'Edited';
      case 'PREVIOUS_VERSION': return 'From last version';
      case 'SYNONYM': return 'Name match';
      case 'RECORD_ELEMENT_NAME': return 'Element name';
      case 'COMPOSED': return 'Built from parts';
      default: return 'Similar name';
    }
  }

  private request(): MappingRequest {
    return {
      recordPath: this.recordPath,
      fieldMappings: this.rows.map(r => r.mapping),
      customXslt: this.customXslt,
      xslt: this.customXslt ? this.xslt : undefined,
      approvedBy: this.approvedBy.trim() || undefined
    };
  }

  private signature(): string {
    const r = this.request();
    return JSON.stringify([r.recordPath, r.fieldMappings, r.customXslt, r.xslt]);
  }

  get validatedAndUnchanged(): boolean {
    return !!this.result && this.result.valid && this.validatedSignature === this.signature();
  }

  validate(): void {
    this.busy = 'Compiling the mapping and running it on the sample…';
    this.error = '';
    const sig = this.signature();
    this.api.validate(this.loadId, this.request()).subscribe(
      r => {
        this.result = r;
        this.validatedSignature = sig;
        if (!this.customXslt) {
          this.xslt = r.xslt;
        }
        this.busy = '';
      },
      (err: HttpErrorResponse) => {
        this.busy = '';
        this.error = ApiService.message(err);
      }
    );
  }

  approve(): void {
    if (!this.approvedBy.trim()) {
      this.error = 'Enter your name to approve the mapping.';
      return;
    }
    this.busy = 'Saving the new mapping version and starting the load…';
    this.error = '';
    this.api.approve(this.loadId, this.request()).subscribe(
      () => this.router.navigate(['/loads', this.loadId]),
      (err: HttpErrorResponse) => {
        this.busy = '';
        if (err.status === 422 && err.error) {
          this.result = err.error as ValidationResult;
        }
        this.error = ApiService.message(err);
      }
    );
  }

  previewColumns(): string[] {
    return this.rows.map(r => r.field.name);
  }
}
