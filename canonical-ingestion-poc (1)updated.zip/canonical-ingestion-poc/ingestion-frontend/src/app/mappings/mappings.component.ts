import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ApiService } from '../core/api.service';
import { MappingDefinition } from '../core/models';

/** Registry of approved mapping versions; each is also saved as .xsl + .json in the mapping store folder. */
@Component({
  selector: 'app-mappings',
  template: `
    <div class="page">
      <div class="page-head">
        <div>
          <h1>Mappings</h1>
          <p>One active version per provider and format. Each version is also saved as an .xsl file in the
            mapping store folder, so the next environment can reuse it.</p>
        </div>
      </div>
      <div class="note bad" *ngIf="error">{{ error }}</div>
      <div class="panel flush">
        <div class="table-wrap">
          <table class="grid">
            <thead><tr><th>Provider</th><th class="num">Version</th><th>State</th><th>Record element</th>
              <th class="num">Fields mapped</th><th>Approved</th><th>Stored as</th><th></th></tr></thead>
            <tbody>
              <ng-container *ngFor="let m of mappings">
                <tr [class.retired]="m.status !== 'APPROVED'">
                  <td><strong>{{ m.providerCode }}</strong> <span class="chip">{{ m.format }}</span></td>
                  <td class="num">v{{ m.versionNo }}</td>
                  <td><span class="chip" [class.ok]="m.status === 'APPROVED'">{{ m.status === 'APPROVED' ? 'In use' : 'Replaced' }}</span></td>
                  <td class="mono">{{ m.recordPath }}</td>
                  <td class="num">{{ mapped(m) }} of {{ m.fieldMappings.length }}</td>
                  <td>{{ m.approvedBy }}<div class="sub">{{ m.approvedAt | date:'d MMM y, HH:mm' }}</div></td>
                  <td class="mono sub">{{ m.storePath }}</td>
                  <td class="actions">
                    <button class="btn small" (click)="toggle(m)" [attr.aria-expanded]="open === m.mappingId">Fields</button>
                    <a class="btn small" [href]="api.xsltUrl(m.mappingId)">Download .xsl</a>
                  </td>
                </tr>
                <tr *ngIf="open === m.mappingId" class="expand">
                  <td colspan="8">
                    <table class="inner">
                      <tr *ngFor="let f of m.fieldMappings"><td class="mono">{{ f.field }}</td>
                        <td class="mono">{{ f.expression || '–' }}<span class="muted" *ngIf="f.multiValued"> (all values)</span></td></tr>
                    </table>
                    <p class="muted sub">{{ m.knownPaths.length }} source fields known. Built by {{ m.generatedBy | lowercase }}.</p>
                  </td>
                </tr>
              </ng-container>
            </tbody>
          </table>
        </div>
        <div class="empty" *ngIf="loaded && !mappings.length">No mappings approved yet. They appear here after the first file of a
          provider is reviewed.</div>
      </div>
    </div>
  `,
  styles: [`
    .sub { font-size: .8rem; color: var(--muted); }
    .retired td { color: var(--muted); }
    .actions { white-space: nowrap; text-align: right; }
    .btn.small { padding: 3px 9px; font-size: .82rem; margin-left: 4px; }
    .expand td { background: var(--paper); }
    .inner td { padding: 2px 16px 2px 0; border: 0; font-size: .86rem; }
  `]
})
export class MappingsComponent implements OnInit {

  mappings: MappingDefinition[] = [];
  loaded = false;
  error = '';
  open?: number;

  constructor(public api: ApiService) { }

  ngOnInit(): void {
    this.api.mappings().subscribe(
      list => {
        this.mappings = list;
        this.loaded = true;
      },
      (err: HttpErrorResponse) => this.error = ApiService.message(err)
    );
  }

  mapped(m: MappingDefinition): number {
    return m.fieldMappings.filter(f => !!f.expression).length;
  }

  toggle(m: MappingDefinition): void {
    this.open = this.open === m.mappingId ? undefined : m.mappingId;
  }
}
