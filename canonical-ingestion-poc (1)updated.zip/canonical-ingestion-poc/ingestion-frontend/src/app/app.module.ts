import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { UploadComponent } from './upload/upload.component';
import { LoadsComponent } from './loads/loads.component';
import { LoadDetailComponent } from './load-detail/load-detail.component';
import { MappingReviewComponent } from './mapping-review/mapping-review.component';
import { MappingsComponent } from './mappings/mappings.component';
import { LedgerComponent } from './shared/ledger.component';
import { StatusBadgeComponent } from './shared/status-badge.component';
import { BytesPipe, CountPipe, DurationPipe, StatusLabelPipe } from './shared/format.pipes';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'loads' },
  { path: 'upload', component: UploadComponent },
  { path: 'loads', component: LoadsComponent },
  { path: 'loads/:id', component: LoadDetailComponent },
  { path: 'loads/:id/mapping', component: MappingReviewComponent },
  { path: 'mappings', component: MappingsComponent },
  { path: '**', redirectTo: 'loads' }
];

@NgModule({
  declarations: [
    AppComponent, UploadComponent, LoadsComponent, LoadDetailComponent, MappingReviewComponent, MappingsComponent,
    LedgerComponent, StatusBadgeComponent, CountPipe, DurationPipe, BytesPipe, StatusLabelPipe
  ],
  imports: [BrowserModule, HttpClientModule, FormsModule, RouterModule.forRoot(routes)],
  bootstrap: [AppComponent]
})
export class AppModule { }
