import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <header class="bar">
      <div class="inner">
        <a class="brand" routerLink="/loads">
          <img src="assets/favicon.svg" alt="" width="22" height="22">
          <span>List Ingestion</span>
        </a>
        <nav aria-label="Main">
          <a routerLink="/upload" routerLinkActive="on">Upload files</a>
          <a routerLink="/loads" routerLinkActive="on">Loads</a>
          <a routerLink="/mappings" routerLinkActive="on">Mappings</a>
        </nav>
      </div>
    </header>
    <main><router-outlet></router-outlet></main>
  `,
  styles: [`
    .bar { background: var(--ink); color: #fff; }
    .inner { max-width: 1240px; margin: 0 auto; padding: 0 24px; display: flex; align-items: center; gap: 28px;
             height: 54px; }
    .brand { display: flex; align-items: center; gap: 10px; color: #fff; text-decoration: none; font-weight: 650;
             font-size: 1.02rem; }
    nav { display: flex; gap: 4px; height: 100%; }
    nav a { color: #C9D2DF; text-decoration: none; padding: 0 12px; display: flex; align-items: center;
            border-bottom: 3px solid transparent; font-size: .93rem; }
    nav a:hover { color: #fff; }
    nav a.on { color: #fff; border-bottom-color: #9FD3B4; }
    @media (max-width: 640px) { .inner { padding: 0 12px; gap: 10px; } .brand span { display: none; }
                                nav a { padding: 0 8px; } }
  `]
})
export class AppComponent { }
