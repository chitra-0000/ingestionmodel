import { Component, OnDestroy, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { Subscription, timer } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { ApiService } from '../core/api.service';
import { LoadRun, RUNNING } from '../core/models';

/** Load history; refreshes every 3 seconds while anything is still running. */
@Component({
  selector: 'app-loads',
  templateUrl: './loads.component.html',
  styles: [`
    .file { max-width: 260px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .sub { font-size: .82rem; color: var(--muted); }
    .live { font-variant-numeric: tabular-nums; }
  `]
})
export class LoadsComponent implements OnInit, OnDestroy {

  loads: LoadRun[] = [];
  loaded = false;
  error = '';
  private sub?: Subscription;

  constructor(private api: ApiService, private router: Router) { }

  ngOnInit(): void {
    this.sub = timer(0, 3000).pipe(switchMap(() => this.api.loads(100))).subscribe(
      list => {
        this.loads = list;
        this.loaded = true;
        this.error = '';
      },
      (err: HttpErrorResponse) => this.error = ApiService.message(err)
    );
  }

  isRunning(l: LoadRun): boolean {
    return RUNNING.indexOf(l.status) >= 0;
  }

  open(l: LoadRun): void {
    this.router.navigate(l.status === 'MAPPING_REVIEW' ? ['/loads', l.loadId, 'mapping'] : ['/loads', l.loadId]);
  }

  ngOnDestroy(): void {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }
}
