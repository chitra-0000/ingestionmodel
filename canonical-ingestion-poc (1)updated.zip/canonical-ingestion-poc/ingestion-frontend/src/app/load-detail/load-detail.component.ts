import { Component, OnDestroy, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Subscription, timer } from 'rxjs';
import { switchMap, takeWhile } from 'rxjs/operators';
import { ApiService } from '../core/api.service';
import { DqIssue, DqProfile, LoadRun, RUNNING } from '../core/models';

interface Stage { name: string; ms: number; }

@Component({
  selector: 'app-load-detail',
  templateUrl: './load-detail.component.html',
  styleUrls: ['./load-detail.component.css']
})
export class LoadDetailComponent implements OnInit, OnDestroy {

  run?: LoadRun;
  profile?: DqProfile;
  issues: DqIssue[] = [];
  issueFilter = '';
  shownIssues = 25;
  error = '';
  private sub?: Subscription;

  constructor(private route: ActivatedRoute, public api: ApiService) { }

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.sub = timer(0, 2000).pipe(
      switchMap(() => this.api.load(id)),
      takeWhile(r => RUNNING.indexOf(r.status) >= 0, true)
    ).subscribe(
      r => {
        this.run = r;
        if (RUNNING.indexOf(r.status) < 0 && r.status !== 'MAPPING_REVIEW' && r.sourceCount > 0) {
          this.loadReport(id);
        }
      },
      (err: HttpErrorResponse) => this.error = ApiService.message(err)
    );
  }

  private loadReport(id: number): void {
    this.api.dqProfile(id).subscribe(p => this.profile = p, () => this.profile = undefined);
    this.filterIssues(this.issueFilter);
  }

  filterIssues(severity: string): void {
    if (!this.run) {
      return;
    }
    this.issueFilter = severity;
    this.shownIssues = 25;
    this.api.issues(this.run.loadId, severity || undefined).subscribe(list => this.issues = list);
  }

  get running(): boolean {
    return !!this.run && RUNNING.indexOf(this.run.status) >= 0;
  }

  get exportable(): boolean {
    return !!this.run && ['COMPLETED', 'COMPLETED_WITH_WARNINGS', 'DQ_THRESHOLD_BREACHED'].indexOf(this.run.status) >= 0;
  }

  get stages(): Stage[] {
    if (!this.run) {
      return [];
    }
    return [
      { name: 'Store raw file', ms: this.run.storeMs },
      { name: 'Read structure', ms: this.run.schemaMs },
      { name: 'Map and insert', ms: this.run.transformMs },
      { name: 'Quality checks', ms: this.run.dqMs }
    ];
  }

  stageWidth(ms: number): number {
    const total = this.stages.reduce((a, s) => a + s.ms, 0);
    return total ? Math.max(1.5, ms * 100 / total) : 0;
  }

  get insertRate(): number {
    return this.run && this.run.transformMs ? Math.round(this.run.sourceCount * 1000 / this.run.transformMs) : 0;
  }

  get subscriberUrl(): string {
    return this.run ? this.api.subscriberUrl(this.run.providerCode, this.run.format) : '';
  }

  ngOnDestroy(): void {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }
}
