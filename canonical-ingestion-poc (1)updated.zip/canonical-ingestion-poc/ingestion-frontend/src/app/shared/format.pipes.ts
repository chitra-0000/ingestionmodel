import { Pipe, PipeTransform } from '@angular/core';

/** 5000000 -> "50,00,000" (Indian grouping, as the team counts in lakhs). */
@Pipe({ name: 'count' })
export class CountPipe implements PipeTransform {
  transform(value: number | null | undefined): string {
    if (value === null || value === undefined) {
      return '–';
    }
    return Number(value).toLocaleString('en-IN');
  }
}

/** Milliseconds -> "2 min 14 s" / "3.4 s". */
@Pipe({ name: 'duration' })
export class DurationPipe implements PipeTransform {
  transform(ms: number | null | undefined): string {
    if (!ms) {
      return '–';
    }
    if (ms < 1000) {
      return `${ms} ms`;
    }
    const s = ms / 1000;
    if (s < 60) {
      return `${s.toFixed(1)} s`;
    }
    const m = Math.floor(s / 60);
    return `${m} min ${Math.round(s - m * 60)} s`;
  }
}

/** Bytes -> "1.9 GB". */
@Pipe({ name: 'bytes' })
export class BytesPipe implements PipeTransform {
  transform(b: number | null | undefined): string {
    if (!b) {
      return '–';
    }
    const units = ['B', 'KB', 'MB', 'GB'];
    let v = b;
    let i = 0;
    while (v >= 1024 && i < units.length - 1) {
      v /= 1024;
      i++;
    }
    return `${v.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
  }
}

/** Status code -> plain words for the badge. */
@Pipe({ name: 'statusLabel' })
export class StatusLabelPipe implements PipeTransform {
  private static readonly LABELS: { [k: string]: string } = {
    STORED: 'Stored',
    ANALYZING: 'Reading structure',
    MAPPING_REVIEW: 'Mapping needs review',
    QUEUED: 'Queued',
    LOADING: 'Loading',
    DQ_CHECKS: 'Checking quality',
    COMPLETED: 'Loaded',
    COMPLETED_WITH_WARNINGS: 'Loaded with warnings',
    DQ_THRESHOLD_BREACHED: 'Too many rejects',
    FAILED: 'Failed'
  };

  transform(status: string | null | undefined): string {
    return status ? (StatusLabelPipe.LABELS[status] || status) : '';
  }
}
