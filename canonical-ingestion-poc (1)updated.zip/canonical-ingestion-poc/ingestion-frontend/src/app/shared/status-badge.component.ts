import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { LoadStatus, RUNNING } from '../core/models';

@Component({
  selector: 'app-status',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<span class="badge" [ngClass]="tone">
      <span class="dot" [class.pulse]="running" aria-hidden="true"></span>{{ status | statusLabel }}</span>`,
  styles: [`
    .badge { display: inline-flex; align-items: center; gap: 6px; padding: 2px 9px 2px 7px; border-radius: 999px;
             font-size: .82rem; font-weight: 600; white-space: nowrap; border: 1px solid transparent; }
    .dot { width: 7px; height: 7px; border-radius: 50%; background: currentColor; }
    .ok { color: var(--ok); background: var(--ok-wash); }
    .warn { color: var(--warn); background: var(--warn-wash); }
    .bad { color: var(--bad); background: var(--bad-wash); }
    .act { color: var(--action); background: var(--action-wash); border-color: var(--action); }
    .run { color: var(--ink-soft); background: var(--paper-deep); }
    .pulse { animation: pulse 1.4s ease-in-out infinite; }
    @keyframes pulse { 50% { opacity: .25; } }
    @media (prefers-reduced-motion: reduce) { .pulse { animation: none; } }
  `]
})
export class StatusBadgeComponent {
  @Input() status!: LoadStatus;

  get running(): boolean {
    return RUNNING.indexOf(this.status) >= 0;
  }

  get tone(): string {
    switch (this.status) {
      case 'COMPLETED': return 'ok';
      case 'COMPLETED_WITH_WARNINGS': return 'warn';
      case 'DQ_THRESHOLD_BREACHED':
      case 'FAILED': return 'bad';
      case 'MAPPING_REVIEW': return 'act';
      default: return 'run';
    }
  }
}
