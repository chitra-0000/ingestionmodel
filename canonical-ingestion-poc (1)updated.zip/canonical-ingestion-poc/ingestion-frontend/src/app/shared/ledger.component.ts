import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { LoadRun } from '../core/models';

/**
 * The reconciliation line: source records = loaded + rejected + duplicates.
 * This is the number an operator has to trust before a list is published, so it is the visual anchor.
 */
@Component({
  selector: 'app-ledger',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="ledger" [class.compact]="compact" [class.broken]="run.reconciled === false">
      <div class="term source">
        <span class="num">{{ run.sourceCount | count }}</span>
        <span class="cap">in file</span>
      </div>
      <span class="op">=</span>
      <div class="term ok">
        <span class="num">{{ run.loadedCount | count }}</span>
        <span class="cap">loaded</span>
      </div>
      <span class="op">+</span>
      <div class="term bad" [class.zero]="!run.rejectedCount">
        <span class="num">{{ run.rejectedCount | count }}</span>
        <span class="cap">rejected</span>
      </div>
      <span class="op">+</span>
      <div class="term bad" [class.zero]="!run.duplicateCount">
        <span class="num">{{ run.duplicateCount | count }}</span>
        <span class="cap">duplicates</span>
      </div>
      <div class="verdict" *ngIf="run.reconciled !== undefined && run.reconciled !== null">
        <svg *ngIf="run.reconciled" viewBox="0 0 20 20" aria-hidden="true"><path d="M4 10.5l4 4 8-9" /></svg>
        <span>{{ run.reconciled ? 'Reconciled' : 'Does not reconcile' }}</span>
      </div>
    </div>
  `,
  styles: [`
    .ledger { display: flex; align-items: flex-end; flex-wrap: wrap; gap: 6px 14px; padding: 18px 0 14px;
              border-bottom: 3px double var(--rule-strong); }
    .term { display: flex; flex-direction: column; }
    .num { font-size: 2.1rem; line-height: 1.05; font-weight: 650; letter-spacing: -0.02em;
           font-variant-numeric: tabular-nums; color: var(--ink); }
    .cap { font-size: .82rem; color: var(--muted); margin-top: 2px; }
    .op { font-size: 1.6rem; color: var(--muted); padding-bottom: 20px; font-weight: 300; }
    .ok .num { color: var(--ok); }
    .bad .num { color: var(--bad); }
    .zero .num { color: var(--muted-light); }
    .verdict { margin-left: auto; display: flex; align-items: center; gap: 6px; padding-bottom: 20px;
               color: var(--ok); font-weight: 600; }
    .verdict svg { width: 20px; height: 20px; fill: none; stroke: currentColor; stroke-width: 2.4;
                   stroke-linecap: round; stroke-linejoin: round; }
    .broken .verdict { color: var(--bad); }
    .compact { padding: 4px 0; border-bottom: 0; gap: 2px 8px; }
    .compact .num { font-size: 1rem; font-weight: 600; }
    .compact .cap { display: none; }
    .compact .op { font-size: .95rem; padding-bottom: 0; }
    .compact .verdict { padding-bottom: 0; margin-left: 6px; font-size: .85rem; }
    .compact .verdict span { display: none; }
    @media (max-width: 640px) { .num { font-size: 1.5rem; } .verdict { margin-left: 0; width: 100%; } }
  `]
})
export class LedgerComponent {
  @Input() run!: LoadRun;
  @Input() compact = false;
}
