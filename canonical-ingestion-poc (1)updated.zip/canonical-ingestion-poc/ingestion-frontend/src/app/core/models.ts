export type FileFormat = 'XML' | 'CSV';

export type LoadStatus =
  'STORED' | 'ANALYZING' | 'MAPPING_REVIEW' | 'QUEUED' | 'LOADING' | 'DQ_CHECKS' |
  'COMPLETED' | 'COMPLETED_WITH_WARNINGS' | 'DQ_THRESHOLD_BREACHED' | 'FAILED';

export const RUNNING: LoadStatus[] = ['STORED', 'ANALYZING', 'QUEUED', 'LOADING', 'DQ_CHECKS'];

export interface LoadRun {
  loadId: number;
  providerCode: string;
  format: FileFormat;
  originalName?: string;
  uploadedBy?: string;
  status: LoadStatus;
  statusMessage?: string;
  sizeBytes: number;
  recordPath?: string;
  mappingId?: number;
  mappingVersion?: number;
  targetTable?: string;
  sourceCount: number;
  loadedCount: number;
  rejectedCount: number;
  duplicateCount: number;
  warningCount: number;
  newPathCount: number;
  reconciled?: boolean;
  storeMs: number;
  schemaMs: number;
  transformMs: number;
  dqMs: number;
  totalMs: number;
  createdAt?: string;
  finishedAt?: string;
  progressRecords: number;
  recordsPerSecond: number;
}

export interface RecordCandidate { path: string; count: number; depth: number; }

export interface PathInfo { path: string; recordsWithValue: number; maxPerRecord: number; samples: string[]; }

export interface CanonicalField {
  name: string;
  type: 'STRING' | 'DATE' | 'COUNTRY' | 'ENUM';
  maxLength: number;
  mandatory: boolean;
  joinMultiple: boolean;
  description?: string;
  allowedValues: string[];
}

export interface FieldMapping {
  field: string;
  expression: string;
  multiValued: boolean;
  confidence: number;
  matchedBy: string;
}

export interface MappingDraft {
  loadId: number;
  providerCode: string;
  format: FileFormat;
  recordPath: string;
  recordCandidates: RecordCandidate[];
  fieldMappings: FieldMapping[];
  xslt: string;
  generatedBy: string;
  basedOnVersion?: number;
  newPaths: string[];
  missingPaths: string[];
  unmappedPaths: string[];
  sourcePaths: PathInfo[];
  canonicalFields: CanonicalField[];
}

export interface MappingRequest {
  recordPath: string;
  fieldMappings: FieldMapping[];
  xslt?: string;
  customXslt: boolean;
  approvedBy?: string;
}

export interface DqIssue {
  recordNo: number;
  field?: string;
  rule: string;
  severity: 'REJECT' | 'WARN';
  message?: string;
  rawValue?: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  xslt: string;
  previewRecords: number;
  previewRejected: number;
  previewRows: { [key: string]: string }[];
  previewIssues: DqIssue[];
}

export interface DqProfile {
  fieldCompleteness: { field: string; mandatory: boolean; filled: number; percent: number }[];
  ruleCounts: { severity: string; rule: string; field: string; count: number }[];
  newPaths: { path: string; records: number }[];
  sourceCount: number;
  rowsInTargetTable: number;
  skippedSiblingElements: number;
  duplicateFileOfLoads: number[];
  rejectPercent: number;
  rejectThresholdPercent: number;
}

export interface MappingDefinition {
  mappingId: number;
  providerCode: string;
  format: FileFormat;
  versionNo: number;
  schemaFingerprint: string;
  recordPath: string;
  fieldMappings: FieldMapping[];
  knownPaths: string[];
  customXslt: boolean;
  status: string;
  generatedBy: string;
  approvedBy: string;
  approvedAt: string;
  storePath?: string;
}
