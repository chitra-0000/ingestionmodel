import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpEvent, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import {
  DqIssue, DqProfile, LoadRun, MappingDefinition, MappingDraft, MappingRequest, ValidationResult
} from './models';

@Injectable({ providedIn: 'root' })
export class ApiService {

  private readonly base = environment.apiBase;

  constructor(private http: HttpClient) { }

  upload(file: File, providerCode: string, uploadedBy: string): Observable<HttpEvent<LoadRun>> {
    const form = new FormData();
    form.append('file', file, file.name);
    form.append('providerCode', providerCode);
    if (uploadedBy) {
      form.append('uploadedBy', uploadedBy);
    }
    return this.http.post<LoadRun>(`${this.base}/loads`, form, { reportProgress: true, observe: 'events' });
  }

  loads(limit = 50): Observable<LoadRun[]> {
    return this.http.get<LoadRun[]>(`${this.base}/loads`, { params: new HttpParams().set('limit', String(limit)) });
  }

  load(id: number): Observable<LoadRun> {
    return this.http.get<LoadRun>(`${this.base}/loads/${id}`);
  }

  dqProfile(id: number): Observable<DqProfile> {
    return this.http.get<DqProfile>(`${this.base}/loads/${id}/dq-profile`);
  }

  issues(id: number, severity?: string): Observable<DqIssue[]> {
    let params = new HttpParams().set('limit', '200');
    if (severity) {
      params = params.set('severity', severity);
    }
    return this.http.get<DqIssue[]>(`${this.base}/loads/${id}/issues`, { params });
  }

  draft(id: number, recordPath?: string): Observable<MappingDraft> {
    const params = recordPath ? new HttpParams().set('recordPath', recordPath) : new HttpParams();
    return this.http.get<MappingDraft>(`${this.base}/loads/${id}/mapping-draft`, { params });
  }

  validate(id: number, req: MappingRequest): Observable<ValidationResult> {
    return this.http.post<ValidationResult>(`${this.base}/loads/${id}/mapping/validate`, req);
  }

  approve(id: number, req: MappingRequest): Observable<ValidationResult> {
    return this.http.post<ValidationResult>(`${this.base}/loads/${id}/mapping/approve`, req);
  }

  mappings(): Observable<MappingDefinition[]> {
    return this.http.get<MappingDefinition[]>(`${this.base}/mappings`);
  }

  exportUrl(id: number, format: 'csv' | 'xml'): string {
    return `${this.base}/loads/${id}/export?format=${format}`;
  }

  issuesExportUrl(id: number): string {
    return `${this.base}/loads/${id}/issues/export`;
  }

  xsltUrl(mappingId: number): string {
    return `${this.base}/mappings/${mappingId}/xslt`;
  }

  subscriberUrl(provider: string, format: string): string {
    return `${this.base}/v1/lists/${encodeURIComponent(provider)}/${format}/records?afterRecordNo=0&limit=100`;
  }

  /** The server returns { error, details } for business errors; fall back to a plain message. */
  static message(err: HttpErrorResponse): string {
    if (err.status === 0) {
      return 'The server cannot be reached. Check that the backend is running on port 8080.';
    }
    const body = err.error as { error?: string; details?: string[]; errors?: string[] } | null;
    if (body && body.errors && body.errors.length) {
      return body.errors.join(' ');
    }
    if (body && body.error) {
      return body.details && body.details.length ? `${body.error}: ${body.details.join('; ')}` : body.error;
    }
    return `Request failed (HTTP ${err.status}).`;
  }
}
