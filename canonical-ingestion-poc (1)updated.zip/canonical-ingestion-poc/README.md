# Canonical ingestion POC

Upload a provider file (XML or CSV). The original is stored in the database, mapped to one common
record with a versioned XSLT, checked for data quality, and served as CSV/XML exports and a
subscriber API. Approved mappings are saved to a folder too, so the next integration reuses them.

```
ingestion-backend/    Java 8, Spring Boot 2.7.18, Maven   (open in IntelliJ)
ingestion-frontend/   Angular 11.2.4, Node 14.17.6        (open in VS Code)
```

## The flow

| Diagram step | Where it happens |
|---|---|
| Runtime XML upload | `POST /api/loads` (multipart). Upload screen takes up to 20 files at once |
| Raw XML stored in DB | `RAW_FILE.CONTENT_GZIP` (BLOB, gzip, SHA-256). Streamed, never fully in memory. Purged after 160 days |
| Extract schema and bounded sample | `SchemaExtractor`: detects the repeating record element (offers `/Root/Records/*` when Person and Entity records are mixed), profiles the first 1,000 records |
| Approved mapping exists? | `MappingService.findApplicable`: same record path, and no field the approved version doesn't know |
| AI generates XSLT mapping | `RuleBasedMappingGenerator` behind the `MappingGenerator` interface (name and synonym matching). An AI generator can be added later behind the same interface |
| Compile, preview and validate | Static XSLT security check, compile (JDK XSLTC, secure processing), run on the first 200 records with every DQ rule |
| Show mapping errors | Mapping review screen lists compile, security and data errors |
| Save versioned mapping in DB | `MAPPING_DEFINITION` (one active version per provider + format) **and** `mapping-store/<PROVIDER>/<FORMAT>/v<n>.xsl + .json` |
| Transform raw XML from DB | `LoadProcessor`: BLOB → gunzip → StAX, one small DOM per record → 4 worker threads: XSLT → DQ → JDBC batch 5,000 |
| Save canonical records | One table for every provider, format and version: `CANONICAL_RECORD`, keyed by `LOAD_ID`, with `PROVIDER_CODE` and `FILE_FORMAT` on every row |
| Generate CSV / XML | `GET /api/loads/{id}/export?format=csv|xml` (streamed) |
| Expose subscriber API | `GET /api/v1/lists` and `GET /api/v1/lists/{provider}/{format}/records?afterRecordNo=0&limit=1000` |

Every provider is mapped into the same common record, defined once in `canonical-model.json`, and
stored in one table. The GUI and subscribers read all lists from one place; one subject's history
across versions is a single indexed lookup on (`PROVIDER_CODE`, `SOURCE_RECORD_ID`).

Nothing from the source is lost. Fields without a canonical column, alias values behind a primary
value, and the original text of values that failed a check are kept as JSON in `EXTRA_ATTRS`
(`EXTRA_ATTRS_CLOB` when longer than 4,000 bytes). The raw file stays in `RAW_FILE`.

## Measured performance

Measured in a 2-CPU sandbox, which is slower than an office laptop or an Oracle server.

| 50,00,000 records, 2.0 GB XML | Result | Target |
|---|---|---|
| Store raw file | 6.5 s | |
| Map and insert (transform + DQ + batch insert) | **2 min 13 s** (37,600 records/s) | 5 min |
| Set-based checks (duplicates, reconciliation) | 1 min 19 s | |
| Upload to reconciled | **3 min 49 s** | 10–15 min |
| CSV export, all rows | 41 s | |
| XML export, all rows | 1 min 42 s | |
| JVM heap | `-Xmx2g`, about 200 MB used afterwards | |

The 50 lakh run used the `h2file` profile. The in-memory H2 profile keeps every row in the heap
(about 800 MB per million rows), so use it for functional tests only. Oracle numbers will differ
and should be measured. The UI shows the time for each step of every load.

## Run it

### Backend

```bash
cd ingestion-backend
mvn clean package              # runs 11 tests, including one end-to-end flow on H2

# In-memory H2 (default): functional testing, up to about 1M records
java -Xmx2g -jar target/ingestion-backend-1.0.0-SNAPSHOT.jar

# H2 on disk: volume tests (5M+) on a laptop without Oracle
java -Xmx2g -jar target/ingestion-backend-1.0.0-SNAPSHOT.jar --spring.profiles.active=h2file

# Oracle 19c: a DBA first runs src/main/resources/db/schema.sql in the app schema
export ORACLE_URL=jdbc:oracle:thin:@//dbhost:1521/ORCLPDB1
export ORACLE_USER=ingest_app
export ORACLE_PASSWORD=...     # never in a file
java -Xmx2g -jar target/ingestion-backend-1.0.0-SNAPSHOT.jar --spring.profiles.active=oracle
```

The application creates no tables at runtime: `schema.sql` creates every table, including
`CANONICAL_RECORD`. If Oracle Partitioning is licensed, use the partitioned variant described at the end
of `schema.sql` (one partition per load). Dropping an old list version then takes seconds instead of a
multi-million-row DELETE.

### Frontend

```bash
cd ingestion-frontend
npm install
npm start                      # http://localhost:4200, proxies /api to localhost:8080
npm run build                  # dist/ingestion-frontend for deployment behind the same reverse proxy
```

### Test data

```bash
cd ingestion-backend && mvn compile
java -cp target/classes com.bank.ingestion.tools.SampleDataGenerator xml 5000000 sample-5m.xml
java -cp target/classes com.bank.ingestion.tools.SampleDataGenerator csv 5000000 sample-5m.csv
java -cp target/classes com.bank.ingestion.tools.SampleDataGenerator xml-drift 1000 drift.xml   # adds a new field
```

Generated files contain realistic defects: missing names, duplicate ids, impossible dates, unknown
countries, control characters, and country values as codes, alpha-3 or English names.

## Demo script (about 10 minutes)

1. Generate a file with `SampleDataGenerator xml 20000 sample.xml` and upload it with provider `SAMPLE`. The load stops at **Mapping needs review** and all
   13 fields are pre-filled, including `Residence | Country` for mixed Person and Entity records.
2. Click **Validate on sample** to see the preview and the quality findings, then **Approve and load**.
3. The load page shows the reconciliation line: in file = loaded + rejected + duplicates, checked.
4. Upload the same structure again. It loads straight away with no review, and is flagged as
   identical to the earlier load.
5. Upload `xml-drift`. It stops for review because one new field appeared; approving creates v2.
6. Restart the backend (H2 is wiped). Mappings re-import from `mapping-store/`, and the next file loads
   without review.

## Data-quality rules

| Rule | Effect |
|---|---|
| MANDATORY_MISSING, LENGTH_EXCEEDED, COLUMN_COUNT, TRANSFORM_ERROR | Record not loaded |
| DUPLICATE_KEY (same `SOURCE_RECORD_ID` in one file) | First occurrence kept, later ones removed (set-based SQL after the load) |
| INVALID_DATE, INVALID_COUNTRY, INVALID_VALUE | Loaded; column left empty, original value kept in `EXTRA_ATTRS` |
| MULTIPLE_VALUES, DATE_IN_FUTURE, DATE_IMPLAUSIBLE, CONTROL_CHARS, INVALID_ENCODING | Loaded and flagged |
| Load level | Reconciliation, reject threshold (1%), new source fields, sibling elements not loaded, identical file |

All values are trimmed, whitespace-collapsed and normalised to Unicode NFC. Dates become ISO text
and partial dates survive (`1970`, `1970-05`). Countries become ISO alpha-2. Every hit is counted;
up to 1,000 examples per rule and field are stored in `DQ_ISSUE`.

The canonical record and its rules are defined in `src/main/resources/canonical-model.json`. Adding a
field there adds the column to `CANONICAL_RECORD` (ALTER TABLE) at the next load.

## Security and quality-scan fixes (Sonar, Fortify, Nexus)

- **XXE:** every parser comes from `XmlSecurity`, with DTDs, external entities and external stylesheets
  disabled. There is a unit test for this.
- **XSLT injection:** a whitelist of XSLT elements, output elements `r`, `f` and `x` only, and no
  `document()`, `unparsed-text`, `system-property` or extension functions. The check runs after XML
  parsing, so `&#100;ocument(` tricks are caught. The compiler also runs with secure processing on.
- **SQL injection:** all values are bind parameters. The only dynamic identifiers are table and
  column names, and they come from whitelisted provider codes and the validated canonical model.
- **Path traversal:** provider codes are whitelisted, uploaded file names are reduced to their last
  segment, and mapping-store paths are checked to stay inside the store.
- **Log forging:** user text is stripped of CR/LF before it is logged.
- **CSV formula injection:** exported cells starting with `= + - @` are prefixed with `'`.
- **Error leakage:** no stack traces or SQL reach clients; unexpected errors return a reference id
  that matches the server log.
- **Credentials:** the Oracle password comes from environment variables. CORS is limited to the
  Angular origin.
- **Dependencies (Nexus):** Spring Framework 5.3.39, Tomcat 9.0.123, Logback 1.2.13 and Jackson 2.17.2
  are pinned. SnakeYAML is excluded because the app uses properties files. The H2 console is off.

Expect Nexus to flag the platform itself. Spring Boot 2.7, Angular 11 and Node 14 are end-of-life
upstream, and that comes with the Java 8 / Angular 11 baseline rather than this code. The upgrade path
is Spring Boot 3 (Java 17) and a current Angular.

## Not in this POC

- **Authentication:** the approver name is typed in. In production it should come from SSO, and
  four-eyes approval would be enforced server-side.
- **Publication workflow:** validation and certification by different users before publishing to the
  DSS is not built yet. Any completed load is served to subscribers.
- **Cleanup of old versions:** older loads stay in `CANONICAL_RECORD` (with partitioning this becomes a partition drop).
- **AI mapping generator:** the interface is in place, but no AI integration is included.
