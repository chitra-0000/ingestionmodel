package com.bank.ingestion;

import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.domain.SchemaProfile;
import com.bank.ingestion.service.CanonicalModel;
import com.bank.ingestion.service.dq.CountryNormalizer;
import com.bank.ingestion.service.dq.DateNormalizer;
import com.bank.ingestion.service.dq.RecordValidator;
import com.bank.ingestion.service.mapping.RuleBasedMappingGenerator;
import com.bank.ingestion.service.mapping.XsltSecurityValidator;
import com.bank.ingestion.service.source.CsvParser;
import com.bank.ingestion.service.source.CsvRecordReader;
import com.bank.ingestion.service.source.RecordData;
import com.bank.ingestion.service.source.XmlRecordReader;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/** Fast tests (no Spring context) for the parts most likely to break silently. */
class UnitTests {

    private final CanonicalModel model = new CanonicalModel(new ObjectMapper());

    UnitTests() throws Exception {
    }

    @Test
    void xsltValidatorBlocksDangerousConstructs() {
        XsltSecurityValidator v = new XsltSecurityValidator();
        String evil = "<xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" "
                + "xmlns:rt=\"http://xml.apache.org/xalan/java/java.lang.Runtime\"><xsl:template match=\"/*\"><r>"
                + "<f n=\"A\"><xsl:value-of select=\"&#100;ocument('file:///etc/passwd')\"/></f>"
                + "<f n=\"B\"><xsl:value-of select=\"rt:exec(rt:getRuntime(),'id')\"/></f></r>"
                + "<xsl:result-document href=\"x\"/><script/></xsl:template></xsl:stylesheet>";
        List<String> errors = v.check(evil);
        assertThat(errors).anyMatch(e -> e.contains("document()"))
                .anyMatch(e -> e.contains("rt:exec("))
                .anyMatch(e -> e.contains("result-document"))
                .anyMatch(e -> e.contains("<script>"))
                .anyMatch(e -> e.contains("xmlns:rt"));
        assertThat(v.check("<!DOCTYPE x [<!ENTITY e SYSTEM \"file:///etc/passwd\">]><x>&e;</x>"))
                .anyMatch(e -> e.contains("not well-formed"));
    }

    @Test
    void xsltValidatorAcceptsGeneratedShape() {
        String ok = "<xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\"><xsl:template match=\"/*\">"
                + "<r><f n=\"FULL_NAME\"><xsl:value-of select=\"normalize-space(concat(First, ' ', Last))\"/></f>"
                + "<x p=\"a/@b\"><xsl:for-each select=\"a/@b\"><xsl:if test=\"position() &gt; 1\">|</xsl:if>"
                + "<xsl:value-of select=\".\"/></xsl:for-each></x></r></xsl:template></xsl:stylesheet>";
        assertThat(new XsltSecurityValidator().check(ok)).isEmpty();
    }

    @Test
    void datesAreNormalisedKeepingPartialDates() {
        DateNormalizer d = new DateNormalizer("DMY");
        assertThat(d.normalise("1970-05-12")).isEqualTo("1970-05-12");
        assertThat(d.normalise("12/05/1970")).isEqualTo("1970-05-12");
        assertThat(d.normalise("05/13/1970")).isEqualTo("1970-05-13");
        assertThat(d.normalise("12 May 1970")).isEqualTo("1970-05-12");
        assertThat(d.normalise("12-MAY-1970")).isEqualTo("1970-05-12");
        assertThat(d.normalise("May 12, 1970")).isEqualTo("1970-05-12");
        assertThat(d.normalise("19700512")).isEqualTo("1970-05-12");
        assertThat(d.normalise("1970-05-12T10:00:00Z")).isEqualTo("1970-05-12");
        assertThat(d.normalise("1970")).isEqualTo("1970");
        assertThat(d.normalise("05/1970")).isEqualTo("1970-05");
        assertThat(d.normalise("31/02/1975")).isNull();
        assertThat(d.normalise("unknown")).isNull();
        assertThat(new DateNormalizer("MDY").normalise("03/04/1970")).isEqualTo("1970-03-04");
    }

    @Test
    void countriesAcceptCodesAndNames() {
        assertThat(CountryNormalizer.normalise("IN")).isEqualTo("IN");
        assertThat(CountryNormalizer.normalise("ind")).isEqualTo("IN");
        assertThat(CountryNormalizer.normalise("India")).isEqualTo("IN");
        assertThat(CountryNormalizer.normalise("United Arab Emirates")).isEqualTo("AE");
        assertThat(CountryNormalizer.normalise("UK")).isEqualTo("GB");
        assertThat(CountryNormalizer.normalise("Kosovo")).isEqualTo("XK");
        assertThat(CountryNormalizer.normalise("Atlantis")).isNull();
    }

    @Test
    void csvParserHandlesQuotesAndEmbeddedLineBreaks() throws Exception {
        CsvParser p = new CsvParser(new StringReader("a,\"b,c\",\"say \"\"hi\"\"\"\r\n\r\n1,\"line1\nline2\",3"), ',');
        assertThat(p.next()).containsExactly("a", "b,c", "say \"hi\"");
        assertThat(p.next()).containsExactly("1", "line1\nline2", "3");
        assertThat(p.next()).isNull();
        assertThat(CsvParser.detectDelimiter("a;b;\"c;d\";e")).isEqualTo(';');
        assertThat(CsvRecordReader.toElementNames(Arrays.asList("Date of Birth", "1st", "xmlName", "a", "a")))
                .containsExactly("Date_of_Birth", "_1st", "_xmlName", "a", "a_2");
    }

    @Test
    void csvReaderRejectsWrongColumnCountAndReportsNewColumns() throws Exception {
        String csv = "﻿id,name,extra\n1,Ann,x\n2,Bob\n";
        try (CsvRecordReader r = new CsvRecordReader(new ByteArrayInputStream(csv.getBytes(StandardCharsets.UTF_8)),
                new HashSet<>(Arrays.asList("id", "name")), null, true)) {
            RecordData first = r.next();
            assertThat(first.isRejected()).isFalse();
            assertThat(first.getNewPathValues()).hasSize(1);
            assertThat(first.getNewPathValues().get(0)).containsExactly("extra", "x");
            assertThat(r.next().getRejectRule()).isEqualTo(CsvRecordReader.RULE_COLUMN_COUNT);
            assertThat(r.next()).isNull();
        }
    }

    @Test
    void xmlReaderSplitsWildcardRecordsAndCountsSkippedSiblings() throws Exception {
        String xml = "<L xmlns=\"urn:x\"><Records><P id=\"1\"><N>a</N></P><E id=\"2\"><N>b</N></E></Records></L>";
        try (XmlRecordReader r = new XmlRecordReader(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)),
                "/L/Records/*", null, null, true)) {
            assertThat(r.next().getDocument().getDocumentElement().getTagName()).isEqualTo("P");
            assertThat(r.next().getDocument().getDocumentElement().getTagName()).isEqualTo("E");
            assertThat(r.next()).isNull();
        }
        try (XmlRecordReader r = new XmlRecordReader(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)),
                "/L/Records/P", Collections.singleton("@id"), null, true)) {
            RecordData p = r.next();
            assertThat(p.getNewPathValues()).hasSize(1);
            assertThat(p.getNewPathValues().get(0)).containsExactly("N", "a");
            assertThat(r.next()).isNull();
            assertThat(r.skippedSiblingElements()).isEqualTo(1);
        }
    }

    @Test
    void xmlReaderRefusesExternalEntities() {
        String xml = "<!DOCTYPE L [<!ENTITY e SYSTEM \"file:///etc/passwd\">]><L><R><N>&e;</N></R></L>";
        boolean failed = false;
        try (XmlRecordReader r = new XmlRecordReader(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)),
                "/L/R", null, null, true)) {
            RecordData d = r.next();
            failed = d == null || !d.getDocument().getDocumentElement().getTextContent().contains("root:");
        } catch (Exception e) {
            failed = true;
        }
        assertThat(failed).as("external entity must not be resolved").isTrue();
    }

    @Test
    void recordValidatorRejectsAndWarns() {
        RecordValidator v = new RecordValidator(model, new DateNormalizer("DMY"));
        String[] raw = new String[model.fields().size()];
        raw[model.indexOf("SOURCE_RECORD_ID")] = "X1";
        raw[model.indexOf("FULL_NAME")] = "  Ann \u0007  Lee ";
        raw[model.indexOf("DATE_OF_BIRTH")] = "31/02/1975";
        raw[model.indexOf("NATIONALITY")] = "US|GB";
        raw[model.indexOf("GENDER")] = "female";
        RecordValidator.Result r = v.validate(1, raw);
        assertThat(r.rejected()).isFalse();
        assertThat(r.values()[model.indexOf("FULL_NAME")]).isEqualTo("Ann Lee");
        assertThat(r.values()[model.indexOf("DATE_OF_BIRTH")]).isNull();
        assertThat(r.values()[model.indexOf("NATIONALITY")]).isEqualTo("US");
        assertThat(r.values()[model.indexOf("GENDER")]).isEqualTo("F");
        assertThat(r.issues()).extracting("rule").contains(RecordValidator.CONTROL_CHARS,
                RecordValidator.INVALID_DATE, RecordValidator.MULTIPLE_VALUES);
        assertThat(r.originals()).isNotEmpty();

        String[] missing = new String[model.fields().size()];
        missing[model.indexOf("SOURCE_RECORD_ID")] = "X2";
        assertThat(v.validate(2, missing).rejected()).isTrue();
    }

    @Test
    void ruleBasedGeneratorMapsCommonNames() {
        SchemaProfile p = new SchemaProfile();
        p.setFormat(FileFormat.XML);
        p.setRecordPath("/L/Records/*");
        p.setSampleRecordCount(10);
        for (String path : Arrays.asList("@id", "Name/FirstName", "Name/Surname", "DOB", "Residence", "Country", "Name/@type")) {
            SchemaProfile.PathInfo info = new SchemaProfile.PathInfo();
            info.setPath(path);
            info.setRecordsWithValue(10);
            info.setMaxPerRecord(1);
            p.getPaths().add(info);
        }
        RuleBasedMappingGenerator g = new RuleBasedMappingGenerator(model);
        java.util.Map<String, String> m = new java.util.HashMap<>();
        g.suggest(p).forEach(f -> m.put(f.getField(), f.getExpression()));
        assertThat(m.get("SOURCE_RECORD_ID")).isEqualTo("@id");
        assertThat(m.get("FIRST_NAME")).isEqualTo("Name/FirstName");
        assertThat(m.get("LAST_NAME")).isEqualTo("Name/Surname");
        assertThat(m.get("DATE_OF_BIRTH")).isEqualTo("DOB");
        assertThat(m.get("COUNTRY_CODE")).contains("Residence").contains("Country");
        assertThat(m.get("RECORD_TYPE")).isEqualTo("local-name()");
        assertThat(m.get("FULL_NAME")).startsWith("normalize-space(concat(");
    }
}
