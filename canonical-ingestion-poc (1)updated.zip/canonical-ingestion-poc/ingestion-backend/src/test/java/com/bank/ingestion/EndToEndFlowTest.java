package com.bank.ingestion;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * The whole diagram on H2: upload -> raw store -> schema -> no mapping -> draft -> validate -> approve
 * -> transform -> DQ -> reconciled; then a second file with the same structure loads without review.
 */
@SpringBootTest(properties = {"spring.profiles.active=h2", "ingestion.work-dir=target/test-work"})
@AutoConfigureMockMvc
class EndToEndFlowTest {

    /** A fresh mapping store per run, so a mapping approved by an earlier run is not reused. */
    @DynamicPropertySource
    static void mappingStore(DynamicPropertyRegistry registry) throws java.io.IOException {
        java.nio.file.Path dir = java.nio.file.Files.createTempDirectory("test-mapping-store");
        registry.add("ingestion.mapping-store-dir", dir::toString);
    }

    private static final String CSV = "uid,full_name,dob,country,program\n"
            + "A1,Ann Lee,12/05/1970,India,OFAC SDN\n"
            + "A2,Bob Roy,1980-01-02,GB,EU\n"
            + "A3,,1990,US,UN\n"          // missing mandatory name -> rejected
            + "A2,Bob Roy again,1980,GB,EU\n" // duplicate id -> rejected after load
            + "A4,Cy Dee,31/02/1975,Atlantis,HMT\n"; // invalid date + country -> loaded with warnings

    @Autowired
    private MockMvc mvc;
    @Autowired
    private ObjectMapper json;
    @Autowired
    private org.springframework.jdbc.core.JdbcTemplate jdbc;

    @Test
    void uploadReviewApproveLoadAndReuse() throws Exception {
        long first = upload("TESTPROV", "list1.csv");
        assertThat(waitFor(first, "MAPPING_REVIEW").path("status").asText()).isEqualTo("MAPPING_REVIEW");

        JsonNode draft = read(mvc.perform(get("/api/loads/" + first + "/mapping-draft")).andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString());
        ObjectNode req = json.createObjectNode();
        req.put("recordPath", draft.path("recordPath").asText());
        req.set("fieldMappings", draft.path("fieldMappings"));
        req.put("approvedBy", "tester");

        JsonNode validation = read(mvc.perform(post("/api/loads/" + first + "/mapping/validate")
                .contentType(MediaType.APPLICATION_JSON).content(req.toString())).andReturn().getResponse().getContentAsString());
        assertThat(validation.path("errors").toString()).isEqualTo("[]");

        mvc.perform(post("/api/loads/" + first + "/mapping/approve").contentType(MediaType.APPLICATION_JSON).content(req.toString()))
                .andExpect(status().isOk());
        JsonNode done = waitFor(first, "COMPLETED");
        assertThat(done.path("status").asText()).isEqualTo("DQ_THRESHOLD_BREACHED"); // 2 of 5 rejected > 1%
        assertThat(done.path("sourceCount").asLong()).isEqualTo(5);
        assertThat(done.path("loadedCount").asLong()).isEqualTo(3);
        assertThat(done.path("rejectedCount").asLong()).isEqualTo(1);
        assertThat(done.path("duplicateCount").asLong()).isEqualTo(1);
        assertThat(done.path("reconciled").asBoolean()).isTrue();

        // Same structure again: approved mapping exists -> loads straight away, no review.
        long second = upload("TESTPROV", "list2.csv");
        JsonNode again = waitFor(second, "COMPLETED");
        assertThat(again.path("mappingVersion").asInt()).isEqualTo(1);
        assertThat(again.path("statusMessage").asText()).contains("identical to earlier load");

        org.springframework.test.web.servlet.MvcResult started = mvc.perform(get("/api/loads/" + first + "/export")
                .param("format", "csv")).andReturn();
        String export = mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch(started))
                .andReturn().getResponse().getContentAsString();
        assertThat(export).contains("A1,").contains("IN").contains("1970-05-12").doesNotContain("A3,");
        Integer rows = jdbc.queryForObject("SELECT COUNT(*) FROM CANONICAL_RECORD WHERE PROVIDER_CODE = 'TESTPROV' AND FILE_FORMAT = 'CSV'", Integer.class);
        assertThat(rows).isEqualTo(6);
    }

    private long upload(String provider, String name) throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", name, "text/csv", CSV.getBytes(StandardCharsets.UTF_8));
        String body = mvc.perform(multipart("/api/loads").file(file).param("providerCode", provider))
                .andExpect(status().isAccepted()).andReturn().getResponse().getContentAsString();
        return read(body).path("loadId").asLong();
    }

    /** Polls until the status starts with the prefix or the load ends. */
    private JsonNode waitFor(long loadId, String prefix) throws Exception {
        JsonNode n = null;
        for (int i = 0; i < 100; i++) {
            n = read(mvc.perform(get("/api/loads/" + loadId)).andReturn().getResponse().getContentAsString());
            String s = n.path("status").asText();
            if (s.startsWith(prefix) || "FAILED".equals(s) || "DQ_THRESHOLD_BREACHED".equals(s) || "MAPPING_REVIEW".equals(s) && !prefix.equals(s)) {
                if (!"MAPPING_REVIEW".equals(s) || prefix.equals(s)) {
                    return n;
                }
            }
            Thread.sleep(100);
        }
        return n;
    }

    private JsonNode read(String body) throws java.io.IOException {
        return json.readTree(body);
    }
}
