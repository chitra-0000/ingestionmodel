-- Canonical ingestion POC: fixed tables.
-- Runs unchanged on H2 (MODE=Oracle) and Oracle 19c. On Oracle, a DBA runs it once in the app schema.
-- No tables are created at runtime: every provider and format is loaded into CANONICAL_RECORD.

CREATE SEQUENCE LOAD_SEQ START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE MAPPING_SEQ START WITH 1 INCREMENT BY 1 NOCACHE;

-- One row per uploaded file: the original bytes, gzip-compressed, kept for the retention period.
CREATE TABLE RAW_FILE (
    LOAD_ID             NUMBER(19)          NOT NULL,
    ORIGINAL_NAME       VARCHAR2(255 CHAR),
    FILE_FORMAT         VARCHAR2(10)        NOT NULL,
    SIZE_BYTES          NUMBER(19)          NOT NULL,
    COMPRESSED_BYTES    NUMBER(19)          NOT NULL,
    SHA256              VARCHAR2(64)        NOT NULL,
    CONTENT_GZIP        BLOB                NOT NULL,
    CREATED_AT          TIMESTAMP           NOT NULL,
    CONSTRAINT PK_RAW_FILE PRIMARY KEY (LOAD_ID)
);

-- One row per load (= one version of a provider list) with status, counts, timings and DQ profile.
CREATE TABLE LOAD_RUN (
    LOAD_ID             NUMBER(19)          NOT NULL,
    PROVIDER_CODE       VARCHAR2(20)        NOT NULL,
    FILE_FORMAT         VARCHAR2(10)        NOT NULL,
    ORIGINAL_NAME       VARCHAR2(255 CHAR),
    UPLOADED_BY         VARCHAR2(100 CHAR),
    STATUS              VARCHAR2(30)        NOT NULL,
    STATUS_MESSAGE      VARCHAR2(1000 CHAR),
    SIZE_BYTES          NUMBER(19),
    SHA256              VARCHAR2(64),
    SCHEMA_FINGERPRINT  VARCHAR2(64),
    RECORD_PATH         VARCHAR2(500 CHAR),
    SCHEMA_JSON         CLOB,
    MAPPING_ID          NUMBER(19),
    MAPPING_VERSION     NUMBER(10),
    TARGET_TABLE        VARCHAR2(30),
    SOURCE_COUNT        NUMBER(19)          DEFAULT 0,
    LOADED_COUNT        NUMBER(19)          DEFAULT 0,
    REJECTED_COUNT      NUMBER(19)          DEFAULT 0,
    DUPLICATE_COUNT     NUMBER(19)          DEFAULT 0,
    WARNING_COUNT       NUMBER(19)          DEFAULT 0,
    NEW_PATH_COUNT      NUMBER(19)          DEFAULT 0,
    RECONCILED          NUMBER(1),
    DQ_PROFILE_JSON     CLOB,
    STORE_MS            NUMBER(19)          DEFAULT 0,
    SCHEMA_MS           NUMBER(19)          DEFAULT 0,
    TRANSFORM_MS        NUMBER(19)          DEFAULT 0,
    DQ_MS               NUMBER(19)          DEFAULT 0,
    TOTAL_MS            NUMBER(19)          DEFAULT 0,
    CREATED_AT          TIMESTAMP           NOT NULL,
    FINISHED_AT         TIMESTAMP,
    CONSTRAINT PK_LOAD_RUN PRIMARY KEY (LOAD_ID)
);
CREATE INDEX IX_LOAD_RUN_PROVIDER ON LOAD_RUN (PROVIDER_CODE, FILE_FORMAT, STATUS);

-- Approved, versioned mappings. The same content is also written to the mapping-store folder.
CREATE TABLE MAPPING_DEFINITION (
    MAPPING_ID          NUMBER(19)          NOT NULL,
    PROVIDER_CODE       VARCHAR2(20)        NOT NULL,
    FILE_FORMAT         VARCHAR2(10)        NOT NULL,
    VERSION_NO          NUMBER(10)          NOT NULL,
    SCHEMA_FINGERPRINT  VARCHAR2(64)        NOT NULL,
    RECORD_PATH         VARCHAR2(500 CHAR)  NOT NULL,
    FIELD_MAPPING_JSON  CLOB                NOT NULL,
    KNOWN_PATHS_JSON    CLOB                NOT NULL,
    XSLT_CONTENT        CLOB                NOT NULL,
    CUSTOM_XSLT         NUMBER(1)           DEFAULT 0 NOT NULL,
    STATUS              VARCHAR2(20)        NOT NULL,
    GENERATED_BY        VARCHAR2(30)        NOT NULL,
    APPROVED_BY         VARCHAR2(100 CHAR)  NOT NULL,
    APPROVED_AT         TIMESTAMP           NOT NULL,
    STORE_PATH          VARCHAR2(500 CHAR),
    CONSTRAINT PK_MAPPING_DEFINITION PRIMARY KEY (MAPPING_ID),
    CONSTRAINT UQ_MAPPING_VERSION UNIQUE (PROVIDER_CODE, FILE_FORMAT, VERSION_NO)
);

-- Data-quality findings. Every finding is counted in LOAD_RUN.DQ_PROFILE_JSON; detail rows are capped per rule.
CREATE TABLE DQ_ISSUE (
    LOAD_ID             NUMBER(19)          NOT NULL,
    RECORD_NO           NUMBER(19)          NOT NULL,
    FIELD_NAME          VARCHAR2(500 CHAR),
    RULE_CODE           VARCHAR2(40)        NOT NULL,
    SEVERITY            VARCHAR2(10)        NOT NULL,
    MESSAGE             VARCHAR2(500 CHAR),
    RAW_VALUE           VARCHAR2(500 CHAR)
);
CREATE INDEX IX_DQ_ISSUE_LOAD ON DQ_ISSUE (LOAD_ID, RECORD_NO);

-- The common record object: one table for every provider, format and list version.
-- Columns from RECORD_TYPE to REMARKS mirror src/main/resources/canonical-model.json; when a field is
-- added there, the application adds the column with ALTER TABLE at the next load.
CREATE TABLE CANONICAL_RECORD (
    LOAD_ID             NUMBER(19)          NOT NULL,
    RECORD_NO           NUMBER(19)          NOT NULL,
    PROVIDER_CODE       VARCHAR2(20)        NOT NULL,
    FILE_FORMAT         VARCHAR2(10)        NOT NULL,
    MAPPING_VERSION     NUMBER(10)          NOT NULL,
    DQ_STATUS           VARCHAR2(4)         NOT NULL,
    SOURCE_RECORD_ID    VARCHAR2(100 CHAR),
    RECORD_TYPE         VARCHAR2(10 CHAR),
    FULL_NAME           VARCHAR2(500 CHAR),
    FIRST_NAME          VARCHAR2(200 CHAR),
    LAST_NAME           VARCHAR2(200 CHAR),
    DATE_OF_BIRTH       VARCHAR2(10 CHAR),
    GENDER              VARCHAR2(1 CHAR),
    NATIONALITY         VARCHAR2(2 CHAR),
    COUNTRY_CODE        VARCHAR2(2 CHAR),
    LIST_CODE           VARCHAR2(500 CHAR),
    ACTION              VARCHAR2(10 CHAR),
    LAST_UPDATED        VARCHAR2(10 CHAR),
    REMARKS             VARCHAR2(2000 CHAR),
    EXTRA_ATTRS         VARCHAR2(4000 BYTE),
    EXTRA_ATTRS_CLOB    CLOB,
    CONSTRAINT PK_CANONICAL_RECORD PRIMARY KEY (LOAD_ID, RECORD_NO)
);
-- Look up one subject across all versions of a provider's list (GUI search, history).
CREATE INDEX IX_CANONICAL_RECORD_SRC ON CANONICAL_RECORD (PROVIDER_CODE, SOURCE_RECORD_ID);

-- ORACLE, if the Partitioning option is licensed (recommended for production), create the table instead with
--     ... CONSTRAINT PK_CANONICAL_RECORD PRIMARY KEY (LOAD_ID, RECORD_NO) USING INDEX LOCAL )
--     PARTITION BY RANGE (LOAD_ID) INTERVAL (1) (PARTITION P0 VALUES LESS THAN (1));
-- One partition per load: removing an old list version is ALTER TABLE ... DROP PARTITION (seconds)
-- instead of a DELETE of millions of rows, and every query by LOAD_ID touches one partition only.
-- Create IX_CANONICAL_RECORD_SRC as LOCAL as well.
