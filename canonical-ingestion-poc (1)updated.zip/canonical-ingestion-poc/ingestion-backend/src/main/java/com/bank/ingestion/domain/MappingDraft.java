package com.bank.ingestion.domain;

import java.util.ArrayList;
import java.util.List;

/** What the mapping review screen shows: suggested field mappings, the generated XSLT and any schema drift. */
public class MappingDraft {

    private long loadId;
    private String providerCode;
    private FileFormat format;
    private String recordPath;
    private List<SchemaProfile.RecordCandidate> recordCandidates = new ArrayList<>();
    private List<FieldMapping> fieldMappings = new ArrayList<>();
    private String xslt;
    private String generatedBy;
    /** Set when the draft starts from an earlier approved version of this provider + format. */
    private Integer basedOnVersion;
    /** Paths in this file that the previous approved version did not know (schema drift). */
    private List<String> newPaths = new ArrayList<>();
    /** Paths the previous version knew that this file's sample does not contain. */
    private List<String> missingPaths = new ArrayList<>();
    /** Source paths not mapped to a canonical field; they are kept in EXTRA_ATTRS. */
    private List<String> unmappedPaths = new ArrayList<>();
    private List<SchemaProfile.PathInfo> sourcePaths = new ArrayList<>();
    private List<CanonicalField> canonicalFields = new ArrayList<>();

    public long getLoadId() { return loadId; }
    public void setLoadId(long loadId) { this.loadId = loadId; }
    public String getProviderCode() { return providerCode; }
    public void setProviderCode(String providerCode) { this.providerCode = providerCode; }
    public FileFormat getFormat() { return format; }
    public void setFormat(FileFormat format) { this.format = format; }
    public String getRecordPath() { return recordPath; }
    public void setRecordPath(String recordPath) { this.recordPath = recordPath; }
    public List<SchemaProfile.RecordCandidate> getRecordCandidates() { return recordCandidates; }
    public void setRecordCandidates(List<SchemaProfile.RecordCandidate> recordCandidates) { this.recordCandidates = recordCandidates; }
    public List<FieldMapping> getFieldMappings() { return fieldMappings; }
    public void setFieldMappings(List<FieldMapping> fieldMappings) { this.fieldMappings = fieldMappings; }
    public String getXslt() { return xslt; }
    public void setXslt(String xslt) { this.xslt = xslt; }
    public String getGeneratedBy() { return generatedBy; }
    public void setGeneratedBy(String generatedBy) { this.generatedBy = generatedBy; }
    public Integer getBasedOnVersion() { return basedOnVersion; }
    public void setBasedOnVersion(Integer basedOnVersion) { this.basedOnVersion = basedOnVersion; }
    public List<String> getNewPaths() { return newPaths; }
    public void setNewPaths(List<String> newPaths) { this.newPaths = newPaths; }
    public List<String> getMissingPaths() { return missingPaths; }
    public void setMissingPaths(List<String> missingPaths) { this.missingPaths = missingPaths; }
    public List<String> getUnmappedPaths() { return unmappedPaths; }
    public void setUnmappedPaths(List<String> unmappedPaths) { this.unmappedPaths = unmappedPaths; }
    public List<SchemaProfile.PathInfo> getSourcePaths() { return sourcePaths; }
    public void setSourcePaths(List<SchemaProfile.PathInfo> sourcePaths) { this.sourcePaths = sourcePaths; }
    public List<CanonicalField> getCanonicalFields() { return canonicalFields; }
    public void setCanonicalFields(List<CanonicalField> canonicalFields) { this.canonicalFields = canonicalFields; }
}
