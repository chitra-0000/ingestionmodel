package com.bank.ingestion.config;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLInputFactory;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;

/**
 * Hardened XML factories (Fortify / Sonar: XXE, external entity and external stylesheet access).
 * Every XML parser, StAX reader and XSLT compiler in the application is created here.
 */
public final class XmlSecurity {

    /** JDK built-in XSLTC: compiles stylesheets to bytecode, thread-safe Templates, no extra dependency. */
    private static final String JDK_TRANSFORMER_FACTORY =
            "com.sun.org.apache.xalan.internal.xsltc.trax.TransformerFactoryImpl";

    private XmlSecurity() {
    }

    public static XMLInputFactory newXmlInputFactory() {
        XMLInputFactory f = XMLInputFactory.newInstance();
        f.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
        f.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
        f.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, Boolean.FALSE);
        f.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE, Boolean.TRUE);
        f.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);
        return f;
    }

    public static DocumentBuilder newDocumentBuilder() {
        try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            f.setFeature("http://xml.org/sax/features/external-general-entities", false);
            f.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            f.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            f.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            f.setXIncludeAware(false);
            f.setExpandEntityReferences(false);
            f.setNamespaceAware(true);
            return f.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            throw new IllegalStateException("Cannot create secure DocumentBuilder", e);
        }
    }

    /**
     * Secure XSLT compiler: secure processing on (no extension functions), no external
     * stylesheet or DTD access (blocks document(), xsl:import/include of remote or local files).
     */
    public static TransformerFactory newTransformerFactory() {
        try {
            TransformerFactory f = TransformerFactory.newInstance(JDK_TRANSFORMER_FACTORY, null);
            f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            f.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
            return f;
        } catch (TransformerConfigurationException e) {
            throw new IllegalStateException("Cannot create secure TransformerFactory", e);
        }
    }
}
