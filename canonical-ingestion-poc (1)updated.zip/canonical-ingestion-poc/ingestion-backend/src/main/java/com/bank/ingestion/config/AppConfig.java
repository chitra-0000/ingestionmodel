package com.bank.ingestion.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

@Configuration
public class AppConfig implements WebMvcConfigurer {

    public static final String INGESTION_EXECUTOR = "ingestionExecutor";

    private final IngestionProperties props;

    public AppConfig(IngestionProperties props) {
        this.props = props;
    }

    /**
     * Runs whole loads in the background. Two loads run at a time (each uses its own worker pool);
     * up to 50 more wait in the queue, which covers "up to 20 files arriving at once".
     */
    @Bean(name = INGESTION_EXECUTOR)
    public Executor ingestionExecutor() {
        ThreadPoolTaskExecutor ex = new ThreadPoolTaskExecutor();
        ex.setCorePoolSize(2);
        ex.setMaxPoolSize(2);
        ex.setQueueCapacity(50);
        ex.setThreadNamePrefix("load-");
        ex.setRejectedExecutionHandler(new ThreadPoolExecutor.AbortPolicy());
        ex.setWaitForTasksToCompleteOnShutdown(false);
        ex.initialize();
        return ex;
    }

    /** CORS restricted to the configured Angular origin only (no wildcard). */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOrigins(props.getAllowedOrigin())
                .allowedMethods("GET", "POST")
                .allowedHeaders("Content-Type")
                .maxAge(3600);
    }
}
