package com.bank.ingestion.repository;

import com.bank.ingestion.domain.FileFormat;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

/** Original files, gzip-compressed, in RAW_FILE.CONTENT_GZIP (BLOB). Streamed in and out, never fully in memory. */
@Repository
public class RawFileRepository {

    /** Receives the stored (still compressed) bytes of a raw file. */
    public interface ContentReader<T> {
        T read(InputStream compressedContent) throws Exception;
    }

    private final DataSource dataSource;
    private final JdbcTemplate jdbc;

    public RawFileRepository(DataSource dataSource, JdbcTemplate jdbc) {
        this.dataSource = dataSource;
        this.jdbc = jdbc;
    }

    public void insert(long loadId, String originalName, FileFormat format, long sizeBytes, String sha256,
                       Path gzipFile) throws SQLException, IOException {
        long compressedBytes = Files.size(gzipFile);
        String sql = "INSERT INTO RAW_FILE (LOAD_ID, ORIGINAL_NAME, FILE_FORMAT, SIZE_BYTES, COMPRESSED_BYTES, SHA256, "
                + "CONTENT_GZIP, CREATED_AT) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = dataSource.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             InputStream in = Files.newInputStream(gzipFile)) {
            ps.setLong(1, loadId);
            ps.setString(2, originalName);
            ps.setString(3, format.name());
            ps.setLong(4, sizeBytes);
            ps.setLong(5, compressedBytes);
            ps.setString(6, sha256);
            ps.setBinaryStream(7, in, compressedBytes);
            ps.setTimestamp(8, new Timestamp(System.currentTimeMillis()));
            ps.executeUpdate();
            if (!con.getAutoCommit()) {
                con.commit();
            }
        }
    }

    /**
     * Streams the compressed content to the reader while holding one connection.
     * Used for schema extraction, preview and the full transform ("Transform raw XML from DB").
     */
    public <T> T readContent(long loadId, ContentReader<T> reader) throws Exception {
        try (Connection con = dataSource.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT CONTENT_GZIP FROM RAW_FILE WHERE LOAD_ID = ?")) {
            ps.setLong(1, loadId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    throw new IllegalStateException("Raw file not found for load " + loadId);
                }
                try (InputStream in = rs.getBinaryStream(1)) {
                    return reader.read(in);
                }
            }
        }
    }

    public boolean exists(long loadId) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM RAW_FILE WHERE LOAD_ID = ?", Integer.class, loadId);
        return n != null && n > 0;
    }

    /** Earlier loads of the same provider with byte-identical content (duplicate file check). */
    public List<Long> findEarlierLoadsWithSameContent(String providerCode, String sha256, long excludeLoadId) {
        return jdbc.queryForList("SELECT r.LOAD_ID FROM RAW_FILE r JOIN LOAD_RUN l ON l.LOAD_ID = r.LOAD_ID "
                        + "WHERE l.PROVIDER_CODE = ? AND r.SHA256 = ? AND r.LOAD_ID <> ? ORDER BY r.LOAD_ID",
                Long.class, providerCode, sha256, excludeLoadId);
    }

    public int purgeOlderThan(Timestamp cutoff) {
        return jdbc.update("DELETE FROM RAW_FILE WHERE CREATED_AT < ?", cutoff);
    }
}
