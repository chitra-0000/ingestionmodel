package com.bank.ingestion.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * All tunables in one place (prefix "ingestion" in application.properties).
 */
@ConfigurationProperties(prefix = "ingestion")
public class IngestionProperties {

    /** Worker threads that transform and insert records in parallel. */
    private int workers = 4;
    /** Rows per JDBC batch / commit. */
    private int batchSize = 5000;
    /** Records handed from the reader thread to a worker in one unit. */
    private int queueChunkSize = 1000;
    /** Records read for schema extraction and mapping preview (bounded sample). */
    private int sampleRecords = 1000;
    /** Records transformed when previewing a mapping in the UI. */
    private int previewRecords = 200;
    /** Max element events scanned to detect the repeating record element. */
    private int maxScanElements = 300000;
    /** Load is flagged DQ_THRESHOLD_BREACHED (not publishable) above this reject percentage. */
    private double maxRejectPercent = 1.0;
    /** Detail rows stored per (rule, field) per load; all occurrences are still counted. */
    private int maxIssueSamplesPerRule = 1000;
    /** Day-month order for ambiguous slash dates such as 03/04/1970: DMY or MDY. */
    private String slashDateOrder = "DMY";
    /** Raw files older than this are purged by the retention job. */
    private int rawRetentionDays = 160;
    /** Folder where approved mappings are written as .xsl + .json for the next integration. */
    private String mappingStoreDir = "./mapping-store";
    /** Scratch folder for compressing uploads before they are streamed into the BLOB. */
    private String workDir = "./work";
    /** Fetch size for streaming reads (export, subscriber API). */
    private int fetchSize = 5000;
    /** Upper bound for one subscriber API page. */
    private int maxApiPageSize = 5000;
    /** Allowed browser origin for the Angular app. */
    private String allowedOrigin = "http://localhost:4200";

    public int getWorkers() { return workers; }
    public void setWorkers(int workers) { this.workers = workers; }
    public int getBatchSize() { return batchSize; }
    public void setBatchSize(int batchSize) { this.batchSize = batchSize; }
    public int getQueueChunkSize() { return queueChunkSize; }
    public void setQueueChunkSize(int queueChunkSize) { this.queueChunkSize = queueChunkSize; }
    public int getSampleRecords() { return sampleRecords; }
    public void setSampleRecords(int sampleRecords) { this.sampleRecords = sampleRecords; }
    public int getPreviewRecords() { return previewRecords; }
    public void setPreviewRecords(int previewRecords) { this.previewRecords = previewRecords; }
    public int getMaxScanElements() { return maxScanElements; }
    public void setMaxScanElements(int maxScanElements) { this.maxScanElements = maxScanElements; }
    public double getMaxRejectPercent() { return maxRejectPercent; }
    public void setMaxRejectPercent(double maxRejectPercent) { this.maxRejectPercent = maxRejectPercent; }
    public int getMaxIssueSamplesPerRule() { return maxIssueSamplesPerRule; }
    public void setMaxIssueSamplesPerRule(int maxIssueSamplesPerRule) { this.maxIssueSamplesPerRule = maxIssueSamplesPerRule; }
    public String getSlashDateOrder() { return slashDateOrder; }
    public void setSlashDateOrder(String slashDateOrder) { this.slashDateOrder = slashDateOrder; }
    public int getRawRetentionDays() { return rawRetentionDays; }
    public void setRawRetentionDays(int rawRetentionDays) { this.rawRetentionDays = rawRetentionDays; }
    public String getMappingStoreDir() { return mappingStoreDir; }
    public void setMappingStoreDir(String mappingStoreDir) { this.mappingStoreDir = mappingStoreDir; }
    public String getWorkDir() { return workDir; }
    public void setWorkDir(String workDir) { this.workDir = workDir; }
    public int getFetchSize() { return fetchSize; }
    public void setFetchSize(int fetchSize) { this.fetchSize = fetchSize; }
    public int getMaxApiPageSize() { return maxApiPageSize; }
    public void setMaxApiPageSize(int maxApiPageSize) { this.maxApiPageSize = maxApiPageSize; }
    public String getAllowedOrigin() { return allowedOrigin; }
    public void setAllowedOrigin(String allowedOrigin) { this.allowedOrigin = allowedOrigin; }
}
