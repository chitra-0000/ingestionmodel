package com.bank.ingestion.domain;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * One field of the common record object. Defined in canonical-model.json so the model and its
 * data-quality rules can change without code changes.
 */
public class CanonicalField {

    public enum Type { STRING, DATE, COUNTRY, ENUM }

    private String name;
    private Type type = Type.STRING;
    private int maxLength = 200;
    private boolean mandatory;
    /** When the source repeats the value inside a record, keep all of them joined with '|' (else the first). */
    private boolean joinMultiple;
    private String description;
    /** Source field names (normalised: lower case, letters and digits only) used by the rule-based generator. */
    private List<String> synonyms = new ArrayList<>();
    /** ENUM only: allowed canonical values. */
    private List<String> allowedValues = new ArrayList<>();
    /** ENUM only: source value (normalised) to canonical value, e.g. "male" -> "M". */
    private Map<String, String> valueAliases = new LinkedHashMap<>();

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Type getType() { return type; }
    public void setType(Type type) { this.type = type; }
    public int getMaxLength() { return maxLength; }
    public void setMaxLength(int maxLength) { this.maxLength = maxLength; }
    public boolean isMandatory() { return mandatory; }
    public void setMandatory(boolean mandatory) { this.mandatory = mandatory; }
    public boolean isJoinMultiple() { return joinMultiple; }
    public void setJoinMultiple(boolean joinMultiple) { this.joinMultiple = joinMultiple; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public List<String> getSynonyms() { return synonyms; }
    public void setSynonyms(List<String> synonyms) { this.synonyms = synonyms; }
    public List<String> getAllowedValues() { return allowedValues; }
    public void setAllowedValues(List<String> allowedValues) { this.allowedValues = allowedValues; }
    public Map<String, String> getValueAliases() { return valueAliases; }
    public void setValueAliases(Map<String, String> valueAliases) { this.valueAliases = valueAliases; }

    /** Column width in the target table. Dates are stored as ISO text so partial dates (1970, 1970-05) survive. */
    public int columnLength() {
        switch (type) {
            case DATE:
                return 10;
            case COUNTRY:
                return 2;
            default:
                return maxLength;
        }
    }
}
