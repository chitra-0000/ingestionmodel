package com.bank.ingestion.service.source;

import org.w3c.dom.Document;

import java.util.List;

/** One source record handed from the reader thread to a worker. */
public final class RecordData {

    private final long recordNo;
    private final Document document;
    /** Values of paths the approved mapping does not know (schema drift), as {path, value}. Null when none. */
    private final List<String[]> newPathValues;
    /** Set when the record cannot be transformed at all (for example a CSV row with the wrong column count). */
    private final String rejectRule;
    private final String rejectMessage;

    private RecordData(long recordNo, Document document, List<String[]> newPathValues, String rejectRule, String rejectMessage) {
        this.recordNo = recordNo;
        this.document = document;
        this.newPathValues = newPathValues;
        this.rejectRule = rejectRule;
        this.rejectMessage = rejectMessage;
    }

    public static RecordData of(long recordNo, Document document, List<String[]> newPathValues) {
        return new RecordData(recordNo, document, newPathValues, null, null);
    }

    public static RecordData rejected(long recordNo, String rule, String message) {
        return new RecordData(recordNo, null, null, rule, message);
    }

    public long getRecordNo() { return recordNo; }
    public Document getDocument() { return document; }
    public List<String[]> getNewPathValues() { return newPathValues; }
    public String getRejectRule() { return rejectRule; }
    public String getRejectMessage() { return rejectMessage; }
    public boolean isRejected() { return rejectRule != null; }
}
