package com.bank.ingestion.web;

import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.service.RecordQueryService;
import com.bank.ingestion.util.ApiException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Subscriber API ("Expose subscriber API"): the latest published version of each list, read page by page.
 * <pre>
 * GET /api/v1/lists
 * GET /api/v1/lists/{provider}/{format}/records?afterRecordNo=0&amp;limit=1000[&amp;loadId=...]
 * </pre>
 * Only COMPLETED / COMPLETED_WITH_WARNINGS loads are served. Authentication (SSO / API keys) is outside this POC.
 */
@RestController
@RequestMapping("/api/v1/lists")
public class SubscriberController {

    private final RecordQueryService records;

    public SubscriberController(RecordQueryService records) {
        this.records = records;
    }

    @GetMapping
    public List<Map<String, Object>> lists() {
        return records.publishedLists();
    }

    @GetMapping("/{provider}/{format}/records")
    public Map<String, Object> page(@PathVariable String provider, @PathVariable String format,
                                    @RequestParam(value = "loadId", required = false) Long loadId,
                                    @RequestParam(value = "afterRecordNo", defaultValue = "0") long afterRecordNo,
                                    @RequestParam(value = "limit", defaultValue = "1000") int limit) {
        FileFormat f;
        try {
            f = FileFormat.valueOf(format.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            throw ApiException.badRequest("format must be XML or CSV");
        }
        return records.page(provider, f, loadId, Math.max(0, afterRecordNo), limit);
    }
}
