package com.bank.ingestion.service.source;

import com.bank.ingestion.config.XmlSecurity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Set;

/**
 * Streams an XML file with StAX and cuts it into one small DOM document per record element, so the
 * heap stays flat whatever the file size. Namespaces are dropped (local names only) so mappings use
 * plain paths. The record path may end with "*" to take every child of a parent element as a record,
 * e.g. /PFA/Records/* for files that mix Person and Entity records.
 */
public final class XmlRecordReader implements RecordReader {

    private static final XMLInputFactory FACTORY = XmlSecurity.newXmlInputFactory();

    private final XMLStreamReader xml;
    private final String[] segments;
    private final PathTrie trie;
    private final ValueVisitor visitor;
    private final boolean buildDocument;
    private final DocumentBuilder builder;

    private int depth;
    private int matched;
    private long recordNo;
    private long skippedSiblings;

    /**
     * @param knownPaths    paths known to the approved mapping (drift detection) or null
     * @param visitor       receives every value (schema profiling) or null
     * @param buildDocument false when only the visitor is needed
     */
    public XmlRecordReader(InputStream in, String recordPath, Set<String> knownPaths, ValueVisitor visitor,
                           boolean buildDocument) throws XMLStreamException {
        synchronized (FACTORY) {
            this.xml = FACTORY.createXMLStreamReader(in);
        }
        this.segments = splitPath(recordPath);
        this.trie = new PathTrie(knownPaths);
        this.visitor = visitor;
        this.buildDocument = buildDocument;
        this.builder = buildDocument ? XmlSecurity.newDocumentBuilder() : null;
    }

    public static String[] splitPath(String recordPath) {
        String p = recordPath == null ? "" : recordPath.trim();
        while (p.startsWith("/")) {
            p = p.substring(1);
        }
        if (p.isEmpty()) {
            throw new IllegalArgumentException("Record path is empty");
        }
        return p.split("/");
    }

    @Override
    public RecordData next() throws XMLStreamException {
        while (xml.hasNext()) {
            int event = xml.next();
            if (event == XMLStreamConstants.START_ELEMENT) {
                depth++;
                if (matched == depth - 1 && depth <= segments.length && matches(segments[depth - 1], xml.getLocalName())) {
                    matched = depth;
                    if (matched == segments.length) {
                        recordNo++;
                        RecordData record = readRecord();
                        depth--;
                        matched = depth;
                        return record;
                    }
                } else if (matched == depth - 1 && depth == segments.length) {
                    skippedSiblings++;
                }
            } else if (event == XMLStreamConstants.END_ELEMENT) {
                depth--;
                if (matched > depth) {
                    matched = depth;
                }
            }
        }
        return null;
    }

    private static boolean matches(String segment, String name) {
        return "*".equals(segment) || segment.equals(name);
    }

    /** Reads the record subtree; the reader is positioned on the record's START_ELEMENT. */
    private RecordData readRecord() throws XMLStreamException {
        Document doc = null;
        Deque<Element> elements = new ArrayDeque<>();
        Deque<PathTrie.Node> nodes = new ArrayDeque<>();
        Deque<StringBuilder> texts = new ArrayDeque<>();
        List<String[]> newValues = null;

        if (buildDocument) {
            doc = builder.newDocument();
            doc.setStrictErrorChecking(false);
            Element root = doc.createElement(xml.getLocalName());
            doc.appendChild(root);
            elements.push(root);
        }
        nodes.push(trie.root());
        texts.push(new StringBuilder(0));
        newValues = readAttributes(doc == null ? null : elements.peek(), trie.root(), newValues);

        while (xml.hasNext()) {
            int event = xml.next();
            if (event == XMLStreamConstants.START_ELEMENT) {
                PathTrie.Node node = trie.child(nodes.peek(), xml.getLocalName());
                nodes.push(node);
                texts.push(new StringBuilder(0));
                Element el = null;
                if (doc != null) {
                    el = doc.createElement(xml.getLocalName());
                    elements.peek().appendChild(el);
                    elements.push(el);
                }
                newValues = readAttributes(el, node, newValues);
            } else if (event == XMLStreamConstants.CHARACTERS || event == XMLStreamConstants.CDATA) {
                if (!xml.isWhiteSpace()) {
                    String text = xml.getText();
                    texts.peek().append(text);
                    if (doc != null) {
                        elements.peek().appendChild(doc.createTextNode(text));
                    }
                }
            } else if (event == XMLStreamConstants.END_ELEMENT) {
                PathTrie.Node node = nodes.pop();
                StringBuilder text = texts.pop();
                if (doc != null) {
                    elements.pop();
                }
                if (text.length() > 0 && !node.path().isEmpty()) {
                    newValues = onValue(node, node.path(), text.toString(), newValues);
                }
                if (nodes.isEmpty()) {
                    break;
                }
            }
        }
        if (visitor != null) {
            visitor.endRecord(recordNo);
        }
        return RecordData.of(recordNo, doc, newValues);
    }

    private List<String[]> readAttributes(Element el, PathTrie.Node owner, List<String[]> newValues) {
        List<String[]> result = newValues;
        int count = xml.getAttributeCount();
        for (int i = 0; i < count; i++) {
            String name = xml.getAttributeLocalName(i);
            String value = xml.getAttributeValue(i);
            if (el != null) {
                el.setAttribute(name, value);
            }
            if (value != null && !value.isEmpty()) {
                String path = trie.attributePath(owner, name);
                result = onValue(null, path, value, result);
            }
        }
        return result;
    }

    private List<String[]> onValue(PathTrie.Node node, String path, String value, List<String[]> newValues) {
        if (visitor != null) {
            visitor.value(recordNo, path, value);
        }
        boolean known = node != null ? trie.isKnown(node) : trie.isKnown(path);
        if (known) {
            return newValues;
        }
        List<String[]> result = newValues == null ? new ArrayList<String[]>(2) : newValues;
        result.add(new String[]{path, value});
        return result;
    }

    @Override
    public long skippedSiblingElements() {
        return skippedSiblings;
    }

    @Override
    public void close() {
        try {
            xml.close();
        } catch (XMLStreamException e) {
            // Closing the StAX reader only releases parser state; the underlying stream is closed by its owner.
        }
    }
}
