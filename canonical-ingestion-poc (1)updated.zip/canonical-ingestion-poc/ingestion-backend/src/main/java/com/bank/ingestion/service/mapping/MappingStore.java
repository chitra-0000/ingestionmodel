package com.bank.ingestion.service.mapping;

import com.bank.ingestion.config.IngestionProperties;
import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.domain.MappingDefinition;
import com.bank.ingestion.repository.MappingRepository;
import com.bank.ingestion.util.Texts;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Approved mappings on disk, so they survive a database reset and can be committed to Git or copied to
 * the next environment:
 * <pre>
 * mapping-store/
 *   DJ/XML/v1.xsl      the stylesheet
 *   DJ/XML/v1.json     record path, field mappings, known paths, fingerprint, approver
 * </pre>
 * At startup every version missing from MAPPING_DEFINITION is imported (H2 restarts, new environments).
 */
@Component
public class MappingStore {

    private static final Logger LOG = LoggerFactory.getLogger(MappingStore.class);
    private static final Pattern VERSION_FILE = Pattern.compile("^v(\\d{1,6})\\.json$");

    private final Path root;
    private final ObjectMapper json;

    public MappingStore(IngestionProperties props, ObjectMapper objectMapper) {
        this.root = Paths.get(props.getMappingStoreDir()).toAbsolutePath().normalize();
        this.json = objectMapper.copy().enable(SerializationFeature.INDENT_OUTPUT);
    }

    /** Writes v{n}.xsl and v{n}.json atomically (temp file + move); returns the relative store path. */
    public String write(MappingDefinition m) throws IOException {
        Path dir = folder(m.getProviderCode(), m.getFormat());
        Files.createDirectories(dir);
        String base = "v" + m.getVersionNo();
        writeAtomically(dir.resolve(base + ".xsl"), m.getXslt().getBytes(StandardCharsets.UTF_8));
        MappingDefinition meta = copyWithoutXslt(m);
        writeAtomically(dir.resolve(base + ".json"), json.writeValueAsBytes(meta));
        return root.relativize(dir.resolve(base + ".xsl")).toString().replace('\\', '/');
    }

    /** Reads every stored version (for the startup import). Invalid files are skipped with a warning. */
    public List<MappingDefinition> readAll() {
        List<MappingDefinition> result = new ArrayList<>();
        if (!Files.isDirectory(root)) {
            return result;
        }
        try (DirectoryStream<Path> providers = Files.newDirectoryStream(root)) {
            for (Path providerDir : providers) {
                for (FileFormat format : FileFormat.values()) {
                    Path dir = providerDir.resolve(format.name());
                    if (Files.isDirectory(dir)) {
                        readFolder(providerDir.getFileName().toString(), format, dir, result);
                    }
                }
            }
        } catch (IOException e) {
            LOG.warn("Cannot scan mapping store {}: {}", root, e.getMessage());
        }
        return result;
    }

    private void readFolder(String provider, FileFormat format, Path dir, List<MappingDefinition> result) throws IOException {
        try (DirectoryStream<Path> files = Files.newDirectoryStream(dir, "v*.json")) {
            for (Path meta : files) {
                Matcher m = VERSION_FILE.matcher(meta.getFileName().toString());
                Path xsl = dir.resolve(meta.getFileName().toString().replace(".json", ".xsl"));
                if (!m.matches() || !Files.isRegularFile(xsl)) {
                    continue;
                }
                try {
                    MappingDefinition def = json.readValue(meta.toFile(), MappingDefinition.class);
                    def.setProviderCode(Texts.requireProviderCode(provider));
                    def.setFormat(format);
                    def.setVersionNo(Integer.parseInt(m.group(1)));
                    def.setXslt(new String(Files.readAllBytes(xsl), StandardCharsets.UTF_8));
                    def.setStorePath(root.relativize(xsl).toString().replace('\\', '/'));
                    if (def.getStatus() == null) {
                        def.setStatus(MappingRepository.STATUS_APPROVED);
                    }
                    result.add(def);
                } catch (IOException | RuntimeException e) {
                    LOG.warn("Skipping unreadable mapping file {}: {}", meta.getFileName(), e.getMessage());
                }
            }
        }
    }

    /** Provider code and format are whitelisted, and the result must stay inside the store (path traversal guard). */
    private Path folder(String providerCode, FileFormat format) {
        Path dir = root.resolve(Texts.requireProviderCode(providerCode)).resolve(format.name()).normalize();
        if (!dir.startsWith(root)) {
            throw new IllegalArgumentException("Mapping folder outside the store");
        }
        return dir;
    }

    private static void writeAtomically(Path target, byte[] content) throws IOException {
        Path tmp = Files.createTempFile(target.getParent(), ".tmp-", ".part");
        try {
            Files.write(tmp, content);
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    private static MappingDefinition copyWithoutXslt(MappingDefinition m) {
        MappingDefinition c = new MappingDefinition();
        c.setProviderCode(m.getProviderCode());
        c.setFormat(m.getFormat());
        c.setVersionNo(m.getVersionNo());
        c.setSchemaFingerprint(m.getSchemaFingerprint());
        c.setRecordPath(m.getRecordPath());
        c.setFieldMappings(m.getFieldMappings());
        c.setKnownPaths(m.getKnownPaths());
        c.setCustomXslt(m.isCustomXslt());
        c.setStatus(m.getStatus());
        c.setGeneratedBy(m.getGeneratedBy());
        c.setApprovedBy(m.getApprovedBy());
        c.setApprovedAt(m.getApprovedAt());
        return c;
    }

    public Path root() {
        return root;
    }
}
