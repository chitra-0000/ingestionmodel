package com.bank.ingestion.service.mapping;

import com.bank.ingestion.domain.CanonicalField;
import com.bank.ingestion.domain.FieldMapping;
import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.domain.SchemaProfile;
import com.bank.ingestion.service.CanonicalModel;
import com.bank.ingestion.util.Texts;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Matches source paths to canonical fields by name: exact synonym (90), parent+leaf synonym (85),
 * name contains a synonym (60), synonym contains the name (50). Coverage in the sample and shallow
 * paths win ties. Each source path is used by at most one field unless the match is exact.
 */
@Component
public class RuleBasedMappingGenerator implements MappingGenerator {

    public static final String NAME = "RULE_BASED";

    private static final int EXACT = 90;
    private static final int PARENT_EXACT = 85;
    private static final int CONTAINS = 60;
    private static final int CONTAINED = 50;
    private static final int MIN_SCORE = 50;
    private static final int MIN_FUZZY_LENGTH = 4;

    private final CanonicalModel model;

    public RuleBasedMappingGenerator(CanonicalModel model) {
        this.model = model;
    }

    @Override
    public String name() {
        return NAME;
    }

    @Override
    public List<FieldMapping> suggest(SchemaProfile profile) {
        List<Candidate> candidates = new ArrayList<>();
        int sample = Math.max(1, profile.getSampleRecordCount());
        for (CanonicalField field : model.fields()) {
            for (SchemaProfile.PathInfo path : profile.getPaths()) {
                int base = score(field, path.getPath());
                if (base >= MIN_SCORE) {
                    double coverage = (double) path.getRecordsWithValue() / sample;
                    double rank = base + coverage * 5 - Math.min(depth(path.getPath()), 5);
                    candidates.add(new Candidate(field, path, base, rank));
                }
            }
        }
        candidates.sort((a, b) -> Double.compare(b.rank, a.rank));

        Map<String, FieldMapping> chosen = new LinkedHashMap<>();
        Map<String, List<Candidate>> exactByField = new HashMap<>();
        Set<String> usedPaths = new HashSet<>();
        // A path that is an exact name match for some field is reserved for exact matches:
        // "Country" must not go to NATIONALITY by similarity when it is exactly COUNTRY_CODE.
        Set<String> exactPaths = new HashSet<>();
        for (Candidate c : candidates) {
            if (c.score >= EXACT) {
                exactPaths.add(c.path.getPath());
                exactByField.computeIfAbsent(c.field.getName(), k -> new ArrayList<>()).add(c);
            }
        }
        for (Candidate c : candidates) {
            String fieldName = c.field.getName();
            boolean weak = c.score < EXACT;
            if (chosen.containsKey(fieldName) || (weak && (usedPaths.contains(c.path.getPath()) || exactPaths.contains(c.path.getPath())))) {
                continue;
            }
            boolean multi = c.field.isJoinMultiple() && c.path.getMaxPerRecord() > 1;
            chosen.put(fieldName, new FieldMapping(fieldName, c.path.getPath(), multi, Math.min(99, c.score),
                    c.score >= PARENT_EXACT ? "SYNONYM" : "NAME_SIMILARITY"));
            usedPaths.add(c.path.getPath());
        }
        combineExactAlternatives(chosen, exactByField);
        applyFallbacks(profile, chosen);

        List<FieldMapping> result = new ArrayList<>();
        for (CanonicalField f : model.fields()) {
            FieldMapping m = chosen.get(f.getName());
            result.add(m != null ? m : new FieldMapping(f.getName(), "", false, 0, "NONE"));
        }
        return result;
    }

    /**
     * Two exact matches for one field (Person/Residence and Entity/Country -> COUNTRY_CODE) become an
     * XPath union: the first one present in each record wins.
     */
    private static void combineExactAlternatives(Map<String, FieldMapping> chosen, Map<String, List<Candidate>> exactByField) {
        for (Map.Entry<String, List<Candidate>> e : exactByField.entrySet()) {
            FieldMapping m = chosen.get(e.getKey());
            if (m == null || e.getValue().size() < 2 || m.isMultiValued()) {
                continue;
            }
            Set<String> usedElsewhere = new HashSet<>();
            for (FieldMapping other : chosen.values()) {
                if (other != m) {
                    usedElsewhere.add(other.getExpression());
                }
            }
            StringBuilder union = new StringBuilder();
            for (Candidate c : e.getValue()) {
                if (usedElsewhere.contains(c.path.getPath())) {
                    continue;
                }
                if (union.length() > 0) {
                    union.append(" | ");
                }
                union.append(c.path.getPath());
            }
            m.setExpression(union.toString());
        }
    }

    private void applyFallbacks(SchemaProfile profile, Map<String, FieldMapping> chosen) {
        if (profile.getFormat() == FileFormat.XML && !chosen.containsKey("RECORD_TYPE") && model.field("RECORD_TYPE") != null) {
            chosen.put("RECORD_TYPE", new FieldMapping("RECORD_TYPE", "local-name()", false, 70, "RECORD_ELEMENT_NAME"));
        }
        FieldMapping first = chosen.get("FIRST_NAME");
        FieldMapping last = chosen.get("LAST_NAME");
        if (!chosen.containsKey("FULL_NAME") && model.field("FULL_NAME") != null && first != null && last != null) {
            chosen.put("FULL_NAME", new FieldMapping("FULL_NAME",
                    "normalize-space(concat(" + first.getExpression() + ", ' ', " + last.getExpression() + "))",
                    false, 60, "COMPOSED"));
        }
    }

    private static int score(CanonicalField field, String path) {
        // Record type is a property of the record itself, not of a nested element (avoids Name/@type).
        if ("RECORD_TYPE".equals(field.getName()) && depth(path) > 0) {
            return 0;
        }
        String[] segs = path.split("/");
        String leaf = Texts.normaliseName(segs[segs.length - 1]);
        String parentLeaf = segs.length > 1 ? Texts.normaliseName(segs[segs.length - 2]) + leaf : null;
        int best = 0;
        for (String s : field.getSynonyms()) {
            if (s.equals(leaf)) {
                return EXACT;
            }
            if (s.equals(parentLeaf)) {
                best = Math.max(best, PARENT_EXACT);
            } else if (leaf.length() >= MIN_FUZZY_LENGTH && s.length() >= MIN_FUZZY_LENGTH && leaf.contains(s)) {
                best = Math.max(best, CONTAINS);
            } else if (leaf.length() >= MIN_FUZZY_LENGTH && s.contains(leaf)) {
                best = Math.max(best, CONTAINED);
            }
        }
        return best;
    }

    private static int depth(String path) {
        int d = 0;
        for (int i = 0; i < path.length(); i++) {
            if (path.charAt(i) == '/') {
                d++;
            }
        }
        return d;
    }

    private static final class Candidate {
        private final CanonicalField field;
        private final SchemaProfile.PathInfo path;
        private final int score;
        private final double rank;

        Candidate(CanonicalField field, SchemaProfile.PathInfo path, int score, double rank) {
            this.field = field;
            this.path = path;
            this.score = score;
            this.rank = rank;
        }
    }
}
