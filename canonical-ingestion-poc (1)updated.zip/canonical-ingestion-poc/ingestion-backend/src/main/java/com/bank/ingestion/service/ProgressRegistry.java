package com.bank.ingestion.service;

import org.springframework.stereotype.Component;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/** Live record counters for running loads, read by the status endpoint while the UI polls. */
@Component
public class ProgressRegistry {

    /** Progress of one running load. */
    public static final class Progress {
        private final AtomicLong records = new AtomicLong();
        private final long startNanos = System.nanoTime();

        public void add(long n) {
            records.addAndGet(n);
        }

        public long records() {
            return records.get();
        }

        public double recordsPerSecond() {
            double seconds = (System.nanoTime() - startNanos) / 1e9;
            return seconds <= 0 ? 0 : Math.round(records.get() / seconds);
        }
    }

    private final ConcurrentHashMap<Long, Progress> running = new ConcurrentHashMap<>();

    public Progress start(long loadId) {
        Progress p = new Progress();
        running.put(loadId, p);
        return p;
    }

    public Progress get(long loadId) {
        return running.get(loadId);
    }

    public void finish(long loadId) {
        running.remove(loadId);
    }
}
