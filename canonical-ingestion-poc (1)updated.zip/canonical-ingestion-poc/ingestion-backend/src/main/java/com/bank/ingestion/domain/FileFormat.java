package com.bank.ingestion.domain;

/** Supported source formats. Each provider + format pair gets its own target table. */
public enum FileFormat {
    XML,
    CSV
}
