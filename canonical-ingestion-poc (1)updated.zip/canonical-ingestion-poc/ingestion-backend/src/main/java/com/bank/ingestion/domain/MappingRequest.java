package com.bank.ingestion.domain;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;

/** Body of "validate" and "approve" calls from the mapping review screen. */
public class MappingRequest {

    @NotBlank
    @Size(max = 500)
    private String recordPath;

    @Valid
    @Size(max = 100)
    private List<FieldMapping> fieldMappings = new ArrayList<>();

    /** Only used when customXslt is true (advanced edit); otherwise the XSLT is generated from fieldMappings. */
    @Size(max = 200_000)
    private String xslt;

    private boolean customXslt;

    /** Required for approve. In production this comes from SSO, not from the request body. */
    @Size(max = 100)
    @Pattern(regexp = "^[\\p{L}0-9 ._@-]*$", message = "contains invalid characters")
    private String approvedBy;

    public String getRecordPath() { return recordPath; }
    public void setRecordPath(String recordPath) { this.recordPath = recordPath; }
    public List<FieldMapping> getFieldMappings() { return fieldMappings; }
    public void setFieldMappings(List<FieldMapping> fieldMappings) { this.fieldMappings = fieldMappings; }
    public String getXslt() { return xslt; }
    public void setXslt(String xslt) { this.xslt = xslt; }
    public boolean isCustomXslt() { return customXslt; }
    public void setCustomXslt(boolean customXslt) { this.customXslt = customXslt; }
    public String getApprovedBy() { return approvedBy; }
    public void setApprovedBy(String approvedBy) { this.approvedBy = approvedBy; }
}
