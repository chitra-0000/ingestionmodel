package com.bank.ingestion.service.mapping;

import com.bank.ingestion.config.XmlSecurity;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Static check of a stylesheet before it is compiled (Fortify: XSLT injection).
 * Mappings can be hand-edited (and later AI-generated), so only a small, safe subset of XSLT is allowed:
 * <ul>
 *   <li>XSL elements from a whitelist (no import/include/result-document/message/processing-instruction)</li>
 *   <li>literal output elements r, f, x only (the output contract)</li>
 *   <li>no file/URL/environment functions (document, unparsed-text, system-property, ...)</li>
 *   <li>no extension functions or extension namespaces</li>
 * </ul>
 * Attribute values are checked after XML parsing, so character-reference tricks such as
 * &amp;#100;ocument( are caught too. The compiler itself also runs with secure processing on.
 */
@Component
public class XsltSecurityValidator {

    public static final String XSL_NS = "http://www.w3.org/1999/XSL/Transform";

    private static final Set<String> ALLOWED_XSL = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
            "stylesheet", "transform", "output", "template", "value-of", "for-each", "if", "choose", "when",
            "otherwise", "text", "variable", "param", "with-param", "call-template", "apply-templates", "sort",
            "attribute", "copy-of", "strip-space", "preserve-space", "key")));
    private static final Set<String> ALLOWED_LITERALS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList("r", "f", "x")));

    private static final Pattern FORBIDDEN_FUNCTION = Pattern.compile(
            "(?<![\\w.-])(document|doc|doc-available|unparsed-text|unparsed-text-lines|unparsed-text-available|collection|"
                    + "uri-collection|system-property|environment-variable|available-environment-variables|function-available|"
                    + "element-available|unparsed-entity-uri|transform|load-xquery-module)\\s*\\(");
    /** prefix:function( - extension functions such as java:java.lang.Runtime.exec( */
    private static final Pattern PREFIXED_FUNCTION = Pattern.compile("(?<![\\w.-])([A-Za-z_][\\w.-]*):[A-Za-z_][\\w.-]*\\s*\\(");

    public List<String> check(String xslt) {
        List<String> errors = new ArrayList<>();
        if (xslt == null || xslt.trim().isEmpty()) {
            errors.add("XSLT is empty");
            return errors;
        }
        Document doc;
        try {
            doc = XmlSecurity.newDocumentBuilder().parse(new InputSource(new StringReader(xslt)));
        } catch (SAXException | IOException e) {
            errors.add("XSLT is not well-formed XML: " + e.getMessage());
            return errors;
        }
        Element root = doc.getDocumentElement();
        if (!XSL_NS.equals(root.getNamespaceURI())
                || !("stylesheet".equals(root.getLocalName()) || "transform".equals(root.getLocalName()))) {
            errors.add("Root element must be xsl:stylesheet");
        }
        if (root.hasAttribute("extension-element-prefixes")) {
            errors.add("extension-element-prefixes is not allowed");
        }
        walk(root, errors);
        return errors;
    }

    private void walk(Element el, List<String> errors) {
        String ns = el.getNamespaceURI();
        String name = el.getLocalName();
        if (XSL_NS.equals(ns)) {
            if (!ALLOWED_XSL.contains(name)) {
                errors.add("xsl:" + name + " is not allowed");
            }
        } else if (ns != null || !ALLOWED_LITERALS.contains(name)) {
            errors.add("Output element <" + el.getTagName() + "> is not allowed (only r, f, x)");
        }
        NamedNodeMap attrs = el.getAttributes();
        for (int i = 0; i < attrs.getLength(); i++) {
            Attr a = (Attr) attrs.item(i);
            if ("http://www.w3.org/2000/xmlns/".equals(a.getNamespaceURI())) {
                if (!XSL_NS.equals(a.getValue())) {
                    errors.add("Namespace declaration " + a.getName() + " is not allowed");
                }
                continue;
            }
            checkExpression(a.getValue(), errors);
        }
        NodeList children = el.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child.getNodeType() == Node.ELEMENT_NODE) {
                walk((Element) child, errors);
            } else if (child.getNodeType() == Node.PROCESSING_INSTRUCTION_NODE) {
                errors.add("Processing instructions are not allowed");
            }
        }
    }

    private static void checkExpression(String value, List<String> errors) {
        Matcher m = FORBIDDEN_FUNCTION.matcher(value);
        if (m.find()) {
            errors.add("Function " + m.group(1) + "() is not allowed");
        }
        Matcher p = PREFIXED_FUNCTION.matcher(value);
        if (p.find()) {
            errors.add("Extension function call '" + p.group() + "' is not allowed");
        }
    }
}
