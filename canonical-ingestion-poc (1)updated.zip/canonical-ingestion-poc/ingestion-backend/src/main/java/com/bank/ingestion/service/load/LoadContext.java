package com.bank.ingestion.service.load;

import com.bank.ingestion.service.ProgressRegistry;
import com.bank.ingestion.service.dq.DqStats;
import com.bank.ingestion.service.source.RecordData;

import javax.xml.transform.Templates;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/** State shared by the reader thread and the workers of one load. */
final class LoadContext {

    /** End-of-input marker, one per worker. Compared by identity. */
    static final List<RecordData> POISON = Collections.emptyList();

    final long loadId;
    final String providerCode;
    final String fileFormat;
    final String table;
    final int mappingVersion;
    final Templates templates;
    final String insertSql;
    final int batchSize;
    final DqStats stats;
    final ProgressRegistry.Progress progress;
    final BlockingQueue<List<RecordData>> queue;
    final AtomicReference<Throwable> failure = new AtomicReference<>();

    @SuppressWarnings("squid:S00107") // immutable holder for one load; a builder would add nothing here
    LoadContext(long loadId, String providerCode, String fileFormat, String table, int mappingVersion,
                Templates templates, String insertSql, int batchSize, DqStats stats,
                ProgressRegistry.Progress progress, BlockingQueue<List<RecordData>> queue) {
        this.loadId = loadId;
        this.providerCode = providerCode;
        this.fileFormat = fileFormat;
        this.table = table;
        this.mappingVersion = mappingVersion;
        this.templates = templates;
        this.insertSql = insertSql;
        this.batchSize = batchSize;
        this.stats = stats;
        this.progress = progress;
        this.queue = queue;
    }

    void fail(Throwable t) {
        failure.compareAndSet(null, t);
    }

    boolean failed() {
        return failure.get() != null;
    }

    /** Bounded hand-off: waits while workers are busy (back-pressure), gives up if the load has failed. */
    boolean offer(List<RecordData> chunk) throws InterruptedException {
        while (!failed()) {
            if (queue.offer(chunk, 500, TimeUnit.MILLISECONDS)) {
                return true;
            }
        }
        return false;
    }
}
