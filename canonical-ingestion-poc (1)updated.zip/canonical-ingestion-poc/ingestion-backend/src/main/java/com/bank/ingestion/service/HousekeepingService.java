package com.bank.ingestion.service;

import com.bank.ingestion.config.IngestionProperties;
import com.bank.ingestion.domain.MappingDefinition;
import com.bank.ingestion.repository.LoadRunRepository;
import com.bank.ingestion.repository.MappingRepository;
import com.bank.ingestion.repository.RawFileRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Startup: loads interrupted by a restart are marked FAILED, and approved mappings from the mapping
 * store are imported if the database does not have them (H2 restart, new environment).
 * Nightly: raw files older than the retention period are purged.
 */
@Service
public class HousekeepingService {

    private static final Logger LOG = LoggerFactory.getLogger(HousekeepingService.class);

    private final IngestionProperties props;
    private final LoadRunRepository loads;
    private final MappingRepository mappings;
    private final RawFileRepository rawFiles;
    private final com.bank.ingestion.service.mapping.MappingStore store;

    public HousekeepingService(IngestionProperties props, LoadRunRepository loads, MappingRepository mappings,
                               RawFileRepository rawFiles, com.bank.ingestion.service.mapping.MappingStore store) {
        this.props = props;
        this.loads = loads;
        this.mappings = mappings;
        this.rawFiles = rawFiles;
        this.store = store;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void onStartup() {
        for (Long id : loads.findInterrupted()) {
            loads.markFailed(id, "Interrupted by a server restart. Upload the file again.", 0);
            LOG.warn("Load {} marked FAILED (interrupted by restart)", id);
        }
        importStoredMappings();
    }

    void importStoredMappings() {
        List<MappingDefinition> stored = store.readAll();
        Map<String, MappingDefinition> latest = new HashMap<>();
        int imported = 0;
        for (MappingDefinition m : stored) {
            if (!mappings.exists(m.getProviderCode(), m.getFormat(), m.getVersionNo())) {
                m.setMappingId(mappings.nextId());
                mappings.insert(m);
                imported++;
                String key = m.getProviderCode() + "/" + m.getFormat();
                MappingDefinition current = latest.get(key);
                if (current == null || current.getVersionNo() < m.getVersionNo()) {
                    latest.put(key, m);
                }
            }
        }
        for (MappingDefinition m : latest.values()) {
            mappings.retireOthers(m.getProviderCode(), m.getFormat(), m.getMappingId());
        }
        LOG.info("Mapping store {}: {} version(s) found, {} imported", store.root(), stored.size(), imported);
    }

    /** Daily at 02:15 server time. */
    @Scheduled(cron = "0 15 2 * * *")
    public void purgeOldRawFiles() {
        Timestamp cutoff = new Timestamp(System.currentTimeMillis() - TimeUnit.DAYS.toMillis(props.getRawRetentionDays()));
        int n = rawFiles.purgeOlderThan(cutoff);
        LOG.info("Retention: purged {} raw file(s) older than {} days", n, props.getRawRetentionDays());
    }
}
