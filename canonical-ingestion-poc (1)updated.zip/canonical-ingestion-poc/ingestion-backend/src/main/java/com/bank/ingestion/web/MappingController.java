package com.bank.ingestion.web;

import com.bank.ingestion.domain.CanonicalField;
import com.bank.ingestion.domain.MappingDefinition;
import com.bank.ingestion.repository.MappingRepository;
import com.bank.ingestion.service.CanonicalModel;
import com.bank.ingestion.util.ApiException;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.util.List;

/** Mapping registry (all approved versions) and the canonical model. */
@RestController
@RequestMapping("/api")
public class MappingController {

    private final MappingRepository mappings;
    private final CanonicalModel model;

    public MappingController(MappingRepository mappings, CanonicalModel model) {
        this.mappings = mappings;
        this.model = model;
    }

    @GetMapping("/mappings")
    public List<MappingDefinition> all() {
        List<MappingDefinition> list = mappings.findAll();
        for (MappingDefinition m : list) {
            m.setXslt(null);
        }
        return list;
    }

    @GetMapping("/mappings/{mappingId}")
    public MappingDefinition one(@PathVariable long mappingId) {
        return mappings.findById(mappingId).orElseThrow(() -> ApiException.notFound("Mapping " + mappingId + " not found"));
    }

    @GetMapping("/mappings/{mappingId}/xslt")
    public ResponseEntity<String> xslt(@PathVariable long mappingId) {
        MappingDefinition m = one(mappingId);
        String fileName = m.getProviderCode() + "_" + m.getFormat() + "_v" + m.getVersionNo() + ".xsl";
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(fileName).build().toString())
                .contentType(new MediaType("application", "xslt+xml", StandardCharsets.UTF_8))
                .body(m.getXslt());
    }

    @GetMapping("/canonical-model")
    public List<CanonicalField> canonicalModel() {
        return model.fields();
    }
}
