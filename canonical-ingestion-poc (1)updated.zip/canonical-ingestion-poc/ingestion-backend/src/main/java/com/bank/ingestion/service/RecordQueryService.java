package com.bank.ingestion.service;

import com.bank.ingestion.config.IngestionProperties;
import com.bank.ingestion.domain.DqIssue;
import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.domain.LoadRun;
import com.bank.ingestion.domain.LoadStatus;
import com.bank.ingestion.repository.DqIssueRepository;
import com.bank.ingestion.repository.LoadRunRepository;
import com.bank.ingestion.repository.TargetTableManager;
import com.bank.ingestion.util.ApiException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Reads canonical records back out: "Generate CSV / XML" (streamed, fetch-size bounded) and the
 * subscriber API (keyset pagination on the primary key, so page 5,000 costs the same as page 1).
 */
@Service
public class RecordQueryService {

    private static final XMLOutputFactory XML_OUT = XMLOutputFactory.newInstance();

    private final IngestionProperties props;
    private final LoadRunRepository loads;
    private final TargetTableManager tables;
    private final DqIssueRepository issues;
    private final JdbcTemplate streaming;
    private final ObjectMapper json;

    public RecordQueryService(IngestionProperties props, LoadRunRepository loads, TargetTableManager tables,
                              DqIssueRepository issues, DataSource dataSource, ObjectMapper json) {
        this.props = props;
        this.loads = loads;
        this.tables = tables;
        this.issues = issues;
        this.json = json;
        this.streaming = new JdbcTemplate(dataSource);
        this.streaming.setFetchSize(props.getFetchSize());
    }

    public LoadRun requireExportable(long loadId) {
        LoadRun run = loads.find(loadId).orElseThrow(() -> ApiException.notFound("Load " + loadId + " not found"));
        LoadStatus s = run.getStatus();
        if (!(s.isPublishable() || s == LoadStatus.DQ_THRESHOLD_BREACHED)) {
            throw ApiException.conflict("Load " + loadId + " is " + s + "; records can be exported once it has completed");
        }
        return run;
    }

    private String selectSql(String table) {
        return "SELECT RECORD_NO, DQ_STATUS, " + String.join(", ", tables.dataColumns()) + ", "
                + TargetTableManager.EXTRA_ATTRS + ", " + TargetTableManager.EXTRA_ATTRS_CLOB + " FROM "
                + TargetTableManager.requireSafe(table);
    }

    // ---------------------------------------------------------------- export

    public void exportCsv(LoadRun run, OutputStream os) throws IOException {
        List<String> cols = tables.dataColumns();
        Writer w = new BufferedWriter(new OutputStreamWriter(os, StandardCharsets.UTF_8), 1 << 16);
        w.write('﻿');
        w.write("RECORD_NO,DQ_STATUS," + String.join(",", cols) + ",EXTRA_ATTRS\r\n");
        streaming.query(selectSql(run.getTargetTable()) + " WHERE LOAD_ID = ? ORDER BY RECORD_NO", (RowCallbackHandler) rs -> {
            try {
                w.write(rs.getString(1));
                w.write(',');
                w.write(rs.getString(2));
                for (int i = 0; i < cols.size(); i++) {
                    w.write(',');
                    w.write(csvCell(rs.getString(3 + i)));
                }
                w.write(',');
                w.write(csvCell(extra(rs, cols.size())));
                w.write("\r\n");
            } catch (IOException e) {
                throw new ExportAbortedException(e);
            }
        }, run.getLoadId());
        w.flush();
    }

    public void exportXml(LoadRun run, OutputStream os) throws XMLStreamException {
        List<String> cols = tables.dataColumns();
        XMLStreamWriter x = XML_OUT.createXMLStreamWriter(os, "UTF-8");
        x.writeStartDocument("UTF-8", "1.0");
        x.writeStartElement("canonicalRecords");
        x.writeAttribute("provider", run.getProviderCode());
        x.writeAttribute("format", run.getFormat().name());
        x.writeAttribute("loadId", String.valueOf(run.getLoadId()));
        x.writeAttribute("mappingVersion", String.valueOf(run.getMappingVersion()));
        streaming.query(selectSql(run.getTargetTable()) + " WHERE LOAD_ID = ? ORDER BY RECORD_NO", (RowCallbackHandler) rs -> {
            try {
                x.writeStartElement("record");
                x.writeAttribute("recordNo", rs.getString(1));
                x.writeAttribute("dqStatus", rs.getString(2));
                for (int i = 0; i < cols.size(); i++) {
                    String v = rs.getString(3 + i);
                    if (v != null) {
                        x.writeStartElement(cols.get(i));
                        x.writeCharacters(xmlSafe(v));
                        x.writeEndElement();
                    }
                }
                String extra = extra(rs, cols.size());
                if (extra != null) {
                    x.writeStartElement("EXTRA_ATTRS");
                    x.writeCharacters(xmlSafe(extra));
                    x.writeEndElement();
                }
                x.writeEndElement();
            } catch (XMLStreamException e) {
                throw new ExportAbortedException(e);
            }
        }, run.getLoadId());
        x.writeEndElement();
        x.writeEndDocument();
        x.flush();
        x.close();
    }

    public void exportIssuesCsv(long loadId, OutputStream os) throws IOException {
        Writer w = new BufferedWriter(new OutputStreamWriter(os, StandardCharsets.UTF_8));
        w.write('﻿');
        w.write("RECORD_NO,SEVERITY,RULE,FIELD,MESSAGE,VALUE\r\n");
        for (DqIssue i : issues.findByLoad(loadId, null, 100_000)) {
            w.write(i.getRecordNo() + "," + i.getSeverity() + "," + i.getRule() + "," + csvCell(i.getField()) + ","
                    + csvCell(i.getMessage()) + "," + csvCell(i.getRawValue()) + "\r\n");
        }
        w.flush();
    }

    /**
     * RFC 4180 quoting plus CSV/formula-injection protection (Fortify): cells starting with = + - @ or a
     * control character are prefixed with a single quote so spreadsheets do not evaluate them.
     */
    static String csvCell(String v) {
        if (v == null || v.isEmpty()) {
            return "";
        }
        String s = v;
        char first = s.charAt(0);
        if (first == '=' || first == '+' || first == '-' || first == '@' || first == '\t' || first == '\r') {
            s = "'" + s;
        }
        if (s.indexOf(',') >= 0 || s.indexOf('"') >= 0 || s.indexOf('\n') >= 0 || s.indexOf('\r') >= 0) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }

    /** Drops characters not allowed in XML 1.0 (source extras are stored as received). */
    static String xmlSafe(String v) {
        StringBuilder sb = null;
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            boolean ok = c == 0x9 || c == 0xA || c == 0xD || (c >= 0x20 && c <= 0xD7FF) || (c >= 0xE000 && c <= 0xFFFD)
                    || Character.isSurrogate(c);
            if (!ok && sb == null) {
                sb = new StringBuilder(v.length());
                sb.append(v, 0, i);
            } else if (ok && sb != null) {
                sb.append(c);
            }
        }
        return sb == null ? v : sb.toString();
    }

    private static String extra(ResultSet rs, int fieldCount) throws SQLException {
        String small = rs.getString(3 + fieldCount);
        return small != null ? small : rs.getString(4 + fieldCount);
    }

    // ---------------------------------------------------------------- subscriber API

    public List<Map<String, Object>> publishedLists() {
        List<Map<String, Object>> result = new ArrayList<>();
        for (LoadRun r : loads.findLatestPublished()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("provider", r.getProviderCode());
            m.put("format", r.getFormat());
            m.put("loadId", r.getLoadId());
            m.put("mappingVersion", r.getMappingVersion());
            m.put("records", r.getLoadedCount());
            m.put("status", r.getStatus());
            m.put("loadedAt", r.getFinishedAt());
            result.add(m);
        }
        return result;
    }

    public Map<String, Object> page(String providerRaw, FileFormat format, Long loadIdParam, long afterRecordNo, int limitParam) {
        String provider = com.bank.ingestion.util.Texts.requireProviderCode(providerRaw);
        int limit = Math.max(1, Math.min(limitParam, props.getMaxApiPageSize()));
        LoadRun run = resolveLoad(provider, format, loadIdParam);
        List<String> cols = tables.dataColumns();
        List<Map<String, Object>> records = streaming.query(selectSql(run.getTargetTable())
                        + " WHERE LOAD_ID = ? AND RECORD_NO > ? ORDER BY RECORD_NO FETCH FIRST ? ROWS ONLY",
                (rs, n) -> toRecord(rs, cols), run.getLoadId(), afterRecordNo, limit);
        Map<String, Object> page = new LinkedHashMap<>();
        page.put("provider", provider);
        page.put("format", format);
        page.put("loadId", run.getLoadId());
        page.put("mappingVersion", run.getMappingVersion());
        page.put("totalRecords", run.getLoadedCount());
        page.put("count", records.size());
        page.put("nextAfterRecordNo", records.size() == limit ? records.get(records.size() - 1).get("recordNo") : null);
        page.put("records", records);
        return page;
    }

    private LoadRun resolveLoad(String provider, FileFormat format, Long loadId) {
        if (loadId != null) {
            LoadRun run = loads.find(loadId).orElseThrow(() -> ApiException.notFound("Load " + loadId + " not found"));
            if (!run.getProviderCode().equals(provider) || run.getFormat() != format || !run.getStatus().isPublishable()) {
                throw ApiException.notFound("No published load " + loadId + " for " + provider + "/" + format);
            }
            return run;
        }
        for (LoadRun r : loads.findLatestPublished()) {
            if (r.getProviderCode().equals(provider) && r.getFormat() == format) {
                return r;
            }
        }
        throw ApiException.notFound("No published list for " + provider + "/" + format);
    }

    private Map<String, Object> toRecord(ResultSet rs, List<String> cols) throws SQLException {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("recordNo", rs.getLong(1));
        m.put("dqStatus", rs.getString(2));
        for (int i = 0; i < cols.size(); i++) {
            String v = rs.getString(3 + i);
            if (v != null) {
                m.put(cols.get(i), v);
            }
        }
        String extra = extra(rs, cols.size());
        if (extra != null) {
            try {
                JsonNode node = json.readTree(extra);
                m.put("extraAttributes", node);
            } catch (IOException e) {
                m.put("extraAttributes", extra);
            }
        }
        return m;
    }

    /** Unchecked wrapper so a client disconnect stops the JDBC row loop. */
    public static final class ExportAbortedException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        ExportAbortedException(Throwable cause) {
            super("Export aborted", cause);
        }
    }
}
