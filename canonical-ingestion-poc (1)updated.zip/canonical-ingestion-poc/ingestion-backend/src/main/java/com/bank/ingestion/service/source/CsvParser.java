package com.bank.ingestion.service.source;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

/**
 * Streaming RFC 4180 CSV parser: quoted fields, doubled quotes inside quotes, line breaks inside
 * quotes, CRLF or LF line endings. No external dependency, no whole-file buffering.
 */
public final class CsvParser {

    private static final int BUFFER = 1 << 16;

    private final Reader in;
    private final char delimiter;
    private final char[] buf = new char[BUFFER];
    private int pos;
    private int len;
    private boolean eof;
    private final StringBuilder field = new StringBuilder(64);
    private long physicalLine = 1;

    public CsvParser(Reader in, char delimiter) {
        this.in = in;
        this.delimiter = delimiter;
    }

    /** Delimiter with the most occurrences outside quotes in the header line: , ; | or tab. */
    public static char detectDelimiter(String headerLine) {
        char[] candidates = {',', ';', '|', '\t'};
        int[] counts = new int[candidates.length];
        boolean quoted = false;
        for (int i = 0; i < headerLine.length(); i++) {
            char c = headerLine.charAt(i);
            if (c == '"') {
                quoted = !quoted;
            } else if (!quoted) {
                for (int k = 0; k < candidates.length; k++) {
                    if (c == candidates[k]) {
                        counts[k]++;
                    }
                }
            }
        }
        int best = 0;
        for (int k = 1; k < candidates.length; k++) {
            if (counts[k] > counts[best]) {
                best = k;
            }
        }
        return candidates[best];
    }

    public long physicalLine() {
        return physicalLine;
    }

    /** @return the next record's fields, or null at end of input. Blank lines are skipped. */
    public List<String> next() throws IOException {
        while (true) {
            int c = read();
            if (c == -1) {
                return null;
            }
            if (c == '\r' || c == '\n') {
                consumeLineEnd(c);
                continue;
            }
            unread();
            return readRecord();
        }
    }

    private List<String> readRecord() throws IOException {
        List<String> fields = new ArrayList<>(24);
        field.setLength(0);
        boolean quoted = false;
        boolean wasQuoted = false;
        while (true) {
            int c = read();
            if (c == -1) {
                fields.add(field.toString());
                return fields;
            }
            if (quoted) {
                if (c == '"') {
                    int n = read();
                    if (n == '"') {
                        field.append('"');
                    } else {
                        quoted = false;
                        if (n != -1) {
                            unread();
                        }
                    }
                } else {
                    if (c == '\n') {
                        physicalLine++;
                    }
                    field.append((char) c);
                }
            } else if (c == '"' && field.length() == 0 && !wasQuoted) {
                quoted = true;
                wasQuoted = true;
            } else if (c == delimiter) {
                fields.add(field.toString());
                field.setLength(0);
                wasQuoted = false;
            } else if (c == '\r' || c == '\n') {
                consumeLineEnd(c);
                fields.add(field.toString());
                return fields;
            } else {
                field.append((char) c);
            }
        }
    }

    private void consumeLineEnd(int c) throws IOException {
        physicalLine++;
        if (c == '\r') {
            int n = read();
            if (n != '\n' && n != -1) {
                unread();
            }
        }
    }

    private int read() throws IOException {
        if (pos >= len) {
            if (eof) {
                return -1;
            }
            len = in.read(buf, 0, BUFFER);
            pos = 0;
            if (len <= 0) {
                eof = true;
                len = 0;
                return -1;
            }
        }
        return buf[pos++];
    }

    /** Only ever called right after a successful read(), so pos > 0. */
    private void unread() {
        pos--;
    }
}
