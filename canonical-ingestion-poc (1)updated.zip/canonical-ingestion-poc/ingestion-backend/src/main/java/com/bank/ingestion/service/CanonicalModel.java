package com.bank.ingestion.service;

import com.bank.ingestion.domain.CanonicalField;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/** The common record object, loaded once from canonical-model.json. */
@Component
public class CanonicalModel {

    private static final Pattern COLUMN_NAME = Pattern.compile("^[A-Z][A-Z0-9_]{0,29}$");

    private final List<CanonicalField> fields;
    private final Map<String, CanonicalField> byName;

    public CanonicalModel(ObjectMapper objectMapper) throws IOException {
        List<CanonicalField> loaded = new ArrayList<>();
        try (InputStream in = new ClassPathResource("canonical-model.json").getInputStream()) {
            JsonNode root = objectMapper.readTree(in);
            for (JsonNode node : root.path("fields")) {
                CanonicalField f = objectMapper.treeToValue(node, CanonicalField.class);
                // Field names become column names in generated DDL, so they must be safe identifiers.
                if (f.getName() == null || !COLUMN_NAME.matcher(f.getName()).matches()) {
                    throw new IllegalStateException("Invalid canonical field name: " + f.getName());
                }
                loaded.add(f);
            }
        }
        Map<String, CanonicalField> index = new LinkedHashMap<>();
        for (CanonicalField f : loaded) {
            index.put(f.getName(), f);
        }
        this.fields = Collections.unmodifiableList(loaded);
        this.byName = Collections.unmodifiableMap(index);
    }

    public List<CanonicalField> fields() {
        return fields;
    }

    public CanonicalField field(String name) {
        return byName.get(name);
    }

    public int indexOf(String name) {
        for (int i = 0; i < fields.size(); i++) {
            if (fields.get(i).getName().equals(name)) {
                return i;
            }
        }
        return -1;
    }
}
