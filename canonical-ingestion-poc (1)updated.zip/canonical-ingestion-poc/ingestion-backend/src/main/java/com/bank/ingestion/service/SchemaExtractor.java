package com.bank.ingestion.service;

import com.bank.ingestion.config.IngestionProperties;
import com.bank.ingestion.config.XmlSecurity;
import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.domain.SchemaProfile;
import com.bank.ingestion.repository.RawFileRepository;
import com.bank.ingestion.service.source.CsvRecordReader;
import com.bank.ingestion.service.source.RecordReader;
import com.bank.ingestion.service.source.XmlRecordReader;
import com.bank.ingestion.util.ApiException;
import com.bank.ingestion.util.Texts;
import org.springframework.stereotype.Service;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.GZIPInputStream;

/**
 * "Extract schema and bounded sample": finds the repeating record element and profiles the first N
 * records (paths, coverage, multi-valued paths, example values). Reads only the head of the stored file.
 */
@Service
public class SchemaExtractor {

    private static final int MAX_SAMPLES_PER_PATH = 5;
    private static final int MAX_SAMPLE_LENGTH = 80;
    private static final int MAX_CANDIDATES = 10;

    private final RawFileRepository rawFiles;
    private final IngestionProperties props;

    public SchemaExtractor(RawFileRepository rawFiles, IngestionProperties props) {
        this.rawFiles = rawFiles;
        this.props = props;
    }

    public static InputStream decompress(InputStream stored) throws IOException {
        return new BufferedInputStream(new GZIPInputStream(stored, 1 << 16), 1 << 16);
    }

    public SchemaProfile extract(long loadId, FileFormat format, String recordPathOverride) throws Exception {
        SchemaProfile profile = format == FileFormat.CSV ? extractCsv(loadId) : extractXml(loadId, recordPathOverride);
        profile.setFingerprint(fingerprint(profile));
        return profile;
    }

    public static String fingerprint(SchemaProfile profile) {
        List<String> paths = new ArrayList<>();
        for (SchemaProfile.PathInfo p : profile.getPaths()) {
            paths.add(p.getPath());
        }
        Collections.sort(paths);
        return Texts.sha256(profile.getFormat() + "|" + profile.getRecordPath() + "|" + String.join("\n", paths));
    }

    private SchemaProfile extractCsv(long loadId) throws Exception {
        return rawFiles.readContent(loadId, stored -> {
            PathStats stats = new PathStats();
            try (CsvRecordReader reader = new CsvRecordReader(decompress(stored), null, stats, false)) {
                int n = 0;
                while (n < props.getSampleRecords() && reader.next() != null) {
                    n++;
                }
                SchemaProfile p = new SchemaProfile();
                p.setFormat(FileFormat.CSV);
                p.setRecordPath(CsvRecordReader.RECORD_PATH);
                p.setRecordCandidates(Collections.singletonList(new SchemaProfile.RecordCandidate(CsvRecordReader.RECORD_PATH, n, 2)));
                p.setCsvDelimiter(reader.delimiter());
                p.setCsvColumns(reader.columns());
                p.setSampleRecordCount(n);
                // The header defines a CSV schema completely, so empty columns are still known paths.
                for (SchemaProfile.CsvColumn c : reader.columns()) {
                    stats.ensure(c.getElement());
                }
                p.setPaths(stats.result());
                if (n == 0) {
                    throw ApiException.badRequest("CSV file has a header but no data rows");
                }
                return p;
            }
        });
    }

    private SchemaProfile extractXml(long loadId, String recordPathOverride) throws Exception {
        List<SchemaProfile.RecordCandidate> candidates = rawFiles.readContent(loadId, stored -> scanCandidates(decompress(stored)));
        String recordPath = Texts.isBlank(recordPathOverride) ? null : normaliseRecordPath(recordPathOverride);
        if (recordPath == null) {
            if (candidates.isEmpty()) {
                throw ApiException.badRequest("No repeating record element found in the XML file");
            }
            recordPath = candidates.get(0).getPath();
        }
        final String chosen = recordPath;
        SchemaProfile profile = rawFiles.readContent(loadId, stored -> {
            PathStats stats = new PathStats();
            try (XmlRecordReader reader = new XmlRecordReader(decompress(stored), chosen, null, stats, false)) {
                int n = 0;
                while (n < props.getSampleRecords() && reader.next() != null) {
                    n++;
                }
                SchemaProfile p = new SchemaProfile();
                p.setFormat(FileFormat.XML);
                p.setRecordPath(chosen);
                p.setSampleRecordCount(n);
                p.setPaths(stats.result());
                return p;
            }
        });
        if (profile.getSampleRecordCount() == 0) {
            throw ApiException.badRequest("Record path " + chosen + " matches no elements");
        }
        profile.setRecordCandidates(candidates);
        return profile;
    }

    /** "/PFA/Records/*" style path: slash-separated XML names, optional trailing "*". */
    public static String normaliseRecordPath(String raw) {
        String p = raw.trim();
        if (!p.matches("^/?[A-Za-z_][\\w.-]*(/[A-Za-z_][\\w.-]*)*(/\\*)?$")) {
            throw ApiException.badRequest("Record path must look like /Root/Records/Record or /Root/Records/*");
        }
        return p.startsWith("/") ? p : "/" + p;
    }

    /**
     * Repeating elements that have child elements, shallowest first. When the best candidate has
     * sibling record types under the same parent (Person + Entity), "parent/*" is offered first.
     */
    List<SchemaProfile.RecordCandidate> scanCandidates(InputStream in) throws Exception {
        XMLInputFactory f = XmlSecurity.newXmlInputFactory();
        XMLStreamReader xml = f.createXMLStreamReader(in);
        Map<String, long[]> counts = new LinkedHashMap<>();
        Set<String> withChildren = new HashSet<>();
        Deque<String> stack = new ArrayDeque<>();
        int scanned = 0;
        try {
            while (xml.hasNext() && scanned < props.getMaxScanElements()) {
                int ev = xml.next();
                if (ev == XMLStreamConstants.START_ELEMENT) {
                    scanned++;
                    String parent = stack.isEmpty() ? "" : stack.peek();
                    if (!parent.isEmpty()) {
                        withChildren.add(parent);
                    }
                    String path = parent + "/" + xml.getLocalName();
                    stack.push(path);
                    long[] c = counts.get(path);
                    if (c == null) {
                        counts.put(path, new long[]{1});
                    } else {
                        c[0]++;
                    }
                } else if (ev == XMLStreamConstants.END_ELEMENT) {
                    stack.pop();
                }
            }
        } finally {
            xml.close();
        }
        List<SchemaProfile.RecordCandidate> list = new ArrayList<>();
        for (Map.Entry<String, long[]> e : counts.entrySet()) {
            if (e.getValue()[0] >= 2 && withChildren.contains(e.getKey())) {
                list.add(new SchemaProfile.RecordCandidate(e.getKey(), e.getValue()[0], depthOf(e.getKey())));
            }
        }
        list.sort((a, b) -> a.getDepth() != b.getDepth() ? Integer.compare(a.getDepth(), b.getDepth()) : Long.compare(b.getCount(), a.getCount()));
        addWildcardCandidate(list, counts, withChildren);
        return list.size() > MAX_CANDIDATES ? new ArrayList<>(list.subList(0, MAX_CANDIDATES)) : list;
    }

    private static void addWildcardCandidate(List<SchemaProfile.RecordCandidate> list, Map<String, long[]> counts, Set<String> withChildren) {
        if (list.isEmpty()) {
            return;
        }
        String best = list.get(0).getPath();
        String parent = best.substring(0, best.lastIndexOf('/'));
        if (parent.isEmpty()) {
            return;
        }
        long total = 0;
        int types = 0;
        for (Map.Entry<String, long[]> e : counts.entrySet()) {
            String p = e.getKey();
            if (p.startsWith(parent + "/") && p.indexOf('/', parent.length() + 1) < 0 && withChildren.contains(p)) {
                total += e.getValue()[0];
                types++;
            }
        }
        if (types > 1) {
            list.add(0, new SchemaProfile.RecordCandidate(parent + "/*", total, depthOf(best)));
        }
    }

    private static int depthOf(String path) {
        int d = 0;
        for (int i = 0; i < path.length(); i++) {
            if (path.charAt(i) == '/') {
                d++;
            }
        }
        return d;
    }

    /** Collects per-path statistics over the sampled records. */
    static final class PathStats implements RecordReader.ValueVisitor {
        private final Map<String, SchemaProfile.PathInfo> paths = new LinkedHashMap<>();
        private final Map<String, int[]> perRecord = new HashMap<>();

        void ensure(String path) {
            if (!paths.containsKey(path)) {
                SchemaProfile.PathInfo info = new SchemaProfile.PathInfo();
                info.setPath(path);
                paths.put(path, info);
            }
        }

        @Override
        public void value(long recordNo, String path, String value) {
            ensure(path);
            int[] c = perRecord.get(path);
            if (c == null) {
                perRecord.put(path, new int[]{1});
            } else {
                c[0]++;
            }
            SchemaProfile.PathInfo info = paths.get(path);
            if (info.getSamples().size() < MAX_SAMPLES_PER_PATH) {
                String v = Texts.truncate(value.trim(), MAX_SAMPLE_LENGTH);
                if (!v.isEmpty() && !info.getSamples().contains(v)) {
                    info.getSamples().add(v);
                }
            }
        }

        @Override
        public void endRecord(long recordNo) {
            for (Map.Entry<String, int[]> e : perRecord.entrySet()) {
                SchemaProfile.PathInfo info = paths.get(e.getKey());
                info.setRecordsWithValue(info.getRecordsWithValue() + 1);
                info.setMaxPerRecord(Math.max(info.getMaxPerRecord(), e.getValue()[0]));
            }
            perRecord.clear();
        }

        List<SchemaProfile.PathInfo> result() {
            return new ArrayList<>(paths.values());
        }
    }
}
