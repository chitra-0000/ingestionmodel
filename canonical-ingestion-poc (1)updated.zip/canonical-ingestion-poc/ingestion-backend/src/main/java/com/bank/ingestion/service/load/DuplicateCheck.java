package com.bank.ingestion.service.load;

import com.bank.ingestion.domain.DqIssue;
import com.bank.ingestion.repository.DqIssueRepository;
import com.bank.ingestion.repository.TargetTableManager;
import com.bank.ingestion.service.dq.DqStats;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Set-based duplicate check after the load (keeps the heap flat): SOURCE_RECORD_ID must be unique within
 * a file. The first occurrence is kept; later ones are removed from the target table and reported.
 * The window query only runs when the cheap GROUP BY has found duplicates.
 */
@Component
public class DuplicateCheck {

    public static final String RULE_DUPLICATE_KEY = "DUPLICATE_KEY";
    private static final int DELETE_BATCH = 1000;

    private final JdbcTemplate jdbc;
    private final DqIssueRepository issues;

    public DuplicateCheck(JdbcTemplate jdbc, DqIssueRepository issues) {
        this.jdbc = jdbc;
        this.issues = issues;
    }

    /** @return number of duplicate rows removed */
    public long run(String table, long loadId, DqStats stats) {
        TargetTableManager.requireSafe(table);
        Long dupKeys = jdbc.queryForObject("SELECT COUNT(*) FROM (SELECT SOURCE_RECORD_ID FROM " + table
                + " WHERE LOAD_ID = ? GROUP BY SOURCE_RECORD_ID HAVING COUNT(*) > 1) d", Long.class, loadId);
        if (dupKeys == null || dupKeys == 0) {
            return 0;
        }
        List<Object[]> rows = jdbc.query("SELECT RECORD_NO, SOURCE_RECORD_ID, FIRST_NO FROM ("
                        + "SELECT RECORD_NO, SOURCE_RECORD_ID, MIN(RECORD_NO) OVER (PARTITION BY SOURCE_RECORD_ID) FIRST_NO, "
                        + "COUNT(*) OVER (PARTITION BY SOURCE_RECORD_ID) CNT FROM " + table + " WHERE LOAD_ID = ?) t "
                        + "WHERE CNT > 1 AND RECORD_NO > FIRST_NO ORDER BY RECORD_NO",
                (rs, n) -> new Object[]{rs.getLong(1), rs.getString(2), rs.getLong(3)}, loadId);

        List<DqIssue> details = new ArrayList<>();
        List<Object[]> deletes = new ArrayList<>(DELETE_BATCH);
        for (Object[] r : rows) {
            long recordNo = (Long) r[0];
            DqIssue issue = new DqIssue(recordNo, "SOURCE_RECORD_ID", RULE_DUPLICATE_KEY, DqIssue.Severity.REJECT,
                    "Duplicate of record " + r[2] + "; first occurrence kept", (String) r[1]);
            if (stats.count(issue)) {
                details.add(issue);
            }
            deletes.add(new Object[]{loadId, recordNo});
            if (deletes.size() == DELETE_BATCH) {
                jdbc.batchUpdate("DELETE FROM " + table + " WHERE LOAD_ID = ? AND RECORD_NO = ?", deletes);
                deletes.clear();
            }
        }
        if (!deletes.isEmpty()) {
            jdbc.batchUpdate("DELETE FROM " + table + " WHERE LOAD_ID = ? AND RECORD_NO = ?", deletes);
        }
        issues.insertAll(loadId, details);
        return rows.size();
    }
}
