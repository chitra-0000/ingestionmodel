package com.bank.ingestion.service.mapping;

import com.bank.ingestion.config.XmlSecurity;
import org.springframework.stereotype.Component;

import javax.xml.transform.ErrorListener;
import javax.xml.transform.Templates;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

/** Security check + compile. A compiled {@link Templates} is thread-safe and shared by all workers. */
@Component
public class XsltCompiler {

    private final XsltSecurityValidator validator;

    public XsltCompiler(XsltSecurityValidator validator) {
        this.validator = validator;
    }

    /** Result of a compile attempt: either templates or the reasons it failed. */
    public static final class Result {
        private final Templates templates;
        private final List<String> errors;

        Result(Templates templates, List<String> errors) {
            this.templates = templates;
            this.errors = errors;
        }

        public Templates templates() {
            return templates;
        }

        public List<String> errors() {
            return errors;
        }

        public boolean ok() {
            return templates != null && errors.isEmpty();
        }
    }

    public Result compile(String xslt) {
        List<String> errors = validator.check(xslt);
        if (!errors.isEmpty()) {
            return new Result(null, errors);
        }
        final List<String> compileErrors = new ArrayList<>();
        TransformerFactory factory = XmlSecurity.newTransformerFactory();
        factory.setErrorListener(new ErrorListener() {
            @Override
            public void warning(TransformerException e) {
                // Warnings do not stop compilation.
            }

            @Override
            public void error(TransformerException e) {
                compileErrors.add(e.getMessageAndLocation());
            }

            @Override
            public void fatalError(TransformerException e) {
                compileErrors.add(e.getMessageAndLocation());
            }
        });
        try {
            Templates t = factory.newTemplates(new StreamSource(new StringReader(xslt)));
            return new Result(t, compileErrors);
        } catch (TransformerConfigurationException e) {
            if (compileErrors.isEmpty()) {
                compileErrors.add("XSLT does not compile: " + e.getMessageAndLocation());
            }
            return new Result(null, compileErrors);
        }
    }
}
