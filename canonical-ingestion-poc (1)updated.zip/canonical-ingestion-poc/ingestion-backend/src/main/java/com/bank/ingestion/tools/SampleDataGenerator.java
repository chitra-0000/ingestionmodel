package com.bank.ingestion.tools;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Locale;
import java.util.Random;

/**
 * Generates provider-like test files with realistic data-quality defects, for volume and DQ testing.
 * No Spring dependency; run after "mvn compile":
 * <pre>
 *   java -cp target/classes com.bank.ingestion.tools.SampleDataGenerator xml 5000000 sample-5m.xml
 *   java -cp target/classes com.bank.ingestion.tools.SampleDataGenerator csv 5000000 sample-5m.csv
 *   java -cp target/classes com.bank.ingestion.tools.SampleDataGenerator xml-drift 1000 sample-drift.xml
 * </pre>
 * XML: /SanctionsList/Records with Person and Entity records plus a CountryList reference section.
 * "xml-drift" adds a new PlaceOfBirth element to every person (schema drift test).
 * Injected defects (approximate rates): missing name 0.05% (reject), duplicate id 0.02% (reject),
 * invalid date 0.5%, unknown country 0.3%, control characters in CSV 0.1% (warnings).
 */
public final class SampleDataGenerator {

    private static final String[] FIRST = {"John", "Maria", "Ahmed", "Wei", "Olga", "Rahul", "Fatima", "Carlos", "Yuki", "Ivan",
            "Priya", "Hassan", "Elena", "Kofi", "Anna", "Mohammed", "Lucia", "Dmitri", "Aisha", "Pierre", "José", "Zoë"};
    private static final String[] LAST = {"Smith", "Garcia", "Khan", "Zhang", "Petrova", "Sharma", "Hussein", "Lopez", "Tanaka",
            "Ivanov", "Iyer", "Rahman", "Rossi", "Mensah", "Novak", "Ali", "Fernández", "Volkov", "Bello", "Dubois", "Müller"};
    private static final String[] ORG = {"Trading", "Shipping", "Holdings", "Industries", "Logistics", "Petroleum", "Finance", "Minerals"};
    private static final String[] ORG_SUFFIX = {"LLC", "Ltd", "GmbH", "SA", "FZE", "JSC", "Pvt Ltd"};
    /** Mix of alpha-2, alpha-3 and English names, as providers really send them. */
    private static final String[] COUNTRY = {"IN", "IND", "India", "RU", "RUS", "Russia", "IR", "Iran", "DE", "Germany",
            "AE", "ARE", "United Arab Emirates", "CN", "China", "GB", "United Kingdom", "US", "USA", "SY", "Syria", "KP", "VE"};
    private static final String[] LISTS = {"OFAC SDN", "EU Consolidated", "UN 1267", "HMT", "PEP", "MAS"};
    private static final String[] ACTIONS = {"add", "chg", "del", "add", "add", "chg"};
    private static final String[] GENDER = {"Male", "Female", "M", "F", "male", "Unknown"};

    private final Random rnd = new Random(42); // NOSONAR: deterministic test data, not security relevant
    private final boolean drift;

    private SampleDataGenerator(boolean drift) {
        this.drift = drift;
    }

    public static void main(String[] args) throws IOException {
        if (args.length != 3) {
            throw new IllegalArgumentException("Usage: SampleDataGenerator xml|csv|xml-drift <records> <outputFile>");
        }
        String kind = args[0].toLowerCase(Locale.ROOT);
        long count = Long.parseLong(args[1]);
        Path out = Paths.get(args[2]).toAbsolutePath().normalize();
        long t0 = System.currentTimeMillis();
        try (Writer w = new BufferedWriter(Files.newBufferedWriter(out, StandardCharsets.UTF_8), 1 << 20)) {
            SampleDataGenerator g = new SampleDataGenerator(kind.endsWith("drift"));
            if (kind.startsWith("xml")) {
                g.xml(w, count);
            } else {
                g.csv(w, count);
            }
        }
        System.out.printf("Wrote %,d records to %s (%,d MB) in %d s%n", count, out, Files.size(out) >> 20, // NOSONAR CLI tool
                (System.currentTimeMillis() - t0) / 1000);
    }

    // ------------------------------------------------------------------ XML

    private void xml(Writer w, long count) throws IOException {
        w.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<SanctionsList date=\"2026-11-01\" provider=\"SAMPLE\">\n");
        w.write("  <Header><Publisher>Sample Data Ltd</Publisher><RecordCount>" + count + "</RecordCount></Header>\n");
        w.write("  <CountryList>\n");
        for (String c : new String[]{"IN|India", "RU|Russia", "IR|Iran", "DE|Germany", "AE|United Arab Emirates", "GB|United Kingdom"}) {
            String[] p = c.split("\\|");
            w.write("    <Country code=\"" + p[0] + "\" name=\"" + p[1] + "\"/>\n");
        }
        w.write("  </CountryList>\n  <Records>\n");
        String lastId = "P0000001";
        for (long i = 1; i <= count; i++) {
            boolean entity = rnd.nextInt(10) == 0;
            String id = (entity ? "E" : "P") + String.format("%07d", i);
            if (i > 1 && chance(2)) {
                id = lastId;
            }
            lastId = id;
            if (entity) {
                writeEntity(w, id);
            } else {
                writePerson(w, id);
            }
        }
        w.write("  </Records>\n</SanctionsList>\n");
    }

    private void writePerson(Writer w, String id) throws IOException {
        String first = pick(FIRST);
        String last = pick(LAST);
        StringBuilder sb = new StringBuilder(512);
        sb.append("    <Person id=\"").append(id).append("\" action=\"").append(pick(ACTIONS))
                .append("\" date=\"").append(date(true)).append("\">")
                .append("<Gender>").append(pick(GENDER)).append("</Gender><NameDetails><Name type=\"Primary\">");
        if (!chance(5)) {
            sb.append("<FullName>").append(esc(nameWithDefects(first + " " + last, true))).append("</FullName>");
        }
        sb.append("<FirstName>").append(esc(first)).append("</FirstName><Surname>").append(esc(last)).append("</Surname></Name>");
        if (rnd.nextInt(10) < 3) {
            sb.append("<Name type=\"AKA\"><FullName>").append(esc(pick(FIRST) + " " + last)).append("</FullName></Name>");
        }
        sb.append("</NameDetails><DateOfBirth>").append(dob()).append("</DateOfBirth>")
                .append("<Nationality>").append(esc(country())).append("</Nationality>")
                .append("<Residence>").append(esc(country())).append("</Residence>");
        if (drift) {
            sb.append("<PlaceOfBirth>").append(pick(new String[]{"Mumbai", "Tehran", "Moscow", "Berlin"})).append("</PlaceOfBirth>");
        }
        appendLists(sb);
        if (rnd.nextInt(5) == 0) {
            sb.append("<Remarks>").append(esc("Listed under programme " + pick(LISTS) + ", passport ref " + rnd.nextInt(999999))).append("</Remarks>");
        }
        sb.append("</Person>\n");
        w.write(sb.toString());
    }

    private void writeEntity(Writer w, String id) throws IOException {
        StringBuilder sb = new StringBuilder(384);
        sb.append("    <Entity id=\"").append(id).append("\" action=\"").append(pick(ACTIONS))
                .append("\" date=\"").append(date(true)).append("\"><NameDetails><Name type=\"Primary\">");
        if (!chance(5)) {
            sb.append("<FullName>").append(esc(pick(LAST) + " " + pick(ORG) + " " + pick(ORG_SUFFIX))).append("</FullName>");
        }
        sb.append("</Name></NameDetails><Country>").append(esc(country())).append("</Country>");
        appendLists(sb);
        sb.append("</Entity>\n");
        w.write(sb.toString());
    }

    private void appendLists(StringBuilder sb) {
        sb.append("<SanctionsReferences>");
        int n = 1 + rnd.nextInt(2);
        for (int k = 0; k < n; k++) {
            sb.append("<Reference list=\"").append(pick(LISTS)).append("\"/>");
        }
        sb.append("</SanctionsReferences>");
    }

    // ------------------------------------------------------------------ CSV

    private void csv(Writer w, long count) throws IOException {
        w.write("uid,type,full_name,first_name,last_name,dob,gender,nationality,country,program,action,last_updated,remarks,place_of_birth\r\n");
        String lastId = "C0000001";
        StringBuilder sb = new StringBuilder(512);
        for (long i = 1; i <= count; i++) {
            boolean entity = rnd.nextInt(10) == 0;
            String id = "C" + String.format("%07d", i);
            if (i > 1 && chance(2)) {
                id = lastId;
            }
            lastId = id;
            String first = entity ? "" : pick(FIRST);
            String last = entity ? "" : pick(LAST);
            String full = entity ? pick(LAST) + " " + pick(ORG) + ", " + pick(ORG_SUFFIX) : first + " " + last;
            sb.setLength(0);
            sb.append(id).append(',').append(entity ? "Entity" : "Individual").append(',')
                    .append(cell(chance(5) ? "" : nameWithDefects(full, false))).append(',')
                    .append(cell(first)).append(',').append(cell(last)).append(',')
                    .append(entity ? "" : dob()).append(',').append(entity ? "" : pick(GENDER)).append(',')
                    .append(cell(entity ? "" : country())).append(',').append(cell(country())).append(',')
                    .append(cell(pick(LISTS))).append(',').append(pick(ACTIONS)).append(',').append(date(false)).append(',')
                    .append(cell(rnd.nextInt(5) == 0 ? "Note: \"see programme\" " + pick(LISTS) : "")).append(',')
                    .append(cell(entity ? "" : pick(new String[]{"Mumbai", "Tehran", "Moscow", "Berlin"})))
                    .append("\r\n");
            w.write(sb.toString());
        }
    }

    private static String cell(String v) {
        if (v.indexOf(',') >= 0 || v.indexOf('"') >= 0 || v.indexOf('\n') >= 0) {
            return "\"" + v.replace("\"", "\"\"") + "\"";
        }
        return v;
    }

    // ------------------------------------------------------------------ helpers

    /** Rate in units of 1/10,000. */
    private boolean chance(int perTenThousand) {
        return rnd.nextInt(10_000) < perTenThousand;
    }

    /** XML 1.0 cannot carry control characters, so XML gets messy whitespace (cleaned silently) instead. */
    private String nameWithDefects(String name, boolean xml) {
        if (!chance(10)) {
            return name;
        }
        return xml ? "  " + name.replace(" ", "\u00A0 ") + " " : name.replace(" ", " \u0007");
    }

    private String dob() {
        if (chance(50)) {
            return rnd.nextBoolean() ? "31/02/1975" : "unknown";
        }
        int y = 1940 + rnd.nextInt(60);
        int m = 1 + rnd.nextInt(12);
        int d = 1 + rnd.nextInt(28);
        switch (rnd.nextInt(4)) {
            case 0:
                return String.format("%04d-%02d-%02d", y, m, d);
            case 1:
                return String.format("%02d/%02d/%04d", d, m, y);
            case 2:
                return String.format("%02d %s %04d", d, new String[]{"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug",
                        "Sep", "Oct", "Nov", "Dec"}[m - 1], y);
            default:
                return String.valueOf(y);
        }
    }

    private String date(boolean iso) {
        int m = 1 + rnd.nextInt(10);
        int d = 1 + rnd.nextInt(28);
        return iso ? String.format("2026-%02d-%02d", m, d) : String.format("%02d/%02d/2026", d, m);
    }

    private String country() {
        return chance(30) ? "Atlantis" : pick(COUNTRY);
    }

    private String pick(String[] values) {
        return values[rnd.nextInt(values.length)];
    }

    private static String esc(String v) {
        return v.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
