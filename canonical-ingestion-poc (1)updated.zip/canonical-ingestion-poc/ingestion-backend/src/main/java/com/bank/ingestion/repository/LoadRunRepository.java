package com.bank.ingestion.repository;

import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.domain.LoadRun;
import com.bank.ingestion.domain.LoadStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public class LoadRunRepository {

    private static final String COLUMNS = "LOAD_ID, PROVIDER_CODE, FILE_FORMAT, ORIGINAL_NAME, UPLOADED_BY, STATUS, "
            + "STATUS_MESSAGE, SIZE_BYTES, SHA256, SCHEMA_FINGERPRINT, RECORD_PATH, MAPPING_ID, MAPPING_VERSION, "
            + "TARGET_TABLE, SOURCE_COUNT, LOADED_COUNT, REJECTED_COUNT, DUPLICATE_COUNT, WARNING_COUNT, NEW_PATH_COUNT, "
            + "RECONCILED, STORE_MS, SCHEMA_MS, TRANSFORM_MS, DQ_MS, TOTAL_MS, CREATED_AT, FINISHED_AT";

    private static final int MAX_MESSAGE = 1000;

    private final JdbcTemplate jdbc;

    public LoadRunRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public long nextId() {
        Long id = jdbc.queryForObject("SELECT LOAD_SEQ.NEXTVAL FROM DUAL", Long.class);
        if (id == null) {
            throw new IllegalStateException("LOAD_SEQ returned no value");
        }
        return id;
    }

    public void insert(long loadId, String providerCode, FileFormat format, String originalName, String uploadedBy) {
        jdbc.update("INSERT INTO LOAD_RUN (LOAD_ID, PROVIDER_CODE, FILE_FORMAT, ORIGINAL_NAME, UPLOADED_BY, STATUS, CREATED_AT) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?)",
                loadId, providerCode, format.name(), originalName, uploadedBy, LoadStatus.STORED.name(),
                new Timestamp(System.currentTimeMillis()));
    }

    public void markStored(long loadId, long sizeBytes, String sha256, long storeMs, String message) {
        jdbc.update("UPDATE LOAD_RUN SET SIZE_BYTES = ?, SHA256 = ?, STORE_MS = ?, STATUS_MESSAGE = ? WHERE LOAD_ID = ?",
                sizeBytes, sha256, storeMs, cut(message), loadId);
    }

    public void updateStatus(long loadId, LoadStatus status, String message) {
        jdbc.update("UPDATE LOAD_RUN SET STATUS = ?, STATUS_MESSAGE = ? WHERE LOAD_ID = ?",
                status.name(), cut(message), loadId);
    }

    public void saveSchema(long loadId, String fingerprint, String recordPath, String schemaJson, long schemaMs) {
        jdbc.update("UPDATE LOAD_RUN SET SCHEMA_FINGERPRINT = ?, RECORD_PATH = ?, SCHEMA_JSON = ?, SCHEMA_MS = ? WHERE LOAD_ID = ?",
                fingerprint, recordPath, schemaJson, schemaMs, loadId);
    }

    public Optional<String> findSchemaJson(long loadId) {
        List<String> rows = jdbc.queryForList("SELECT SCHEMA_JSON FROM LOAD_RUN WHERE LOAD_ID = ?", String.class, loadId);
        return rows.isEmpty() || rows.get(0) == null ? Optional.empty() : Optional.of(rows.get(0));
    }

    public void assignMapping(long loadId, long mappingId, int version, String targetTable) {
        jdbc.update("UPDATE LOAD_RUN SET MAPPING_ID = ?, MAPPING_VERSION = ?, TARGET_TABLE = ? WHERE LOAD_ID = ?",
                mappingId, version, targetTable, loadId);
    }

    public void saveResult(LoadRun r, String dqProfileJson) {
        jdbc.update("UPDATE LOAD_RUN SET STATUS = ?, STATUS_MESSAGE = ?, SOURCE_COUNT = ?, LOADED_COUNT = ?, REJECTED_COUNT = ?, "
                        + "DUPLICATE_COUNT = ?, WARNING_COUNT = ?, NEW_PATH_COUNT = ?, RECONCILED = ?, DQ_PROFILE_JSON = ?, "
                        + "TRANSFORM_MS = ?, DQ_MS = ?, TOTAL_MS = ?, FINISHED_AT = ? WHERE LOAD_ID = ?",
                r.getStatus().name(), cut(r.getStatusMessage()), r.getSourceCount(), r.getLoadedCount(), r.getRejectedCount(),
                r.getDuplicateCount(), r.getWarningCount(), r.getNewPathCount(),
                r.getReconciled() == null ? null : (r.getReconciled() ? 1 : 0), dqProfileJson,
                r.getTransformMs(), r.getDqMs(), r.getTotalMs(), new Timestamp(System.currentTimeMillis()), r.getLoadId());
    }

    public void markFailed(long loadId, String message, long totalMs) {
        jdbc.update("UPDATE LOAD_RUN SET STATUS = ?, STATUS_MESSAGE = ?, TOTAL_MS = ?, FINISHED_AT = ? WHERE LOAD_ID = ?",
                LoadStatus.FAILED.name(), cut(message), totalMs, new Timestamp(System.currentTimeMillis()), loadId);
    }

    public Optional<LoadRun> find(long loadId) {
        List<LoadRun> rows = jdbc.query("SELECT " + COLUMNS + " FROM LOAD_RUN WHERE LOAD_ID = ?", MAPPER, loadId);
        return rows.isEmpty() ? Optional.<LoadRun>empty() : Optional.of(rows.get(0));
    }

    public Optional<String> findDqProfileJson(long loadId) {
        List<String> rows = jdbc.queryForList("SELECT DQ_PROFILE_JSON FROM LOAD_RUN WHERE LOAD_ID = ?", String.class, loadId);
        return rows.isEmpty() || rows.get(0) == null ? Optional.empty() : Optional.of(rows.get(0));
    }

    public List<LoadRun> findRecent(int limit) {
        return jdbc.query("SELECT " + COLUMNS + " FROM LOAD_RUN ORDER BY LOAD_ID DESC FETCH FIRST ? ROWS ONLY", MAPPER,
                Math.max(1, Math.min(limit, 500)));
    }

    /** Latest publishable load of each provider + format (what subscribers see). */
    public List<LoadRun> findLatestPublished() {
        return jdbc.query("SELECT " + COLUMNS + " FROM LOAD_RUN l WHERE l.STATUS IN ('COMPLETED','COMPLETED_WITH_WARNINGS') "
                + "AND l.LOAD_ID = (SELECT MAX(x.LOAD_ID) FROM LOAD_RUN x WHERE x.PROVIDER_CODE = l.PROVIDER_CODE "
                + "AND x.FILE_FORMAT = l.FILE_FORMAT AND x.STATUS IN ('COMPLETED','COMPLETED_WITH_WARNINGS')) "
                + "ORDER BY l.PROVIDER_CODE, l.FILE_FORMAT", MAPPER);
    }

    public List<Long> findWaitingForReview(String providerCode, FileFormat format) {
        return jdbc.queryForList("SELECT LOAD_ID FROM LOAD_RUN WHERE PROVIDER_CODE = ? AND FILE_FORMAT = ? AND STATUS = ? ORDER BY LOAD_ID",
                Long.class, providerCode, format.name(), LoadStatus.MAPPING_REVIEW.name());
    }

    /** Moves a load to QUEUED only if it is still in the expected state (guards double approval). */
    public boolean transition(long loadId, LoadStatus from, LoadStatus to, String message) {
        return jdbc.update("UPDATE LOAD_RUN SET STATUS = ?, STATUS_MESSAGE = ? WHERE LOAD_ID = ? AND STATUS = ?",
                to.name(), cut(message), loadId, from.name()) == 1;
    }

    /** Loads left half-way by a restart are marked FAILED at startup. */
    public List<Long> findInterrupted() {
        return jdbc.queryForList("SELECT LOAD_ID FROM LOAD_RUN WHERE STATUS IN ('ANALYZING','QUEUED','LOADING','DQ_CHECKS')", Long.class);
    }

    private static String cut(String message) {
        return message == null || message.length() <= MAX_MESSAGE ? message : message.substring(0, MAX_MESSAGE);
    }

    private static final RowMapper<LoadRun> MAPPER = LoadRunRepository::map;

    private static LoadRun map(ResultSet rs, int rowNum) throws SQLException {
        LoadRun r = new LoadRun();
        r.setLoadId(rs.getLong("LOAD_ID"));
        r.setProviderCode(rs.getString("PROVIDER_CODE"));
        r.setFormat(FileFormat.valueOf(rs.getString("FILE_FORMAT")));
        r.setOriginalName(rs.getString("ORIGINAL_NAME"));
        r.setUploadedBy(rs.getString("UPLOADED_BY"));
        r.setStatus(LoadStatus.valueOf(rs.getString("STATUS")));
        r.setStatusMessage(rs.getString("STATUS_MESSAGE"));
        r.setSizeBytes(rs.getLong("SIZE_BYTES"));
        r.setSha256(rs.getString("SHA256"));
        r.setSchemaFingerprint(rs.getString("SCHEMA_FINGERPRINT"));
        r.setRecordPath(rs.getString("RECORD_PATH"));
        long mappingId = rs.getLong("MAPPING_ID");
        r.setMappingId(rs.wasNull() ? null : mappingId);
        int version = rs.getInt("MAPPING_VERSION");
        r.setMappingVersion(rs.wasNull() ? null : version);
        r.setTargetTable(rs.getString("TARGET_TABLE"));
        r.setSourceCount(rs.getLong("SOURCE_COUNT"));
        r.setLoadedCount(rs.getLong("LOADED_COUNT"));
        r.setRejectedCount(rs.getLong("REJECTED_COUNT"));
        r.setDuplicateCount(rs.getLong("DUPLICATE_COUNT"));
        r.setWarningCount(rs.getLong("WARNING_COUNT"));
        r.setNewPathCount(rs.getLong("NEW_PATH_COUNT"));
        int reconciled = rs.getInt("RECONCILED");
        r.setReconciled(rs.wasNull() ? null : reconciled == 1);
        r.setStoreMs(rs.getLong("STORE_MS"));
        r.setSchemaMs(rs.getLong("SCHEMA_MS"));
        r.setTransformMs(rs.getLong("TRANSFORM_MS"));
        r.setDqMs(rs.getLong("DQ_MS"));
        r.setTotalMs(rs.getLong("TOTAL_MS"));
        r.setCreatedAt(rs.getTimestamp("CREATED_AT"));
        r.setFinishedAt(rs.getTimestamp("FINISHED_AT"));
        return r;
    }
}
