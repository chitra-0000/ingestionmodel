package com.bank.ingestion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Canonical ingestion POC.
 * Flow: upload -> raw file stored in DB -> schema + bounded sample -> approved mapping lookup
 * -> (rule-based XSLT draft, validate, approve, version) -> transform from DB -> canonical records
 * -> data-quality checks -> CSV/XML export and subscriber API.
 */
@SpringBootApplication
@ConfigurationPropertiesScan
@EnableAsync
@EnableScheduling
public class IngestionApplication {

    public static void main(String[] args) {
        SpringApplication.run(IngestionApplication.class, args);
    }
}
