package com.bank.ingestion.domain;

/**
 * Canonical field <- source expression. The expression is an XPath 1.0 expression relative to the
 * record element: a path such as "NameDetails/Name/FirstName" or "@id", or a function such as
 * "local-name()" or a constant such as "'PERSON'".
 */
public class FieldMapping {

    private String field;
    private String expression;
    /** Join all matches with '|' instead of taking the first. */
    private boolean multiValued;
    /** 0-100, how sure the rule-based generator is. 100 = taken from an approved mapping. */
    private int confidence;
    /** How the suggestion was made: SYNONYM, NAME_CONTAINS, PREVIOUS_VERSION, MANUAL, NONE. */
    private String matchedBy;

    public FieldMapping() {
    }

    public FieldMapping(String field, String expression, boolean multiValued, int confidence, String matchedBy) {
        this.field = field;
        this.expression = expression;
        this.multiValued = multiValued;
        this.confidence = confidence;
        this.matchedBy = matchedBy;
    }

    public String getField() { return field; }
    public void setField(String field) { this.field = field; }
    public String getExpression() { return expression; }
    public void setExpression(String expression) { this.expression = expression; }
    public boolean isMultiValued() { return multiValued; }
    public void setMultiValued(boolean multiValued) { this.multiValued = multiValued; }
    public int getConfidence() { return confidence; }
    public void setConfidence(int confidence) { this.confidence = confidence; }
    public String getMatchedBy() { return matchedBy; }
    public void setMatchedBy(String matchedBy) { this.matchedBy = matchedBy; }
}
