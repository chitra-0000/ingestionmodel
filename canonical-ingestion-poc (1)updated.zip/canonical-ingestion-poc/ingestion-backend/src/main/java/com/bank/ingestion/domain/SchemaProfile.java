package com.bank.ingestion.domain;

import java.util.ArrayList;
import java.util.List;

/**
 * Result of "Extract schema and bounded sample": the repeating record element, every field path seen
 * in the sample (relative to the record), how often it occurs and a few example values.
 */
public class SchemaProfile {

    private FileFormat format;
    /** Absolute path of the record element, e.g. /PFA/Records/Person. For CSV: /records/record. */
    private String recordPath;
    private List<RecordCandidate> recordCandidates = new ArrayList<>();
    private List<PathInfo> paths = new ArrayList<>();
    private int sampleRecordCount;
    /** CSV only. */
    private char csvDelimiter = ',';
    private List<CsvColumn> csvColumns = new ArrayList<>();
    private String fingerprint;

    public FileFormat getFormat() { return format; }
    public void setFormat(FileFormat format) { this.format = format; }
    public String getRecordPath() { return recordPath; }
    public void setRecordPath(String recordPath) { this.recordPath = recordPath; }
    public List<RecordCandidate> getRecordCandidates() { return recordCandidates; }
    public void setRecordCandidates(List<RecordCandidate> recordCandidates) { this.recordCandidates = recordCandidates; }
    public List<PathInfo> getPaths() { return paths; }
    public void setPaths(List<PathInfo> paths) { this.paths = paths; }
    public int getSampleRecordCount() { return sampleRecordCount; }
    public void setSampleRecordCount(int sampleRecordCount) { this.sampleRecordCount = sampleRecordCount; }
    public char getCsvDelimiter() { return csvDelimiter; }
    public void setCsvDelimiter(char csvDelimiter) { this.csvDelimiter = csvDelimiter; }
    public List<CsvColumn> getCsvColumns() { return csvColumns; }
    public void setCsvColumns(List<CsvColumn> csvColumns) { this.csvColumns = csvColumns; }
    public String getFingerprint() { return fingerprint; }
    public void setFingerprint(String fingerprint) { this.fingerprint = fingerprint; }

    /** A repeating element that could be the record. */
    public static class RecordCandidate {
        private String path;
        private long count;
        private int depth;

        public RecordCandidate() {
        }

        public RecordCandidate(String path, long count, int depth) {
            this.path = path;
            this.count = count;
            this.depth = depth;
        }

        public String getPath() { return path; }
        public void setPath(String path) { this.path = path; }
        public long getCount() { return count; }
        public void setCount(long count) { this.count = count; }
        public int getDepth() { return depth; }
        public void setDepth(int depth) { this.depth = depth; }
    }

    /** A leaf value path relative to the record: "Name/FirstName" or "@id" or "Name/@type". */
    public static class PathInfo {
        private String path;
        /** Number of sampled records containing this path. */
        private int recordsWithValue;
        /** Highest number of occurrences inside one record (> 1 means multi-valued). */
        private int maxPerRecord;
        private List<String> samples = new ArrayList<>();

        public String getPath() { return path; }
        public void setPath(String path) { this.path = path; }
        public int getRecordsWithValue() { return recordsWithValue; }
        public void setRecordsWithValue(int recordsWithValue) { this.recordsWithValue = recordsWithValue; }
        public int getMaxPerRecord() { return maxPerRecord; }
        public void setMaxPerRecord(int maxPerRecord) { this.maxPerRecord = maxPerRecord; }
        public List<String> getSamples() { return samples; }
        public void setSamples(List<String> samples) { this.samples = samples; }
    }

    /** CSV header and the XML element name it becomes for the XSLT. */
    public static class CsvColumn {
        private String header;
        private String element;

        public CsvColumn() {
        }

        public CsvColumn(String header, String element) {
            this.header = header;
            this.element = element;
        }

        public String getHeader() { return header; }
        public void setHeader(String header) { this.header = header; }
        public String getElement() { return element; }
        public void setElement(String element) { this.element = element; }
    }
}
