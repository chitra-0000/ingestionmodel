package com.bank.ingestion.domain;

/** One data-quality finding for one record. */
public class DqIssue {

    public enum Severity { REJECT, WARN }

    private long loadId;
    private long recordNo;
    private String field;
    private String rule;
    private Severity severity;
    private String message;
    private String rawValue;

    public DqIssue() {
    }

    public DqIssue(long recordNo, String field, String rule, Severity severity, String message, String rawValue) {
        this.recordNo = recordNo;
        this.field = field;
        this.rule = rule;
        this.severity = severity;
        this.message = message;
        this.rawValue = rawValue;
    }

    public long getLoadId() { return loadId; }
    public void setLoadId(long loadId) { this.loadId = loadId; }
    public long getRecordNo() { return recordNo; }
    public void setRecordNo(long recordNo) { this.recordNo = recordNo; }
    public String getField() { return field; }
    public void setField(String field) { this.field = field; }
    public String getRule() { return rule; }
    public void setRule(String rule) { this.rule = rule; }
    public Severity getSeverity() { return severity; }
    public void setSeverity(Severity severity) { this.severity = severity; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getRawValue() { return rawValue; }
    public void setRawValue(String rawValue) { this.rawValue = rawValue; }
}
