package com.bank.ingestion.service.dq;

import com.bank.ingestion.domain.CanonicalField;
import com.bank.ingestion.domain.DqIssue;
import com.bank.ingestion.service.CanonicalModel;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.LongAdder;

/**
 * Thread-safe counters for one load: field completeness, every rule hit (counted, not just sampled),
 * and new source paths. Becomes LOAD_RUN.DQ_PROFILE_JSON.
 */
public final class DqStats {

    private final CanonicalModel model;
    private final int maxSamplesPerRule;
    private final LongAdder[] filled;
    private final ConcurrentHashMap<String, LongAdder> ruleCounts = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, AtomicInteger> storedSamples = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, LongAdder> newPaths = new ConcurrentHashMap<>();
    private final LongAdder loaded = new LongAdder();
    private final LongAdder rejected = new LongAdder();
    private final LongAdder warned = new LongAdder();

    public DqStats(CanonicalModel model, int maxSamplesPerRule) {
        this.model = model;
        this.maxSamplesPerRule = maxSamplesPerRule;
        this.filled = new LongAdder[model.fields().size()];
        for (int i = 0; i < filled.length; i++) {
            filled[i] = new LongAdder();
        }
    }

    /** Counts the issue; returns true when a detail row should also be stored (first N per rule and field). */
    public boolean count(DqIssue issue) {
        String key = issue.getSeverity() + "|" + issue.getRule() + "|" + (issue.getField() == null ? "" : issue.getField());
        ruleCounts.computeIfAbsent(key, k -> new LongAdder()).increment();
        return storedSamples.computeIfAbsent(key, k -> new AtomicInteger()).incrementAndGet() <= maxSamplesPerRule;
    }

    public void countLoaded(String[] values, boolean warning) {
        loaded.increment();
        if (warning) {
            warned.increment();
        }
        for (int i = 0; i < values.length; i++) {
            if (values[i] != null) {
                filled[i].increment();
            }
        }
    }

    public void countRejected() {
        rejected.increment();
    }

    public void countNewPath(String path) {
        newPaths.computeIfAbsent(path, k -> new LongAdder()).increment();
    }

    public long loaded() { return loaded.sum(); }
    public long rejected() { return rejected.sum(); }
    public long warned() { return warned.sum(); }
    public int newPathCount() { return newPaths.size(); }

    /** Profile for the UI and LOAD_RUN.DQ_PROFILE_JSON. Completeness is relative to the final loaded count. */
    public Map<String, Object> toProfile(long finalLoaded, Map<String, Object> loadLevel) {
        Map<String, Object> profile = new LinkedHashMap<>();
        List<Map<String, Object>> completeness = new ArrayList<>();
        List<CanonicalField> fields = model.fields();
        for (int i = 0; i < fields.size(); i++) {
            Map<String, Object> row = new LinkedHashMap<>();
            long n = Math.min(filled[i].sum(), finalLoaded);
            row.put("field", fields.get(i).getName());
            row.put("mandatory", fields.get(i).isMandatory());
            row.put("filled", n);
            row.put("percent", finalLoaded == 0 ? 0 : Math.round(n * 1000.0 / finalLoaded) / 10.0);
            completeness.add(row);
        }
        profile.put("fieldCompleteness", completeness);

        List<Map<String, Object>> rules = new ArrayList<>();
        for (Map.Entry<String, LongAdder> e : new TreeMap<>(ruleCounts).entrySet()) {
            String[] k = e.getKey().split("\\|", -1);
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("severity", k[0]);
            row.put("rule", k[1]);
            row.put("field", k[2]);
            row.put("count", e.getValue().sum());
            rules.add(row);
        }
        profile.put("ruleCounts", rules);

        List<Map<String, Object>> drift = new ArrayList<>();
        for (Map.Entry<String, LongAdder> e : new TreeMap<>(newPaths).entrySet()) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("path", e.getKey());
            row.put("records", e.getValue().sum());
            drift.add(row);
        }
        profile.put("newPaths", drift);
        profile.putAll(loadLevel);
        return profile;
    }
}
