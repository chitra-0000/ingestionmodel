package com.bank.ingestion.service.dq;

import com.bank.ingestion.domain.CanonicalField;
import com.bank.ingestion.domain.DqIssue;
import com.bank.ingestion.service.CanonicalModel;
import com.bank.ingestion.util.Texts;

import java.text.Normalizer;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Record-level data-quality rules, applied to every record after mapping. Stateless and thread-safe.
 *
 * <table>
 *   <tr><th>Rule</th><th>Severity</th><th>Effect</th></tr>
 *   <tr><td>MANDATORY_MISSING</td><td>REJECT</td><td>record not loaded</td></tr>
 *   <tr><td>LENGTH_EXCEEDED</td><td>REJECT</td><td>record not loaded (no silent truncation)</td></tr>
 *   <tr><td>INVALID_DATE / INVALID_COUNTRY / INVALID_VALUE</td><td>WARN</td><td>column empty, original kept in EXTRA_ATTRS</td></tr>
 *   <tr><td>MULTIPLE_VALUES</td><td>WARN</td><td>first value used, all values kept in EXTRA_ATTRS</td></tr>
 *   <tr><td>DATE_IN_FUTURE / DATE_IMPLAUSIBLE</td><td>WARN</td><td>value kept</td></tr>
 *   <tr><td>CONTROL_CHARS</td><td>WARN</td><td>control characters removed</td></tr>
 *   <tr><td>INVALID_ENCODING</td><td>WARN</td><td>value kept with replacement characters</td></tr>
 * </table>
 * Every value is also cleaned: whitespace trimmed and collapsed, Unicode normalised to NFC.
 */
public final class RecordValidator {

    public static final String MANDATORY_MISSING = "MANDATORY_MISSING";
    public static final String LENGTH_EXCEEDED = "LENGTH_EXCEEDED";
    public static final String INVALID_DATE = "INVALID_DATE";
    public static final String DATE_IN_FUTURE = "DATE_IN_FUTURE";
    public static final String DATE_IMPLAUSIBLE = "DATE_IMPLAUSIBLE";
    public static final String INVALID_COUNTRY = "INVALID_COUNTRY";
    public static final String INVALID_VALUE = "INVALID_VALUE";
    public static final String MULTIPLE_VALUES = "MULTIPLE_VALUES";
    public static final String CONTROL_CHARS = "CONTROL_CHARS";
    public static final String INVALID_ENCODING = "INVALID_ENCODING";

    /** Prefix for original values kept in EXTRA_ATTRS when a column had to be left empty. */
    public static final String ORIGINAL_PREFIX = "_original.";

    private static final int MIN_BIRTH_YEAR = 1900;

    private final CanonicalModel model;
    private final DateNormalizer dates;

    public RecordValidator(CanonicalModel model, DateNormalizer dates) {
        this.model = model;
        this.dates = dates;
    }

    /** Validation outcome for one record. */
    public static final class Result {
        private final String[] values;
        private final List<DqIssue> issues = new ArrayList<>(2);
        private final List<String[]> originals = new ArrayList<>(0);
        private boolean rejected;

        Result(int size) {
            this.values = new String[size];
        }

        public String[] values() { return values; }
        public List<DqIssue> issues() { return issues; }
        public List<String[]> originals() { return originals; }
        public boolean rejected() { return rejected; }
        public boolean warned() { return !rejected && !issues.isEmpty(); }
    }

    public Result validate(long recordNo, String[] raw) {
        List<CanonicalField> fields = model.fields();
        Result r = new Result(fields.size());
        LocalDate today = LocalDate.now();
        for (int i = 0; i < fields.size(); i++) {
            CanonicalField f = fields.get(i);
            String value = clean(recordNo, f.getName(), raw[i], r);
            if (value == null) {
                if (f.isMandatory()) {
                    reject(r, recordNo, f.getName(), MANDATORY_MISSING, "Mandatory field is empty", raw[i]);
                }
                continue;
            }
            r.values[i] = checkType(recordNo, f, value, today, r);
        }
        return r;
    }

    private String checkType(long recordNo, CanonicalField f, String value, LocalDate today, Result r) {
        switch (f.getType()) {
            case DATE:
                return checkDate(recordNo, f, firstOf(recordNo, f, value, r), today, r);
            case COUNTRY:
                return checkCountry(recordNo, f, firstOf(recordNo, f, value, r), r);
            case ENUM:
                return checkEnum(recordNo, f, firstOf(recordNo, f, value, r), r);
            default:
                if (value.length() > f.getMaxLength()) {
                    reject(r, recordNo, f.getName(), LENGTH_EXCEEDED,
                            "Length " + value.length() + " exceeds " + f.getMaxLength(), value);
                    return null;
                }
                return value;
        }
    }

    /** Single-valued types: a joined multi-value ("US|GB") keeps the first value, all values go to EXTRA_ATTRS. */
    private static String firstOf(long recordNo, CanonicalField f, String value, Result r) {
        int sep = value.indexOf('|');
        if (sep < 0) {
            return value;
        }
        warn(r, recordNo, f.getName(), MULTIPLE_VALUES, "Several values supplied; first one used", value);
        r.originals.add(new String[]{ORIGINAL_PREFIX + f.getName(), value});
        return value.substring(0, sep).trim();
    }

    private String checkDate(long recordNo, CanonicalField f, String value, LocalDate today, Result r) {
        String iso = dates.normalise(value);
        if (iso == null) {
            warn(r, recordNo, f.getName(), INVALID_DATE, "Not a recognised date", value);
            r.originals.add(new String[]{ORIGINAL_PREFIX + f.getName(), value});
            return null;
        }
        if (DateNormalizer.isAfter(iso, today)) {
            warn(r, recordNo, f.getName(), DATE_IN_FUTURE, "Date is in the future", value);
        } else if ("DATE_OF_BIRTH".equals(f.getName()) && DateNormalizer.year(iso) < MIN_BIRTH_YEAR) {
            warn(r, recordNo, f.getName(), DATE_IMPLAUSIBLE, "Birth year before " + MIN_BIRTH_YEAR, value);
        }
        return iso;
    }

    private static String checkCountry(long recordNo, CanonicalField f, String value, Result r) {
        String code = CountryNormalizer.normalise(value);
        if (code == null) {
            warn(r, recordNo, f.getName(), INVALID_COUNTRY, "Not a recognised ISO country", value);
            r.originals.add(new String[]{ORIGINAL_PREFIX + f.getName(), value});
        }
        return code;
    }

    private static String checkEnum(long recordNo, CanonicalField f, String value, Result r) {
        String upper = value.toUpperCase(Locale.ROOT);
        if (f.getAllowedValues().contains(upper)) {
            return upper;
        }
        String alias = f.getValueAliases().get(Texts.normaliseName(value));
        if (alias != null) {
            return alias;
        }
        warn(r, recordNo, f.getName(), INVALID_VALUE, "Allowed: " + f.getAllowedValues(), value);
        r.originals.add(new String[]{ORIGINAL_PREFIX + f.getName(), value});
        return null;
    }

    /**
     * Trim, collapse whitespace (tabs and line breaks become spaces), drop other control characters and
     * normalise to NFC. Plain printable ASCII takes the fast path and is returned untouched.
     */
    private static String clean(long recordNo, String field, String raw, Result r) {
        if (raw == null) {
            return null;
        }
        if (isCleanAscii(raw)) {
            return raw.isEmpty() ? null : raw;
        }
        StringBuilder sb = new StringBuilder(raw.length());
        boolean controls = false;
        boolean replacement = false;
        boolean space = false;
        boolean ascii = true;
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == ' ') {
                space = sb.length() > 0;
                continue;
            }
            if (Character.isISOControl(c)) {
                controls = true;
                continue;
            }
            if (c == '�') {
                replacement = true;
            }
            if (c > 0x7E) {
                ascii = false;
            }
            if (space) {
                sb.append(' ');
                space = false;
            }
            sb.append(c);
        }
        if (controls) {
            warn(r, recordNo, field, CONTROL_CHARS, "Control characters removed", raw);
        }
        if (replacement) {
            warn(r, recordNo, field, INVALID_ENCODING, "Contains bytes that are not valid UTF-8", raw);
        }
        String out = sb.toString();
        if (!ascii && !Normalizer.isNormalized(out, Normalizer.Form.NFC)) {
            out = Normalizer.normalize(out, Normalizer.Form.NFC);
        }
        return out.isEmpty() ? null : out;
    }

    private static boolean isCleanAscii(String s) {
        int n = s.length();
        if (n == 0) {
            return true;
        }
        if (s.charAt(0) == ' ' || s.charAt(n - 1) == ' ') {
            return false;
        }
        char prev = 'x';
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            if (c < 0x20 || c > 0x7E || (c == ' ' && prev == ' ')) {
                return false;
            }
            prev = c;
        }
        return true;
    }

    private static void reject(Result r, long recordNo, String field, String rule, String message, String raw) {
        r.rejected = true;
        r.issues.add(new DqIssue(recordNo, field, rule, DqIssue.Severity.REJECT, message, raw));
    }

    private static void warn(Result r, long recordNo, String field, String rule, String message, String raw) {
        r.issues.add(new DqIssue(recordNo, field, rule, DqIssue.Severity.WARN, message, raw));
    }
}
