package com.bank.ingestion.service.mapping;

import com.bank.ingestion.domain.FieldMapping;
import com.bank.ingestion.domain.SchemaProfile;
import com.bank.ingestion.util.Texts;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Turns field mappings into an XSLT 1.0 stylesheet that runs once per record.
 *
 * Output contract (checked by {@link XsltSecurityValidator}):
 * <pre>
 * &lt;r&gt;
 *   &lt;f n="CANONICAL_FIELD"&gt;value&lt;/f&gt;   one per mapped canonical field
 *   &lt;x p="source/path"&gt;value&lt;/x&gt;      every other source path, kept in EXTRA_ATTRS
 * &lt;/r&gt;
 * </pre>
 * Repeated values are joined with '|'.
 */
@Component
public class XsltBuilder {

    public static final String MULTI_SEPARATOR = "|";

    public String build(String recordPath, List<FieldMapping> mappings, List<SchemaProfile.PathInfo> extraPaths) {
        StringBuilder x = new StringBuilder(4096);
        x.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
                .append("<!-- Canonical mapping. Record: ").append(escapeComment(recordPath)).append(" -->\n")
                .append("<xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\">\n")
                .append("  <xsl:output method=\"xml\" encoding=\"UTF-8\" omit-xml-declaration=\"yes\"/>\n")
                .append("  <xsl:template match=\"/*\">\n")
                .append("    <r>\n");
        for (FieldMapping m : mappings) {
            if (Texts.isBlank(m.getExpression())) {
                continue;
            }
            x.append("      <f n=\"").append(attr(m.getField())).append("\">");
            appendValue(x, m.getExpression().trim(), m.isMultiValued());
            x.append("</f>\n");
        }
        if (!extraPaths.isEmpty()) {
            x.append("      <!-- Source fields without a canonical column: kept in EXTRA_ATTRS -->\n");
        }
        for (SchemaProfile.PathInfo p : extraPaths) {
            x.append("      <x p=\"").append(avt(attr(p.getPath()))).append("\">");
            appendValue(x, p.getPath(), p.getMaxPerRecord() > 1);
            x.append("</x>\n");
        }
        x.append("    </r>\n")
                .append("  </xsl:template>\n")
                .append("</xsl:stylesheet>\n");
        return x.toString();
    }

    private static void appendValue(StringBuilder x, String expression, boolean multi) {
        String select = attr(expression);
        if (multi) {
            x.append("<xsl:for-each select=\"").append(select).append("\">")
                    .append("<xsl:if test=\"position() &gt; 1\">").append(MULTI_SEPARATOR).append("</xsl:if>")
                    .append("<xsl:value-of select=\".\"/></xsl:for-each>");
        } else {
            x.append("<xsl:value-of select=\"").append(select).append("\"/>");
        }
    }

    /** XML attribute escaping (the expression is user-editable). */
    static String attr(String value) {
        StringBuilder sb = new StringBuilder(value.length() + 8);
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '&':
                    sb.append("&amp;");
                    break;
                case '<':
                    sb.append("&lt;");
                    break;
                case '>':
                    sb.append("&gt;");
                    break;
                case '"':
                    sb.append("&quot;");
                    break;
                default:
                    sb.append(c);
            }
        }
        return sb.toString();
    }

    /** Literal-result-element attributes are attribute value templates: braces must be doubled. */
    private static String avt(String value) {
        return value.replace("{", "{{").replace("}", "}}");
    }

    private static String escapeComment(String value) {
        return value == null ? "" : value.replace("--", "- -");
    }
}
