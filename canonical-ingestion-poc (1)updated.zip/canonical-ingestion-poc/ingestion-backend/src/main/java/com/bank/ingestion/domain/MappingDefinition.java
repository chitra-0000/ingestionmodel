package com.bank.ingestion.domain;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/** An approved, versioned mapping (MAPPING_DEFINITION row + .xsl/.json files in the mapping store). */
public class MappingDefinition {

    private long mappingId;
    private String providerCode;
    private FileFormat format;
    private int versionNo;
    private String schemaFingerprint;
    private String recordPath;
    private List<FieldMapping> fieldMappings = new ArrayList<>();
    /** Every source path the mapping was approved against (used to detect new fields). */
    private List<String> knownPaths = new ArrayList<>();
    private String xslt;
    private boolean customXslt;
    private String status;
    private String generatedBy;
    private String approvedBy;
    private Timestamp approvedAt;
    private String storePath;

    public long getMappingId() { return mappingId; }
    public void setMappingId(long mappingId) { this.mappingId = mappingId; }
    public String getProviderCode() { return providerCode; }
    public void setProviderCode(String providerCode) { this.providerCode = providerCode; }
    public FileFormat getFormat() { return format; }
    public void setFormat(FileFormat format) { this.format = format; }
    public int getVersionNo() { return versionNo; }
    public void setVersionNo(int versionNo) { this.versionNo = versionNo; }
    public String getSchemaFingerprint() { return schemaFingerprint; }
    public void setSchemaFingerprint(String schemaFingerprint) { this.schemaFingerprint = schemaFingerprint; }
    public String getRecordPath() { return recordPath; }
    public void setRecordPath(String recordPath) { this.recordPath = recordPath; }
    public List<FieldMapping> getFieldMappings() { return fieldMappings; }
    public void setFieldMappings(List<FieldMapping> fieldMappings) { this.fieldMappings = fieldMappings; }
    public List<String> getKnownPaths() { return knownPaths; }
    public void setKnownPaths(List<String> knownPaths) { this.knownPaths = knownPaths; }
    public String getXslt() { return xslt; }
    public void setXslt(String xslt) { this.xslt = xslt; }
    public boolean isCustomXslt() { return customXslt; }
    public void setCustomXslt(boolean customXslt) { this.customXslt = customXslt; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getGeneratedBy() { return generatedBy; }
    public void setGeneratedBy(String generatedBy) { this.generatedBy = generatedBy; }
    public String getApprovedBy() { return approvedBy; }
    public void setApprovedBy(String approvedBy) { this.approvedBy = approvedBy; }
    public Timestamp getApprovedAt() { return approvedAt == null ? null : new Timestamp(approvedAt.getTime()); }
    public void setApprovedAt(Timestamp approvedAt) { this.approvedAt = approvedAt == null ? null : new Timestamp(approvedAt.getTime()); }
    public String getStorePath() { return storePath; }
    public void setStorePath(String storePath) { this.storePath = storePath; }
}
