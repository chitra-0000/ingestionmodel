package com.bank.ingestion.domain;

import java.sql.Timestamp;

/** One uploaded file and everything that happened to it (LOAD_RUN row + live progress). */
public class LoadRun {

    private long loadId;
    private String providerCode;
    private FileFormat format;
    private String originalName;
    private String uploadedBy;
    private LoadStatus status;
    private String statusMessage;
    private long sizeBytes;
    private String sha256;
    private String schemaFingerprint;
    private String recordPath;
    private Long mappingId;
    private Integer mappingVersion;
    private String targetTable;
    private long sourceCount;
    private long loadedCount;
    private long rejectedCount;
    private long duplicateCount;
    private long warningCount;
    private long newPathCount;
    private Boolean reconciled;
    private long storeMs;
    private long schemaMs;
    private long transformMs;
    private long dqMs;
    private long totalMs;
    private Timestamp createdAt;
    private Timestamp finishedAt;
    /** Live only (not persisted): records processed so far while LOADING. */
    private long progressRecords;
    private double recordsPerSecond;

    public long getLoadId() { return loadId; }
    public void setLoadId(long loadId) { this.loadId = loadId; }
    public String getProviderCode() { return providerCode; }
    public void setProviderCode(String providerCode) { this.providerCode = providerCode; }
    public FileFormat getFormat() { return format; }
    public void setFormat(FileFormat format) { this.format = format; }
    public String getOriginalName() { return originalName; }
    public void setOriginalName(String originalName) { this.originalName = originalName; }
    public String getUploadedBy() { return uploadedBy; }
    public void setUploadedBy(String uploadedBy) { this.uploadedBy = uploadedBy; }
    public LoadStatus getStatus() { return status; }
    public void setStatus(LoadStatus status) { this.status = status; }
    public String getStatusMessage() { return statusMessage; }
    public void setStatusMessage(String statusMessage) { this.statusMessage = statusMessage; }
    public long getSizeBytes() { return sizeBytes; }
    public void setSizeBytes(long sizeBytes) { this.sizeBytes = sizeBytes; }
    public String getSha256() { return sha256; }
    public void setSha256(String sha256) { this.sha256 = sha256; }
    public String getSchemaFingerprint() { return schemaFingerprint; }
    public void setSchemaFingerprint(String schemaFingerprint) { this.schemaFingerprint = schemaFingerprint; }
    public String getRecordPath() { return recordPath; }
    public void setRecordPath(String recordPath) { this.recordPath = recordPath; }
    public Long getMappingId() { return mappingId; }
    public void setMappingId(Long mappingId) { this.mappingId = mappingId; }
    public Integer getMappingVersion() { return mappingVersion; }
    public void setMappingVersion(Integer mappingVersion) { this.mappingVersion = mappingVersion; }
    public String getTargetTable() { return targetTable; }
    public void setTargetTable(String targetTable) { this.targetTable = targetTable; }
    public long getSourceCount() { return sourceCount; }
    public void setSourceCount(long sourceCount) { this.sourceCount = sourceCount; }
    public long getLoadedCount() { return loadedCount; }
    public void setLoadedCount(long loadedCount) { this.loadedCount = loadedCount; }
    public long getRejectedCount() { return rejectedCount; }
    public void setRejectedCount(long rejectedCount) { this.rejectedCount = rejectedCount; }
    public long getDuplicateCount() { return duplicateCount; }
    public void setDuplicateCount(long duplicateCount) { this.duplicateCount = duplicateCount; }
    public long getWarningCount() { return warningCount; }
    public void setWarningCount(long warningCount) { this.warningCount = warningCount; }
    public long getNewPathCount() { return newPathCount; }
    public void setNewPathCount(long newPathCount) { this.newPathCount = newPathCount; }
    public Boolean getReconciled() { return reconciled; }
    public void setReconciled(Boolean reconciled) { this.reconciled = reconciled; }
    public long getStoreMs() { return storeMs; }
    public void setStoreMs(long storeMs) { this.storeMs = storeMs; }
    public long getSchemaMs() { return schemaMs; }
    public void setSchemaMs(long schemaMs) { this.schemaMs = schemaMs; }
    public long getTransformMs() { return transformMs; }
    public void setTransformMs(long transformMs) { this.transformMs = transformMs; }
    public long getDqMs() { return dqMs; }
    public void setDqMs(long dqMs) { this.dqMs = dqMs; }
    public long getTotalMs() { return totalMs; }
    public void setTotalMs(long totalMs) { this.totalMs = totalMs; }
    public Timestamp getCreatedAt() { return createdAt == null ? null : new Timestamp(createdAt.getTime()); }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt == null ? null : new Timestamp(createdAt.getTime()); }
    public Timestamp getFinishedAt() { return finishedAt == null ? null : new Timestamp(finishedAt.getTime()); }
    public void setFinishedAt(Timestamp finishedAt) { this.finishedAt = finishedAt == null ? null : new Timestamp(finishedAt.getTime()); }
    public long getProgressRecords() { return progressRecords; }
    public void setProgressRecords(long progressRecords) { this.progressRecords = progressRecords; }
    public double getRecordsPerSecond() { return recordsPerSecond; }
    public void setRecordsPerSecond(double recordsPerSecond) { this.recordsPerSecond = recordsPerSecond; }
}
