package com.bank.ingestion.service.mapping;

import com.bank.ingestion.config.IngestionProperties;
import com.bank.ingestion.domain.CanonicalField;
import com.bank.ingestion.domain.DqIssue;
import com.bank.ingestion.domain.FieldMapping;
import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.domain.LoadRun;
import com.bank.ingestion.domain.MappingDefinition;
import com.bank.ingestion.domain.MappingDraft;
import com.bank.ingestion.domain.MappingRequest;
import com.bank.ingestion.domain.SchemaProfile;
import com.bank.ingestion.domain.ValidationResult;
import com.bank.ingestion.repository.MappingRepository;
import com.bank.ingestion.repository.RawFileRepository;
import com.bank.ingestion.service.CanonicalModel;
import com.bank.ingestion.service.SchemaExtractor;
import com.bank.ingestion.service.dq.DateNormalizer;
import com.bank.ingestion.service.dq.RecordValidator;
import com.bank.ingestion.service.source.CsvRecordReader;
import com.bank.ingestion.service.source.RecordData;
import com.bank.ingestion.service.source.RecordReader;
import com.bank.ingestion.service.source.XmlRecordReader;
import com.bank.ingestion.util.ApiException;
import com.bank.ingestion.util.Texts;
import org.springframework.stereotype.Service;

import javax.xml.transform.TransformerException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * Mapping lifecycle: lookup of an approved mapping for a new file, draft generation (rule-based, or the
 * previous approved version plus drift), compile/preview/validate, and versioned approval.
 */
@Service
public class MappingService {

    public static final String GENERATED_PREVIOUS = "PREVIOUS_VERSION";
    public static final String GENERATED_MANUAL = "MANUAL_XSLT";
    private static final int PREVIEW_ROWS_RETURNED = 50;
    private static final int PREVIEW_ISSUES_RETURNED = 100;
    private static final double MAX_PREVIEW_REJECT_PERCENT = 50.0;

    private final IngestionProperties props;
    private final CanonicalModel model;
    private final MappingRepository mappings;
    private final RawFileRepository rawFiles;
    private final MappingGenerator generator;
    private final XsltBuilder xsltBuilder;
    private final XsltCompiler compiler;
    private final MappingStore store;

    public MappingService(IngestionProperties props, CanonicalModel model, MappingRepository mappings,
                          RawFileRepository rawFiles, MappingGenerator generator, XsltBuilder xsltBuilder,
                          XsltCompiler compiler, MappingStore store) {
        this.props = props;
        this.model = model;
        this.mappings = mappings;
        this.rawFiles = rawFiles;
        this.generator = generator;
        this.xsltBuilder = xsltBuilder;
        this.compiler = compiler;
        this.store = store;
    }

    /**
     * "Approved mapping exists?" - the active mapping applies when the record path is the same and the
     * file brings no field the mapping was not approved for.
     */
    public MappingDefinition findApplicable(String providerCode, FileFormat format, SchemaProfile profile) {
        MappingDefinition active = mappings.findActive(providerCode, format).orElse(null);
        if (active == null || !active.getRecordPath().equals(profile.getRecordPath())) {
            return null;
        }
        Set<String> known = new HashSet<>(active.getKnownPaths());
        for (SchemaProfile.PathInfo p : profile.getPaths()) {
            if (!known.contains(p.getPath())) {
                return null;
            }
        }
        return active;
    }

    /** Why no mapping applied: used as the status message of a load waiting for review. */
    public String reviewReason(String providerCode, FileFormat format, SchemaProfile profile) {
        MappingDefinition active = mappings.findActive(providerCode, format).orElse(null);
        if (active == null) {
            return "New provider/format: no approved mapping yet. Review the suggested mapping.";
        }
        if (!active.getRecordPath().equals(profile.getRecordPath())) {
            return "Record path changed from " + active.getRecordPath() + " to " + profile.getRecordPath() + ". Review the mapping.";
        }
        int newFields = newPaths(active, profile).size();
        return "Schema drift: " + newFields + " new field(s) compared with mapping v" + active.getVersionNo() + ". Approval required.";
    }

    public MappingDraft draft(LoadRun run, SchemaProfile profile) {
        MappingDraft d = new MappingDraft();
        d.setLoadId(run.getLoadId());
        d.setProviderCode(run.getProviderCode());
        d.setFormat(run.getFormat());
        d.setRecordPath(profile.getRecordPath());
        d.setRecordCandidates(profile.getRecordCandidates());
        d.setSourcePaths(profile.getPaths());
        d.setCanonicalFields(model.fields());

        MappingDefinition active = mappings.findActive(run.getProviderCode(), run.getFormat()).orElse(null);
        List<FieldMapping> fields;
        if (active != null && active.getRecordPath().equals(profile.getRecordPath())) {
            fields = fromPrevious(active, profile);
            d.setGeneratedBy(GENERATED_PREVIOUS);
            d.setBasedOnVersion(active.getVersionNo());
            d.setNewPaths(newPaths(active, profile));
            d.setMissingPaths(missingPaths(active, profile));
        } else {
            fields = generator.suggest(profile);
            d.setGeneratedBy(generator.name());
        }
        d.setFieldMappings(fields);
        d.setUnmappedPaths(pathNames(unmappedPaths(fields, profile)));
        d.setXslt(xsltBuilder.build(profile.getRecordPath(), fields, unmappedPaths(fields, profile)));
        return d;
    }

    /** Previous version's mappings; new fields are suggested by the generator only for still-empty canonical fields. */
    private List<FieldMapping> fromPrevious(MappingDefinition active, SchemaProfile profile) {
        Map<String, FieldMapping> previous = new HashMap<>();
        for (FieldMapping f : active.getFieldMappings()) {
            previous.put(f.getField(), f);
        }
        Map<String, FieldMapping> suggested = new HashMap<>();
        for (FieldMapping f : generator.suggest(profile)) {
            suggested.put(f.getField(), f);
        }
        List<FieldMapping> result = new ArrayList<>();
        for (CanonicalField c : model.fields()) {
            FieldMapping p = previous.get(c.getName());
            if (p != null && !Texts.isBlank(p.getExpression())) {
                result.add(new FieldMapping(c.getName(), p.getExpression(), p.isMultiValued(), 100, GENERATED_PREVIOUS));
            } else {
                FieldMapping s = suggested.get(c.getName());
                result.add(s != null ? s : new FieldMapping(c.getName(), "", false, 0, "NONE"));
            }
        }
        return result;
    }

    public ValidationResult validate(LoadRun run, SchemaProfile profile, MappingRequest req) {
        ValidationResult result = new ValidationResult();
        String recordPath = req.getRecordPath();
        String xslt = req.isCustomXslt() ? req.getXslt()
                : xsltBuilder.build(recordPath, req.getFieldMappings(), unmappedPaths(req.getFieldMappings(), profile));
        result.setXslt(xslt);

        if (!req.isCustomXslt()) {
            checkFieldMappings(req.getFieldMappings(), result);
        }
        if (!recordPath.equals(profile.getRecordPath())) {
            result.getErrors().add("Record path differs from the analysed one; reload the draft for " + recordPath);
        }
        XsltCompiler.Result compiled = compiler.compile(xslt);
        result.getErrors().addAll(compiled.errors());
        if (compiled.ok() && result.getErrors().isEmpty()) {
            preview(run, recordPath, compiled, result);
        }
        result.setValid(result.getErrors().isEmpty());
        return result;
    }

    private void checkFieldMappings(List<FieldMapping> fields, ValidationResult result) {
        Set<String> seen = new HashSet<>();
        for (FieldMapping f : fields) {
            if (model.field(f.getField()) == null) {
                result.getErrors().add("Unknown canonical field " + f.getField());
            } else if (!seen.add(f.getField())) {
                result.getErrors().add("Field " + f.getField() + " is mapped twice");
            }
        }
        for (CanonicalField c : model.fields()) {
            FieldMapping f = find(fields, c.getName());
            boolean empty = f == null || Texts.isBlank(f.getExpression());
            if (c.isMandatory() && empty) {
                result.getErrors().add("Mandatory field " + c.getName() + " is not mapped");
            } else if (!empty && f.getConfidence() > 0 && f.getConfidence() < 60) {
                result.getWarnings().add(c.getName() + " was matched by name similarity only (" + f.getExpression() + "); please confirm");
            }
        }
    }

    /** Runs the compiled mapping and the DQ rules on the first N records of the stored file. */
    private void preview(LoadRun run, String recordPath, XsltCompiler.Result compiled, ValidationResult result) {
        RecordValidator validator = new RecordValidator(model, new DateNormalizer(props.getSlashDateOrder()));
        int limit = props.getPreviewRecords();
        try {
            RecordTransformer transformer = new RecordTransformer(compiled.templates(), model);
            rawFiles.readContent(run.getLoadId(), stored -> {
                InputStream in = SchemaExtractor.decompress(stored);
                try (RecordReader reader = run.getFormat() == FileFormat.CSV
                        ? new CsvRecordReader(in, null, null, true)
                        : new XmlRecordReader(in, recordPath, null, null, true)) {
                    RecordData rd;
                    int n = 0;
                    while (n < limit && (rd = reader.next()) != null) {
                        n++;
                        previewOne(rd, transformer, validator, result);
                    }
                    result.setPreviewRecords(n);
                }
                return null;
            });
        } catch (Exception e) {
            result.getErrors().add("Preview failed: " + e.getMessage());
            return;
        }
        int records = Math.max(1, result.getPreviewRecords());
        double rejectPercent = result.getPreviewRejected() * 100.0 / records;
        // More than half rejected almost always means a wrong mapping, so it blocks approval. Above the load
        // threshold it is only a warning: the data itself may be bad, and the load step holds that version back.
        String summary = String.format("%d of %d preview records would be rejected (%.1f%%)",
                result.getPreviewRejected(), result.getPreviewRecords(), rejectPercent);
        if (rejectPercent > MAX_PREVIEW_REJECT_PERCENT) {
            result.getErrors().add(summary + ". Check the mappings of the fields listed in the issues.");
        } else if (rejectPercent > props.getMaxRejectPercent()) {
            result.getWarnings().add(summary + String.format(", above the %.1f%% load limit. If the mapping is right, "
                    + "the file's data is the problem and the load will be held back for review.", props.getMaxRejectPercent()));
        }
        warnEmptyFields(result);
    }

    private void previewOne(RecordData rd, RecordTransformer transformer, RecordValidator validator, ValidationResult result) {
        if (rd.isRejected()) {
            result.setPreviewRejected(result.getPreviewRejected() + 1);
            addIssue(result, new DqIssue(rd.getRecordNo(), null, rd.getRejectRule(), DqIssue.Severity.REJECT, rd.getRejectMessage(), null));
            return;
        }
        RecordTransformer.Output out;
        try {
            out = transformer.transform(rd.getDocument());
        } catch (TransformerException e) {
            result.setPreviewRejected(result.getPreviewRejected() + 1);
            addIssue(result, new DqIssue(rd.getRecordNo(), null, "TRANSFORM_ERROR", DqIssue.Severity.REJECT, e.getMessage(), null));
            return;
        }
        RecordValidator.Result v = validator.validate(rd.getRecordNo(), out.values());
        for (DqIssue i : v.issues()) {
            addIssue(result, i);
        }
        if (v.rejected()) {
            result.setPreviewRejected(result.getPreviewRejected() + 1);
        }
        if (result.getPreviewRows().size() < PREVIEW_ROWS_RETURNED) {
            Map<String, String> row = new LinkedHashMap<>();
            row.put("_recordNo", String.valueOf(rd.getRecordNo()));
            row.put("_dqStatus", v.rejected() ? "REJECT" : (v.warned() ? "WARN" : "OK"));
            for (int i = 0; i < model.fields().size(); i++) {
                row.put(model.fields().get(i).getName(), v.rejected() ? out.values()[i] : v.values()[i]);
            }
            row.put("_extraFields", String.valueOf(out.extras().size()));
            result.getPreviewRows().add(row);
        }
    }

    private static void addIssue(ValidationResult result, DqIssue issue) {
        if (result.getPreviewIssues().size() < PREVIEW_ISSUES_RETURNED) {
            result.getPreviewIssues().add(issue);
        }
    }

    private void warnEmptyFields(ValidationResult result) {
        for (CanonicalField c : model.fields()) {
            boolean anyValue = false;
            for (Map<String, String> row : result.getPreviewRows()) {
                if (row.get(c.getName()) != null) {
                    anyValue = true;
                    break;
                }
            }
            if (!anyValue && !result.getPreviewRows().isEmpty()) {
                result.getWarnings().add(c.getName() + " is empty in every preview record");
            }
        }
    }

    /** Validates again (never trust the client), then stores a new version in the DB and the mapping store. */
    public MappingDefinition approve(LoadRun run, SchemaProfile profile, MappingRequest req, ValidationResult validation) throws Exception {
        if (!validation.isValid()) {
            throw ApiException.badRequest("Mapping is not valid: " + String.join("; ", validation.getErrors()));
        }
        if (Texts.isBlank(req.getApprovedBy())) {
            throw ApiException.badRequest("Approver is required");
        }
        MappingDefinition active = mappings.findActive(run.getProviderCode(), run.getFormat()).orElse(null);
        Set<String> known = new TreeSet<>(pathNames(profile.getPaths()));
        if (active != null && active.getRecordPath().equals(req.getRecordPath())) {
            known.addAll(active.getKnownPaths());
        }
        MappingDefinition m = new MappingDefinition();
        m.setMappingId(mappings.nextId());
        m.setProviderCode(run.getProviderCode());
        m.setFormat(run.getFormat());
        m.setVersionNo(mappings.nextVersion(run.getProviderCode(), run.getFormat()));
        m.setSchemaFingerprint(profile.getFingerprint());
        m.setRecordPath(req.getRecordPath());
        m.setFieldMappings(req.getFieldMappings());
        m.setKnownPaths(new ArrayList<>(known));
        m.setXslt(validation.getXslt());
        m.setCustomXslt(req.isCustomXslt());
        m.setStatus(MappingRepository.STATUS_APPROVED);
        m.setGeneratedBy(req.isCustomXslt() ? GENERATED_MANUAL : generatorLabel(req.getFieldMappings()));
        m.setApprovedBy(req.getApprovedBy().trim());
        m.setApprovedAt(new Timestamp(System.currentTimeMillis()));
        m.setStorePath(store.write(m));
        mappings.insert(m);
        mappings.retireOthers(m.getProviderCode(), m.getFormat(), m.getMappingId());
        return m;
    }

    private String generatorLabel(List<FieldMapping> fields) {
        for (FieldMapping f : fields) {
            if (GENERATED_PREVIOUS.equals(f.getMatchedBy())) {
                return GENERATED_PREVIOUS;
            }
        }
        return generator.name();
    }

    private static List<String> newPaths(MappingDefinition active, SchemaProfile profile) {
        Set<String> known = new HashSet<>(active.getKnownPaths());
        List<String> result = new ArrayList<>();
        for (SchemaProfile.PathInfo p : profile.getPaths()) {
            if (!known.contains(p.getPath())) {
                result.add(p.getPath());
            }
        }
        return result;
    }

    private static List<String> missingPaths(MappingDefinition active, SchemaProfile profile) {
        Set<String> present = new HashSet<>(pathNames(profile.getPaths()));
        List<String> result = new ArrayList<>();
        for (String p : active.getKnownPaths()) {
            if (!present.contains(p)) {
                result.add(p);
            }
        }
        return result;
    }

    /**
     * Paths not fully captured by a field mapping go to EXTRA_ATTRS so nothing is lost: paths not used
     * verbatim, and repeating paths mapped to a single-value field (e.g. alias names behind the primary name).
     */
    private static List<SchemaProfile.PathInfo> unmappedPaths(List<FieldMapping> fields, SchemaProfile profile) {
        Map<String, Boolean> used = new HashMap<>();
        for (FieldMapping f : fields) {
            if (f.getExpression() == null) {
                continue;
            }
            for (String part : f.getExpression().split("\\|")) {
                String path = part.trim();
                used.put(path, Boolean.TRUE.equals(used.get(path)) || f.isMultiValued());
            }
        }
        List<SchemaProfile.PathInfo> result = new ArrayList<>();
        for (SchemaProfile.PathInfo p : profile.getPaths()) {
            Boolean multi = used.get(p.getPath());
            boolean fullyCaptured = multi != null && (multi || p.getMaxPerRecord() <= 1);
            if (!fullyCaptured) {
                result.add(p);
            }
        }
        return result;
    }

    private static List<String> pathNames(List<SchemaProfile.PathInfo> paths) {
        List<String> names = new ArrayList<>(paths.size());
        for (SchemaProfile.PathInfo p : paths) {
            names.add(p.getPath());
        }
        return names;
    }

    private static FieldMapping find(List<FieldMapping> fields, String name) {
        for (FieldMapping f : fields) {
            if (name.equals(f.getField())) {
                return f;
            }
        }
        return null;
    }
}
