package com.bank.ingestion.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Outcome of "Compile, preview and validate". */
public class ValidationResult {

    private boolean valid;
    private List<String> errors = new ArrayList<>();
    private List<String> warnings = new ArrayList<>();
    private String xslt;
    private int previewRecords;
    private int previewRejected;
    private List<Map<String, String>> previewRows = new ArrayList<>();
    private List<DqIssue> previewIssues = new ArrayList<>();

    public boolean isValid() { return valid; }
    public void setValid(boolean valid) { this.valid = valid; }
    public List<String> getErrors() { return errors; }
    public void setErrors(List<String> errors) { this.errors = errors; }
    public List<String> getWarnings() { return warnings; }
    public void setWarnings(List<String> warnings) { this.warnings = warnings; }
    public String getXslt() { return xslt; }
    public void setXslt(String xslt) { this.xslt = xslt; }
    public int getPreviewRecords() { return previewRecords; }
    public void setPreviewRecords(int previewRecords) { this.previewRecords = previewRecords; }
    public int getPreviewRejected() { return previewRejected; }
    public void setPreviewRejected(int previewRejected) { this.previewRejected = previewRejected; }
    public List<Map<String, String>> getPreviewRows() { return previewRows; }
    public void setPreviewRows(List<Map<String, String>> previewRows) { this.previewRows = previewRows; }
    public List<DqIssue> getPreviewIssues() { return previewIssues; }
    public void setPreviewIssues(List<DqIssue> previewIssues) { this.previewIssues = previewIssues; }
}
