package com.bank.ingestion.repository;

import com.bank.ingestion.domain.CanonicalField;
import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.service.CanonicalModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * The single CANONICAL_RECORD table: every provider and format, every load, in the same common columns.
 * PROVIDER_CODE and FILE_FORMAT say where a row came from; LOAD_ID says which version of the list.
 * Source fields without a canonical column are kept as JSON in EXTRA_ATTRS (or EXTRA_ATTRS_CLOB when
 * longer than 4000 bytes), so nothing is lost.
 *
 * The DBA creates the table with db/schema.sql. The application only adds a column when a field is
 * added to canonical-model.json; it never creates tables at runtime.
 */
@Component
public class TargetTableManager {

    public static final String TABLE = "CANONICAL_RECORD";
    public static final String EXTRA_ATTRS = "EXTRA_ATTRS";
    public static final String EXTRA_ATTRS_CLOB = "EXTRA_ATTRS_CLOB";
    public static final int EXTRA_ATTRS_MAX_BYTES = 4000;

    private static final Logger LOG = LoggerFactory.getLogger(TargetTableManager.class);

    private final DataSource dataSource;
    private final JdbcTemplate jdbc;
    private final CanonicalModel model;

    public TargetTableManager(DataSource dataSource, JdbcTemplate jdbc, CanonicalModel model) {
        this.dataSource = dataSource;
        this.jdbc = jdbc;
        this.model = model;
    }

    /** Every provider and format share one table; kept as a method so callers record where rows went. */
    public static String tableName(String providerCode, FileFormat format) {
        return TABLE;
    }

    /** Only the canonical table may ever reach dynamic SQL. */
    public static String requireSafe(String tableName) {
        if (!TABLE.equals(tableName)) {
            throw new IllegalArgumentException("Unexpected target table");
        }
        return tableName;
    }

    /**
     * Checks the table exists and adds columns for canonical fields added to the model since it was created.
     * Creates the table only when it is missing (H2 test profiles); on Oracle the DBA script has created it.
     */
    public synchronized void ensureTable(String tableName) throws SQLException {
        requireSafe(tableName);
        Set<String> existing = existingColumns();
        if (existing.isEmpty()) {
            jdbc.execute(createTableDdl());
            jdbc.execute("CREATE INDEX IX_CANONICAL_RECORD_SRC ON " + TABLE + " (PROVIDER_CODE, SOURCE_RECORD_ID)");
            LOG.info("Created table {}", TABLE);
            return;
        }
        for (CanonicalField f : model.fields()) {
            if (!existing.contains(f.getName())) {
                jdbc.execute("ALTER TABLE " + TABLE + " ADD (" + f.getName() + " VARCHAR2(" + f.columnLength() + " CHAR))");
                LOG.info("Added column {} to {} (new field in canonical-model.json)", f.getName(), TABLE);
            }
        }
    }

    /** Same DDL as db/schema.sql, generated from the model (used when the table is missing). */
    String createTableDdl() {
        StringBuilder ddl = new StringBuilder("CREATE TABLE ").append(TABLE).append(" (")
                .append("LOAD_ID NUMBER(19) NOT NULL, ")
                .append("RECORD_NO NUMBER(19) NOT NULL, ")
                .append("PROVIDER_CODE VARCHAR2(20) NOT NULL, ")
                .append("FILE_FORMAT VARCHAR2(10) NOT NULL, ")
                .append("MAPPING_VERSION NUMBER(10) NOT NULL, ")
                .append("DQ_STATUS VARCHAR2(4) NOT NULL, ");
        for (CanonicalField f : model.fields()) {
            ddl.append(f.getName()).append(" VARCHAR2(").append(f.columnLength()).append(" CHAR), ");
        }
        ddl.append(EXTRA_ATTRS).append(" VARCHAR2(").append(EXTRA_ATTRS_MAX_BYTES).append(" BYTE), ")
                .append(EXTRA_ATTRS_CLOB).append(" CLOB, ")
                .append("CONSTRAINT PK_CANONICAL_RECORD PRIMARY KEY (LOAD_ID, RECORD_NO))");
        return ddl.toString();
    }

    private Set<String> existingColumns() throws SQLException {
        Set<String> cols = new HashSet<>();
        try (Connection con = dataSource.getConnection()) {
            DatabaseMetaData md = con.getMetaData();
            try (ResultSet rs = md.getColumns(null, con.getSchema(), TABLE, null)) {
                while (rs.next()) {
                    cols.add(rs.getString("COLUMN_NAME").toUpperCase(Locale.ROOT));
                }
            }
        }
        return cols;
    }

    /** Canonical field columns, in model order (used by insert, export and the API). */
    public List<String> dataColumns() {
        List<String> cols = new ArrayList<>();
        for (CanonicalField f : model.fields()) {
            cols.add(f.getName());
        }
        return cols;
    }

    public String insertSql(String tableName) {
        requireSafe(tableName);
        StringBuilder cols = new StringBuilder("LOAD_ID, RECORD_NO, PROVIDER_CODE, FILE_FORMAT, MAPPING_VERSION, DQ_STATUS");
        StringBuilder marks = new StringBuilder("?, ?, ?, ?, ?, ?");
        for (CanonicalField f : model.fields()) {
            cols.append(", ").append(f.getName());
            marks.append(", ?");
        }
        cols.append(", ").append(EXTRA_ATTRS).append(", ").append(EXTRA_ATTRS_CLOB);
        marks.append(", ?, ?");
        return "INSERT INTO " + TABLE + " (" + cols + ") VALUES (" + marks + ")";
    }

    public int deleteLoad(String tableName, long loadId) {
        requireSafe(tableName);
        return jdbc.update("DELETE FROM " + TABLE + " WHERE LOAD_ID = ?", loadId);
    }

    public long countLoad(String tableName, long loadId) {
        requireSafe(tableName);
        Long n = jdbc.queryForObject("SELECT COUNT(*) FROM " + TABLE + " WHERE LOAD_ID = ?", Long.class, loadId);
        return n == null ? 0 : n;
    }

    public boolean tableExists(String tableName) throws SQLException {
        requireSafe(tableName);
        return !existingColumns().isEmpty();
    }
}
