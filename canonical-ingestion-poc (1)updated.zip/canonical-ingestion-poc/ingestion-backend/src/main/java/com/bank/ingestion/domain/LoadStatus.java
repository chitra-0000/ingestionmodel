package com.bank.ingestion.domain;

/** Lifecycle of one uploaded file (one load = one version of a provider list). */
public enum LoadStatus {
    STORED,
    ANALYZING,
    MAPPING_REVIEW,
    QUEUED,
    LOADING,
    DQ_CHECKS,
    COMPLETED,
    COMPLETED_WITH_WARNINGS,
    DQ_THRESHOLD_BREACHED,
    FAILED;

    public boolean isRunning() {
        return this == ANALYZING || this == QUEUED || this == LOADING || this == DQ_CHECKS;
    }

    public boolean isPublishable() {
        return this == COMPLETED || this == COMPLETED_WITH_WARNINGS;
    }
}
