package com.bank.ingestion.service;

import com.bank.ingestion.config.AppConfig;
import com.bank.ingestion.config.IngestionProperties;
import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.domain.LoadRun;
import com.bank.ingestion.domain.LoadStatus;
import com.bank.ingestion.domain.MappingDefinition;
import com.bank.ingestion.domain.MappingDraft;
import com.bank.ingestion.domain.MappingRequest;
import com.bank.ingestion.domain.SchemaProfile;
import com.bank.ingestion.domain.ValidationResult;
import com.bank.ingestion.repository.LoadRunRepository;
import com.bank.ingestion.repository.RawFileRepository;
import com.bank.ingestion.repository.TargetTableManager;
import com.bank.ingestion.service.load.LoadProcessor;
import com.bank.ingestion.service.mapping.MappingService;
import com.bank.ingestion.util.ApiException;
import com.bank.ingestion.util.Texts;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.zip.Deflater;
import java.util.zip.GZIPOutputStream;

/**
 * Orchestrates the flow in the diagram: upload -> raw store -> schema -> mapping lookup ->
 * (review/approve) -> transform/load -> DQ. Long steps run on the ingestion executor.
 */
@Service
public class IngestionService {

    private static final Logger LOG = LoggerFactory.getLogger(IngestionService.class);
    private static final int MAX_NAME = 255;
    private static final int COPY_BUFFER = 1 << 16;

    private final IngestionProperties props;
    private final LoadRunRepository loads;
    private final RawFileRepository rawFiles;
    private final SchemaExtractor schemaExtractor;
    private final MappingService mappingService;
    private final LoadProcessor processor;
    private final ProgressRegistry progress;
    private final ObjectMapper json;
    private final Executor executor;

    @SuppressWarnings("squid:S00107") // Spring constructor injection of collaborators
    public IngestionService(IngestionProperties props, LoadRunRepository loads, RawFileRepository rawFiles,
                            SchemaExtractor schemaExtractor, MappingService mappingService, LoadProcessor processor,
                            ProgressRegistry progress, ObjectMapper json,
                            @Qualifier(AppConfig.INGESTION_EXECUTOR) Executor executor) {
        this.props = props;
        this.loads = loads;
        this.rawFiles = rawFiles;
        this.schemaExtractor = schemaExtractor;
        this.mappingService = mappingService;
        this.processor = processor;
        this.progress = progress;
        this.json = json;
        this.executor = executor;
    }

    // ---------------------------------------------------------------- upload

    public LoadRun upload(MultipartFile file, String providerRaw, String uploadedByRaw) throws Exception {
        String provider = Texts.requireProviderCode(providerRaw);
        if (file == null || file.isEmpty()) {
            throw ApiException.badRequest("File is empty");
        }
        String name = safeFileName(file.getOriginalFilename());
        String uploadedBy = Texts.isBlank(uploadedByRaw) ? null : Texts.truncate(Texts.forLog(uploadedByRaw.trim()), 100);
        FileFormat format = detectFormat(file, name);

        long loadId = loads.nextId();
        loads.insert(loadId, provider, format, name, uploadedBy);
        long t0 = System.currentTimeMillis();
        Path workDir = Paths.get(props.getWorkDir()).toAbsolutePath().normalize();
        Files.createDirectories(workDir);
        Path gz = Files.createTempFile(workDir, "load-" + loadId + "-", ".gz");
        try {
            MessageDigest sha = Texts.newSha256();
            long size;
            try (InputStream in = new DigestInputStream(new BufferedInputStream(file.getInputStream(), COPY_BUFFER), sha);
                 OutputStream out = new FastGzipOutputStream(Files.newOutputStream(gz))) {
                size = copy(in, out);
            }
            String hash = Texts.toHex(sha.digest());
            rawFiles.insert(loadId, name, format, size, hash, gz);
            List<Long> same = rawFiles.findEarlierLoadsWithSameContent(provider, hash, loadId);
            String note = same.isEmpty() ? "Stored" : "Stored. Warning: identical content to earlier load(s) " + same;
            loads.markStored(loadId, size, hash, System.currentTimeMillis() - t0, note);
        } catch (IOException | RuntimeException e) {
            loads.markFailed(loadId, "Upload could not be stored", System.currentTimeMillis() - t0);
            throw e;
        } finally {
            Files.deleteIfExists(gz);
        }
        LOG.info("Load {} stored: provider={} format={} file={}", loadId, provider, format, Texts.forLog(name));
        submit(loadId, () -> analyzeAndRoute(loadId));
        return getLoad(loadId);
    }

    private static long copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[COPY_BUFFER];
        long total = 0;
        int n;
        while ((n = in.read(buf)) != -1) {
            out.write(buf, 0, n);
            total += n;
        }
        return total;
    }

    /** Extension and content must agree: XML starts with '<' after an optional BOM and whitespace. */
    private static FileFormat detectFormat(MultipartFile file, String name) throws IOException {
        String lower = name.toLowerCase(Locale.ROOT);
        boolean xmlExt = lower.endsWith(".xml");
        boolean csvExt = lower.endsWith(".csv") || lower.endsWith(".txt");
        if (!xmlExt && !csvExt) {
            throw ApiException.badRequest("Only .xml, .csv or .txt files are accepted");
        }
        boolean looksXml = false;
        try (InputStream in = file.getInputStream()) {
            byte[] head = new byte[512];
            int n = in.read(head);
            for (int i = 0; i < n; i++) {
                int b = head[i] & 0xFF;
                if (b == 0xEF || b == 0xBB || b == 0xBF || Character.isWhitespace(b)) {
                    continue;
                }
                looksXml = b == '<';
                break;
            }
        }
        if (xmlExt && !looksXml) {
            throw ApiException.badRequest("File has an .xml extension but does not contain XML");
        }
        if (csvExt && looksXml) {
            throw ApiException.badRequest("File has a .csv/.txt extension but contains XML");
        }
        return xmlExt ? FileFormat.XML : FileFormat.CSV;
    }

    /** Keep only the last path segment and printable characters (path traversal and log forging). */
    private static String safeFileName(String original) {
        String n = original == null ? "upload" : original;
        n = n.substring(Math.max(n.lastIndexOf('/'), n.lastIndexOf('\\')) + 1);
        n = Texts.forLog(n).trim();
        if (n.isEmpty()) {
            n = "upload";
        }
        return Texts.truncate(n, MAX_NAME);
    }

    // ---------------------------------------------------------------- analyse and route

    void analyzeAndRoute(long loadId) {
        LoadRun run = getLoad(loadId);
        long t0 = System.currentTimeMillis();
        try {
            loads.updateStatus(loadId, LoadStatus.ANALYZING, "Extracting schema and bounded sample");
            SchemaProfile profile = schemaExtractor.extract(loadId, run.getFormat(), null);
            loads.saveSchema(loadId, profile.getFingerprint(), profile.getRecordPath(), json.writeValueAsString(profile),
                    System.currentTimeMillis() - t0);
            route(run, profile);
        } catch (Exception e) {
            LOG.error("Analysis of load {} failed", loadId, e);
            String msg = e instanceof ApiException ? e.getMessage() : "Schema extraction failed: " + LoadProcessor.describe(e);
            loads.markFailed(loadId, msg, System.currentTimeMillis() - t0);
        }
    }

    /** "Approved mapping exists?" Yes: load straight away. No: wait for mapping review. */
    private void route(LoadRun run, SchemaProfile profile) {
        MappingDefinition mapping = mappingService.findApplicable(run.getProviderCode(), run.getFormat(), profile);
        if (mapping == null) {
            loads.updateStatus(run.getLoadId(), LoadStatus.MAPPING_REVIEW,
                    mappingService.reviewReason(run.getProviderCode(), run.getFormat(), profile));
            return;
        }
        loads.assignMapping(run.getLoadId(), mapping.getMappingId(), mapping.getVersionNo(),
                TargetTableManager.tableName(run.getProviderCode(), run.getFormat()));
        loads.updateStatus(run.getLoadId(), LoadStatus.QUEUED, "Using approved mapping v" + mapping.getVersionNo());
        processor.process(run.getLoadId());
    }

    // ---------------------------------------------------------------- mapping review

    public MappingDraft draft(long loadId, String recordPathOverride) throws Exception {
        LoadRun run = requireReview(loadId);
        SchemaProfile profile = schema(loadId);
        if (!Texts.isBlank(recordPathOverride) && run.getFormat() == FileFormat.XML
                && !SchemaExtractor.normaliseRecordPath(recordPathOverride).equals(profile.getRecordPath())) {
            long t0 = System.currentTimeMillis();
            profile = schemaExtractor.extract(loadId, run.getFormat(), recordPathOverride);
            loads.saveSchema(loadId, profile.getFingerprint(), profile.getRecordPath(), json.writeValueAsString(profile),
                    System.currentTimeMillis() - t0);
        }
        return mappingService.draft(run, profile);
    }

    public ValidationResult validate(long loadId, MappingRequest req) throws Exception {
        LoadRun run = requireReview(loadId);
        normalise(req);
        return mappingService.validate(run, schema(loadId), req);
    }

    public ValidationResult approve(long loadId, MappingRequest req) throws Exception {
        LoadRun run = requireReview(loadId);
        normalise(req);
        SchemaProfile profile = schema(loadId);
        ValidationResult validation = mappingService.validate(run, profile, req);
        if (!validation.isValid()) {
            return validation;
        }
        if (!loads.transition(loadId, LoadStatus.MAPPING_REVIEW, LoadStatus.QUEUED, "Mapping approved, queued")) {
            throw ApiException.conflict("Load is no longer waiting for mapping review");
        }
        MappingDefinition m;
        try {
            m = mappingService.approve(run, profile, req, validation);
        } catch (Exception e) {
            loads.updateStatus(loadId, LoadStatus.MAPPING_REVIEW, "Approval failed; please retry");
            throw e;
        }
        LOG.info("Mapping {} v{} approved by {} for load {}", run.getProviderCode(), m.getVersionNo(),
                Texts.forLog(m.getApprovedBy()), loadId);
        loads.assignMapping(loadId, m.getMappingId(), m.getVersionNo(),
                TargetTableManager.tableName(run.getProviderCode(), run.getFormat()));
        loads.updateStatus(loadId, LoadStatus.QUEUED, "Queued with mapping v" + m.getVersionNo());
        submit(loadId, () -> processor.process(loadId));
        recheckWaiting(run.getProviderCode(), run.getFormat(), loadId);
        return validation;
    }

    /** Other files of the same provider waiting for review are loaded automatically if the new version covers them. */
    private void recheckWaiting(String provider, FileFormat format, long approvedLoadId) {
        for (Long other : loads.findWaitingForReview(provider, format)) {
            if (other == approvedLoadId) {
                continue;
            }
            submit(other, () -> {
                try {
                    route(getLoad(other), schema(other));
                } catch (Exception e) {
                    LOG.warn("Re-check of load {} failed: {}", other, e.getMessage());
                }
            });
        }
    }

    private void normalise(MappingRequest req) {
        req.setRecordPath(SchemaExtractor.normaliseRecordPath(req.getRecordPath()));
    }

    private LoadRun requireReview(long loadId) {
        LoadRun run = getLoad(loadId);
        if (run.getStatus() != LoadStatus.MAPPING_REVIEW) {
            throw ApiException.conflict("Load " + loadId + " is " + run.getStatus() + ", not waiting for mapping review");
        }
        return run;
    }

    public SchemaProfile schema(long loadId) throws IOException {
        String raw = loads.findSchemaJson(loadId).orElseThrow(() -> ApiException.notFound("Schema not extracted yet for load " + loadId));
        return json.readValue(raw, SchemaProfile.class);
    }

    // ---------------------------------------------------------------- queries

    public LoadRun getLoad(long loadId) {
        LoadRun run = loads.find(loadId).orElseThrow(() -> ApiException.notFound("Load " + loadId + " not found"));
        ProgressRegistry.Progress p = progress.get(loadId);
        if (p != null) {
            run.setProgressRecords(p.records());
            run.setRecordsPerSecond(p.recordsPerSecond());
        }
        return run;
    }

    public List<LoadRun> recentLoads(int limit) {
        List<LoadRun> list = loads.findRecent(limit);
        for (LoadRun run : list) {
            ProgressRegistry.Progress p = progress.get(run.getLoadId());
            if (p != null) {
                run.setProgressRecords(p.records());
                run.setRecordsPerSecond(p.recordsPerSecond());
            }
        }
        return list;
    }

    private void submit(long loadId, Runnable task) {
        try {
            executor.execute(task);
        } catch (RejectedExecutionException e) {
            loads.markFailed(loadId, "Server busy: too many files queued. Upload again later.", 0);
            throw ApiException.conflict("Too many files are being processed; try again later");
        }
    }

    /** gzip at the fastest level: the raw store must not become the bottleneck for multi-GB files. */
    private static final class FastGzipOutputStream extends GZIPOutputStream {
        FastGzipOutputStream(OutputStream out) throws IOException {
            super(out, COPY_BUFFER);
            def.setLevel(Deflater.BEST_SPEED);
        }
    }
}
