package com.bank.ingestion.service.source;

import java.io.Closeable;

/** Streams records one by one from a decompressed source file. */
public interface RecordReader extends Closeable {

    /** Called for every value in a record, with its path relative to the record. */
    interface ValueVisitor {
        void value(long recordNo, String path, String value);

        /** Called after the last value of a record. */
        default void endRecord(long recordNo) {
        }
    }

    /** @return the next record, or null at end of file */
    RecordData next() throws Exception;

    /** Elements next to the records (same parent, different name) that were not loaded. */
    long skippedSiblingElements();
}
