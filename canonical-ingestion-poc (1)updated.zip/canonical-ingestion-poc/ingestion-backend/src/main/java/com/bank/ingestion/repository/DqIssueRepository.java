package com.bank.ingestion.repository;

import com.bank.ingestion.domain.DqIssue;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Repository
public class DqIssueRepository {

    public static final String INSERT_SQL = "INSERT INTO DQ_ISSUE (LOAD_ID, RECORD_NO, FIELD_NAME, RULE_CODE, SEVERITY, MESSAGE, RAW_VALUE) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?)";

    private static final int MAX_TEXT = 500;

    private final JdbcTemplate jdbc;

    public DqIssueRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** Binds one issue onto the shared insert statement (used by the batch workers). */
    public static void bind(PreparedStatement ps, long loadId, DqIssue i) throws SQLException {
        ps.setLong(1, loadId);
        ps.setLong(2, i.getRecordNo());
        ps.setString(3, cut(i.getField()));
        ps.setString(4, i.getRule());
        ps.setString(5, i.getSeverity().name());
        ps.setString(6, cut(i.getMessage()));
        ps.setString(7, cut(i.getRawValue()));
    }

    public void insertAll(long loadId, List<DqIssue> issues) {
        jdbc.batchUpdate(INSERT_SQL, issues, 1000, (ps, issue) -> bind(ps, loadId, issue));
    }

    public List<DqIssue> findByLoad(long loadId, String severity, int limit) {
        String filter = severity == null ? "" : " AND SEVERITY = ?";
        Object[] args = severity == null ? new Object[]{loadId, limit} : new Object[]{loadId, severity, limit};
        return jdbc.query("SELECT LOAD_ID, RECORD_NO, FIELD_NAME, RULE_CODE, SEVERITY, MESSAGE, RAW_VALUE FROM DQ_ISSUE "
                + "WHERE LOAD_ID = ?" + filter + " ORDER BY RECORD_NO FETCH FIRST ? ROWS ONLY", (rs, n) -> {
            DqIssue i = new DqIssue();
            i.setLoadId(rs.getLong(1));
            i.setRecordNo(rs.getLong(2));
            i.setField(rs.getString(3));
            i.setRule(rs.getString(4));
            i.setSeverity(DqIssue.Severity.valueOf(rs.getString(5)));
            i.setMessage(rs.getString(6));
            i.setRawValue(rs.getString(7));
            return i;
        }, args);
    }

    public int deleteByLoad(long loadId) {
        return jdbc.update("DELETE FROM DQ_ISSUE WHERE LOAD_ID = ?", loadId);
    }

    /** Oracle VARCHAR2 limits are in bytes; keep well under 500 chars of mostly single-byte text. */
    private static String cut(String value) {
        if (value == null || value.length() <= MAX_TEXT / 2) {
            return value;
        }
        return value.substring(0, MAX_TEXT / 2) + "...";
    }
}
