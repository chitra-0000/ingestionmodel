package com.bank.ingestion.service.source;

import com.bank.ingestion.config.XmlSecurity;
import com.bank.ingestion.domain.SchemaProfile;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PushbackInputStream;
import java.io.Reader;
import java.io.StringReader;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Streams a CSV file (UTF-8, optional BOM, header row) and turns each row into a tiny XML document
 * &lt;record&gt;&lt;column&gt;value&lt;/column&gt;...&lt;/record&gt;, so CSV and XML share the same XSLT
 * mapping and data-quality path. Invalid UTF-8 bytes become U+FFFD and are reported by the DQ rules.
 */
public final class CsvRecordReader implements RecordReader {

    public static final String RECORD_ELEMENT = "record";
    public static final String RECORD_PATH = "/records/record";
    public static final String RULE_COLUMN_COUNT = "COLUMN_COUNT";

    private final Reader reader;
    private final CsvParser parser;
    private final List<String> headers;
    private final String[] elementNames;
    private final char delimiter;
    private final PathTrie trie;
    private final ValueVisitor visitor;
    private final boolean buildDocument;
    private final DocumentBuilder builder;
    private long recordNo;

    public CsvRecordReader(InputStream in, Set<String> knownPaths, ValueVisitor visitor, boolean buildDocument) throws IOException {
        this.reader = utf8Reader(in);
        String headerLine = readLine(reader);
        if (headerLine == null || headerLine.trim().isEmpty()) {
            throw new IOException("CSV file has no header row");
        }
        this.delimiter = CsvParser.detectDelimiter(headerLine);
        List<String> parsed = new CsvParser(new StringReader(headerLine), delimiter).next();
        this.headers = parsed == null ? new ArrayList<String>() : parsed;
        this.elementNames = toElementNames(headers);
        this.parser = new CsvParser(reader, delimiter);
        this.trie = new PathTrie(knownPaths);
        this.visitor = visitor;
        this.buildDocument = buildDocument;
        this.builder = buildDocument ? XmlSecurity.newDocumentBuilder() : null;
    }

    private static Reader utf8Reader(InputStream in) throws IOException {
        PushbackInputStream pin = new PushbackInputStream(in, 3);
        byte[] bom = new byte[3];
        int n = pin.read(bom, 0, 3);
        boolean hasBom = n == 3 && (bom[0] & 0xFF) == 0xEF && (bom[1] & 0xFF) == 0xBB && (bom[2] & 0xFF) == 0xBF;
        if (!hasBom && n > 0) {
            pin.unread(bom, 0, n);
        }
        CharsetDecoder decoder = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPLACE)
                .onUnmappableCharacter(CodingErrorAction.REPLACE);
        return new InputStreamReader(pin, decoder);
    }

    /** Header is read character by character so the main parser can continue from the next byte. */
    private static String readLine(Reader r) throws IOException {
        StringBuilder sb = new StringBuilder(256);
        int c;
        while ((c = r.read()) != -1) {
            if (c == '\n') {
                break;
            }
            if (c != '\r') {
                sb.append((char) c);
            }
        }
        return c == -1 && sb.length() == 0 ? null : sb.toString();
    }

    /** Header text to a valid, unique XML element name: "Date of Birth" -> "Date_of_Birth", "1st" -> "_1st". */
    public static String[] toElementNames(List<String> headers) {
        String[] names = new String[headers.size()];
        Set<String> used = new HashSet<>();
        for (int i = 0; i < headers.size(); i++) {
            String h = headers.get(i) == null ? "" : headers.get(i).trim();
            StringBuilder sb = new StringBuilder();
            for (int k = 0; k < h.length(); k++) {
                char c = h.charAt(k);
                boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '.';
                sb.append(ok ? c : '_');
            }
            if (sb.length() == 0) {
                sb.append("column_").append(i + 1);
            }
            char first = sb.charAt(0);
            boolean startOk = (first >= 'a' && first <= 'z') || (first >= 'A' && first <= 'Z') || first == '_';
            if (!startOk) {
                sb.insert(0, '_');
            }
            if (sb.length() >= 3 && sb.substring(0, 3).toLowerCase(Locale.ROOT).equals("xml")) {
                sb.insert(0, '_');
            }
            String name = sb.toString();
            String unique = name;
            int suffix = 2;
            while (!used.add(unique)) {
                unique = name + "_" + suffix++;
            }
            names[i] = unique;
        }
        return names;
    }

    public char delimiter() {
        return delimiter;
    }

    public List<SchemaProfile.CsvColumn> columns() {
        List<SchemaProfile.CsvColumn> cols = new ArrayList<>(headers.size());
        for (int i = 0; i < headers.size(); i++) {
            cols.add(new SchemaProfile.CsvColumn(headers.get(i), elementNames[i]));
        }
        return cols;
    }

    @Override
    public RecordData next() throws IOException {
        List<String> fields = parser.next();
        if (fields == null) {
            return null;
        }
        recordNo++;
        if (fields.size() != headers.size()) {
            return RecordData.rejected(recordNo, RULE_COLUMN_COUNT,
                    "Expected " + headers.size() + " columns but found " + fields.size()
                            + " (near line " + parser.physicalLine() + ")");
        }
        Document doc = null;
        Element root = null;
        if (buildDocument) {
            doc = builder.newDocument();
            doc.setStrictErrorChecking(false);
            root = doc.createElement(RECORD_ELEMENT);
            doc.appendChild(root);
        }
        List<String[]> newValues = null;
        for (int i = 0; i < fields.size(); i++) {
            String value = fields.get(i);
            if (value.isEmpty()) {
                continue;
            }
            String path = elementNames[i];
            if (doc != null) {
                Element el = doc.createElement(path);
                el.appendChild(doc.createTextNode(value));
                root.appendChild(el);
            }
            if (visitor != null) {
                visitor.value(recordNo, path, value);
            }
            if (!trie.isKnown(path)) {
                if (newValues == null) {
                    newValues = new ArrayList<>(2);
                }
                newValues.add(new String[]{path, value});
            }
        }
        if (visitor != null) {
            visitor.endRecord(recordNo);
        }
        return RecordData.of(recordNo, doc, newValues);
    }

    @Override
    public long skippedSiblingElements() {
        return 0;
    }

    @Override
    public void close() throws IOException {
        reader.close();
    }
}
