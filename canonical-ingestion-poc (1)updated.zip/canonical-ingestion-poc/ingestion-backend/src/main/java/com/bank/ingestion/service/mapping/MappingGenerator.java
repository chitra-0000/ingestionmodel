package com.bank.ingestion.service.mapping;

import com.bank.ingestion.domain.FieldMapping;
import com.bank.ingestion.domain.SchemaProfile;

import java.util.List;

/**
 * Suggests canonical field mappings for a new source structure.
 * Today: {@link RuleBasedMappingGenerator}. An AI-backed generator can be added later behind this
 * interface; it would receive only the schema profile (paths and masked samples), never full data.
 */
public interface MappingGenerator {

    String name();

    List<FieldMapping> suggest(SchemaProfile profile);
}
