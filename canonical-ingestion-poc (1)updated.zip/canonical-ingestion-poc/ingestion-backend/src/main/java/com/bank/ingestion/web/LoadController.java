package com.bank.ingestion.web;

import com.bank.ingestion.domain.DqIssue;
import com.bank.ingestion.domain.LoadRun;
import com.bank.ingestion.domain.MappingDraft;
import com.bank.ingestion.domain.MappingRequest;
import com.bank.ingestion.domain.SchemaProfile;
import com.bank.ingestion.domain.ValidationResult;
import com.bank.ingestion.repository.DqIssueRepository;
import com.bank.ingestion.repository.LoadRunRepository;
import com.bank.ingestion.service.IngestionService;
import com.bank.ingestion.service.RecordQueryService;
import com.bank.ingestion.util.ApiException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import javax.validation.Valid;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;

/** Upload, load status, mapping review, DQ issues and exports. */
@RestController
@Validated
@RequestMapping("/api/loads")
public class LoadController {

    private final IngestionService ingestion;
    private final RecordQueryService records;
    private final LoadRunRepository loads;
    private final DqIssueRepository issues;
    private final ObjectMapper json;

    public LoadController(IngestionService ingestion, RecordQueryService records, LoadRunRepository loads,
                          DqIssueRepository issues, ObjectMapper json) {
        this.ingestion = ingestion;
        this.records = records;
        this.loads = loads;
        this.issues = issues;
        this.json = json;
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<LoadRun> upload(@RequestPart("file") MultipartFile file,
                                          @RequestParam("providerCode") String providerCode,
                                          @RequestParam(value = "uploadedBy", required = false) String uploadedBy) throws Exception {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(ingestion.upload(file, providerCode, uploadedBy));
    }

    @GetMapping
    public List<LoadRun> recent(@RequestParam(value = "limit", defaultValue = "50") int limit) {
        return ingestion.recentLoads(limit);
    }

    @GetMapping("/{loadId}")
    public LoadRun get(@PathVariable long loadId) {
        return ingestion.getLoad(loadId);
    }

    @GetMapping("/{loadId}/schema")
    public SchemaProfile schema(@PathVariable long loadId) throws IOException {
        return ingestion.schema(loadId);
    }

    @GetMapping("/{loadId}/dq-profile")
    public JsonNode dqProfile(@PathVariable long loadId) throws IOException {
        String profile = loads.findDqProfileJson(loadId).orElseThrow(() -> ApiException.notFound("No DQ profile yet for load " + loadId));
        return json.readTree(profile);
    }

    @GetMapping("/{loadId}/issues")
    public List<DqIssue> issues(@PathVariable long loadId,
                                @RequestParam(value = "severity", required = false) String severity,
                                @RequestParam(value = "limit", defaultValue = "200") int limit) {
        String sev = severity == null ? null : DqIssue.Severity.valueOf(severity.toUpperCase(Locale.ROOT)).name();
        return issues.findByLoad(loadId, sev, Math.max(1, Math.min(limit, 1000)));
    }

    // ---- mapping review

    @GetMapping("/{loadId}/mapping-draft")
    public MappingDraft draft(@PathVariable long loadId,
                              @RequestParam(value = "recordPath", required = false) String recordPath) throws Exception {
        return ingestion.draft(loadId, recordPath);
    }

    @PostMapping("/{loadId}/mapping/validate")
    public ValidationResult validate(@PathVariable long loadId, @Valid @RequestBody MappingRequest req) throws Exception {
        return ingestion.validate(loadId, req);
    }

    @PostMapping("/{loadId}/mapping/approve")
    public ResponseEntity<ValidationResult> approve(@PathVariable long loadId, @Valid @RequestBody MappingRequest req) throws Exception {
        ValidationResult r = ingestion.approve(loadId, req);
        return r.isValid() ? ResponseEntity.ok(r) : ResponseEntity.unprocessableEntity().body(r);
    }

    // ---- exports ("Generate CSV / XML")

    @GetMapping("/{loadId}/export")
    public ResponseEntity<StreamingResponseBody> export(@PathVariable long loadId,
                                                        @RequestParam(value = "format", defaultValue = "csv") String format) {
        LoadRun run = records.requireExportable(loadId);
        boolean xml = "xml".equalsIgnoreCase(format);
        if (!xml && !"csv".equalsIgnoreCase(format)) {
            throw ApiException.badRequest("format must be csv or xml");
        }
        String fileName = run.getProviderCode() + "_" + run.getFormat() + "_load" + loadId + (xml ? ".xml" : ".csv");
        StreamingResponseBody body = out -> {
            try {
                if (xml) {
                    records.exportXml(run, out);
                } else {
                    records.exportCsv(run, out);
                }
            } catch (javax.xml.stream.XMLStreamException e) {
                throw new IOException("XML export failed", e);
            }
        };
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(fileName, StandardCharsets.UTF_8).build().toString())
                .contentType(xml ? MediaType.APPLICATION_XML : new MediaType("text", "csv", StandardCharsets.UTF_8))
                .body(body);
    }

    @GetMapping("/{loadId}/issues/export")
    public ResponseEntity<StreamingResponseBody> exportIssues(@PathVariable long loadId) {
        ingestion.getLoad(loadId);
        StreamingResponseBody body = out -> records.exportIssuesCsv(loadId, out);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename("dq_issues_load" + loadId + ".csv").build().toString())
                .contentType(new MediaType("text", "csv", StandardCharsets.UTF_8))
                .body(body);
    }
}
