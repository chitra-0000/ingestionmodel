package com.bank.ingestion.service.mapping;

import com.bank.ingestion.service.CanonicalModel;
import org.w3c.dom.Document;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Applies the compiled mapping to one record. One instance per worker thread (Transformer is not thread-safe).
 * The XSLT output is consumed as SAX events straight into arrays: no output XML is ever serialised.
 */
public final class RecordTransformer {

    /** Mapping output for one record. */
    public static final class Output {
        /** Raw canonical values in model order (null = not produced). */
        private final String[] values;
        /** {path, value} pairs for EXTRA_ATTRS. */
        private final List<String[]> extras;

        Output(String[] values, List<String[]> extras) {
            this.values = values;
            this.extras = extras;
        }

        public String[] values() {
            return values;
        }

        public List<String[]> extras() {
            return extras;
        }
    }

    private final Transformer transformer;
    private final Collector collector;

    public RecordTransformer(Templates templates, CanonicalModel model) throws TransformerConfigurationException {
        this.transformer = templates.newTransformer();
        this.collector = new Collector(model);
    }

    public Output transform(Document record) throws TransformerException {
        collector.reset();
        transformer.transform(new DOMSource(record), new SAXResult(collector));
        return new Output(collector.values, collector.extras);
    }

    private static final class Collector extends DefaultHandler {
        private final Map<String, Integer> index = new HashMap<>();
        private final int size;
        private final StringBuilder text = new StringBuilder(128);
        private String[] values;
        private List<String[]> extras;
        private int currentField = -1;
        private String currentExtra;

        Collector(CanonicalModel model) {
            for (int i = 0; i < model.fields().size(); i++) {
                index.put(model.fields().get(i).getName(), i);
            }
            this.size = model.fields().size();
        }

        void reset() {
            values = new String[size];
            extras = new ArrayList<>(8);
            currentField = -1;
            currentExtra = null;
        }

        @Override
        public void startElement(String uri, String localName, String qName, Attributes atts) {
            String name = localName == null || localName.isEmpty() ? qName : localName;
            text.setLength(0);
            if ("f".equals(name)) {
                Integer i = index.get(atts.getValue("n"));
                currentField = i == null ? -1 : i;
            } else if ("x".equals(name)) {
                currentExtra = atts.getValue("p");
            }
        }

        @Override
        public void characters(char[] ch, int start, int length) {
            if (currentField >= 0 || currentExtra != null) {
                text.append(ch, start, length);
            }
        }

        @Override
        public void endElement(String uri, String localName, String qName) {
            String name = localName == null || localName.isEmpty() ? qName : localName;
            if ("f".equals(name)) {
                if (currentField >= 0 && text.length() > 0) {
                    values[currentField] = text.toString();
                }
                currentField = -1;
            } else if ("x".equals(name)) {
                if (currentExtra != null && text.length() > 0) {
                    extras.add(new String[]{currentExtra, text.toString()});
                }
                currentExtra = null;
            }
        }
    }
}
