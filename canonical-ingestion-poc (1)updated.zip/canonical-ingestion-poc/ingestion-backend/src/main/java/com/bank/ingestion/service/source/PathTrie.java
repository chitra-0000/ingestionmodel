package com.bank.ingestion.service.source;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Relative paths inside a record ("Name/FirstName", "@id", "Name/@type") without building strings per element.
 * Each distinct path is built once; afterwards walking a record is one hash lookup per element.
 */
public final class PathTrie {

    /** One node per distinct element path. */
    public static final class Node {
        private final String path;
        private final Map<String, Node> children = new HashMap<>();
        private final Map<String, String> attributePaths = new HashMap<>();
        /** Cached "is this path known to the mapping": 0 = not checked yet, 1 = known, 2 = new. */
        private byte known;

        Node(String path) {
            this.path = path;
        }

        public String path() {
            return path;
        }
    }

    private final Node root = new Node("");
    private final Set<String> knownPaths;

    /** @param knownPaths paths known to the approved mapping, or null when drift detection is not needed */
    public PathTrie(Set<String> knownPaths) {
        this.knownPaths = knownPaths;
    }

    public Node root() {
        return root;
    }

    public Node child(Node parent, String name) {
        Node n = parent.children.get(name);
        if (n == null) {
            n = new Node(parent.path.isEmpty() ? name : parent.path + "/" + name);
            parent.children.put(name, n);
        }
        return n;
    }

    public String attributePath(Node owner, String attributeName) {
        String p = owner.attributePaths.get(attributeName);
        if (p == null) {
            p = owner.path.isEmpty() ? "@" + attributeName : owner.path + "/@" + attributeName;
            owner.attributePaths.put(attributeName, p);
        }
        return p;
    }

    public boolean isKnown(Node node) {
        if (knownPaths == null) {
            return true;
        }
        if (node.known == 0) {
            node.known = knownPaths.contains(node.path) ? (byte) 1 : (byte) 2;
        }
        return node.known == 1;
    }

    public boolean isKnown(String path) {
        return knownPaths == null || knownPaths.contains(path);
    }
}
