package com.bank.ingestion.repository;

import com.bank.ingestion.domain.FieldMapping;
import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.domain.MappingDefinition;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class MappingRepository {

    public static final String STATUS_APPROVED = "APPROVED";

    private static final String COLUMNS = "MAPPING_ID, PROVIDER_CODE, FILE_FORMAT, VERSION_NO, SCHEMA_FINGERPRINT, RECORD_PATH, "
            + "FIELD_MAPPING_JSON, KNOWN_PATHS_JSON, XSLT_CONTENT, CUSTOM_XSLT, STATUS, GENERATED_BY, APPROVED_BY, "
            + "APPROVED_AT, STORE_PATH";

    private static final TypeReference<List<FieldMapping>> FIELD_LIST = new TypeReference<List<FieldMapping>>() { };
    private static final TypeReference<List<String>> STRING_LIST = new TypeReference<List<String>>() { };

    private final JdbcTemplate jdbc;
    private final ObjectMapper json;
    private final RowMapper<MappingDefinition> mapper = this::map;

    public MappingRepository(JdbcTemplate jdbc, ObjectMapper json) {
        this.jdbc = jdbc;
        this.json = json;
    }

    public long nextId() {
        Long id = jdbc.queryForObject("SELECT MAPPING_SEQ.NEXTVAL FROM DUAL", Long.class);
        if (id == null) {
            throw new IllegalStateException("MAPPING_SEQ returned no value");
        }
        return id;
    }

    public int nextVersion(String providerCode, FileFormat format) {
        Integer max = jdbc.queryForObject("SELECT MAX(VERSION_NO) FROM MAPPING_DEFINITION WHERE PROVIDER_CODE = ? AND FILE_FORMAT = ?",
                Integer.class, providerCode, format.name());
        return max == null ? 1 : max + 1;
    }

    public boolean exists(String providerCode, FileFormat format, int version) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM MAPPING_DEFINITION WHERE PROVIDER_CODE = ? AND FILE_FORMAT = ? AND VERSION_NO = ?",
                Integer.class, providerCode, format.name(), version);
        return n != null && n > 0;
    }

    public void insert(MappingDefinition m) {
        jdbc.update("INSERT INTO MAPPING_DEFINITION (" + COLUMNS + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                m.getMappingId(), m.getProviderCode(), m.getFormat().name(), m.getVersionNo(), m.getSchemaFingerprint(),
                m.getRecordPath(), toJson(m.getFieldMappings()), toJson(m.getKnownPaths()), m.getXslt(),
                m.isCustomXslt() ? 1 : 0, m.getStatus(), m.getGeneratedBy(), m.getApprovedBy(), m.getApprovedAt(),
                m.getStorePath());
    }

    /** Older approved versions are retired when a new one is approved: one active mapping per provider + format. */
    public void retireOthers(String providerCode, FileFormat format, long keepMappingId) {
        jdbc.update("UPDATE MAPPING_DEFINITION SET STATUS = 'RETIRED' WHERE PROVIDER_CODE = ? AND FILE_FORMAT = ? "
                + "AND MAPPING_ID <> ? AND STATUS = ?", providerCode, format.name(), keepMappingId, STATUS_APPROVED);
    }

    public Optional<MappingDefinition> findActive(String providerCode, FileFormat format) {
        List<MappingDefinition> rows = jdbc.query("SELECT " + COLUMNS + " FROM MAPPING_DEFINITION WHERE PROVIDER_CODE = ? "
                + "AND FILE_FORMAT = ? AND STATUS = ? ORDER BY VERSION_NO DESC", mapper, providerCode, format.name(), STATUS_APPROVED);
        return rows.isEmpty() ? Optional.<MappingDefinition>empty() : Optional.of(rows.get(0));
    }

    public Optional<MappingDefinition> findById(long mappingId) {
        List<MappingDefinition> rows = jdbc.query("SELECT " + COLUMNS + " FROM MAPPING_DEFINITION WHERE MAPPING_ID = ?", mapper, mappingId);
        return rows.isEmpty() ? Optional.<MappingDefinition>empty() : Optional.of(rows.get(0));
    }

    public List<MappingDefinition> findAll() {
        return jdbc.query("SELECT " + COLUMNS + " FROM MAPPING_DEFINITION ORDER BY PROVIDER_CODE, FILE_FORMAT, VERSION_NO DESC", mapper);
    }

    private String toJson(Object value) {
        try {
            return json.writeValueAsString(value);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Cannot serialise mapping", e);
        }
    }

    private MappingDefinition map(ResultSet rs, int rowNum) throws SQLException {
        MappingDefinition m = new MappingDefinition();
        m.setMappingId(rs.getLong("MAPPING_ID"));
        m.setProviderCode(rs.getString("PROVIDER_CODE"));
        m.setFormat(FileFormat.valueOf(rs.getString("FILE_FORMAT")));
        m.setVersionNo(rs.getInt("VERSION_NO"));
        m.setSchemaFingerprint(rs.getString("SCHEMA_FINGERPRINT"));
        m.setRecordPath(rs.getString("RECORD_PATH"));
        try {
            m.setFieldMappings(json.readValue(rs.getString("FIELD_MAPPING_JSON"), FIELD_LIST));
            m.setKnownPaths(json.readValue(rs.getString("KNOWN_PATHS_JSON"), STRING_LIST));
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Corrupt mapping JSON for mapping " + m.getMappingId(), e);
        }
        m.setXslt(rs.getString("XSLT_CONTENT"));
        m.setCustomXslt(rs.getInt("CUSTOM_XSLT") == 1);
        m.setStatus(rs.getString("STATUS"));
        m.setGeneratedBy(rs.getString("GENERATED_BY"));
        m.setApprovedBy(rs.getString("APPROVED_BY"));
        m.setApprovedAt(rs.getTimestamp("APPROVED_AT"));
        m.setStorePath(rs.getString("STORE_PATH"));
        return m;
    }
}
