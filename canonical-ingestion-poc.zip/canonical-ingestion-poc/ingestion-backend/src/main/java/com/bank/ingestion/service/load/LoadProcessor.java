package com.bank.ingestion.service.load;

import com.bank.ingestion.config.IngestionProperties;
import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.domain.LoadRun;
import com.bank.ingestion.domain.LoadStatus;
import com.bank.ingestion.domain.MappingDefinition;
import com.bank.ingestion.repository.DqIssueRepository;
import com.bank.ingestion.repository.LoadRunRepository;
import com.bank.ingestion.repository.MappingRepository;
import com.bank.ingestion.repository.RawFileRepository;
import com.bank.ingestion.repository.TargetTableManager;
import com.bank.ingestion.service.CanonicalModel;
import com.bank.ingestion.service.ProgressRegistry;
import com.bank.ingestion.service.SchemaExtractor;
import com.bank.ingestion.service.dq.DateNormalizer;
import com.bank.ingestion.service.dq.DqStats;
import com.bank.ingestion.service.dq.RecordValidator;
import com.bank.ingestion.service.mapping.XsltCompiler;
import com.bank.ingestion.service.source.CsvRecordReader;
import com.bank.ingestion.service.source.RecordData;
import com.bank.ingestion.service.source.RecordReader;
import com.bank.ingestion.service.source.XmlRecordReader;
import com.bank.ingestion.util.ApiException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import javax.xml.stream.Location;
import javax.xml.stream.XMLStreamException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * "Transform raw XML from DB" + "Save canonical records" + data-quality checks for one load.
 *
 * <pre>
 *  BLOB -> gunzip -> StAX/CSV reader (1 thread) -> bounded queue -> N workers: XSLT -> DQ -> JDBC batch
 *                                                                   then: duplicates, reconciliation, profile
 * </pre>
 * Memory is bounded by queue capacity x chunk size, independent of file size.
 */
@Service
public class LoadProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(LoadProcessor.class);

    private final IngestionProperties props;
    private final DataSource dataSource;
    private final CanonicalModel model;
    private final RawFileRepository rawFiles;
    private final LoadRunRepository loads;
    private final MappingRepository mappings;
    private final DqIssueRepository issues;
    private final TargetTableManager tables;
    private final XsltCompiler compiler;
    private final DuplicateCheck duplicateCheck;
    private final ProgressRegistry progressRegistry;
    private final ObjectMapper json;
    private final RecordValidator validator;

    @SuppressWarnings("squid:S00107") // Spring constructor injection of collaborators
    public LoadProcessor(IngestionProperties props, DataSource dataSource, CanonicalModel model, RawFileRepository rawFiles,
                         LoadRunRepository loads, MappingRepository mappings, DqIssueRepository issues,
                         TargetTableManager tables, XsltCompiler compiler, DuplicateCheck duplicateCheck,
                         ProgressRegistry progressRegistry, ObjectMapper json) {
        this.props = props;
        this.dataSource = dataSource;
        this.model = model;
        this.rawFiles = rawFiles;
        this.loads = loads;
        this.mappings = mappings;
        this.issues = issues;
        this.tables = tables;
        this.compiler = compiler;
        this.duplicateCheck = duplicateCheck;
        this.progressRegistry = progressRegistry;
        this.json = json;
        this.validator = new RecordValidator(model, new DateNormalizer(props.getSlashDateOrder()));
    }

    public void process(long loadId) {
        long start = System.currentTimeMillis();
        LoadRun run = loads.find(loadId).orElseThrow(() -> new IllegalStateException("Load not found: " + loadId));
        MappingDefinition mapping = run.getMappingId() == null ? null : mappings.findById(run.getMappingId()).orElse(null);
        if (mapping == null) {
            loads.markFailed(loadId, "No approved mapping assigned", 0);
            return;
        }
        String table = TargetTableManager.tableName(run.getProviderCode(), run.getFormat());
        try {
            tables.ensureTable(table);
            loads.updateStatus(loadId, LoadStatus.LOADING, "Transforming with mapping v" + mapping.getVersionNo());
            LoadResult result = transformAndLoad(run, mapping, table);
            loads.updateStatus(loadId, LoadStatus.DQ_CHECKS, "Running set-based data-quality checks");
            finish(run, table, result, start);
        } catch (Exception e) {
            String message = describe(e);
            LOG.error("Load {} failed: {}", loadId, message, e);
            cleanup(table, loadId);
            loads.markFailed(loadId, message, System.currentTimeMillis() - start);
        } finally {
            progressRegistry.finish(loadId);
        }
    }

    /** What the reader and workers produced. */
    private static final class LoadResult {
        private long sourceCount;
        private long skippedSiblings;
        private long transformMs;
        private DqStats stats;
    }

    private LoadResult transformAndLoad(LoadRun run, MappingDefinition mapping, String table) throws Exception {
        long t0 = System.currentTimeMillis();
        XsltCompiler.Result compiled = compiler.compile(mapping.getXslt());
        if (!compiled.ok()) {
            throw ApiException.conflict("Approved mapping v" + mapping.getVersionNo() + " no longer compiles: " + compiled.errors());
        }
        int workers = Math.max(1, props.getWorkers());
        DqStats stats = new DqStats(model, props.getMaxIssueSamplesPerRule());
        LoadContext ctx = new LoadContext(run.getLoadId(), table, mapping.getVersionNo(), compiled.templates(),
                tables.insertSql(table), props.getBatchSize(), stats, progressRegistry.start(run.getLoadId()),
                new ArrayBlockingQueue<List<RecordData>>(workers * 2));

        AtomicInteger threadNo = new AtomicInteger();
        ExecutorService pool = Executors.newFixedThreadPool(workers, r -> {
            Thread t = new Thread(r, "load-" + run.getLoadId() + "-w" + threadNo.incrementAndGet());
            t.setDaemon(true);
            return t;
        });
        List<Future<Void>> futures = new ArrayList<>();
        for (int i = 0; i < workers; i++) {
            futures.add(pool.submit(new LoadWorker(ctx, dataSource, model, validator)));
        }
        LoadResult result = new LoadResult();
        try {
            readInto(run, mapping, ctx, result);
        } catch (Exception e) {
            ctx.fail(e);
        } finally {
            for (int i = 0; i < workers; i++) {
                if (!ctx.offer(LoadContext.POISON)) {
                    break;
                }
            }
            awaitWorkers(pool, futures, ctx);
        }
        if (ctx.failed()) {
            Throwable t = ctx.failure.get();
            throw t instanceof Exception ? (Exception) t : new IllegalStateException(t);
        }
        result.stats = stats;
        result.transformMs = System.currentTimeMillis() - t0;
        return result;
    }

    private void readInto(LoadRun run, MappingDefinition mapping, LoadContext ctx, LoadResult result) throws Exception {
        Set<String> known = new HashSet<>(mapping.getKnownPaths());
        int chunkSize = Math.max(1, props.getQueueChunkSize());
        rawFiles.readContent(run.getLoadId(), stored -> {
            InputStream in = SchemaExtractor.decompress(stored);
            try (RecordReader reader = run.getFormat() == FileFormat.CSV
                    ? new CsvRecordReader(in, known, null, true)
                    : new XmlRecordReader(in, mapping.getRecordPath(), known, null, true)) {
                List<RecordData> chunk = new ArrayList<>(chunkSize);
                RecordData rd;
                while (!ctx.failed() && (rd = reader.next()) != null) {
                    result.sourceCount++;
                    chunk.add(rd);
                    if (chunk.size() == chunkSize) {
                        if (!ctx.offer(chunk)) {
                            break;
                        }
                        chunk = new ArrayList<>(chunkSize);
                    }
                }
                if (!chunk.isEmpty()) {
                    ctx.offer(chunk);
                }
                result.skippedSiblings = reader.skippedSiblingElements();
            }
            return null;
        });
    }

    private static void awaitWorkers(ExecutorService pool, List<Future<Void>> futures, LoadContext ctx) throws InterruptedException {
        for (Future<Void> f : futures) {
            try {
                if (ctx.failed()) {
                    f.get(30, TimeUnit.SECONDS);
                } else {
                    f.get();
                }
            } catch (ExecutionException e) {
                ctx.fail(e.getCause());
            } catch (java.util.concurrent.TimeoutException e) {
                f.cancel(true);
            }
        }
        pool.shutdownNow();
        pool.awaitTermination(30, TimeUnit.SECONDS);
    }

    private void finish(LoadRun run, String table, LoadResult r, long start) throws Exception {
        long dq0 = System.currentTimeMillis();
        long loadId = run.getLoadId();
        long duplicates = duplicateCheck.run(table, loadId, r.stats);
        long inserted = r.stats.loaded();
        long loaded = inserted - duplicates;
        long rejected = r.stats.rejected();
        long inTable = tables.countLoad(table, loadId);
        boolean reconciled = inTable == loaded && loaded + rejected + duplicates == r.sourceCount;

        Map<String, Object> loadLevel = new LinkedHashMap<>();
        loadLevel.put("sourceCount", r.sourceCount);
        loadLevel.put("rowsInTargetTable", inTable);
        loadLevel.put("skippedSiblingElements", r.skippedSiblings);
        List<Long> sameFile = rawFiles.findEarlierLoadsWithSameContent(run.getProviderCode(), run.getSha256(), loadId);
        loadLevel.put("duplicateFileOfLoads", sameFile);
        double rejectPercent = r.sourceCount == 0 ? 0 : (rejected + duplicates) * 100.0 / r.sourceCount;
        loadLevel.put("rejectPercent", Math.round(rejectPercent * 100) / 100.0);
        loadLevel.put("rejectThresholdPercent", props.getMaxRejectPercent());

        run.setSourceCount(r.sourceCount);
        run.setLoadedCount(loaded);
        run.setRejectedCount(rejected);
        run.setDuplicateCount(duplicates);
        run.setWarningCount(r.stats.warned());
        run.setNewPathCount(r.stats.newPathCount());
        run.setReconciled(reconciled);
        run.setTransformMs(r.transformMs);
        decideStatus(run, rejectPercent, r.skippedSiblings, sameFile);
        run.setDqMs(System.currentTimeMillis() - dq0);
        run.setTotalMs(run.getStoreMs() + run.getSchemaMs() + (System.currentTimeMillis() - start));
        loads.saveResult(run, json.writeValueAsString(r.stats.toProfile(loaded, loadLevel)));
        LOG.info("Load {} {}: source={} loaded={} rejected={} duplicates={} in {} ms ({} records/s)", loadId,
                run.getStatus(), r.sourceCount, loaded, rejected, duplicates, r.transformMs,
                r.transformMs == 0 ? 0 : r.sourceCount * 1000 / r.transformMs);
    }

    private void decideStatus(LoadRun run, double rejectPercent, long skippedSiblings, List<Long> sameFile) {
        List<String> notes = new ArrayList<>();
        if (run.getSourceCount() == 0) {
            run.setStatus(LoadStatus.FAILED);
            run.setStatusMessage("The file contains no records at " + run.getRecordPath());
            return;
        }
        if (!Boolean.TRUE.equals(run.getReconciled())) {
            run.setStatus(LoadStatus.FAILED);
            run.setStatusMessage("Reconciliation failed: source, loaded and rejected counts do not add up");
            return;
        }
        if (rejectPercent > props.getMaxRejectPercent()) {
            run.setStatus(LoadStatus.DQ_THRESHOLD_BREACHED);
            run.setStatusMessage(String.format("%.2f%% of records rejected (limit %.2f%%); not publishable until reviewed",
                    rejectPercent, props.getMaxRejectPercent())
                    + (sameFile.isEmpty() ? "" : "; identical to earlier load(s) " + sameFile));
            return;
        }
        if (run.getRejectedCount() + run.getDuplicateCount() > 0) {
            notes.add(String.format("%,d records rejected", run.getRejectedCount() + run.getDuplicateCount()));
        }
        if (run.getWarningCount() > 0) {
            notes.add(String.format("%,d records with warnings", run.getWarningCount()));
        }
        if (run.getNewPathCount() > 0) {
            notes.add(run.getNewPathCount() + " new source fields kept in EXTRA_ATTRS; approve a new mapping version to map them");
        }
        if (skippedSiblings > 0) {
            notes.add(String.format("%,d", skippedSiblings) + " sibling elements of another type were not loaded (check the record path)");
        }
        if (!sameFile.isEmpty()) {
            notes.add("identical to earlier load(s) " + sameFile);
        }
        run.setStatus(notes.isEmpty() ? LoadStatus.COMPLETED : LoadStatus.COMPLETED_WITH_WARNINGS);
        run.setStatusMessage(notes.isEmpty() ? "All records loaded and reconciled" : String.join("; ", notes));
    }

    private void cleanup(String table, long loadId) {
        try {
            if (tables.tableExists(table)) {
                tables.deleteLoad(table, loadId);
            }
            issues.deleteByLoad(loadId);
        } catch (SQLException | RuntimeException e) {
            LOG.warn("Cleanup of failed load {} incomplete: {}", loadId, e.getMessage());
        }
    }

    /** Message safe to show in the UI: what went wrong and where, without stack traces or SQL. */
    public static String describe(Throwable e) {
        Throwable t = e;
        while (t.getCause() != null && !(t instanceof XMLStreamException) && !(t instanceof SQLException)
                && !(t instanceof ApiException)) {
            t = t.getCause();
        }
        if (t instanceof ApiException) {
            return t.getMessage();
        }
        if (t instanceof XMLStreamException) {
            Location l = ((XMLStreamException) t).getLocation();
            return "Malformed XML" + (l == null ? "" : " at line " + l.getLineNumber() + ", column " + l.getColumnNumber())
                    + ". Rows of this load were removed; fix the file and upload again.";
        }
        if (t instanceof SQLException) {
            return "Database error during load (SQLState " + ((SQLException) t).getSQLState() + "). Rows of this load were removed.";
        }
        if (t instanceof java.util.zip.ZipException || t instanceof java.io.EOFException) {
            return "Stored file is corrupt or truncated. Upload the file again.";
        }
        return "Load failed (" + t.getClass().getSimpleName() + "). See server log for load details.";
    }
}
