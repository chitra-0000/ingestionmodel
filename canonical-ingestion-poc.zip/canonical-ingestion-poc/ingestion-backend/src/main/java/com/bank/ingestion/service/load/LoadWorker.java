package com.bank.ingestion.service.load;

import com.bank.ingestion.domain.DqIssue;
import com.bank.ingestion.repository.DqIssueRepository;
import com.bank.ingestion.repository.TargetTableManager;
import com.bank.ingestion.service.CanonicalModel;
import com.bank.ingestion.service.dq.RecordValidator;
import com.bank.ingestion.service.mapping.RecordTransformer;
import com.bank.ingestion.service.source.RecordData;
import com.bank.ingestion.util.Texts;

import javax.sql.DataSource;
import javax.xml.transform.TransformerException;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.concurrent.Callable;

/**
 * One worker thread: takes chunks of records, maps each with the compiled XSLT, applies the DQ rules and
 * writes accepted rows with JDBC batches on its own connection (commit per batch).
 */
final class LoadWorker implements Callable<Void> {

    static final String RULE_TRANSFORM_ERROR = "TRANSFORM_ERROR";
    static final String NEW_PATH_PREFIX = "_new.";
    private static final String STATUS_OK = "OK";
    private static final String STATUS_WARN = "WARN";

    private final LoadContext ctx;
    private final DataSource dataSource;
    private final CanonicalModel model;
    private final RecordValidator validator;
    private final int fieldCount;
    private final StringBuilder json = new StringBuilder(512);

    LoadWorker(LoadContext ctx, DataSource dataSource, CanonicalModel model, RecordValidator validator) {
        this.ctx = ctx;
        this.dataSource = dataSource;
        this.model = model;
        this.validator = validator;
        this.fieldCount = model.fields().size();
    }

    @Override
    public Void call() throws Exception {
        try (Connection con = dataSource.getConnection()) {
            con.setAutoCommit(false);
            try (PreparedStatement insert = con.prepareStatement(ctx.insertSql);
                 PreparedStatement issues = con.prepareStatement(DqIssueRepository.INSERT_SQL)) {
                RecordTransformer transformer = new RecordTransformer(ctx.templates, model);
                Batch batch = new Batch();
                while (true) {
                    List<RecordData> chunk = ctx.queue.take();
                    if (chunk == LoadContext.POISON) {
                        break;
                    }
                    if (ctx.failed()) {
                        continue;
                    }
                    for (RecordData rd : chunk) {
                        handle(rd, transformer, insert, issues, batch);
                        if (batch.rows >= ctx.batchSize) {
                            flush(con, insert, issues, batch);
                        }
                    }
                    ctx.progress.add(chunk.size());
                }
                if (!ctx.failed()) {
                    flush(con, insert, issues, batch);
                }
            } catch (SQLException | RuntimeException e) {
                ctx.fail(e);
                rollbackQuietly(con);
                throw e;
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            ctx.fail(e);
        }
        return null;
    }

    private void handle(RecordData rd, RecordTransformer transformer, PreparedStatement insert,
                        PreparedStatement issues, Batch batch) throws SQLException {
        long recordNo = rd.getRecordNo();
        if (rd.isRejected()) {
            ctx.stats.countRejected();
            addIssue(issues, batch, new DqIssue(recordNo, null, rd.getRejectRule(), DqIssue.Severity.REJECT, rd.getRejectMessage(), null));
            return;
        }
        RecordTransformer.Output out;
        try {
            out = transformer.transform(rd.getDocument());
        } catch (TransformerException e) {
            ctx.stats.countRejected();
            addIssue(issues, batch, new DqIssue(recordNo, null, RULE_TRANSFORM_ERROR, DqIssue.Severity.REJECT,
                    "Mapping failed for this record: " + e.getMessage(), null));
            return;
        }
        RecordValidator.Result v = validator.validate(recordNo, out.values());
        for (DqIssue issue : v.issues()) {
            addIssue(issues, batch, issue);
        }
        if (rd.getNewPathValues() != null) {
            for (String[] pv : rd.getNewPathValues()) {
                ctx.stats.countNewPath(pv[0]);
            }
        }
        if (v.rejected()) {
            ctx.stats.countRejected();
            return;
        }
        bindRow(insert, recordNo, v, out.extras(), rd.getNewPathValues());
        insert.addBatch();
        batch.rows++;
        ctx.stats.countLoaded(v.values(), v.warned());
    }

    private void bindRow(PreparedStatement ps, long recordNo, RecordValidator.Result v, List<String[]> extras,
                         List<String[]> newPathValues) throws SQLException {
        int p = 1;
        ps.setLong(p++, ctx.loadId);
        ps.setLong(p++, recordNo);
        ps.setInt(p++, ctx.mappingVersion);
        ps.setString(p++, v.warned() ? STATUS_WARN : STATUS_OK);
        String[] values = v.values();
        for (int i = 0; i < fieldCount; i++) {
            ps.setString(p++, values[i]);
        }
        String extra = extrasJson(extras, v.originals(), newPathValues);
        if (extra == null) {
            ps.setNull(p++, Types.VARCHAR);
            ps.setNull(p, Types.CLOB);
        } else if (utf8Length(extra) <= TargetTableManager.EXTRA_ATTRS_MAX_BYTES) {
            ps.setString(p++, extra);
            ps.setNull(p, Types.CLOB);
        } else {
            ps.setNull(p++, Types.VARCHAR);
            ps.setCharacterStream(p, new StringReader(extra), extra.length());
        }
    }

    /** {"source/path":"value", "_original.FIELD":"bad value", "_new.path":"value"} or null when empty. */
    private String extrasJson(List<String[]> extras, List<String[]> originals, List<String[]> newPathValues) {
        if (extras.isEmpty() && originals.isEmpty() && (newPathValues == null || newPathValues.isEmpty())) {
            return null;
        }
        json.setLength(0);
        json.append('{');
        appendPairs(extras, "");
        appendPairs(originals, "");
        if (newPathValues != null) {
            appendPairs(newPathValues, NEW_PATH_PREFIX);
        }
        json.append('}');
        return json.toString();
    }

    private void appendPairs(List<String[]> pairs, String prefix) {
        for (String[] kv : pairs) {
            if (json.length() > 1) {
                json.append(',');
            }
            Texts.appendJsonString(json, prefix + kv[0]);
            json.append(':');
            Texts.appendJsonString(json, kv[1]);
        }
    }

    static int utf8Length(String s) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c < 0x80) {
                n++;
            } else if (c < 0x800) {
                n += 2;
            } else if (Character.isHighSurrogate(c)) {
                n += 4;
                i++;
            } else {
                n += 3;
            }
        }
        return n;
    }

    private void addIssue(PreparedStatement ps, Batch batch, DqIssue issue) throws SQLException {
        if (ctx.stats.count(issue)) {
            DqIssueRepository.bind(ps, ctx.loadId, issue);
            ps.addBatch();
            batch.issues++;
        }
    }

    private static void flush(Connection con, PreparedStatement insert, PreparedStatement issues, Batch batch) throws SQLException {
        if (batch.rows > 0) {
            insert.executeBatch();
        }
        if (batch.issues > 0) {
            issues.executeBatch();
        }
        con.commit();
        batch.rows = 0;
        batch.issues = 0;
    }

    private static void rollbackQuietly(Connection con) {
        try {
            con.rollback();
        } catch (SQLException ignored) {
            // The load is already failing; its committed rows are removed by the processor's cleanup.
        }
    }

    private static final class Batch {
        private int rows;
        private int issues;
    }
}
