package com.bank.ingestion.repository;

import com.bank.ingestion.domain.CanonicalField;
import com.bank.ingestion.domain.FileFormat;
import com.bank.ingestion.service.CanonicalModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * One target table per provider + format: REC_<PROVIDER>_<FORMAT>, created the first time that pair arrives.
 * Every table has the same canonical columns, so CANONICAL_RECORD views / unions are trivial and the
 * common record object stays the same across providers. Source fields without a canonical column are
 * kept as JSON in EXTRA_ATTRS (or EXTRA_ATTRS_CLOB when longer than 4000 bytes), so nothing is lost.
 */
@Component
public class TargetTableManager {

    public static final String EXTRA_ATTRS = "EXTRA_ATTRS";
    public static final String EXTRA_ATTRS_CLOB = "EXTRA_ATTRS_CLOB";
    public static final int EXTRA_ATTRS_MAX_BYTES = 4000;

    private static final Logger LOG = LoggerFactory.getLogger(TargetTableManager.class);
    private static final Pattern TABLE_NAME = Pattern.compile("^REC_[A-Z][A-Z0-9_]{1,19}_(XML|CSV)$");

    private final DataSource dataSource;
    private final JdbcTemplate jdbc;
    private final CanonicalModel model;

    public TargetTableManager(DataSource dataSource, JdbcTemplate jdbc, CanonicalModel model) {
        this.dataSource = dataSource;
        this.jdbc = jdbc;
        this.model = model;
    }

    /** Provider code is already whitelisted; the name is checked again before it reaches any SQL. */
    public static String tableName(String providerCode, FileFormat format) {
        String name = "REC_" + providerCode + "_" + format.name();
        return requireSafe(name);
    }

    public static String requireSafe(String tableName) {
        if (tableName == null || !TABLE_NAME.matcher(tableName).matches()) {
            throw new IllegalArgumentException("Unsafe target table name");
        }
        return tableName;
    }

    /** Creates the table if missing, and adds columns for canonical fields added to the model since. */
    public synchronized void ensureTable(String tableName) throws SQLException {
        requireSafe(tableName);
        Set<String> existing = existingColumns(tableName);
        if (existing.isEmpty()) {
            jdbc.execute(createTableDdl(tableName));
            LOG.info("Created target table {}", tableName);
            return;
        }
        for (CanonicalField f : model.fields()) {
            if (!existing.contains(f.getName())) {
                jdbc.execute("ALTER TABLE " + tableName + " ADD (" + f.getName() + " VARCHAR2(" + f.columnLength() + " CHAR))");
                LOG.info("Added column {} to {}", f.getName(), tableName);
            }
        }
    }

    private String createTableDdl(String tableName) {
        StringBuilder ddl = new StringBuilder("CREATE TABLE ").append(tableName).append(" (")
                .append("LOAD_ID NUMBER(19) NOT NULL, ")
                .append("RECORD_NO NUMBER(19) NOT NULL, ")
                .append("MAPPING_VERSION NUMBER(10) NOT NULL, ")
                .append("DQ_STATUS VARCHAR2(4) NOT NULL, ");
        for (CanonicalField f : model.fields()) {
            ddl.append(f.getName()).append(" VARCHAR2(").append(f.columnLength()).append(" CHAR), ");
        }
        ddl.append(EXTRA_ATTRS).append(" VARCHAR2(").append(EXTRA_ATTRS_MAX_BYTES).append(" BYTE), ")
                .append(EXTRA_ATTRS_CLOB).append(" CLOB, ")
                .append("CONSTRAINT PK_").append(tableName).append(" PRIMARY KEY (LOAD_ID, RECORD_NO))");
        return ddl.toString();
    }

    private Set<String> existingColumns(String tableName) throws SQLException {
        Set<String> cols = new HashSet<>();
        try (Connection con = dataSource.getConnection()) {
            DatabaseMetaData md = con.getMetaData();
            try (ResultSet rs = md.getColumns(null, con.getSchema(), tableName, null)) {
                while (rs.next()) {
                    cols.add(rs.getString("COLUMN_NAME").toUpperCase(Locale.ROOT));
                }
            }
        }
        return cols;
    }

    /** Column order used by the insert statement and by export. */
    public List<String> dataColumns() {
        List<String> cols = new ArrayList<>();
        for (CanonicalField f : model.fields()) {
            cols.add(f.getName());
        }
        return cols;
    }

    public String insertSql(String tableName) {
        requireSafe(tableName);
        StringBuilder cols = new StringBuilder("LOAD_ID, RECORD_NO, MAPPING_VERSION, DQ_STATUS");
        StringBuilder marks = new StringBuilder("?, ?, ?, ?");
        for (CanonicalField f : model.fields()) {
            cols.append(", ").append(f.getName());
            marks.append(", ?");
        }
        cols.append(", ").append(EXTRA_ATTRS).append(", ").append(EXTRA_ATTRS_CLOB);
        marks.append(", ?, ?");
        return "INSERT INTO " + tableName + " (" + cols + ") VALUES (" + marks + ")";
    }

    public int deleteLoad(String tableName, long loadId) {
        requireSafe(tableName);
        return jdbc.update("DELETE FROM " + tableName + " WHERE LOAD_ID = ?", loadId);
    }

    public long countLoad(String tableName, long loadId) {
        requireSafe(tableName);
        Long n = jdbc.queryForObject("SELECT COUNT(*) FROM " + tableName + " WHERE LOAD_ID = ?", Long.class, loadId);
        return n == null ? 0 : n;
    }

    public boolean tableExists(String tableName) throws SQLException {
        return !existingColumns(requireSafe(tableName)).isEmpty();
    }
}
