-- Canonical ingestion POC: fixed tables.
-- Runs unchanged on H2 (MODE=Oracle) and Oracle 19c. On Oracle, a DBA runs it once in the app schema.
-- Per provider + format target tables (REC_<PROVIDER>_<FORMAT>) are created at runtime by the application.

CREATE SEQUENCE LOAD_SEQ START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE MAPPING_SEQ START WITH 1 INCREMENT BY 1 NOCACHE;

-- One row per uploaded file: the original bytes, gzip-compressed, kept for the retention period.
CREATE TABLE RAW_FILE (
    LOAD_ID             NUMBER(19)          NOT NULL,
    ORIGINAL_NAME       VARCHAR2(255 CHAR),
    FILE_FORMAT         VARCHAR2(10)        NOT NULL,
    SIZE_BYTES          NUMBER(19)          NOT NULL,
    COMPRESSED_BYTES    NUMBER(19)          NOT NULL,
    SHA256              VARCHAR2(64)        NOT NULL,
    CONTENT_GZIP        BLOB                NOT NULL,
    CREATED_AT          TIMESTAMP           NOT NULL,
    CONSTRAINT PK_RAW_FILE PRIMARY KEY (LOAD_ID)
);

-- One row per load (= one version of a provider list) with status, counts, timings and DQ profile.
CREATE TABLE LOAD_RUN (
    LOAD_ID             NUMBER(19)          NOT NULL,
    PROVIDER_CODE       VARCHAR2(20)        NOT NULL,
    FILE_FORMAT         VARCHAR2(10)        NOT NULL,
    ORIGINAL_NAME       VARCHAR2(255 CHAR),
    UPLOADED_BY         VARCHAR2(100 CHAR),
    STATUS              VARCHAR2(30)        NOT NULL,
    STATUS_MESSAGE      VARCHAR2(1000 CHAR),
    SIZE_BYTES          NUMBER(19),
    SHA256              VARCHAR2(64),
    SCHEMA_FINGERPRINT  VARCHAR2(64),
    RECORD_PATH         VARCHAR2(500 CHAR),
    SCHEMA_JSON         CLOB,
    MAPPING_ID          NUMBER(19),
    MAPPING_VERSION     NUMBER(10),
    TARGET_TABLE        VARCHAR2(30),
    SOURCE_COUNT        NUMBER(19)          DEFAULT 0,
    LOADED_COUNT        NUMBER(19)          DEFAULT 0,
    REJECTED_COUNT      NUMBER(19)          DEFAULT 0,
    DUPLICATE_COUNT     NUMBER(19)          DEFAULT 0,
    WARNING_COUNT       NUMBER(19)          DEFAULT 0,
    NEW_PATH_COUNT      NUMBER(19)          DEFAULT 0,
    RECONCILED          NUMBER(1),
    DQ_PROFILE_JSON     CLOB,
    STORE_MS            NUMBER(19)          DEFAULT 0,
    SCHEMA_MS           NUMBER(19)          DEFAULT 0,
    TRANSFORM_MS        NUMBER(19)          DEFAULT 0,
    DQ_MS               NUMBER(19)          DEFAULT 0,
    TOTAL_MS            NUMBER(19)          DEFAULT 0,
    CREATED_AT          TIMESTAMP           NOT NULL,
    FINISHED_AT         TIMESTAMP,
    CONSTRAINT PK_LOAD_RUN PRIMARY KEY (LOAD_ID)
);
CREATE INDEX IX_LOAD_RUN_PROVIDER ON LOAD_RUN (PROVIDER_CODE, FILE_FORMAT, STATUS);

-- Approved, versioned mappings. The same content is also written to the mapping-store folder.
CREATE TABLE MAPPING_DEFINITION (
    MAPPING_ID          NUMBER(19)          NOT NULL,
    PROVIDER_CODE       VARCHAR2(20)        NOT NULL,
    FILE_FORMAT         VARCHAR2(10)        NOT NULL,
    VERSION_NO          NUMBER(10)          NOT NULL,
    SCHEMA_FINGERPRINT  VARCHAR2(64)        NOT NULL,
    RECORD_PATH         VARCHAR2(500 CHAR)  NOT NULL,
    FIELD_MAPPING_JSON  CLOB                NOT NULL,
    KNOWN_PATHS_JSON    CLOB                NOT NULL,
    XSLT_CONTENT        CLOB                NOT NULL,
    CUSTOM_XSLT         NUMBER(1)           DEFAULT 0 NOT NULL,
    STATUS              VARCHAR2(20)        NOT NULL,
    GENERATED_BY        VARCHAR2(30)        NOT NULL,
    APPROVED_BY         VARCHAR2(100 CHAR)  NOT NULL,
    APPROVED_AT         TIMESTAMP           NOT NULL,
    STORE_PATH          VARCHAR2(500 CHAR),
    CONSTRAINT PK_MAPPING_DEFINITION PRIMARY KEY (MAPPING_ID),
    CONSTRAINT UQ_MAPPING_VERSION UNIQUE (PROVIDER_CODE, FILE_FORMAT, VERSION_NO)
);

-- Data-quality findings. Every finding is counted in LOAD_RUN.DQ_PROFILE_JSON; detail rows are capped per rule.
CREATE TABLE DQ_ISSUE (
    LOAD_ID             NUMBER(19)          NOT NULL,
    RECORD_NO           NUMBER(19)          NOT NULL,
    FIELD_NAME          VARCHAR2(500 CHAR),
    RULE_CODE           VARCHAR2(40)        NOT NULL,
    SEVERITY            VARCHAR2(10)        NOT NULL,
    MESSAGE             VARCHAR2(500 CHAR),
    RAW_VALUE           VARCHAR2(500 CHAR)
);
CREATE INDEX IX_DQ_ISSUE_LOAD ON DQ_ISSUE (LOAD_ID, RECORD_NO);
